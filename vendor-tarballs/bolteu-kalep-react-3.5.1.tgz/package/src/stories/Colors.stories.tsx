import * as React from "react";

import cx from "clsx";

import {Link, Typography} from "..";

// import colors from "@bolteu/kalep-tailwind/plugin/colors.json";
export default {
    title: "Tokens/Colors",
    tags: ["autodocs"],
};

const semanticTokens = {
    layer: ["floor-0", "floor-0-grouped", "floor-1", "floor-2", "floor-3", "surface", "surface-inner-shadow"],
    content: [
        "primary",
        "secondary",
        "tertiary",
        "action-primary",
        "action-secondary",
        "danger-primary",
        "danger-secondary",
        "warning-primary",
        "warning-secondary",
        "positive-primary",
        "positive-secondary",
        "promo-primary",
        "promo-secondary",
        "link-primary",
        "link-secondary",
        "active-link-primary",
        "primary-inverted",
    ],
    bg: [
        "neutral-primary",
        "neutral-secondary",
        "neutral-secondary-hard",
        "action-primary",
        "action-secondary",
        "danger-primary",
        "danger-secondary",
        "warning-primary",
        "warning-secondary",
        "positive-primary",
        "positive-secondary",
        "promo-primary",
        "promo-secondary",
    ],
    special: ["bg-disabled", "bg-zebra", "nulled", "scrim"],
    border: [
        "separator",
        "neutral-primary",
        "neutral-secondary",
        "action-primary",
        "action-secondary",
        "danger-primary",
        "danger-secondary",
        "warning-primary",
        "warning-secondary",
        "positive-primary",
        "positive-secondary",
        "promo-primary",
        "promo-secondary",
    ],
    "bg-active": [
        "neutral-primary",
        "neutral-secondary",
        "neutral-secondary-hard",
        "action-primary",
        "action-secondary",
        "danger-primary",
        "danger-secondary",
        "warning-primary",
        "warning-secondary",
        "positive-primary",
        "positive-secondary",
        "promo-primary",
        "promo-secondary",
    ],
    "border-active": ["neutral-secondary", "action-primary", "danger-primary"],
} as const;

const groups = {
    content: {name: "Content", description: "For text, icons and other small graphic elements."},
    layer: {
        name: "Layer",
        description:
            "Layers are similar to the floors of your building — they affect the overall structure of a screen.",
    },
    bg: {
        name: "Background",
        description:
            "Background of any small component such as button, banner, input, status or something similar to them. In general, some element on top of which you place icon and/or text.",
    },
    "bg-active": {name: "Background (active)", description: "For hover and pressed states of backgrounds"},
    border: {name: "Border", description: "For separators, borders and lines inside components"},
    "border-active": {name: "Border (active)", description: "For hover and pressed states of borders"},
    special: {name: "Special"},
};

const copy = (value: string) => {
    navigator.clipboard.writeText(value);
};
const CopyVisual = ({className}) => {
    return (
        <svg width="14px" height="14px" className={`
          shrink-0 text-tertiary
          ${className}
        `}>
            <use href="#copy-icon" />
        </svg>
    );
};

const CopyableCode = ({group, name, onCopy}) => {
    const twClassNames = getTWClassName(group, name);

    return (
        <div className="grid gap-2">
            <div
                className={`
                  group flex justify-between
                  hover:cursor-pointer
                `}
                onClick={() => onCopy(`var(--color-${group}-${name})`)}
            >
                <Typography variant="caption-secondary">
                    <code>{`--color-${group}-${name}`}</code>
                </Typography>
                <CopyVisual className="group-hover:text-primary" />
            </div>
            {twClassNames.map((twClassName: string) => (
                <div className={`
                  group flex justify-between
                  hover:cursor-pointer
                `} onClick={() => onCopy(twClassName)}>
                    <Typography variant="caption-secondary">
                        <svg width="1rem" height="0.5rem" className="-ml-1 mr-1 opacity-70">
                            <use href="#tw-logo-graphic" />
                        </svg>
                        <code>{twClassName}</code>
                    </Typography>
                    <CopyVisual className="group-hover:text-primary" />
                </div>
            ))}
        </div>
    );
};

const Block = ({group, color, name}) => {
    const value = getComputedStyle(document.documentElement).getPropertyValue(`--color-${color}`).trim();

    const [copied, setCopied] = React.useState(false);

    React.useEffect(() => {
        if (copied) {
            const timeout = setTimeout(() => {
                setCopied(false);
            }, 2000);

            return () => clearTimeout(timeout);
        }
        return () => {};
    }, [copied]);

    const onCopy = React.useCallback(
        (passedValue) => {
            copy(passedValue || value);
            setCopied(true);
        },
        [value],
    );

    return (
        <div
            className={cx(
                "relative w-60 overflow-hidden rounded-lg shadow-md",
                name.endsWith("primary") && "col-start-1",
                name.endsWith("secondary") && "col-start-2",
            )}
        >
            <div className="grid h-[8.75rem] w-60">
                <div
                    style={{
                        zIndex: 1,
                        gridRow: 1,
                        gridColumn: 1,
                        backgroundBlendMode: "exclusion",
                        opacity: 0.12,
                        backgroundImage:
                            "repeating-linear-gradient(#000 0, #000 10px, #fff 10px, #fff 20px), repeating-linear-gradient(90deg, #000 0, #000 10px, #fff 10px, #fff 20px)",
                    }}
                />
                <div
                    className="group relative overflow-hidden"
                    style={{
                        zIndex: 2,
                        gridRow: 1,
                        gridColumn: 1,
                        background: `linear-gradient(var(--color-${color}), var(--color-${color})), linear-gradient(120deg, transparent 40%, var(--color-layer-floor-1) 40%)`,
                    }}
                >
                    <span
                        className={`
                          group/value absolute bottom-3 right-3 inline-flex translate-y-8 cursor-pointer items-center
                          gap-2 rounded bg-layer-floor-3 p-1 text-xs opacity-0 shadow transition-all
                          group-hover:translate-y-0 group-hover:opacity-100
                        `}
                        onClick={onCopy}
                    >
                        <code>{value}</code>
                        <CopyVisual className="group-hover/value:text-primary" />
                    </span>
                </div>
            </div>
            <div
                className={cx(
                    "pointer-events-none absolute top-0 z-10 h-[8.75rem] w-full bg-layer-floor-2",
                    "flex flex-col items-center justify-center gap-4",
                    "transition-opacity duration-500",
                    copied ? "opacity-90" : "opacity-0",
                )}
            >
                <svg width="2rem" height="2rem" className="text-positive-primary">
                    <use href="#check-icon" />
                </svg>
                <Typography>Copied!</Typography>
            </div>
            <div className="grid gap-3 bg-layer-floor-2 p-4 pt-2" style={{color: `var(--color-${color})`}}>
                <Typography fontWeight="semibold">{name}</Typography>

                <CopyableCode group={group} name={name} onCopy={onCopy} />
            </div>
        </div>
    );
};

function getTWClassName(group: string, name: string): string[] {
    switch (group) {
        case "content":
            return [`text-${name}`];
        case "content-active":
            return [`text-active-${name}`];
        case "layer":
            return [`bg-layer-${name}`];
        case "bg":
            return [`bg-${name}`];
        case "bg-active":
            return [`bg-active-${name}`];
        case "border":
            return [`border-${name}`];
        case "border-active":
            return [`border-active-${name}`];
        case "special":
            switch (name) {
                case "bg-disabled":
                    return ["bg-special-disabled"];
                case "bg-zebra":
                    return ["bg-special-zebra"];
                case "nulled":
                    return ["bg-special-nulled", "border-special-nulled"];
                case "scrim":
                    return ["bg-special-scrim"];
                default:
                    return [name];
            }
        default:
            return [name];
    }
}

export const Default = () => {
    return (
        <div>
            <svg style={{display: "none"}}>
                <defs>
                    <symbol id="tw-logo-graphic" viewBox="0 0 54 33">
                        <g clipPath="url(#prefix__clip0)">
                            <path
                                fill="#38bdf8"
                                fillRule="evenodd"
                                d="M27 0c-7.2 0-11.7 3.6-13.5 10.8 2.7-3.6 5.85-4.95 9.45-4.05 2.054.513 3.522 2.004 5.147 3.653C30.744 13.09 33.808 16.2 40.5 16.2c7.2 0 11.7-3.6 13.5-10.8-2.7 3.6-5.85 4.95-9.45 4.05-2.054-.513-3.522-2.004-5.147-3.653C36.756 3.11 33.692 0 27 0zM13.5 16.2C6.3 16.2 1.8 19.8 0 27c2.7-3.6 5.85-4.95 9.45-4.05 2.054.514 3.522 2.004 5.147 3.653C17.244 29.29 20.308 32.4 27 32.4c7.2 0 11.7-3.6 13.5-10.8-2.7 3.6-5.85 4.95-9.45 4.05-2.054-.513-3.522-2.004-5.147-3.653C23.256 19.31 20.192 16.2 13.5 16.2z"
                                clipRule="evenodd"
                            />
                        </g>
                    </symbol>
                    <symbol id="copy-icon" viewBox="0 0 24 24">
                        <path
                            d="M8 2C7.44772 2 7 2.44772 7 3C7 3.55228 7.44772 4 8 4H17C18.6569 4 20 5.34315 20 7V16C20 16.5523 20.4477 17 21 17C21.5523 17 22 16.5523 22 16V7C22 4.23858 19.7614 2 17 2H8Z"
                            fill="currentColor"
                        />
                        <path
                            fillRule="evenodd"
                            clipRule="evenodd"
                            d="M2 8C2 6.89543 2.89543 6 4 6H16C17.1046 6 18 6.89543 18 8V20C18 21.1046 17.1046 22 16 22H4C2.89543 22 2 21.1046 2 20V8ZM16 8H4V20H16V8Z"
                            fill="currentColor"
                        />
                    </symbol>
                    <symbol id="check-icon" viewBox="0 0 24 24">
                        <path
                            d="M5.70928 11.6707C5.31774 11.2791 4.68353 11.2786 4.29272 11.6694C3.90191 12.0602 3.9025 12.6944 4.29404 13.0859L7.9454 16.7373C8.72847 17.5204 9.9969 17.5215 10.7785 16.7399L19.8078 7.71059C20.1987 7.31979 20.1981 6.68557 19.8065 6.29404C19.415 5.9025 18.7808 5.90191 18.39 6.29272L9.36064 15.322L5.70928 11.6707Z"
                            fill="currentColor"
                        />
                    </symbol>
                    <clipPath id="prefix__clip0">
                        <path fill="#fff" d="M0 0h54v32.4H0z" />
                    </clipPath>
                </defs>
            </svg>

            <Typography variant="page-title">Semantic colors</Typography>
            <p>
                <Link href="https://www.figma.com/file/FyunMfHadOfBfKXvCJYMJD/%F0%9F%8C%88-Functional-Colors?type=design&node-id=324-11264&mode=design&t=B64UZPkRI1yXb1lp-0">
                    Semantic colors ultimate guide in Figma
                </Link>
                <br />
                <Link href="https://taxify.atlassian.net/wiki/spaces/DS/pages/4183917676/News+from+Design+System+-+Nov+22">
                    News from Design System - Nov 2022 (introducing semantic colors)
                </Link>
            </p>

            <ComponentGroup group="content" />
            <ComponentGroup group="layer" />
            <ComponentGroup group="bg" />
            <ComponentGroup group="bg-active" />
            <ComponentGroup group="border" />
            <ComponentGroup group="border-active" />
            <ComponentGroup group="special" />
        </div>
    );
};

function ComponentGroup({group}) {
    return (
        <div key={group}>
            <Typography variant="title-secondary">{groups[group].name}</Typography>
            {groups[group].description && <Typography>{groups[group].description}</Typography>}

            <div className="my-4 flex flex-wrap gap-4">
                {semanticTokens[group].map((name) => (
                    <Block key={name} group={group} color={`${group}-${name}`} name={name} />
                ))}
            </div>
        </div>
    );
}
