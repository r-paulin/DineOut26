import * as React from "react";

import {Button} from "@/components/Button";
import {Grid} from "@/components/Layout";
import {Typography, TypographyStack} from "@/components/Typography";

import "./languageTests.css";

export default {
    title: "Tests/Languages",
    tags: ["autodocs"],
};

const writtenScriptTestData = {
    zh: {
        scriptName: "Traditional Chinese",
        strings: {
            addHomeAddress: "新增家庭地址",
            tagline: "Bolt 是多功能的移動應用程式。",
        },
    },
    ar: {
        scriptName: "Arabic",
        strings: {
            addHomeAddress: "إضافة عنوان المنزل",
            tagline: "Bolt هو تطبيق التنقُّل المتكامل.",
        },
    },
    ge: {
        scriptName: "Georgian",
        strings: {
            addHomeAddress: "სახლის მისამართის დამატება",
            tagline: "Bolt - ყველაფერი ერთ აპლიკაციაში.",
        },
    },
    th: {
        scriptName: "Thai",
        strings: {
            addHomeAddress: "เพิ่มที่อยู่บ้าน",
            tagline: "Bolt คือแอปพลิเคชันการเดินทางแบบครบวงจร.",
        },
    },
    ua: {
        scriptName: "Ukrainian",
        strings: {
            addHomeAddress: "Додати домашню адресу",
            tagline: "Bolt – це універсальний мобільний додаток.",
        },
    },
    vi: {
        scriptName: "Vietnamese",
        strings: {
            addHomeAddress: "Thêm địa chỉ nhà riêng",
            tagline: "Bolt là ứng dụng di chuyển đa dịch vụ.",
        },
    },
    hy: {
        scriptName: "Armenian",
        strings: {
            addHomeAddress: "Ավելացնել տան հասցեն",
            tagline: "Bolt-ը շարժունակության բոլորը մեկ հավելված է:",
        },
    },
    el: {
        scriptName: "Greek",
        strings: {
            addHomeAddress: "Προσθήκη διεύθυνσης σπιτιού",
            tagline: "Η Bolt είναι η απόλυτη εφαρμογή για μετακινήσεις.",
        },
    },
};

const allTaglines = Object.values(writtenScriptTestData)
    .map((langData) => langData.strings.tagline)
    .join(" ");

export const Languages = () => {
    const [fontAntialiased, setFontAntialiased] = React.useState(true);
    const [fontForceFullStyle, setFontForceFullStyle] = React.useState(false);
    const [fontUseUIVersions, setFontUseUIVersions] = React.useState(false);
    const [tableHovered, setTableHovered] = React.useState(false);

    const rows = Object.entries(writtenScriptTestData).map(([, langData]) => {
        return (
            <tr>
                <td>{langData.scriptName}</td>
                <td>{langData.strings.addHomeAddress}</td>
                <td>{langData.strings.tagline}</td>
            </tr>
        );
    });

    let tableFallbacks = "";
    if (tableHovered) {
        tableFallbacks = fontUseUIVersions ? "with-fallbacks-ui" : "with-fallbacks";
    }

    return (
        <div
            className={`
              ${fontAntialiased ? "smoothing-antialiased" : "smoothing-auto"}
              ${
                fontForceFullStyle ? "font-body-m-regular" : ""
            }
            `}
        >
            <link
                href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@400..700&display=swap"
                rel="stylesheet"
            />
            <Grid>
                <div className="flex gap-4">
                    <label>
                        <input
                            type="checkbox"
                            checked={fontAntialiased}
                            onChange={() => setFontAntialiased(!fontAntialiased)}
                        />
                        -webkit-font-smoothing: antialiased;
                    </label>
                    <label>
                        <input
                            type="checkbox"
                            checked={fontForceFullStyle}
                            onChange={() => setFontForceFullStyle(!fontForceFullStyle)}
                        />
                        Enforce line-height on the default text style
                    </label>
                    <label>
                        <input
                            type="checkbox"
                            checked={fontUseUIVersions}
                            onChange={() => setFontUseUIVersions(!fontUseUIVersions)}
                        />
                        Use UI version of Noto Sans Arabic
                    </label>
                </div>

                <hr className="w-full" />

                <Typography variant="body-s-regular">
                    Hover to swap to version with Noto Sans typefaces as fallbacks
                </Typography>

                <table
                    onMouseOver={() => setTableHovered(true)}
                    onFocus={() => setTableHovered(true)}
                    onMouseOut={() => setTableHovered(false)}
                    onBlur={() => setTableHovered(false)}
                    tabIndex={0}
                    className={tableFallbacks}
                >
                    <tbody>{rows}</tbody>
                </table>

                <hr className="w-full" />

                <Grid columns={2} gap={2}>
                    <TypographyStack
                        primary="No specialised fallbacks"
                        secondary="font-family: InterVariable, sans-serif;"
                    />
                    <TypographyStack
                        primary="Fall back to Noto Sans typefaces"
                        secondary={`font-family: InterVariable, "Noto Sans Arabic${
                            fontUseUIVersions ? " UI" : ""
                        }", "Noto Sans Thai", "Noto Sans Georgian", "Noto Sans TC",
        sans-serif;`}
                    />
                    <p className="no-fallbacks mt-0">{allTaglines}</p>
                    <p className={`
                      ${fontUseUIVersions ? "with-fallbacks-ui" : "with-fallbacks"}
                      mt-0
                    `}>
                        {allTaglines}
                    </p>
                </Grid>

                <hr className="w-full" />

                <div className="flex gap-2">
                    <Button size="sm">التنقُّل </Button>
                    <Button size="sm" overrideClassName="with-fallbacks">
                        التنقُّل{" "}
                    </Button>
                    <Button size="sm" overrideClassName="with-fallbacks-ui">
                        التنقُّل{" "}
                    </Button>
                </div>
            </Grid>
        </div>
    );
};
