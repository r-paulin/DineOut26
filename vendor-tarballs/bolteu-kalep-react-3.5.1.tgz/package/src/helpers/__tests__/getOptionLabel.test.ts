import {getOptionLabelDefault, type SelectOption} from "@/components/_internal/Option";

const defaultOption: SelectOption = {value: "my value", title: "my title"};

test("should return title if string", function titleIfString() {
    expect(getOptionLabelDefault(defaultOption)).toEqual(defaultOption.title);
});

test("should return value if no title", function valueIfNoTitle() {
    expect(getOptionLabelDefault({...defaultOption, title: undefined})).toEqual(defaultOption.value);
});

test("should return empty string if no title or value", function emptyStringIfNoValueOrTitle() {
    expect(getOptionLabelDefault({value: null, title: undefined})).toEqual("");
});

test("should empty string if no option", function emptyStringIfNoOption() {
    expect(getOptionLabelDefault(null)).toEqual("");
});

test("should empty string if title is empty string", function emptyStringIfNoOption() {
    expect(getOptionLabelDefault({value: "bla", title: ""})).toEqual("");
});

test("should call title and return the content if function", function titleResultIfFunction() {
    const titleResult = "title result";

    expect(
        getOptionLabelDefault({
            ...defaultOption,
            title() {
                return titleResult;
            },
        }),
    ).toEqual(titleResult);
});
