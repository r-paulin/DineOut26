export type Appearance<AppeareanceConfigOption> =
    | "action"
    | "danger"
    | "neutral"
    | "promo"
    | "warning"
    | AppeareanceConfigOption;
