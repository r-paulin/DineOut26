export function noop() {}
export function noopNull() {
    return null;
}
