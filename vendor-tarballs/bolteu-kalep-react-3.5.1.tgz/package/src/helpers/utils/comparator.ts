export const defaultComparator = (a: any, b: any) => a === b;
