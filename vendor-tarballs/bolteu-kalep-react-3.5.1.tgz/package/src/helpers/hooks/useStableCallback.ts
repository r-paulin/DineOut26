import React from "react";

export type CallbackType<T extends Array<any>, R = void> = (...args: T) => R;

// Stolen shamelessly from https://github.com/bolteu/beehive-app/blob/68fca1e022e2e8c846cc240b0b728f191a44f05d/common/hooks/useStableCallback.ts#L5
export function useStableCallback<T extends Array<any>, R = void>(func: CallbackType<T, R>): CallbackType<T, R> {
    const functionRef = React.useRef<CallbackType<T, R>>(func);
    React.useEffect(() => {
        functionRef.current = func;
    }, [func]);

    return React.useCallback((...args: T) => functionRef.current(...args), []);
}
