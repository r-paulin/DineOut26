import * as React from "react";

type UseCloseOnEscapeProps = {
    open: boolean;
    onClose?: () => void;
};

export function useCloseOnEscape({open, onClose}: UseCloseOnEscapeProps): void {
    React.useEffect(() => {
        const close = (e: KeyboardEvent) => {
            if (open && e.key === "Escape") {
                onClose?.();
            }
        };
        window.addEventListener("keydown", close);
        return () => window.removeEventListener("keydown", close);
    }, [open, onClose]);
}
