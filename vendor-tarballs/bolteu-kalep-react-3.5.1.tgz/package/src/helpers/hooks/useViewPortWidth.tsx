import * as React from "react";

export const DEFAULT_MOBILE_BREAKPOINT = 640; // Temporary hardcoded value that matches the Tailwind "sm" breakpoint

export const useViewportWidth = () => {
    const [width, setWidth] = React.useState(window.innerWidth);

    React.useEffect(() => {
        const handleWindowResize = () => setWidth(window.innerWidth);
        window.addEventListener("resize", handleWindowResize);
        return () => window.removeEventListener("resize", handleWindowResize);
    }, []);

    return {width};
};
