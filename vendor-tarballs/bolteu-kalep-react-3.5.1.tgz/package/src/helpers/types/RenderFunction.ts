export interface RenderFunction<P> {
    (props: P, defaultRender: (props: P) => JSX.Element | null): JSX.Element | null;
}
