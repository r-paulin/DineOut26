import * as React from "react";

import {cx} from "@/helpers/utils/cx";

import type {SpacingValue, TypographyAlignment, TypographyLineClampValues, TypographyProps} from "./Typography.types";

const styles: {
    base: string;
    alignments: Record<TypographyAlignment, string>;
    lineClamp: Record<TypographyLineClampValues, string>;
} = {
    base: "m-0 text-primary",
    alignments: {
        start: "text-start",
        end: "text-end",
        center: "text-center",
        justify: "text-justify",
    },
    lineClamp: {
        1: "line-clamp-1",
        2: "line-clamp-2",
        3: "line-clamp-3",
        4: "line-clamp-4",
        none: "line-clamp-none",
    },
};

export function Typography({
    align,
    as,
    children,
    color,
    fontSize,
    inline,
    lines,
    variant = "body-m-regular",
    noWrap = false,
    inlineStyle,
    paddingTop,
    paddingBottom,
}: TypographyProps) {
    const Component = as ?? "span";

    const inlineElementStyles = {
        ...(paddingTop && {paddingTop: getRemFomSpacingSize(paddingTop)}),
        ...(paddingBottom && {paddingBottom: getRemFomSpacingSize(paddingBottom)}),
        ...inlineStyle,
    };

    return (
        <Component
            className={cx(
                !lines && (inline ? "inline" : "block"), // line clamping gets overriden by display: block declaration
                styles.base,
                `
                  bolt-font-${variant}
                `,
                align && styles.alignments[align],
                color && `
                  text-${color}
                `, // text color classes are safelisted in tailwind.config.js
                fontSize,
                noWrap && "overflow-hidden text-ellipsis whitespace-nowrap",
                lines && styles.lineClamp[lines],
            )}
            style={inlineElementStyles}
        >
            {children}
        </Component>
    );
}

function getRemFomSpacingSize(spacingValue: SpacingValue): string {
    return `${spacingValue / 4}rem`;
}
