import * as React from "react";

import {cx} from "@/helpers/utils/cx";

import {Typography} from "./Typography";
import type {SpacingValue, TypographyProps} from "./Typography.types";

export interface TypographyStackProps {
    /**
     * alias for 'primary'
     */
    children?: React.ReactNode;
    /**
     * Primary text content
     */
    primary?: React.ReactNode;
    /**
     * Secondary text content
     */
    secondary?: React.ReactNode;
    /**
     * The props to pass to the primary Typography component
     */
    primaryTypographyProps?: Omit<TypographyProps, "children">;
    /**
     * The props to pass to the secondary Typography component
     */
    secondaryTypographyProps?: Omit<TypographyProps, "children">;
    /**
     * Places secondary text above primary text
     */
    isReverse?: boolean;
    /**
     * Gap between primary and secondary text, 0 by default.
     */
    gap?: SpacingValue;
    /**
     * Preconfigured options for typography stack
     * @default base
     * @param base - Use it for common, not dense screens when you need to show the primary text and a supporting text (which should not be required for the task at hand).
     * @param sm - Use it for more dense screens when you need to show the primary text and additional supporting text (which should not be required for the task at hand).
     * @param "sm-expressive" - Mostly for internal views with a special approach to primary/secondary. If you’d like to use it, please check with the Design System team.
     */
    variant?: "base" | "sm" | "sm-expressive";
}

export function TypographyStack(props: TypographyStackProps) {
    const {
        children,
        gap,
        primary,
        secondary,
        primaryTypographyProps,
        secondaryTypographyProps,
        isReverse,
        variant = "base",
    } = props;

    let primaryElement = primary ?? children;
    let secondaryElement = secondary;
    let gapValue = gap;

    const variantPrimaryProps: TypographyStackProps["primaryTypographyProps"] = {};
    const variantSecondaryProps: TypographyStackProps["secondaryTypographyProps"] = {};

    switch (variant) {
        case "sm": {
            variantPrimaryProps.variant = "body-s-regular";
            variantPrimaryProps.color = "primary";
            variantSecondaryProps.variant = "body-xs-regular";
            variantSecondaryProps.color = "secondary";
            break;
        }
        case "sm-expressive": {
            variantPrimaryProps.variant = "body-s-regular";
            variantPrimaryProps.color = "primary";
            variantSecondaryProps.variant = "body-s-regular";
            variantSecondaryProps.color = "primary";
            gapValue = gapValue ?? 1;
            break;
        }
        case "base":
        default: {
            variantPrimaryProps.variant = "body-m-regular";
            variantPrimaryProps.color = "primary";
            variantSecondaryProps.variant = "body-s-regular";
            variantSecondaryProps.color = "secondary";
            break;
        }
    }

    if (primaryElement != null && !isTypographyComponent(primaryElement)) {
        primaryElement = (
            <Typography {...variantPrimaryProps} {...primaryTypographyProps}>
                {primaryElement}
            </Typography>
        );
    }

    if (secondaryElement != null && !isTypographyComponent(secondaryElement)) {
        secondaryElement = (
            <Typography {...variantSecondaryProps} {...secondaryTypographyProps}>
                {secondaryElement}
            </Typography>
        );
    }

    const inlineStyles = {
        ...(gapValue && {gap: getRemFromSpacingSize(gapValue)}),
    };

    return (
        <div className={cx("flex", isReverse ? "flex-col-reverse" : "flex-col")} style={inlineStyles}>
            {primaryElement}
            {secondaryElement}
        </div>
    );
}

function isTypographyComponent(element: React.ReactNode): element is React.ReactElement<TypographyProps> {
    return element != null && (element as any).type === Typography;
}

function getRemFromSpacingSize(spacingValue: SpacingValue): string {
    return `${spacingValue / 4}rem`;
}
