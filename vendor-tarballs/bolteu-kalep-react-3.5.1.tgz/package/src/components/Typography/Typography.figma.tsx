import React from "react";

import figma from "@figma/code-connect";

import {Typography} from "@/components/Typography";

figma.connect(
    Typography,
    "https://www.figma.com/design/nU1QBYZxTAYsIZ4X0jW4tV/%F0%9F%8C%88-Kalep-Web-Semantic-Components?node-id=13255-50360",
    {
        props: {
            text: figma.textContent("_text"),
        },
        example: (props) => <Typography> {props.text}</Typography>,
    },
);
