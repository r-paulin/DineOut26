import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Alert} from "@/index";

import {TypographyStack} from "./TypographyStack";

export default {
    title: "Data Display/TypographyStack",
    component: TypographyStack,
    tags: ["autodocs"],
} as Meta<typeof TypographyStack>;

const Template: StoryFn<typeof TypographyStack> = (args: any) => <TypographyStack {...args} />;

export const Default = Template.bind({});
Default.args = {
    primary: "This is primary",
    secondary: "This is secondary",
};

export const Reversed = Template.bind({});
Reversed.args = {
    ...Default.args,
    isReverse: true,
};

export const Variants = () => {
    return (
        <>
            <div className="mb-2 mt-4 font-mono text-sm text-secondary">base</div>
            <TypographyStack primary="This is primary" secondary="This is secondary" variant="base" />
            <div className="mb-2 mt-4 font-mono text-sm text-secondary">sm</div>
            <TypographyStack primary="This is primary" secondary="This is secondary" variant="sm" />
            <div className="mb-2 mt-4 font-mono text-sm text-secondary">sm-expressive</div>
            <TypographyStack primary="This is primary" secondary="This is secondary" variant="sm-expressive" />
        </>
    );
};

export const TypographyProps = () => {
    return (
        <>
            <Alert severity="info">
                Use <code>primaryTypographyProps</code> and <code>secondaryTypographyProps</code> to control both
                Typography component properties inside the stack.
            </Alert>
            <div className="mt-8 flex w-80 flex-col gap-4">
                <TypographyStack
                    primaryTypographyProps={{lines: 3}}
                    primary="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tempora eaque quibusdam nemo ullam amet? Sed maxime culpa ab officiis minima eveniet asperiores explicabo quidem, iure est obcaecati itaque ut accusamus"
                    secondary="This shows line clamping to 3 lines"
                />
                <TypographyStack
                    primaryTypographyProps={{color: "action-primary"}}
                    primary="This is primary"
                    secondary="And this shows color and font weight overrides"
                />
            </div>
        </>
    );
};
