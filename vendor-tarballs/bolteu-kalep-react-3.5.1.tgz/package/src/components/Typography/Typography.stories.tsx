import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Alert} from "../Alert";
import {Link} from "../Link";
import {Typography} from "./Typography";
import type {BoltFontStyles, TypographySize} from "./Typography.types";

export default {
    title: "Data Display/Typography",
    component: Typography,
    tags: ["autodocs"],
} as Meta<typeof Typography>;

const Template: StoryFn<typeof Typography> = (args: any) => <Typography {...args} />;

export const Default = Template.bind({});
Default.args = {
    children: "The quick fox jumps over the lazy dog",
};

export const Variants = () => {
    const phrase = "The quick brown fox jumps over the lazy dog";
    const variants: BoltFontStyles[] = [
        "heading-l-accent",
        "heading-m-accent",
        "heading-s-accent",
        "heading-xs-accent",
        "heading-xs-regular",
        "body-l-regular",
        "body-l-accent",
        "body-l-compact-regular",
        "body-l-compact-accent",
        "body-m-regular",
        "body-m-accent",
        "body-m-compact-regular",
        "body-m-compact-accent",
        "body-s-regular",
        "body-s-accent",
        "body-s-compact-regular",
        "body-s-compact-accent",
        "body-xs-regular",
        "body-xs-accent",
        "body-xs-compact-regular",
        "body-xs-compact-accent",
        "body-tabular-l-regular",
        "body-tabular-l-accent",
        "body-tabular-l-compact-regular",
        "body-tabular-l-compact-accent",
        "body-tabular-m-regular",
        "body-tabular-m-accent",
        "body-tabular-m-compact-regular",
        "body-tabular-m-compact-accent",
        "body-tabular-s-regular",
        "body-tabular-s-accent",
        "body-tabular-s-compact-regular",
        "body-tabular-s-compact-accent",
        "body-tabular-xs-regular",
        "body-tabular-xs-accent",
        "body-tabular-xs-compact-regular",
        "body-tabular-xs-compact-accent",
        "caps-l-accent",
        "caps-m-accent",
        "caps-s-accent",
        "display-m-regular",
    ];

    return variants.map((variant) => (
        <div className="p-4">
            <div className="font-mono text-sm text-secondary">{variant}</div>
            <Typography variant={variant} paddingTop={2}>
                {phrase}
            </Typography>
        </div>
    ));
};

export const Alignment = () => {
    return (
        <div className="flex flex-col gap-2 p-4">
            <Typography variant="heading-m-accent" align="start">
                Start
            </Typography>
            <Typography align="start" paddingBottom={8}>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem, numquam
                doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum architecto quibusdam odit
                molestiae, culpa illum ea.
            </Typography>
            <Typography variant="heading-m-accent" align="center">
                Center
            </Typography>
            <Typography align="center" paddingBottom={8}>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem, numquam
                doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum architecto quibusdam odit
                molestiae, culpa illum ea.
            </Typography>
            <Typography variant="heading-m-accent" align="end">
                End
            </Typography>
            <Typography align="end" paddingBottom={8}>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem, numquam
                doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum architecto quibusdam odit
                molestiae, culpa illum ea.
            </Typography>
            <Typography variant="heading-m-accent" align="justify">
                Justify
            </Typography>
            <Typography align="justify" paddingBottom={8}>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem, numquam
                doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum architecto quibusdam odit
                molestiae, culpa illum ea.
            </Typography>
        </div>
    );
};

export const FontSizes = () => {
    const sizes: TypographySize[] = [
        "text-xs",
        "text-sm",
        "text-base",
        "text-md",
        "text-lg",
        "text-xl",
        "text-2xl",
        "text-3xl",
        "text-4xl",
        "text-5xl",
        "text-6xl",
    ];

    return sizes.map((size) => (
        <Typography fontSize={size} paddingBottom={2}>
            This text is {size} size
        </Typography>
    ));
};

export const InlineText = () => {
    return (
        <Typography variant="body-m-regular">
            You can nest Typography elements to make them look different like{" "}
            <Typography variant="body-m-accent" inline>
                this semibold part
            </Typography>{" "}
            to enrich your texts or stress some parts. Just use the{" "}
            <Typography variant="body-m-accent" inline>
                inline
            </Typography>{" "}
            prop to not create another block element.
        </Typography>
    );
};

InlineText.parameters = {
    docs: {
        description: {
            story: "By default Typography component renders a block element (even if the underlying HTML element is inline). By passing `inline` prop to Typography component you can make it `display: inline`.",
        },
    },
};

export const NoWrapping = () => {
    return (
        <div className="w-64 resize-x overflow-hidden border border-solid border-separator p-4">
            <Typography noWrap>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam nemo ut nobis eius sunt esse quod dicta
                commodi quos neque labore soluta quam doloribus id sed sequi rerum, nihil sit.
            </Typography>
        </div>
    );
};

export const FontSettings = () => {
    return (
        <div className="flex flex-col gap-4">
            <Alert severity="info" title="Use font-feature-settings to control advanced typographic features">
                Typography component exposes <code>inlineStyle</code> property to enable overriding any inline styles of
                the base component. Among other things you can edit <code>font-feature-settings</code> property which
                controls advanced typographic settings such as small caps, ligatures, and swashes. See{" "}
                <Link href="https://developer.mozilla.org/en-US/docs/Web/CSS/font-feature-settings" target="_blank">
                    MDN docs
                </Link>{" "}
                for more info about <code>font-feature-settings</code> and check{" "}
                <Link href="https://rsms.me/inter/lab/" target="_blank">
                    Inter lab
                </Link>{" "}
                where you can play around with all the font features.
            </Alert>

            <div className="font-mono text-sm text-secondary">zero</div>
            <Typography>
                0 →{" "}
                <Typography
                    inline
                    inlineStyle={{
                        fontFeatureSettings: "'zero' 1",
                    }}
                >
                    0
                </Typography>
            </Typography>
            <div className="font-mono text-sm text-secondary">diagonal-fractions</div>
            <Typography>
                Make fractions fancier: 1/2 →{" "}
                <Typography inline inlineStyle={{fontVariantNumeric: "diagonal-fractions"}}>
                    1/2
                </Typography>
            </Typography>
        </div>
    );
};
