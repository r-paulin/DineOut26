import * as React from "react";

import type {Meta} from "@storybook/react-webpack5";

import type {SpinnerColors} from "./index";
import {Spinner} from "./index";

export default {
    title: "Feedback/Spinner",
    component: Spinner,
    tags: ["autodocs"],
} as Meta<typeof Spinner>;

export const Spinner400 = () => <Spinner size={400} />;

Spinner400.storyName = "Spinner / 400";

export const Spinner500 = () => <Spinner />;

Spinner500.storyName = "Spinner / 500 (Default)";

export const Spinner600 = () => <Spinner size={600} />;

Spinner600.storyName = "Spinner / 600";

export const Spinner700 = () => <Spinner size={700} />;

Spinner700.storyName = "Spinner / 700";

export const SizeAndColor = () => {
    return (
        <div className="h-48 w-48">
            <Spinner size="inherit" color="danger-secondary" />
        </div>
    );
};

SizeAndColor.storyName = "Custom size and color";

export const AllColors = () => {
    const colorsToClassnamesMap = {
        primary: "text-primary",
        "primary-inverted": "text-primary-inverted",
        secondary: "text-secondary",
        tertiary: "text-tertiary",
        "action-primary": "text-action-primary",
        "action-secondary": "text-action-secondary",
        "danger-primary": "text-danger-primary",
        "danger-secondary": "text-danger-secondary",
        "warning-primary": "text-warning-primary",
        "warning-secondary": "text-warning-secondary",
        "positive-primary": "text-positive-primary",
        "positive-secondary": "text-positive-secondary",
        "promo-primary": "text-promo-primary",
        "promo-secondary": "text-promo-secondary",
        "link-primary": "text-link-primary",
        "link-secondary": "text-link-secondary",
    };

    return (
        <div className="inline-grid grid-cols-4 grid-rows-4 gap-4">
            {Object.keys(colorsToClassnamesMap)
                .sort()
                .map((colorName) => {
                    return <Spinner key={colorName} color={colorName as SpinnerColors} />;
                })}
        </div>
    );
};

AllColors.storyName = "All colors!";
