export {Spinner} from "./Spinner";
export type {SpinnerProps, SpinnerColors, SpinnerSizes} from "./Spinner";
