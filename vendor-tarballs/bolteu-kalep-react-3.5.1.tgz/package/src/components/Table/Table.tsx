import * as React from "react";

import {cx} from "@/helpers/utils/cx";

import type {CellProps, RowProps, TableProps} from "./Table.types";

type TableContextType = {isCompact?: boolean; isStriped?: boolean};
const TableContext = React.createContext<TableContextType>({isCompact: false, isStriped: false});

export function Table({children, compact, overrideClassName, striped, ...rest}: TableProps) {
    const contextValue = React.useMemo(() => ({isCompact: compact, isStriped: striped}), [compact, striped]);

    return (
        <TableContext.Provider value={contextValue}>
            <table role="grid" className={cx("w-full border-collapse", overrideClassName)} {...rest}>
                {React.Children.map(children, (child: any) => {
                    return React.cloneElement(child);
                })}
            </table>
        </TableContext.Provider>
    );
}

function Header({children, ...rest}: React.HTMLProps<HTMLTableSectionElement>) {
    return (
        <thead {...rest}>
            {React.Children.map(children, (child: any) => {
                return React.cloneElement(child);
            })}
        </thead>
    );
}

function HeaderRow({children, ...rest}: RowProps) {
    return (
        <tr {...rest}>
            {React.Children.map(children, (child: any) => {
                return React.cloneElement(child);
            })}
        </tr>
    );
}

function HeaderCell({align, className, children, ...rest}: CellProps) {
    const {isCompact} = React.useContext(TableContext);

    return (
        <th
            className={cx(
                "p-0",
                align === "right" ? "text-right" : "text-left",
                "border-0 border-b border-solid border-separator",
                className,
            )}
            {...rest}
        >
            <div
                className={cx(
                    "flex h-full items-center gap-2",
                    "bolt-font-body-s-accent text-primary",
                    isCompact ? "min-h-8 p-1" : "min-h-11 px-3",
                    align === "right" ? "justify-end" : "justify-between",
                )}
            >
                {children}
            </div>
        </th>
    );
}

function Body({children, ...rest}: React.HTMLProps<HTMLTableSectionElement>) {
    return (
        <tbody {...rest}>
            {React.Children.map(children, (child: any) => {
                return React.cloneElement(child);
            })}
        </tbody>
    );
}

function Row({children, className, ...rest}: RowProps) {
    const {isStriped} = React.useContext(TableContext);

    return (
        <tr
            role="row"
            className={cx(
                `
                  bg-special-nulled
                  hover:bg-active-neutral-secondary
                `,
                isStriped && "odd:bg-special-zebra",
                className,
            )}
            {...rest}
        >
            {React.Children.map(children, (child: any) => {
                return React.cloneElement(child);
            })}
        </tr>
    );
}

function Cell({align = "left", children, overrideClassName, ...rest}: CellProps) {
    const {isCompact} = React.useContext(TableContext);

    return (
        <td
            className={cx(
                "border-0 border-b border-solid border-separator p-0 align-middle",
                align === "left" ? "text-left" : "text-right",
                overrideClassName,
            )}
            {...rest}
        >
            <div
                className={cx(
                    "grid w-full items-center",
                    "bolt-font-body-s-regular text-primary",
                    isCompact ? "p-1" : `
                      min-h-12 p-3
                      empty:min-h-0
                    `,
                )}
            >
                {children}
            </div>
        </td>
    );
}

Table.Header = Header;
Table.HeaderRow = HeaderRow;
Table.HeaderCell = HeaderCell;
Table.Body = Body;
Table.Row = Row;
Table.Cell = Cell;
