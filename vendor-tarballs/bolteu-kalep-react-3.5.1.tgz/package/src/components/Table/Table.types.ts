export interface TableProps extends React.HTMLProps<HTMLTableElement> {
    compact?: boolean;
    overrideClassName?: string;
    striped?: boolean;
}

export interface RowProps extends React.HTMLProps<HTMLTableRowElement> {
    overrideClassName?: string;
}

export interface CellProps extends React.HTMLProps<HTMLTableCellElement> {
    align?: "left" | "right";
    overrideClassName?: string;
}
