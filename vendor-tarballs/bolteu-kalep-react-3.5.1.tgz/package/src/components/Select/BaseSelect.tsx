import * as React from "react";

import {useSelect} from "downshift";
import {OverlayContainer, useOverlayPosition} from "@react-aria/overlays";
import {useVirtualizer} from "@tanstack/react-virtual";

import {renderHelperTextDefault} from "@/components/_internal/HelperText";
import {Label} from "@/components/_internal/Label";
import type {SelectOption} from "@/components/_internal/Option";
import {getOptionLabelDefault, renderOptionDefault} from "@/components/_internal/Option";
import {guessOverlayPosition} from "@/components/_internal/Overlay";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";
import {noopNull} from "@/helpers/utils/noop";

import {KALEP_MODAL_CONTENT_ID} from "../_internal/Modal";
import {KALEP_BOTTOMSHEET_CONTENT_ID} from "../BottomSheet/BottomSheet";
import {
    isOptionEqualToValueDefault,
    useSelectStateReducerForMultipleSelect,
    virtualizerEstimateHeightBySize,
} from "./helpers";
import type {BaseSelectProps} from "./Select.types";
import {SelectTrigger} from "./SelectTrigger";

const DEFAULT_VIRTUALIZER_OVERSCAN = 4;
const VIRTUALIZER_VERTICAL_PADDING = 8;

export const BaseSelect = React.forwardRef<HTMLButtonElement, BaseSelectProps>((props, forwardedRef): JSX.Element => {
    const {
        defaultValue,
        defaultOpen,
        disabled,
        error = false,
        fullWidth,
        getOptionLabel = getOptionLabelDefault,
        isOptionEqualToValue = isOptionEqualToValueDefault,
        getValueFromOption,
        helperText,
        infoText,
        id,
        label,
        loading,
        loadingSpinnerAriaLabel,
        multiple,
        multiline,
        name,
        onChange,
        onOpenChange,
        onClear,
        clearable = true,
        open,
        options,
        renderOption = renderOptionDefault,
        renderHelperText = renderHelperTextDefault,
        renderTrigger,
        renderOverlayFooter = noopNull,
        placeholder,
        required,
        size = "md",
        value: valueProp,
        rootClassName,
        overlayConfig,
        portalContainer,
    } = props;

    const internalRef = React.useRef<HTMLButtonElement>(null);
    const dropdownRef = React.useRef<HTMLDivElement>(null);
    const listParentRef = React.useRef<HTMLDivElement>(null);

    const generatedId = useId(id);
    const selectId = id ?? `kalep-select-${generatedId}`;
    const helperTextId = `${selectId}-helper-text`;
    const loadingSpinnerId = `${selectId}-loading-spinner`;

    const virtualizer = useVirtualizer({
        count: options.length,
        getScrollElement: () => listParentRef.current,
        estimateSize: () => virtualizerEstimateHeightBySize(size),
        overscan: DEFAULT_VIRTUALIZER_OVERSCAN,
    });
    const virtualItems = virtualizer.getVirtualItems();

    const {
        isOpen,
        getToggleButtonProps,
        getMenuProps,
        getItemProps,
        selectedItem: value,
        getLabelProps,
        highlightedIndex,
        selectItem,
    } = useSelect<SelectOption>({
        id: selectId,
        items: options,
        itemToString(option) {
            return option ? getOptionLabel(option) : "";
        },
        isItemDisabled(option) {
            return !!option.disabled;
        },
        onIsOpenChange(changes) {
            if (typeof onOpenChange === "function") {
                onOpenChange(changes.isOpen as boolean);
            }

            if (changes.isOpen && changes.highlightedIndex !== undefined && changes.highlightedIndex >= 0) {
                virtualizer.scrollToIndex(changes.highlightedIndex);
            }
        },
        onSelectedItemChange({selectedItem: newOption}) {
            if (typeof onChange === "function") {
                onChange(newOption || null);
            }
        },
        onHighlightedIndexChange(changes) {
            if (
                (changes.type === useSelect.stateChangeTypes.ToggleButtonKeyDownArrowDown ||
                    changes.type === useSelect.stateChangeTypes.ToggleButtonKeyDownArrowUp) &&
                changes.highlightedIndex !== undefined &&
                changes.highlightedIndex !== highlightedIndex
            ) {
                virtualizer.scrollToIndex(changes.highlightedIndex);
            }
        },
        ...(multiple && {stateReducer: useSelectStateReducerForMultipleSelect}),
        selectedItem: multiple ? null : (valueProp as SelectOption), // Downshift instructs to set selectedItem null for multiselect
        initialSelectedItem: multiple ? null : (defaultValue as SelectOption), // Downshift instructs to set selectedItem null for multiselect
        initialIsOpen: defaultOpen,
        isOpen: open,
    });

    const triggerA11yProps = getToggleButtonProps({ref: internalRef});
    const menuA11yProps = getMenuProps({ref: dropdownRef}, {suppressRefError: true});

    if (loading) {
        triggerA11yProps["aria-labelledby"] = `${triggerA11yProps["aria-labelledby"]} ${loadingSpinnerId}`;
        menuA11yProps["aria-labelledby"] = `${menuA11yProps["aria-labelledby"]} ${loadingSpinnerId}`;
    }

    const {overlayProps} = useOverlayPosition({
        targetRef: internalRef,
        overlayRef: dropdownRef,
        isOpen,

        // Default
        placement: "bottom",
        offset: 4,

        // Optional overrides
        ...(overlayConfig?.position || {}),
    });

    if (
        overlayProps?.style &&
        overlayProps.style.top == null &&
        overlayProps.style.bottom == null &&
        isOpen &&
        internalRef.current
    ) {
        // FIXME: Hack to prevent page from scrolling to the end when Select opens for the 1st time
        // More context: https://github.com/bolteu/kalep/pull/730
        overlayProps.style.top = guessOverlayPosition(internalRef.current);
    }

    const overlayStyle = {...overlayProps.style, zIndex: undefined}; // We want to control z-index ourselves

    const handleClear = React.useCallback(() => {
        selectItem(null);
        onChange?.(null);
        onClear?.();
    }, [onClear, onChange, selectItem]);

    return (
        <div className={cx(rootClassName)}>
            <div className={cx("flex flex-col gap-2", fullWidth ? "w-full" : "w-96")}>
                {label && (
                    <Label
                        text={label}
                        infoText={infoText}
                        required={required}
                        disabled={disabled}
                        htmlProps={getLabelProps()}
                    />
                )}
                {typeof renderTrigger === "function" ? (
                    renderTrigger({...props, ...triggerA11yProps})
                ) : (
                    <SelectTrigger
                        value={multiple ? valueProp : value}
                        name={name}
                        isOpen={isOpen}
                        multiple={multiple}
                        disabled={disabled}
                        onClear={handleClear}
                        clearable={clearable}
                        loading={loading}
                        loadingSpinnerId={loadingSpinnerId}
                        loadingSpinnerAriaLabel={loadingSpinnerAriaLabel}
                        error={error}
                        size={size}
                        multiline={multiline}
                        placeholder={placeholder}
                        valueToString={getValueFromOption || getOptionLabel}
                        ariaDescribedby={helperText ? helperTextId : undefined}
                        {...triggerA11yProps}
                        ref={mergeRefs([internalRef, forwardedRef, triggerA11yProps.ref])}
                    />
                )}
                {renderHelperText({...props, helperTextId}, renderHelperTextDefault)}
            </div>
            {isOpen && (
                <OverlayContainer
                    portalContainer={
                        portalContainer ||
                        internalRef?.current?.closest("dialog") ||
                        internalRef?.current?.closest(`#${KALEP_MODAL_CONTENT_ID}`) ||
                        internalRef?.current?.closest(`#${KALEP_BOTTOMSHEET_CONTENT_ID}`) ||
                        document.body
                    }
                >
                    <div
                        className={cx("absolute z-dropdown", "max-h-80 w-max rounded-md shadow-md")}
                        {...menuA11yProps}
                        style={{
                            minWidth: overlayConfig?.minWidth ? `${overlayConfig.minWidth}px` : "initial",
                            maxWidth: overlayConfig?.maxWidth ? `${overlayConfig.maxWidth}px` : "initial",
                            width: internalRef.current?.clientWidth || "initial",
                            ...overlayStyle,
                        }}
                        role="none"
                    >
                        <div
                            ref={listParentRef}
                            className={cx(
                                "max-h-80 w-full overflow-y-auto overscroll-none rounded-md bg-layer-floor-3",
                                fullWidth && "w-full",
                            )}
                            // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex -- in case it's scrollable.
                            tabIndex={0}
                        >
                            <div
                                className={cx("relative")}
                                style={{height: virtualizer.getTotalSize() + VIRTUALIZER_VERTICAL_PADDING}}
                            >
                                <ul
                                    className={cx(
                                        `
                                          m-0 list-none px-0 py-1
                                          empty:py-0
                                        `,
                                        "max-h-full overflow-y-hidden",
                                        "cursor-pointer",
                                    )}
                                    style={{transform: `translateY(${virtualItems[0]?.start ?? 0}px)`}}
                                    role="listbox"
                                    aria-labelledby={menuA11yProps["aria-labelledby"]}
                                    tabIndex={-1}
                                >
                                    {virtualItems.map((virtualItem) => {
                                        const {index} = virtualItem;
                                        const option = options[index];
                                        const optionLabel = getOptionLabel(option);

                                        const optionProps = {
                                            ...getItemProps({
                                                item: option,
                                                index,
                                            }),
                                            highlighted: highlightedIndex === index,
                                            selected: value !== null && isOptionEqualToValue(option, value),
                                            option,
                                            label: optionLabel,
                                            key: virtualItem.key.toString(),
                                            ref: virtualizer.measureElement,
                                            "data-index": virtualItem.index,
                                            size,
                                            multiple,
                                        };

                                        return typeof renderOption === "function"
                                            ? renderOption(optionProps, renderOptionDefault)
                                            : renderOptionDefault(optionProps);
                                    })}
                                </ul>
                            </div>
                            {renderOverlayFooter(props, noopNull)}
                        </div>
                    </div>
                </OverlayContainer>
            )}
        </div>
    );
});
BaseSelect.displayName = "BaseSelect";
