import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import type {SelectOption} from "@/components/_internal/Option";
import {cx} from "@/helpers/utils/cx";

import {Grid} from "../Layout";
import type {SelectProps} from "./index";
import {Select} from "./index";

export default {
    title: "Inputs/Select",
    component: Select,
    tags: ["autodocs"],
    // Downshift uses role="combobox" on Select trigger button and a11y plugin complains about it
    parameters: {
        a11y: {
            config: {
                rules: [
                    {
                        id: "aria-allowed-role",
                        enabled: false,
                    },
                ],
            },
        },
    },
} as Meta<typeof Select>;

const options: SelectOption[] = [
    {title: "Tallinn", value: "1"},
    {title: "Stockholm", value: "2"},
    {title: "Berlin", value: "3"},
    {title: "Warsaw", value: "4"},
    {title: "Paris", value: "5"},
    {title: "London", value: "6"},
    {title: "Lisbon", value: "7"},
    {title: "Johannesburg", value: "8"},
];

const virtualisedOptions: SelectOption[] = [];

for (let i = 0; i < 1000; i++) {
    virtualisedOptions.push({title: `Item ${i}`, value: `value-${i}`, secondary: `Description of item ${i}`});
}

const Template: StoryFn<typeof Select> = (args: SelectProps) => <Select {...args} />;

export const Default = Template.bind({});
Default.args = {
    options,
    label: "Label",
    placeholder: "Placeholder",
    helperText: "Helper text is displayed below the trigger",
    infoText: "Optional info text, shown in a Tooltip",
};

export const Sizes: StoryFn<typeof Select> = () => (
    <div className="flex flex-col gap-8">
        <Select label="Small" options={options} size="sm" placeholder="City" />
        <Select label="Medium (default)" options={options} placeholder="City" />
        <Select label="Large" options={options} size="lg" placeholder="City" />
    </div>
);

export const Multiline = Template.bind({});
const multilineValue = {
    title: "Just an example entry that can be long and span across multiple lines",
    value: "9",
};
Multiline.args = {
    ...Default.args,
    multiline: true,
    options: [multilineValue, ...options],
    defaultValue: multilineValue,
};

export const Disabled = Template.bind({});
Disabled.args = {
    ...Default.args,
    disabled: true,
    value: options[0],
};

export const Error = Template.bind({});
Error.args = {
    ...Default.args,
    value: {title: "Helsinki", value: "0"},
    error: true,
};

export const Required = Template.bind({});
Required.args = {
    ...Default.args,
    required: true,
};

export const Loading = Template.bind({});
Loading.args = {
    ...Default.args,
    loading: true,
    loadingSpinnerAriaLabel: "I am loading",
};

export const WithoutClearing = Template.bind({});
WithoutClearing.args = {
    ...Default.args,
    clearable: false,
    helperText: "Turn off clear button for smaller inputs",
};

export const Readonly = Template.bind({});
Readonly.args = {
    ...Default.args,
    readonly: true,
    value: options[0],
    helperText: "You can still provide helper text for secondary content",
};

export const MultipleReadonly = Template.bind({});
MultipleReadonly.args = {
    ...Default.args,
    readonly: true,
    value: [options[0], options[2], options[3]],
    helperText: "You can still provide helper text for secondary content",
};

export const DisabledItems = Template.bind({});
const modifiedOptions = options.map((option, i) => (i % 4 !== 0 ? option : {...option, disabled: true}));
DisabledItems.args = {
    ...Default.args,
    options: modifiedOptions,
};

export const Controlled: StoryFn<typeof Select> = (args: SelectProps) => {
    const [value, setValue] = React.useState<SelectOption>();
    const handleChange = React.useCallback((newValue) => setValue(newValue), []);

    return (
        <Select
            {...args}
            onChange={handleChange}
            value={value}
            helperText={value ? `${value.title} has been picked` : "Pick something to see this text change"}
        />
    );
};

Controlled.args = {
    ...Default.args,
};
Controlled.argTypes = {
    value: {
        control: {
            disable: true,
        },
    },
    helperText: {
        control: {
            disable: true,
        },
    },
};

const optionsWithSecondaryDescription: SelectOption[] = [
    {title: "Tallinn", value: "1", secondary: "Capital of Estonia"},
    {title: "Stockholm", value: "2", secondary: "Capital of Sweden"},
    {title: "Berlin", value: "3", secondary: "Capital of Germany"},
    {title: "Warsaw", value: "4", secondary: "Capital of Poland"},
    {title: "Paris", value: "5", secondary: "Capital of France"},
    {
        title: "London",
        value: "6",
        secondary: "Capital of the United Kingdom of Great Britain and Northern Ireland (and long country names)",
    },
    {title: "Lisbon", value: "7", secondary: "Capital of Portugal"},
    {title: "Johannesburg", value: "8", secondary: "Capital of South Africa"},
];

export const SecondaryDescription = Template.bind({});
SecondaryDescription.args = {
    ...Default.args,
    options: optionsWithSecondaryDescription,
    helperText: "Give users more context to make a more informed choice!",
};

export const MultipleSecondaryDescription = Template.bind({});
MultipleSecondaryDescription.args = {
    ...Default.args,
    multiple: true,
    options: optionsWithSecondaryDescription,
    helperText: "Give users more context to make a more informed choice!",
};

export const CustomOptionRenderer: StoryFn<typeof Select> = () => {
    const renderOption = React.useCallback(
        (props) => (
            <li
                key={props.option.value}
                onClick={props.onClick}
                className={cx(
                    `
                      cursor-pointer px-4 py-3 text-base
                      hover:bg-promo-secondary
                    `,
                    props.selected && "font-semibold",
                )}
            >
                {props.option.title}
                {props.selected && " 💚"}
            </li>
        ),
        [],
    );

    return (
        <Select
            label="Label:"
            placeholder="Placeholder goes here"
            options={options}
            renderOption={renderOption}
            helperText="Make this Select your own using custom renderers 💚"
        />
    );
};

export const CustomOverlayFooter = Template.bind({});
CustomOverlayFooter.args = {
    ...Default.args,
    renderOverlayFooter: () => <div className="p-2 text-center text-xs text-secondary">© OpenStreetMap</div>,
};

export const MultipleSelection = Template.bind({});
MultipleSelection.args = {
    ...Default.args,
    multiple: true,
    helperText: "Pick as many options as you want",
    defaultValue: [options[0], options[2]],
};

export const MultipleSelectionMultiline = Template.bind({});
MultipleSelectionMultiline.args = {
    ...Default.args,
    multiple: true,
    helperText: "Pick as many options as you want, we show them all",
    defaultValue: [options[0], options[2]],
    multiline: true,
};

export const MultipleSelectionDisabled = Template.bind({});
MultipleSelectionDisabled.args = {
    ...Default.args,
    multiple: true,
    disabled: true,
    onChange: (...args) => console.log(args),
    defaultValue: [options[0], options[2]],
};

export const FullWidth: StoryFn<typeof Select> = () => (
    <Grid columns={15} alignItems="flex-end">
        <Grid.Item colSpan={4}>
            <Select options={options} fullWidth label="City" placeholder="e.g. Paris" required />
        </Grid.Item>
        <Grid.Item colSpan={3}>
            <Select
                placeholder="e.g. Active"
                options={[
                    {value: "1", title: "Active"},
                    {value: "0", title: "Inactive"},
                ]}
                fullWidth
                label="Status"
                infoText="Just some helper text"
            />
        </Grid.Item>
        <Grid.Item colSpan={8}>
            <Select label="City multiple" placeholder="e.g. Tallinn, Paris" options={options} fullWidth multiple />
        </Grid.Item>
    </Grid>
);

export const Virtualisation = Template.bind({});
Virtualisation.args = {
    label: "A thousand options:",
    placeholder: "Select an option",
    helperText: "We render just a handful at a time",
    options: virtualisedOptions,
};

export const OverlayConfiguration = () => (
    <Grid columns={12}>
        <Grid.Item colSpan={1}>
            <Select
                options={optionsWithSecondaryDescription}
                label="City"
                placeholder="🏰"
                helperText="Regular"
                fullWidth
            />
        </Grid.Item>
        <Grid.Item colSpan={1}>
            <Select
                options={optionsWithSecondaryDescription}
                label="City"
                placeholder="🏰"
                helperText="Forced small"
                overlayConfig={{maxWidth: 100}}
                fullWidth
            />
        </Grid.Item>
        <Grid.Item colSpan={1}>
            <Select
                options={optionsWithSecondaryDescription}
                label="City"
                placeholder="🏰"
                helperText="Forced large"
                overlayConfig={{minWidth: 900}}
                fullWidth
            />
        </Grid.Item>
        <Grid.Item visible="HIDDEN_LEAVE_HOLE">🤷‍♂️</Grid.Item>
        <Grid.Item colSpan={2}>
            <Select
                options={optionsWithSecondaryDescription}
                label="City"
                placeholder="e.g Tallinn"
                helperText="Opens 100px down and 300px to the right"
                overlayConfig={{position: {offset: 100, crossOffset: 300}, maxWidth: 300}}
                fullWidth
            />
        </Grid.Item>
    </Grid>
);

const testOptions = [
    ...options,
    {title: "Delivery Courier Administration", value: "foo"},
    {title: "taxify_delivery_eater_campaign_targeting", value: "bar"},
];

export function AllWidths() {
    // array of numbers from 100 to 200 with a step of 10
    const widths = Array.from({length: 16}, (_, i) => i * 10 + 100);

    return (
        <div className="flex gap-8">
            <div className="flex flex-col gap-8">
                {widths.map((width, index) => (
                    <div style={{width: `${width}px`}} key={width}>
                        <Select
                            options={testOptions}
                            size={index % 2 === 0 ? "sm" : "md"}
                            multiple
                            label={`Width: ${width}px`}
                            defaultValue={[testOptions[0]]}
                            fullWidth
                            placeholder="e.g Tallinn"
                        />
                    </div>
                ))}
            </div>
            <div className="flex flex-col gap-8">
                {widths.map((width, index) => (
                    <div style={{width: `${width}px`}} key={width}>
                        <Select
                            options={testOptions}
                            size={index % 2 === 0 ? "sm" : "md"}
                            multiple
                            label={`Width: ${width}px`}
                            defaultValue={[testOptions[testOptions.length - 1]]}
                            fullWidth
                            placeholder="e.g Tallinn"
                        />
                    </div>
                ))}
            </div>
            <div className="flex flex-col gap-8">
                {widths.map((width, index) => (
                    <div style={{width: `${width}px`}} key={width}>
                        <Select
                            options={testOptions}
                            size={index % 2 === 0 ? "sm" : "md"}
                            multiple
                            label={`Width: ${width}px`}
                            defaultValue={[testOptions[testOptions.length - 2]]}
                            fullWidth
                            placeholder="e.g Tallinn"
                        />
                    </div>
                ))}
            </div>
        </div>
    );
}
