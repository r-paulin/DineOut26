import * as React from "react";

import {useMultipleSelection} from "downshift";

import {renderMultipleOptionDefault} from "@/components/_internal/MultipleOption";
import type {OptionProps, SelectOption} from "@/components/_internal/Option";
import {getOptionLabelDefault} from "@/components/_internal/Option";
import {defaultComparator} from "@/helpers/utils/comparator";

import {BaseSelect} from "./BaseSelect";
import {useMultipleSelectionStateReducer} from "./helpers";
import type {SelectProps} from "./Select.types";

export function MultipleSelect({
    getOptionLabel = getOptionLabelDefault,
    onChange: onChangeProp,
    defaultValue,
    disabled,
    value,
    renderOption: renderOptionProp = renderMultipleOptionDefault,
    size,
    isOptionEqualToValue = defaultComparator,
    ...rest
}: SelectProps): JSX.Element {
    if (value !== undefined && !Array.isArray(value)) {
        throw new Error("MultipleSelect requires value to be an array.");
    }

    if (defaultValue !== undefined && !Array.isArray(defaultValue)) {
        throw new Error("MultipleSelect requires defaultValue to be an array.");
    }

    const {selectedItems, setSelectedItems, getDropdownProps} = useMultipleSelection<SelectOption>({
        stateReducer: useMultipleSelectionStateReducer,
        itemToString: getOptionLabelDefault,
        ...(value !== undefined && {
            selectedItems: Array.isArray(value) ? value : [value as SelectOption],
        }),
        ...(defaultValue !== undefined && {
            initialSelectedItems: Array.isArray(defaultValue) ? defaultValue : [defaultValue],
        }),
    });

    getDropdownProps({}, {suppressRefError: true}); // To avoid console error about ref

    const onChange = React.useCallback(
        (newOption: SelectOption | SelectOption[] | null) => {
            if (disabled) {
                return;
            }

            if (!newOption || Array.isArray(newOption)) {
                return;
            }

            const itemIndex = selectedItems.findIndex((option) => {
                return isOptionEqualToValue(option, newOption);
            });

            const newSelectedOptions =
                itemIndex === -1
                    ? [...selectedItems, newOption] // add
                    : [
                          // remove
                          ...selectedItems.slice(0, itemIndex),
                          ...selectedItems.slice(itemIndex + 1),
                      ];

            setSelectedItems(newSelectedOptions);

            if (typeof onChangeProp === "function") {
                onChangeProp(newSelectedOptions);
            }
        },
        [selectedItems, setSelectedItems, onChangeProp, isOptionEqualToValue, disabled],
    );

    const onClear = React.useCallback(() => {
        setSelectedItems([]);

        if (typeof onChangeProp === "function") {
            onChangeProp([]);
        }
    }, [setSelectedItems, onChangeProp]);

    const renderOption = React.useCallback<(OptionProps: OptionProps) => JSX.Element | null>(
        (props) =>
            renderOptionProp(
                {
                    ...props,
                    selected: selectedItems.some((selectedOption) => {
                        return isOptionEqualToValue(selectedOption, props.option);
                    }),
                },
                renderMultipleOptionDefault,
            ),
        [isOptionEqualToValue, renderOptionProp, selectedItems],
    );

    return (
        <BaseSelect
            value={selectedItems}
            defaultValue={defaultValue}
            onChange={onChange}
            onClear={onClear}
            renderOption={renderOption}
            getOptionLabel={getOptionLabel}
            size={size}
            disabled={disabled}
            isOptionEqualToValue={isOptionEqualToValue}
            {...rest}
        />
    );
}
