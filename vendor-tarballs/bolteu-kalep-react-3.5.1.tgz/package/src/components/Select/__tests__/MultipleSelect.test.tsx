import * as React from "react";

import {vi} from "vitest";

import type {SelectOption} from "@/components/_internal/Option";

import {
    clickOnOption,
    clickOnToggleButton,
    defaultProps,
    getOptions,
    getSelectedOption,
    getToggleButton,
    menuSize,
    renderSelect,
    screen,
    user,
} from "./Select.testUtils";

beforeEach(() => {
    // https://github.com/TanStack/virtual/issues/641
    vi.spyOn(Element.prototype, "getBoundingClientRect").mockImplementation(() => ({
        width: 120,
        height: 120,
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
        x: 0,
        y: 0,
        toJSON: () => {},
    }));
});

afterEach(() => {
    vi.restoreAllMocks();
});

test("can select multiple items", async () => {
    const option1 = defaultProps.options[1];
    const option2 = defaultProps.options[2];

    renderSelect({multiple: true});

    await clickOnToggleButton();
    await clickOnOption(option1.title);
    await clickOnOption(option2.title);

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(2);
    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(2);

    await clickOnToggleButton();

    expect(getSelectedOption(option1.title)).toBeInTheDocument();
    expect(getSelectedOption(option2.title)).toBeInTheDocument();
});

test("onChange is called with the new array of items", async function onChangeCall() {
    const onChange = vi.fn();
    const defaultValue = defaultProps.options.slice(0, 2);

    renderSelect({multiple: true, defaultValue, onChange});

    await clickOnToggleButton();
    await clickOnOption(defaultProps.options[2].title);

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenNthCalledWith(1, [...defaultValue, defaultProps.options[2]]);

    await clickOnOption(defaultProps.options[2].title);

    expect(onChange).toHaveBeenCalledTimes(2);
    expect(onChange).toHaveBeenNthCalledWith(2, defaultValue);
});

test("is focusable", async function arrowKeysFocusManagement() {
    const defaultValue = defaultProps.options.slice(0, 3);

    renderSelect({multiple: true, defaultValue});

    await user.tab();
    expect(getToggleButton()).toHaveFocus();
});

test("selection with character keys does not work", async function noSelectionWithCharKeys() {
    const optionToSelect = defaultProps.options[0].title;
    const {rerender} = renderSelect({multiple: true});

    await user.tab();
    await user.keyboard(optionToSelect.slice(0, 2));
    await user.keyboard("[Enter]");

    expect(getToggleButton()).toHaveTextContent(defaultProps.placeholder);

    rerender({multiple: false});

    await user.tab();
    await user.keyboard(optionToSelect.slice(0, 2));
    await user.keyboard("[Enter]");

    expect(getToggleButton()).toHaveTextContent(optionToSelect);
});

test("keep the menu open on selection", async function keepMenuOpenOnSelection() {
    const listSize = defaultProps.options.length;

    renderSelect({multiple: true});

    await clickOnToggleButton();
    await clickOnOption(defaultProps.options[0].title);

    expect(getOptions()).toHaveLength(listSize);

    await user.keyboard("[ArrowDown][Enter]");

    expect(getOptions()).toHaveLength(listSize);

    await user.keyboard("[ArrowDown][Space]");

    expect(getOptions()).toHaveLength(listSize);
    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(3);
});

test("backspace doesn't remove selected options", async function keepOptionsSelectedOnBackspace() {
    const defaultValue = defaultProps.options.slice(0, 2);

    renderSelect({multiple: true, defaultValue});

    await clickOnToggleButton();
    await user.keyboard("[Backspace]");

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(2);

    await clickOnOption(defaultProps.options[3].title);

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(3);

    await user.keyboard("[Backspace]");

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(3);
});

test("getOptionValue is used by selected items as well as options", async () => {
    const optionString = "I am an option";
    const getOptionLabel = vi.fn().mockImplementation(() => optionString);
    const defaultValue = defaultProps.options.slice(0, 1);

    renderSelect({multiple: true, defaultValue, getOptionLabel});

    expect(getSelectedOption(optionString)).toBeInTheDocument();

    await clickOnToggleButton();

    expect(screen.getAllByRole("option", {name: optionString})).toHaveLength(4);
    expect(getOptionLabel).toHaveBeenNthCalledWith(1, defaultValue[0]);
    for (let index = 0; index < defaultProps.options.length; index++) {
        expect(getOptionLabel).toHaveBeenCalledWith(defaultProps.options[index]);
    }
});

test("renderOption is called when passed", async () => {
    const optionContent = "hello";
    const renderOption = vi.fn().mockImplementation((props) => <div key={props.option.value}>{optionContent}</div>);

    renderSelect({renderOption});

    await clickOnToggleButton();

    expect(screen.getAllByText(optionContent)).toHaveLength(menuSize);
});

test("isOptionEqualToValue overides the default compare by reference", async function customEqualFunction() {
    // option with the same value and title, but different reference.
    const defaultValue = [{value: defaultProps.options[0].value, title: defaultProps.options[0].title}];
    // should compare by value, not by reference.
    function isOptionEqualToValue(option1: SelectOption, option2: SelectOption): boolean {
        return option1.value === option2.value;
    }

    renderSelect({multiple: true, defaultValue, isOptionEqualToValue});

    expect(getSelectedOption(defaultValue[0].title)).toBeInTheDocument();

    await clickOnToggleButton();

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(1);
    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(3);

    // check adding items still works.
    await clickOnOption(defaultProps.options[1].title);

    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(2);

    // check removing items still works.
    await clickOnOption(defaultProps.options[0].title);

    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(3);
});

test("MultipleSelect throws when value is not an array", async () => {
    const value = defaultProps.options[0];

    expect(() => renderSelect({multiple: true, value})).toThrow("MultipleSelect requires value to be an array.");
});

test("MultipleSelect throws when value is null", async () => {
    expect(() => renderSelect({multiple: true, value: null})).toThrow("MultipleSelect requires value to be an array.");
});

test("MultipleSelect throws when defaultValue is not an array", async () => {
    const defaultValue = defaultProps.options[0];

    expect(() => renderSelect({multiple: true, defaultValue})).toThrow(
        "MultipleSelect requires defaultValue to be an array.",
    );
});
