import * as React from "react";

import {cx} from "@/helpers/utils/cx";

export interface GhostButtonProps {
    id?: string;
    children: React.ReactNode;
    onClick: (e: React.MouseEvent | React.KeyboardEvent) => void;
    tabIndex?: number;
    overrideClassName?: string;
    disabled?: boolean;
    "aria-label"?: string;
    "aria-selected"?: boolean;
    role?: string;
    as?: React.ElementType;
}

function GhostButton(
    {
        children,
        tabIndex = 0,
        disabled = false,
        onClick,
        overrideClassName,
        role = "button",
        as: Component = "div",
        ...props
    }: GhostButtonProps,
    ref: React.Ref<HTMLDivElement>,
) {
    const onKeyDown = React.useCallback(
        (event: React.KeyboardEvent) => {
            if (event.key === "Enter" || event.key === " ") {
                onClick(event);
            }
        },
        [onClick],
    );

    return (
        <Component
            role={role}
            aria-disabled={disabled}
            tabIndex={tabIndex}
            onClick={disabled ? undefined : onClick}
            onKeyDown={disabled ? undefined : onKeyDown}
            className={cx(
                "inline-block",
                "cursor-pointer",
                "active:scale-975 active:duration-100 active:ease-in-out",
                disabled && "pointer-events-none",
                overrideClassName,
            )}
            ref={ref}
            {...props}
        >
            {children}
        </Component>
    );
}

const ForwardedGhostButton = React.forwardRef<HTMLDivElement, GhostButtonProps>(GhostButton);

export {ForwardedGhostButton as GhostButton};
