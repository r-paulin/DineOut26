import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Show} from "@bolteu/kalep-react-icons";

import {GhostButton} from "./GhostButton";

export default {
    title: "Inputs/GhostButton",
    tags: ["autodocs"],
    component: GhostButton,
} as Meta<typeof GhostButton>;

const Template: StoryFn<typeof GhostButton> = (args: any) => <GhostButton {...args}>{args.children}</GhostButton>;

export const Primary = Template.bind({});
Primary.args = {
    children: "Ghost Button",
    onClick: () => alert("test"),
    disabled: false,
};

function logClicked() {
    console.log("Clicked!");
}

export const InTextField = () => (
    <div className="flex flex-col gap-6 font-sans">
        <div className="flex h-11 w-64 items-center gap-2 rounded-lg border border-solid border-neutral-secondary px-4">
            <input
                type="password"
                placeholder="Password"
                className="h-8 flex-grow border-0 font-sans text-size-inherit"
            />
            <GhostButton
                overrideClassName="p-2 -mr-3 text-primary"
                onClick={logClicked}
                aria-label="toggle show password"
            >
                <Show />
            </GhostButton>
        </div>

        <div className={`
          flex h-11 w-96 items-center justify-between gap-2 rounded-lg border border-solid border-neutral-secondary px-4
        `}>
            <input type="password" placeholder="Password" className="h-8 border-0 font-sans text-size-inherit" />
            <GhostButton overrideClassName="text-primary uppercase text-sm font-semibold" onClick={logClicked}>
                Reveal
            </GhostButton>
        </div>
    </div>
);
