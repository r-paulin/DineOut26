import * as React from "react";

import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {GhostButton as Button} from "../GhostButton";

describe("Button test suite", () => {
    test("Has role='button'", () => {
        const handler = vi.fn();
        render(<Button onClick={handler}>lolo</Button>);
        expect(screen.getByRole("button", {name: "lolo"})).toBeInTheDocument();
    });

    test("'id' attribute is properly reflected", () => {
        const handler = vi.fn();
        const {rerender} = render(<Button onClick={handler}>lolo</Button>);

        // The 'id' is absent, and therefore no attribute should show up.
        expect(screen.getByRole("button", {name: "lolo"})).not.toHaveAttribute("id");

        const testId = "button-test-id";
        rerender(
            <Button onClick={handler} id={testId}>
                lolo
            </Button>,
        );
        expect(screen.getByRole("button", {name: "lolo"})).toHaveAttribute("id", testId);
    });

    test("Click event triggers onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<Button onClick={handler}>lolo</Button>);
        await user.click(screen.getByRole("button", {name: "lolo"}));
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("disabled prop blocks onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        const {rerender} = render(<Button onClick={handler}>lolo</Button>);
        await user.click(screen.getByRole("button", {name: "lolo"}));
        expect(handler).toHaveBeenCalledTimes(1);
        rerender(
            <Button onClick={handler} disabled>
                lolo
            </Button>,
        );
        await user.click(screen.getByRole("button", {name: "lolo"}));
        expect(handler).toHaveBeenCalledTimes(1);
        expect(screen.getByRole("button", {name: "lolo"})).toHaveAttribute("aria-disabled", "true");
    });

    // https://www.w3.org/TR/wai-aria-practices/#keyboard-interaction-3
    test("Tab onto button and trigger onClick handler with Space", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<Button onClick={handler}>lolo</Button>);

        await user.tab();
        expect(screen.getByRole("button", {name: "lolo"})).toHaveFocus();

        await user.keyboard("[Space]");

        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("Tab onto button and trigger onClick handler with Enter", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<Button onClick={handler}>lolo</Button>);

        await user.tab();
        expect(screen.getByRole("button", {name: "lolo"})).toHaveFocus();

        await user.keyboard("[Enter]");

        expect(handler).toHaveBeenCalledTimes(1);
    });
});
