import * as React from "react";

import type {KalepIcon, KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import {cx} from "@/helpers/utils/cx";

const NOOP = () => {};

type Size = "sm" | "md" | "lg";
type Variant = "primary" | "secondary" | "danger" | "tertiary" | "floating" | "static-light";
type State = "disabled" | "loading";

const colors = [
    "text-primary",
    "text-secondary",
    "text-tertiary",
    "text-action-primary",
    "text-action-secondary",
    "text-danger-primary",
    "text-danger-secondary",
    "text-warning-primary",
    "text-warning-secondary",
    "text-positive-primary",
    "text-positive-secondary",
    "text-promo-primary",
    "text-promo-secondary",
    "text-link-primary",
    "text-link-secondary",
    "text-primary-inverted",
] as const;
export type ColorVariant = (typeof colors)[number] | string;

export interface ButtonProps extends Omit<React.ComponentPropsWithoutRef<"button">, "className"> {
    size?: Size;
    loading?: boolean;
    fullWidth?: boolean;
    startIcon?: KalepIconElement;
    endIcon?: KalepIconElement;
    children?: React.ReactNode;
    overrideClassName?: string;
    variant?: Variant;
    /**
     * It's possible to change the content color of the `static-light` variant.
     * It accepts either valid a CSS color expression (e.g. #ffcc00)
     * or a Kalep semantic color name (e.g. text-danger-primary)
     */
    contentColor?: ColorVariant;
}

const sizes: Record<Size, string> = {
    sm: "px-4 py-0 h-9 gap-1 bolt-font-body-s-accent",
    md: "px-6 py-0 h-12 gap-2 bolt-font-body-m-accent",
    lg: "px-6 py-0 h-14 gap-2 bolt-font-body-l-accent",
};

const variants: Record<Variant, string> = {
    primary: "bg-action-primary hover:bg-active-action-primary active:bg-active-action-primary text-static-key-light",
    secondary: "bg-neutral-secondary hover:bg-active-neutral-secondary active:bg-active-neutral-secondary text-primary",
    danger: "bg-danger-primary hover:bg-active-danger-primary active:bg-active-danger-primary text-static-key-light",
    tertiary: "bg-special-nulled hover:bg-action-secondary active:bg-action-secondary text-action-primary",
    floating: "bg-layer-floor-2 shadow-md hover:shadow active:shadow disabled:shadow-md text-primary",
    "static-light":
        "bg-static-key-light hover:bg-static-active-key-light active:bg-static-active-key-light text-static-key-dark",
};

const states: Record<State, string> = {
    disabled:
        "bg-neutral-secondary hover:bg-neutral-secondary active:bg-neutral-secondary text-tertiary cursor-not-allowed",
    loading: "cursor-progress text-transparent",
};

function mapDisabledStateToStyle(disabled: boolean, variant: Variant) {
    if (disabled) {
        if (variant === "static-light") {
            return "bg-static-key-light hover:bg-static-key-light active:bg-static-key-light text-static-tertiary-dark cursor-not-allowed";
        }
        return states.disabled;
    }

    return "active:scale-975 active:ease-in-out active:duration-100";
}

const loadingSpinnerColor: Record<Variant, string> = {
    primary: "text-static-key-light",
    secondary: "text-primary",
    danger: "text-static-key-light",
    tertiary: "text-action-primary",
    floating: "text-primary",
    "static-light": "text-static-key-dark",
};

/**
 * Extend a KalepIconElement with given props.
 *
 * @returns KalepIconElement
 */
function withProps(icon: KalepIconElement, props: Partial<KalepIcon>) {
    return React.cloneElement(icon, props);
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(function createButton(
    {
        children,
        size = "md",
        variant = "primary",
        type = "button",
        disabled = false,
        loading = false,
        fullWidth = false,
        startIcon,
        endIcon,
        onClick,
        contentColor,
        overrideClassName,
        ...props
    }: ButtonProps,
    ref: React.Ref<HTMLButtonElement>,
) {
    // it does not make sense to be disabled and loading at the same time.
    const isLoading = !disabled && loading;

    const buttonContent = (
        <>
            {startIcon && withProps(startIcon, {size, className: "-ms-1"})}
            {children}
            {endIcon && withProps(endIcon, {size, className: "-me-1"})}
        </>
    );

    // eslint-disable-next-line react-hooks/rules-of-hooks -- forwardRef inner function confuses linter
    const hasSemanticContentColor = React.useMemo(() => colors.find((color) => color === contentColor), [contentColor]);

    // eslint-disable-next-line react-hooks/rules-of-hooks -- forwardRef inner function confuses linter
    const style = React.useMemo(() => {
        switch (variant) {
            case "primary": {
                return {
                    backgroundImage: "var(--color-bg-action-primary)", // allows gradient backgrounds
                };
            }

            case "static-light": {
                if (!hasSemanticContentColor && !disabled && contentColor) {
                    return {
                        color: contentColor,
                    };
                }
                return {};
            }

            default: {
                return {};
            }
        }
    }, [variant, hasSemanticContentColor, contentColor, disabled]);

    return (
        <button
            type={type}
            disabled={disabled}
            onClick={isLoading ? NOOP : onClick}
            className={cx(
                /* resets */ "cursor-pointer border-none",
                "relative flex flex-none items-center justify-center",
                "rounded-full duration-150 ease-linear",
                fullWidth ? "w-full" : "w-fit",
                sizes[size],
                variants[variant],
                variant === "static-light" && contentColor && hasSemanticContentColor ? contentColor : null,
                mapDisabledStateToStyle(disabled, variant),
                isLoading && states.loading,
                overrideClassName,
            )}
            style={style}
            ref={ref}
            {...props}
        >
            {buttonContent}
            {isLoading ? (
                <div data-kalep-button-spinner className={cx("absolute", loadingSpinnerColor[variant])}>
                    <SpinnerIcon className={cx("block animate-spin")} size={size} />
                </div>
            ) : null}
        </button>
    );
});
