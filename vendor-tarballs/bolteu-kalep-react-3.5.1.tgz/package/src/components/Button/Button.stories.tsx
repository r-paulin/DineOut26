import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Alert, Heart, Lock, RideStart} from "@bolteu/kalep-react-icons";

import {cx} from "@/helpers/utils/cx";

import {Button} from "./index";

export default {
    title: "Inputs/Button",
    component: Button,
    tags: ["autodocs"],
    argTypes: {
        endIcon: {
            options: ["None", "Lock", "Alert", "RideStart"],
            mapping: {
                None: undefined,
                Lock: <Lock />,
                Alert: <Alert />,
                RideStart: <RideStart />,
            },
        },
        startIcon: {
            options: ["None", "Lock", "Alert", "RideStart"],
            mapping: {
                None: undefined,
                Lock: <Lock />,
                Alert: <Alert />,
                RideStart: <RideStart />,
            },
        },
    },
} as Meta<typeof Button>;

const Template: StoryFn<typeof Button> = (args: any) => <Button {...args}>{args.children}</Button>;

export const Default = Template.bind({});
Default.args = {
    children: "Click me",
};

export const Sizes = () => (
    <div className={cx("flex items-center gap-2")}>
        <Button size="sm">Small</Button>
        <Button size="md">Medium</Button>
        <Button size="lg">Large</Button>
    </div>
);

export const Variants = () => (
    <div>
        <div className={cx("mb-10 flex items-center gap-2")}>
            <Button variant="primary">Primary</Button>
            <Button variant="secondary">Secondary</Button>
            <Button variant="tertiary">Tertiary</Button>
            <Button variant="floating">Floating</Button>
            <Button variant="danger">Danger</Button>
        </div>
        <div className={cx("flex items-center gap-4 bg-promo-primary p-8")}>
            <Button variant="static-light">Static Light</Button>
            <p className="text-static-primary-light">
                Designed for cases like promo banners which may require light buttons that remain light even in dark
                mode
            </p>
        </div>
    </div>
);

export const Disabled = () => (
    <div>
        <div className={cx("mb-10 flex items-center gap-2")}>
            <Button variant="primary" disabled>
                Primary
            </Button>
            <Button variant="secondary" disabled>
                Secondary
            </Button>
            <Button variant="tertiary" disabled>
                Tertiary
            </Button>
            <Button variant="floating" disabled>
                Floating
            </Button>
            <Button variant="danger" disabled>
                Danger
            </Button>
        </div>
        <div className={cx("flex items-center gap-4 bg-promo-primary p-8")}>
            <Button variant="static-light" disabled>
                Static Light
            </Button>
            <p className="text-static-primary-light">
                Designed for cases like promo banners which may require light buttons that remain light even in dark
                mode
            </p>
        </div>
    </div>
);

export const Loading = () => (
    <div>
        <div className={cx("mb-10 flex items-center gap-2")}>
            <Button variant="primary" loading>
                Primary
            </Button>
            <Button variant="secondary" loading>
                Secondary
            </Button>
            <Button variant="tertiary" loading>
                Tertiary
            </Button>
            <Button variant="floating" loading>
                Floating
            </Button>
            <Button variant="danger" loading>
                Danger
            </Button>
        </div>
        <div className={cx("flex items-center gap-4 bg-promo-primary p-8")}>
            <Button variant="static-light" loading>
                Static Light
            </Button>
            <p className="text-static-primary-light">
                Designed for cases like promo banners which may require light buttons that remain light even in dark
                mode
            </p>
        </div>
    </div>
);

export const IconSlots = () => (
    <div className={cx("flex items-center gap-2")}>
        <Button startIcon={<Heart />}>Start</Button>
        <Button endIcon={<Heart />}>End</Button>
    </div>
);
