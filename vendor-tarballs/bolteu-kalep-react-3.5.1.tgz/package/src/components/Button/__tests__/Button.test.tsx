import * as React from "react";

import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Button} from "../index";

describe("Button test suite", () => {
    test("Default button has type='button'", () => {
        render(<Button>lolo</Button>);
        expect(screen.getByRole("button", {name: "lolo"})).toHaveAttribute("type", "button");
    });

    test("Passed button type is preserved", () => {
        render(<Button type="reset">lolo</Button>);
        expect(screen.getByRole("button", {name: "lolo"})).toHaveAttribute("type", "reset");
    });

    test("Click event triggers onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<Button onClick={handler}>lolo</Button>);
        await user.click(screen.getByRole("button", {name: "lolo"}));
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("disabled prop blocks onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        const {rerender} = render(<Button onClick={handler}>lolo</Button>);
        await user.click(screen.getByRole("button", {name: "lolo"}));
        expect(handler).toHaveBeenCalledTimes(1);
        rerender(
            <Button onClick={handler} disabled>
                lolo
            </Button>,
        );
        await user.click(screen.getByRole("button", {name: "lolo"}));
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("loading prop blocks onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        const {rerender} = render(<Button onClick={handler}>lolo</Button>);
        await user.click(screen.getByRole("button"));
        expect(handler).toHaveBeenCalledTimes(1);
        rerender(
            <Button onClick={handler} loading>
                lolo
            </Button>,
        );
        await user.click(screen.getByRole("button"));
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("Tabbing onto button triggers onFocus", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<Button onFocus={handler}>lolo</Button>);

        await user.tab();
        expect(screen.getByRole("button", {name: "lolo"})).toHaveFocus();
        expect(handler).toHaveBeenCalledTimes(1);
    });

    // https://www.w3.org/TR/wai-aria-practices/#keyboard-interaction-3
    test("Tab onto button and trigger onClick handler with Space", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<Button onClick={handler}>lolo</Button>);

        await user.tab();
        expect(screen.getByRole("button", {name: "lolo"})).toHaveFocus();

        await user.keyboard("[Space]");

        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("Tab onto button and trigger onClick handler with Enter", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<Button onClick={handler}>lolo</Button>);

        await user.tab();
        expect(screen.getByRole("button", {name: "lolo"})).toHaveFocus();

        await user.keyboard("[Enter]");

        expect(handler).toHaveBeenCalledTimes(1);
    });
});
