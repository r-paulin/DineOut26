import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import Heart from "@bolteu/kalep-react-icons/dist/Heart";

import {Button} from "@/components/Button";
import {Dialog} from "@/components/Dialog";
import {IconButton} from "@/components/IconButton";
import {IconView} from "@/components/IconView";

import {Typography} from "../Typography";
import type {TooltipProps} from "./index";
import {Tooltip} from "./index";

export default {
    title: "Data Display/Tooltip",
    component: Tooltip,
    tags: ["autodocs"],
} as Meta<typeof Tooltip>;

const Template: StoryFn<typeof Tooltip> = (args: TooltipProps) => (
    <div className="p-4">
        <Tooltip {...args} />
    </div>
);

export const Default = Template.bind({});
Default.args = {content: "Yes, I do!", children: <Button>I have tooltip!</Button>, placement: "bottom"};

export const WithControlledState = ({isDisabled}: {isDisabled: boolean}) => {
    const [isOpen, setIsOpen] = React.useState(false);

    const toggle = React.useCallback(() => setIsOpen((flag) => !flag), [setIsOpen]);

    return (
        <div className="flex flex-col gap-4 p-4">
            <div>
                <Tooltip content="A tooltip" placement="bottom" isOpen={isOpen}>
                    <Button disabled={isDisabled} onClick={toggle}>
                        Tooltip button
                    </Button>
                </Tooltip>
            </div>
        </div>
    );
};

WithControlledState.args = {
    isDisabled: false,
};

export const WithIconButton = () => {
    return (
        <div className="p-4">
            <IconButton icon={<Heart />} aria-label="Like" labelType="tooltip" />
        </div>
    );
};

export const WithIconView = () => {
    return (
        <div className="p-4">
            <Tooltip content="A tooltip" placement="bottom">
                <IconView size="md" color="text-action-primary" icon={<Heart />} alt="Like" />
            </Tooltip>
        </div>
    );
};

export const InsideDialog = () => {
    const [isOpen, setIsOpen] = React.useState(false);
    const openDialog = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const closeDialog = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <div className="p-4">
            <div style={{height: 1800}}>
                ↓ Scroll down to see the button to open a dialog with a tooltip. This mimics a page with scroll ↓
            </div>
            <Tooltip content="This will open the dialog!" placement="top">
                <Button variant="secondary" onClick={openDialog}>
                    Open Dialog
                </Button>
            </Tooltip>
            <Dialog isOpen={isOpen} onRequestClose={closeDialog} title="Hot Unicorn!">
                <Dialog.Content>
                    <Typography>
                        We’re extremely excited to announce that we were chosen as Europe’s Hottest Unicorn at last
                        week’s Europas awards — the most prestigious awards ceremony in the European startup calendar!
                    </Typography>
                </Dialog.Content>
                <Dialog.Footer>
                    <Tooltip content="This will close the dialog!" placement="right">
                        <Button onClick={closeDialog}>Alright!</Button>
                    </Tooltip>
                </Dialog.Footer>
            </Dialog>
        </div>
    );
};
