import * as React from "react";

import {Tooltip as RadixTooltip} from "radix-ui";

import {KALEP_MODAL_CONTENT_ID} from "@/components/_internal/Modal";
import {KALEP_BOTTOMSHEET_CONTENT_ID} from "@/components/BottomSheet/BottomSheet";
import {cx} from "@/helpers/utils/cx";

import type {Placement, RadixPlacement, TooltipProps} from "./Tooltip.types";

const DEFAULT_OFFSET = 4;
const DEFAULT_DELAY = 25;
const DEFAULT_PLACEMENT = "top";

const positions: Record<Placement, RadixPlacement> = {
    top: "top",
    bottom: "bottom",
    left: "left",
    right: "right",
    start: "left",
    end: "right",
};

export function Tooltip({
    isOpen,
    onOpenChange,
    children,
    content,
    delay = DEFAULT_DELAY,
    placement = DEFAULT_PLACEMENT,
    offset = DEFAULT_OFFSET,
    boundaryElement,
}: TooltipProps): JSX.Element {
    const triggerRef = React.useRef<HTMLButtonElement>(null);
    const controlledProps = isOpen !== undefined ? {open: isOpen} : {};

    return content.length ? (
        <RadixTooltip.Provider delayDuration={delay}>
            <RadixTooltip.Root onOpenChange={onOpenChange} {...controlledProps}>
                <RadixTooltip.Trigger asChild ref={triggerRef}>
                    {children}
                </RadixTooltip.Trigger>
                <RadixTooltip.Portal
                    container={
                        boundaryElement ||
                        triggerRef?.current?.closest("dialog") ||
                        triggerRef?.current?.closest(`#${KALEP_MODAL_CONTENT_ID}`) ||
                        triggerRef?.current?.closest(`#${KALEP_BOTTOMSHEET_CONTENT_ID}`) ||
                        undefined
                    }
                >
                    <RadixTooltip.Content
                        side={positions[placement]}
                        sideOffset={offset}
                        className={cx(
                            "w-max max-w-[280px] rounded bg-neutral-primary px-3 py-2 text-primary-inverted ease-out",
                            "bolt-font-body-s-regular break-words text-left",
                            "z-tooltip",
                        )}
                    >
                        {content}
                        <RadixTooltip.Arrow className={cx("fill-[var(--color-bg-neutral-primary)]")} />
                    </RadixTooltip.Content>
                </RadixTooltip.Portal>
            </RadixTooltip.Root>
        </RadixTooltip.Provider>
    ) : (
        children
    );
}
