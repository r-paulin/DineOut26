import type {ReactElement} from "react";

export type Placement = "bottom" | "top" | "left" | "start" | "right" | "end";
export type RadixPlacement = "bottom" | "top" | "left" | "right";

export interface TooltipProps {
    content: string;
    children: ReactElement;
    isOpen?: boolean;
    onOpenChange?: (isOpen: boolean) => void;
    delay?: number;
    offset?: number;
    placement?: Placement;
    boundaryElement?: HTMLElement;
}
