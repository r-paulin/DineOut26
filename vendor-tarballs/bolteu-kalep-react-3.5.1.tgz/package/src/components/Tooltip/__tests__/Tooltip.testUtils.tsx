import * as React from "react";

import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import type {TooltipProps} from "..";
import {Tooltip} from "..";

export * from "@testing-library/react";

export const defaultProps: TooltipProps = {
    children: <button type="button">Hello</button>,
    content: "Hello from tootip!",
};

export const user = userEvent.setup({delay: null});

export function renderTooltip(props: Partial<TooltipProps> = {}) {
    const utils = render(<Tooltip {...defaultProps} {...props} />);

    return utils;
}

export async function hoverTrigger(): Promise<void> {
    await user.hover(getTrigger());
}

export async function unhoverTrigger(): Promise<void> {
    await user.unhover(getTrigger());
}

export async function focusTrigger(): Promise<void> {
    await user.tab();
}

export async function blurTrigger(): Promise<void> {
    if (document.activeElement === getTrigger()) {
        await user.tab();
    }
}

export async function clickTrigger(): Promise<void> {
    await user.click(getTrigger());
}

export function getTrigger(): HTMLElement {
    return screen.getByRole("button", {name: defaultProps.children.props.children});
}
