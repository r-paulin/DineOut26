import * as React from "react";

import Check from "@bolteu/kalep-react-icons/dist/Check";

import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";

export interface CheckboxProps extends Omit<React.ComponentPropsWithoutRef<"input">, "className"> {
    /**
     * Default checked value for uncontrolled component.
     * Has no effect if checked prop is provided.
     */
    defaultChecked?: boolean;
    /**
     * Checkbox can be in an invalid state.
     */
    error?: boolean;
    /**
     * Sets the component to a indeterminate or "mixed" state.
     * Refer to usage guide in Figma.
     */
    indeterminate?: boolean;
    /**
     * Setting a value for checked makes the component controlled.
     */
    checked?: boolean;
    /**
     * When label prop is set the checkbox will be wrapped in a <label> element
     */
    label?: string;
    /**
     * If Checkbox does not have an associated label or labelledby link provide
     * an accessible label in aria-label.
     */
    "aria-label"?: string;
}

const states: Record<"error" | "valid", string> = {
    valid: "border-neutral-primary peer-checked:bg-action-primary peer-indeterminate:bg-action-primary peer-hover:border-active-neutral-primary peer-checked:peer-hover:bg-active-action-primary peer-indeterminate:peer-hover:bg-active-action-primary",
    error: "border-danger-primary peer-checked:bg-danger-primary peer-indeterminate:bg-danger-primary peer-hover:border-active-danger-primary peer-checked:peer-hover:bg-active-danger-primary peer-indeterminate:peer-hover:bg-active-danger-primary",
};

const labelStates: Record<"error" | "valid", string> = {
    valid: "text-primary",
    error: "text-danger-primary",
};

export const Checkbox = React.forwardRef<HTMLInputElement, CheckboxProps>((props, forwardedRef) => {
    const internalRef = React.createRef<HTMLInputElement>();

    const {
        checked,
        disabled = false,
        error = false,
        defaultChecked,
        indeterminate = false,
        label,
        onChange,
        ...rest
    } = props;

    React.useEffect(() => {
        if (internalRef.current) {
            internalRef.current.indeterminate = indeterminate;
        }
    }, [indeterminate, internalRef]);

    const checkboxElement = (
        <span className={cx("relative inline-grid h-6 w-6 shrink-0 grid-cols-1 grid-rows-1 place-items-center p-px")}>
            <input
                type="checkbox"
                checked={checked}
                defaultChecked={defaultChecked}
                disabled={disabled}
                onChange={onChange}
                ref={mergeRefs([internalRef, forwardedRef])}
                aria-invalid={error}
                {...rest}
                className={cx("peer", [
                    "m-0 h-full w-full appearance-none",
                    disabled ? "cursor-not-allowed" : "cursor-pointer",
                    "disabled:pointer-events-none",
                ])}
            />
            <span
                className={cx(
                    "absolute inset-px rounded-sm", // position absolutely 1px from each edge
                    "transition-colors duration-150 ease-linear", // animate color changes
                    "pointer-events-none", // block pointer events from this visual element
                    "border-2 border-solid border-neutral-primary bg-special-nulled text-static-key-light", // default unchecked
                    "peer-checked:border-0", // checked
                    "peer-indeterminate:border-0", // indeterminate
                    "peer-disabled:peer-hover:bg-special-disabled", // disabled hover
                    "peer-disabled:border-0 peer-disabled:bg-special-disabled peer-disabled:text-tertiary", // disabled
                    error ? states.error : states.valid,
                )}
            />
            <Check
                height="22"
                width="22"
                className={cx(
                    `
                      pointer-events-none absolute row-start-1 hidden text-static-key-light
                      peer-checked:inline
                    `,
                    "peer-disabled:text-tertiary",
                )}
            />
            <Dash
                className={cx(
                    `
                      pointer-events-none absolute row-start-1 hidden text-static-key-light
                      peer-indeterminate:inline
                    `,
                    "peer-disabled:text-tertiary",
                )}
            />
        </span>
    );

    if (label) {
        return (
            <label
                className={cx(
                    "bolt-font-body-m-regular inline-flex gap-2",
                    disabled ? "cursor-not-allowed" : "cursor-pointer",
                    error ? labelStates.error : labelStates.valid,
                )}
            >
                {checkboxElement}
                {label}
            </label>
        );
    }

    return checkboxElement;
});
Checkbox.displayName = "Checkbox";

function Dash({className}: {className?: string}) {
    return (
        <svg
            width="12"
            height="2"
            viewBox="0 0 12 2"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className={className}
        >
            <path
                d="M11.25 2H0.75C0.3 2 0 1.6 0 1C0 0.4 0.3 0 0.75 0H11.25C11.7 0 12 0.4 12 1C12 1.6 11.625 2 11.25 2Z"
                fill="currentColor"
            />
        </svg>
    );
}
