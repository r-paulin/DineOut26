import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Checkbox} from "./Checkbox";

export default {
    title: "Inputs/Checkbox",
    component: Checkbox,
    tags: ["autodocs"],
    argTypes: {
        checked: {type: {name: "boolean", required: false}},
        disabled: {type: {name: "boolean", required: false}},
        error: {type: {name: "boolean", required: false}},
    },
} as Meta<typeof Checkbox>;

const Template: StoryFn<typeof Checkbox> = (args: any) => <Checkbox {...args} />;

export const Default = Template.bind({});
Default.args = {
    label: "Pick me",
};

export const Error = Template.bind({});
Error.args = {
    ...Default.args,
    error: true,
};

export const Disabled = Template.bind({});
Disabled.args = {
    ...Default.args,
    disabled: true,
};

export const CustomLabel = () => (
    <label className="inline-flex cursor-pointer gap-2 font-sans text-base font-semibold">
        <Checkbox />
        <span>Pick me</span>
    </label>
);

export const WithoutLabel = Template.bind({});
WithoutLabel.args = {
    ...Default.args,
    label: undefined,
    "aria-label": "But with aria-label for screen readers to pick it up.",
};

export const Indeterminate = () => {
    const [isChild1Checked, setChild1] = React.useState(false);
    const [isChild2Checked, setChild2] = React.useState(false);

    const isParentChecked = isChild1Checked && isChild2Checked;
    const isParentIndeterminate = isChild1Checked !== isChild2Checked;

    const onChange1: React.ChangeEventHandler<HTMLInputElement> = React.useCallback(
        (e) => setChild1(e.target.checked),
        [setChild1],
    );
    const onChange2: React.ChangeEventHandler<HTMLInputElement> = React.useCallback(
        (e) => setChild2(e.target.checked),
        [setChild2],
    );
    const onParentChange: React.ChangeEventHandler<HTMLInputElement> = React.useCallback((e) => {
        setChild1(e.target.checked);
        setChild2(e.target.checked);
    }, []);

    return (
        <form>
            <ul className="list-none p-0">
                <li>
                    <Checkbox
                        checked={isParentChecked}
                        indeterminate={isParentIndeterminate}
                        onChange={onParentChange}
                        label="Parent"
                    />

                    <ul className="list-none pl-6 pt-2">
                        <li className="mb-2">
                            <Checkbox checked={isChild1Checked} onChange={onChange1} label="Child 1" />
                        </li>
                        <li>
                            <Checkbox checked={isChild2Checked} onChange={onChange2} label="Child 2" />
                        </li>
                    </ul>
                </li>
            </ul>
        </form>
    );
};

export const CustomColored = () => {
    return (
        <label
            className="inline-flex cursor-pointer gap-2 font-sans text-base"
            style={
                {
                    "--color-bg-action-primary": "var(--color-bg-promo-primary)",
                    "--color-bg-active-action-primary": "var(--color-bg-active-promo-primary)",
                } as React.CSSProperties
            }
        >
            <Checkbox />

            <span>Pick me</span>
        </label>
    );
};
