import type {AlertContextType} from "@/components/baseui-components/Alert/context/AlertProvider";

export type AlertState = Pick<AlertContextType, "severity" | "visible">;
export type Severity = "error" | "warning" | "promotion" | "success" | "info";
