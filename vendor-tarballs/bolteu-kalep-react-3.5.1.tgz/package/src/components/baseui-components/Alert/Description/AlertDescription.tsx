import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";
import {useIsoLayoutEffect} from "@base-ui/utils/useIsoLayoutEffect";

import type {AlertState} from "@/components/baseui-components/Alert/alert.types";
import {useAlertContext} from "@/components/baseui-components/Alert/context/useAlertContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

export interface AlertDescriptionProps extends Omit<useRender.ComponentProps<"div">, "className"> {
    className?: string | ((state: AlertState) => string);
}
export const AlertDescription = React.forwardRef(function AlertDescription(
    props: AlertDescriptionProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, render, id: idProp, ...otherComponentProps} = props;

    const {severity, setDescriptionId, visible, titleId} = useAlertContext();
    const state: AlertState = {severity, visible};
    const generatedId = useId();
    const id = idProp ?? `kalep-alert-content-${generatedId}`;
    useIsoLayoutEffect(() => {
        setDescriptionId(id);
        return () => {
            setDescriptionId(undefined);
        };
    }, [setDescriptionId, id]);
    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx(
            typeof titleId !== "undefined" ? "text-secondary" : "text-primary",
            addConsumerClasses(state, className),
        ),
        id,
    };
    return useRender({
        ref,
        render,
        defaultTagName: "div",
        state,
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });
});
