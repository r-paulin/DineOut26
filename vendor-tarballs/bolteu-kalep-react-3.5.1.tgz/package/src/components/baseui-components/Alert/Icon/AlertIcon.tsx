import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import type {KalepIcon} from "@bolteu/kalep-react-icons";
import KalepAlertIcon from "@bolteu/kalep-react-icons/dist/Alert";
import KalepCheckCircleFill from "@bolteu/kalep-react-icons/dist/CheckCircle";
import KalepInfoCircle from "@bolteu/kalep-react-icons/dist/InfoCircle";
import KalepOffer from "@bolteu/kalep-react-icons/dist/Offer";

import type {AlertState} from "@/components/baseui-components/Alert/alert.types";
import {colors} from "@/components/baseui-components/Alert/consts";
import {useAlertContext} from "@/components/baseui-components/Alert/context/useAlertContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface AlertIconProps extends Omit<useRender.ComponentProps<"span">, "className"> {
    className?: string | ((state: AlertState) => string);
}

function Icon() {
    const commonIconProps: KalepIcon = {
        "aria-hidden": true,
        size: "lg",
        className: cx("block"),
    };
    const {severity} = useAlertContext();
    switch (severity) {
        case "error":
            return <KalepAlertIcon {...commonIconProps} />;
        case "info":
            return <KalepInfoCircle {...commonIconProps} />;
        case "success":
            return <KalepCheckCircleFill {...commonIconProps} />;
        case "promotion":
            return <KalepOffer {...commonIconProps} />;
        case "warning":
            return <KalepAlertIcon {...commonIconProps} />;
        default:
            return null;
    }
}

export const AlertIcon = React.forwardRef(function AlertIcon(
    props: AlertIconProps,
    ref: React.ForwardedRef<HTMLElement>,
) {
    const {className, children, render, ...otherComponentProps} = props;
    const {severity, visible} = useAlertContext();
    const state: AlertState = {severity, visible};

    const defaultProps: useRender.ElementProps<"span"> = {
        className: cx(colors.iconColors[severity], addConsumerClasses(state, className)),
        children: children || <Icon />,
    };
    return useRender({
        ref,
        state,
        render,
        defaultTagName: "span",
        props: mergeProps<"span">(defaultProps, otherComponentProps),
    });
});
