import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";
import {useControlled} from "@base-ui/utils/useControlled";

import type {AlertState, Severity} from "@/components/baseui-components/Alert/alert.types";
import {colors} from "@/components/baseui-components/Alert/consts";
import {AlertContext} from "@/components/baseui-components/Alert/context/AlertProvider";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

export interface AlertRootProps extends Omit<useRender.ComponentProps<"div">, "className"> {
    severity?: Severity;
    className?: string | ((state: AlertState) => string);
    visible?: boolean;
    defaultVisible?: boolean;
    onVisibleChange?: (visible: boolean) => void;
}
export const AlertRoot = React.forwardRef(function AlertRoot(
    props: AlertRootProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {
        severity = "success",
        className,
        visible: visibilityProp,
        defaultVisible = true,
        render,
        id: idProp,
        onVisibleChange: onVisibleChangeProp,
        ...otherComponentProps
    } = props;
    const [visible, setVisible] = useControlled({
        controlled: visibilityProp,
        default: defaultVisible,
        name: "Alert",
        state: "visible",
    });
    const onVisibleChange = React.useCallback(
        (newVisible: boolean) => {
            onVisibleChangeProp?.(newVisible);
        },
        [onVisibleChangeProp],
    );

    const [descriptionId, setDescriptionId] = React.useState<string | undefined>(undefined);
    const [titleId, setTitleId] = React.useState<string | undefined>(undefined);
    const generatedId = useId();
    const id = idProp ?? `kalep-alert-${generatedId}`;
    const state: AlertState = {severity, visible};
    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx(
            "flex w-full gap-4 p-4",
            "rounded-md border border-solid border-transparent",
            "items-start",
            "bolt-font-body-s-regular",
            colors.background[severity],
            addConsumerClasses(state, className),
        ),
        id,
        role: "region",
        "aria-describedby": titleId ? descriptionId : undefined,
        "aria-labelledby": titleId || descriptionId || undefined,
    };

    const element = useRender({
        defaultTagName: "div",
        ref,
        render,
        state,
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });

    const contextValue = React.useMemo(
        () => ({
            severity,
            visible,
            setVisible,
            setDescriptionId,
            setTitleId,
            descriptionId,
            titleId,
            onVisibleChange,
        }),
        [descriptionId, setVisible, severity, titleId, visible, onVisibleChange],
    );
    return <AlertContext.Provider value={contextValue}>{visible ? element : null}</AlertContext.Provider>;
});
