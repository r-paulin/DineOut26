import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import type {AlertState} from "@/components/baseui-components/Alert/alert.types";
import {colors} from "@/components/baseui-components/Alert/consts";
import {useAlertContext} from "@/components/baseui-components/Alert/context/useAlertContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface AlertActionProps extends Omit<
    useRender.ComponentProps<"button", AlertState>,
    "className" | "onClick"
> {
    className?: string | ((state: AlertState) => string);
    disabled?: boolean;
    onClick?: (e: React.MouseEvent | React.KeyboardEvent) => void;
}

export const AlertAction = React.forwardRef(function AlertAction(
    props: AlertActionProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, disabled, onClick, render, ...otherComponentProps} = props;
    const onKeyDown = React.useCallback(
        (event: React.KeyboardEvent) => {
            if (event.key === "Enter" || event.key === " ") {
                event.preventDefault();
                onClick?.(event);
            }
        },
        [onClick],
    );
    const {severity, visible} = useAlertContext();
    const state: AlertState = {severity, visible};

    const defaultProps: useRender.ElementProps<"button"> = {
        className: cx(
            "appearance-none border-none bg-transparent p-0",
            "mt-4",
            "inline-block",
            "bolt-font-body-m-accent",
            "cursor-pointer",
            "active:scale-975 active:duration-100 active:ease-in-out",
            disabled && "pointer-events-none",
            colors.action[severity],
            addConsumerClasses(state, className),
        ),
        onKeyDown: disabled ? undefined : onKeyDown,
        onClick: disabled ? undefined : onClick,
        tabIndex: disabled ? -1 : 0,
    };
    return useRender({
        defaultTagName: "button",
        state,
        render,
        ref,
        props: mergeProps(defaultProps, otherComponentProps),
    });
});
