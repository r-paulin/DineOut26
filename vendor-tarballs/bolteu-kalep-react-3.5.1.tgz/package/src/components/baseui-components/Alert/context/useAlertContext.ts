import * as React from "react";

import {AlertContext} from "@/components/baseui-components/Alert/context/AlertProvider";

export function useAlertContext() {
    const context = React.useContext(AlertContext);
    if (!context) {
        throw new Error("useAlertContext must be used within an Alert component");
    }
    return context;
}
