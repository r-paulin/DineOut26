import {AlertAction} from "./Action/AlertAction";
import {AlertCloseButton} from "./Close/AlertClose";
import {AlertContent} from "./Content/AlertContent";
import {AlertDescription} from "./Description/AlertDescription";
import {AlertIcon} from "./Icon/AlertIcon";
import {AlertRoot} from "./Root/AlertRoot";
import {AlertTitle} from "./Title/AlertTitle";

/**
 * Alert compound component.
 *
 * Provides a set of subcomponents for building alert messages:
 * - `Alert.Root`: the main container
 * - `Alert.Content`: content wrapper for title and description
 * - `Alert.Title`: title of the alert
 * - `Alert.Description`: description of the alert
 * - `Alert.Icon`: icon representing the alert type
 * - `Alert.Action`: action button for the alert
 * - `Alert.Close`: button to close the alert
 *
 * ### Composition guide
 * ```tsx
 *   <Alert.Root severity={severity}>
 *      <Alert.Icon />
 *      <Alert.Content>
 *          <Alert.Title>TITLE</Alert.Title>
 *          <Alert.Description>CONTENT</Alert.Description>
 *          <Alert.Action onClick={onActionClick}>Action button</Alert.Action>
 *      </Alert.Content>
 *      <Alert.Close onClick={onClose} />
 *   </Alert.Root>
 * ```
 */
export const Alert = {
    Root: AlertRoot,
    Title: AlertTitle,
    Action: AlertAction,
    Close: AlertCloseButton,
    Description: AlertDescription,
    Icon: AlertIcon,
    Content: AlertContent,
};

export {useAlertContext} from "./context/useAlertContext";

Alert.Root.displayName = "Alert.Root";
Alert.Title.displayName = "Alert.Title";
Alert.Action.displayName = "Alert.Action";
Alert.Close.displayName = "Alert.Close";
Alert.Description.displayName = "Alert.Description";
Alert.Icon.displayName = "Alert.Icon";
Alert.Content.displayName = "Alert.Content";
