import * as React from "react";

import type {BaseUIEvent} from "@base-ui/react/utils/types";
import {useControlled} from "@base-ui/utils/useControlled";

import Clear from "@bolteu/kalep-react-icons/dist/Clear";
import Hide from "@bolteu/kalep-react-icons/dist/Hide";
import Show from "@bolteu/kalep-react-icons/dist/Show";

import {GhostButton} from "@/components/baseui-components/GhostButton";
import {Input} from "@/components/baseui-components/Input";
import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";

type InputProps = React.ComponentProps<typeof Input>;

type SlotRenderFn = Extract<
    NonNullable<React.ComponentProps<typeof Input.Slot>["render"]>,
    (...args: any[]) => React.ReactElement
>;

const CLASSNAME_TW_PASSWORD_ACTION_BUTTON = `
  flex items-center justify-center border-0 bg-transparent p-0 text-tertiary outline-none
`;
const CLASSNAME_TW_PASSWORD_ACTION_BUTTON_INTERACTIVE = `
  cursor-pointer
  hover:text-primary
  focus-visible:text-primary
`;
const CLASSNAME_TW_PASSWORD_ACTION_BUTTON_DISABLED = "cursor-not-allowed";

export interface PasswordInputProps extends Omit<
    InputProps,
    "children" | "type" | "onValueChange" | "value" | "defaultValue"
> {
    onValueChange?: (value: string) => void;
    clearButtonAriaLabel?: string;
    hidePasswordAriaLabel?: string;
    showPasswordAriaLabel?: string;
    value?: string;
    defaultValue?: string;
}

/**
 * Password input with built-in show/hide toggle and clear actions.
 *
 * ### Usage
 * Uncontrolled:
 * ```tsx
 * <PasswordInput defaultValue="secret" aria-label="Password" />
 * ```
 *
 * Controlled:
 * ```tsx
 * <PasswordInput value={password} onValueChange={setPassword} aria-label="Password" />
 * ```
 *
 * With custom action labels (e.g. for i18n):
 * ```tsx
 * <PasswordInput
 *     aria-label="Password"
 *     clearButtonAriaLabel="Clear"
 *     showPasswordAriaLabel="Show"
 *     hidePasswordAriaLabel="Hide"
 * />
 * ```
 *
 * Inside a Field for label and validation:
 * ```tsx
 * <Field.Root>
 *     <Field.Label>Password</Field.Label>
 *     <PasswordInput />
 *     <Field.Error />
 * </Field.Root>
 * ```
 *
 * See `Field` and `Form` component documentation for field composition in a form.
 */
export const PasswordInput = React.forwardRef(function PasswordInput(
    props: PasswordInputProps,
    forwardedRef: React.ForwardedRef<HTMLInputElement>,
) {
    const {
        clearButtonAriaLabel = "Clear password",
        defaultValue,
        disabled = false,
        fieldSize = "md",
        hidePasswordAriaLabel = "Hide password",
        onValueChange,
        readOnly = false,
        showPasswordAriaLabel = "Show password",
        value: controlledValue,
        ...otherInputProps
    } = props;
    const [showPassword, setShowPassword] = React.useState(false);
    const [isFocusWithin, setIsFocusWithin] = React.useState(false);

    const [value, setValue] = useControlled({
        controlled: controlledValue !== undefined ? controlledValue : undefined,
        default: defaultValue ?? "",
        name: "PasswordInput",
        state: "value",
    });
    const hasValue = value.length > 0;
    const inputRef = React.useRef<HTMLInputElement | null>(null);
    const clearActionRef = React.useRef<HTMLButtonElement | null>(null);
    const toggleActionRef = React.useRef<HTMLButtonElement | null>(null);

    const iconSize = fieldSize === "sm" ? "sm" : "lg";
    const actionsDisabled = disabled || readOnly;
    const toggleLabel = showPassword ? hidePasswordAriaLabel : showPasswordAriaLabel;

    const actionButtonClassName = cx(
        CLASSNAME_TW_PASSWORD_ACTION_BUTTON,
        actionsDisabled
            ? CLASSNAME_TW_PASSWORD_ACTION_BUTTON_DISABLED
            : CLASSNAME_TW_PASSWORD_ACTION_BUTTON_INTERACTIVE,
    );

    const inputRefWithForwarded = React.useMemo(() => mergeRefs([forwardedRef, inputRef]), [forwardedRef]);

    const handleValueChange = React.useCallback<NonNullable<InputProps["onValueChange"]>>(
        (newValue) => {
            setValue(newValue);
            onValueChange?.(newValue);
        },
        [onValueChange, setValue],
    );

    const handleClearClick = React.useCallback(
        (ev: BaseUIEvent<React.MouseEvent<HTMLButtonElement, MouseEvent>>) => {
            ev.stopPropagation();
            setValue("");
            onValueChange?.("");
            inputRef.current?.focus();
        },
        [onValueChange, setValue],
    );

    const handlePartFocus = React.useCallback(() => {
        setIsFocusWithin(true);
    }, []);

    const handlePartBlur = React.useCallback((event: React.FocusEvent<HTMLElement>) => {
        const target = event.relatedTarget;
        if (target === inputRef.current || target === clearActionRef.current || target === toggleActionRef.current) {
            return;
        }
        setIsFocusWithin(false);
    }, []);

    const renderClearSlot = React.useCallback<SlotRenderFn>(
        (slotProps) => {
            const shouldShowClear = hasValue && !actionsDisabled && isFocusWithin;
            if (!shouldShowClear) {
                const {ref, ...restSlotProps} = slotProps;
                return <span {...restSlotProps} ref={ref as React.Ref<HTMLSpanElement>} />;
            }

            const {ref, className: slotClassName, ...restSlotProps} = slotProps;

            return (
                <GhostButton
                    {...restSlotProps}
                    ref={mergeRefs([ref as React.Ref<HTMLButtonElement>, clearActionRef])}
                    render={<button />}
                    nativeButton
                    type="button"
                    aria-label={clearButtonAriaLabel}
                    disabled={actionsDisabled}
                    className={cx(slotClassName, actionButtonClassName)}
                    onMouseDown={(event) => {
                        // Keep the input focused when clicking the action button.
                        event.preventDefault();
                    }}
                    onFocus={handlePartFocus}
                    onBlur={handlePartBlur}
                    onClick={handleClearClick}
                >
                    <Clear aria-hidden="true" className={cx("block")} size={iconSize} />
                </GhostButton>
            );
        },
        [
            hasValue,
            actionsDisabled,
            isFocusWithin,
            actionButtonClassName,
            clearButtonAriaLabel,
            handlePartBlur,
            handlePartFocus,
            handleClearClick,
            iconSize,
        ],
    );

    const renderToggleSlot = React.useCallback<SlotRenderFn>(
        (slotProps) => {
            const {ref, className: slotClassName, ...restSlotProps} = slotProps;

            return (
                <GhostButton
                    {...restSlotProps}
                    ref={mergeRefs([ref as React.Ref<HTMLButtonElement>, toggleActionRef])}
                    render={<button />}
                    nativeButton
                    type="button"
                    aria-label={toggleLabel}
                    aria-pressed={showPassword}
                    disabled={actionsDisabled}
                    className={cx(slotClassName, actionButtonClassName)}
                    onMouseDown={(event) => {
                        // Keep the input focused when clicking the action button.
                        event.preventDefault();
                    }}
                    onFocus={handlePartFocus}
                    onBlur={handlePartBlur}
                    onClick={(ev) => {
                        ev.stopPropagation();
                        setShowPassword((prev) => !prev);
                    }}
                >
                    {showPassword ? (
                        <Hide aria-hidden="true" className={cx("block")} size={iconSize} />
                    ) : (
                        <Show aria-hidden="true" className={cx("block")} size={iconSize} />
                    )}
                </GhostButton>
            );
        },
        [actionsDisabled, actionButtonClassName, handlePartBlur, handlePartFocus, iconSize, showPassword, toggleLabel],
    );

    return (
        <Input
            {...otherInputProps}
            value={value}
            fieldSize={fieldSize}
            onValueChange={handleValueChange}
            disabled={disabled}
            readOnly={readOnly}
        >
            <Input.Control
                ref={inputRefWithForwarded}
                type={showPassword ? "text" : "password"}
                onFocus={handlePartFocus}
                onBlur={handlePartBlur}
            />
            <Input.Slot render={renderClearSlot} />
            <Input.Slot render={renderToggleSlot} />
        </Input>
    );
});
