import * as React from "react";

import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {PasswordInput} from "../PasswordInput";

const PASSWORD_LABEL = "Password";

describe("PasswordInput", () => {
    test("renders a password input with toggle action", async () => {
        render(<PasswordInput aria-label={PASSWORD_LABEL} />);

        const input = screen.getByLabelText(PASSWORD_LABEL);
        const toggle = screen.getByRole("button", {name: "Show password"});

        expect(input).toHaveAttribute("type", "password");
        expect(toggle).toHaveAccessibleName("Show password");
        expect(screen.queryByRole("button", {name: "Clear password"})).not.toBeInTheDocument();
    });

    test("toggle action switches visibility and accessible label", async () => {
        const user = userEvent.setup();
        render(<PasswordInput aria-label={PASSWORD_LABEL} />);

        const input = screen.getByLabelText(PASSWORD_LABEL);
        const toggle = screen.getByRole("button", {name: "Show password"});

        await user.click(toggle);
        expect(input).toHaveAttribute("type", "text");
        expect(toggle).toHaveAccessibleName("Hide password");

        await user.click(toggle);
        expect(input).toHaveAttribute("type", "password");
        expect(toggle).toHaveAccessibleName("Show password");
    });

    test("clear action appears on focus with value and clears while keeping focus", async () => {
        const user = userEvent.setup();
        render(<PasswordInput aria-label={PASSWORD_LABEL} defaultValue="myLongpassword8" />);

        const input = screen.getByLabelText(PASSWORD_LABEL);
        expect(screen.queryByRole("button", {name: "Clear password"})).not.toBeInTheDocument();

        await user.click(input);
        const clear = await screen.findByRole("button", {name: "Clear password"});
        expect(clear).toBeInTheDocument();

        await user.click(clear);
        expect(input).toHaveValue("");
        expect(input).toHaveFocus();
        expect(screen.queryByRole("button", {name: "Clear password"})).not.toBeInTheDocument();
    });

    test("calls onValueChange when typing and clearing value", async () => {
        const user = userEvent.setup();
        const onValueChange = vi.fn();
        render(<PasswordInput aria-label={PASSWORD_LABEL} onValueChange={onValueChange} />);

        const input = screen.getByLabelText(PASSWORD_LABEL);

        await user.type(input, "abcd");
        expect(onValueChange).toHaveBeenCalled();
        expect(onValueChange).toHaveBeenLastCalledWith("abcd");

        const clear = await screen.findByRole("button", {name: "Clear password"});
        await user.click(clear);

        expect(onValueChange).toHaveBeenLastCalledWith("");
        expect(input).toHaveValue("");
    });

    test("supports controlled value updates", async () => {
        const user = userEvent.setup();

        function ControlledPasswordInput() {
            const [value, setValue] = React.useState("initial-secret");
            return <PasswordInput aria-label={PASSWORD_LABEL} value={value} onValueChange={setValue} />;
        }

        render(<ControlledPasswordInput />);

        const input = screen.getByLabelText(PASSWORD_LABEL);
        expect(input).toHaveValue("initial-secret");

        await user.click(input);
        await user.click(await screen.findByRole("button", {name: "Clear password"}));

        expect(input).toHaveValue("");
    });

    test("keeps clear action hidden for controlled prefilled value until focus", async () => {
        const user = userEvent.setup();

        render(<PasswordInput aria-label={PASSWORD_LABEL} value="initial-secret" onValueChange={vi.fn()} />);

        const input = screen.getByLabelText(PASSWORD_LABEL);
        expect(screen.queryByRole("button", {name: "Clear password"})).not.toBeInTheDocument();

        await user.click(input);
        expect(await screen.findByRole("button", {name: "Clear password"})).toBeInTheDocument();
    });

    test("keeps clear action focused when tabbing from input", async () => {
        const user = userEvent.setup();
        render(<PasswordInput aria-label={PASSWORD_LABEL} defaultValue="myLongpassword8" />);

        const input = screen.getByLabelText(PASSWORD_LABEL);
        await user.click(input);

        const clear = await screen.findByRole("button", {name: "Clear password"});
        await user.tab();

        expect(clear).toBeInTheDocument();
        expect(clear).toHaveFocus();
    });

    test("respects consumer autoComplete", () => {
        render(<PasswordInput aria-label={PASSWORD_LABEL} autoComplete="new-password" />);

        const input = screen.getByLabelText(PASSWORD_LABEL);
        expect(input).toHaveAttribute("autoComplete", "new-password");
    });

    describe("disabled state", () => {
        test("clear button is not rendered when disabled", async () => {
            const user = userEvent.setup();
            render(<PasswordInput aria-label={PASSWORD_LABEL} defaultValue="secret" disabled />);

            await user.click(screen.getByLabelText(PASSWORD_LABEL));
            expect(screen.queryByRole("button", {name: "Clear password"})).not.toBeInTheDocument();
        });

        test("toggle button is rendered but disabled when disabled", () => {
            render(<PasswordInput aria-label={PASSWORD_LABEL} disabled />);

            expect(screen.getByRole("button", {name: "Show password"})).toBeDisabled();
        });
    });

    describe("readOnly state", () => {
        test("clear button is not rendered when readOnly", async () => {
            const user = userEvent.setup();
            render(<PasswordInput aria-label={PASSWORD_LABEL} defaultValue="secret" readOnly />);

            await user.click(screen.getByLabelText(PASSWORD_LABEL));
            expect(screen.queryByRole("button", {name: "Clear password"})).not.toBeInTheDocument();
        });

        test("toggle button is rendered but disabled when readOnly", () => {
            render(<PasswordInput aria-label={PASSWORD_LABEL} readOnly />);

            expect(screen.getByRole("button", {name: "Show password"})).toBeDisabled();
        });
    });
});
