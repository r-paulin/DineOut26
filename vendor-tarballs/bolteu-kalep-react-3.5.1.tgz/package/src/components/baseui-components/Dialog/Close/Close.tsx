import * as React from "react";

import {Dialog as BaseUIDialog} from "@base-ui/react";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {Button} from "@/components/Button";
import {cx} from "@/helpers/utils/cx";

export const DialogCloseComponent = React.forwardRef(function DialogCloseComponent(
    props: BaseUIDialog.Close.Props,
    ref: React.ForwardedRef<HTMLButtonElement>,
) {
        const {render, ...otherProps} = props;
        const defaultRender = React.useCallback(({className, ...componentProps}: HTMLProps<HTMLButtonElement>) => {
            return <Button variant="secondary" {...componentProps} overrideClassName={cx(className)} />;
        }, []);
        return <BaseUIDialog.Close render={render ?? defaultRender} {...otherProps} ref={ref} />;
});
