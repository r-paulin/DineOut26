import * as React from "react";

import {Dialog as BaseUIDialog} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const DialogTitleComponent = React.forwardRef(function DialogTitleComponent(
    props: BaseUIDialog.Title.Props,
    ref: React.ForwardedRef<HTMLHeadingElement>,
) {
        const {render, className, ...rest} = props;
        const dialogTitleClassname = React.useCallback(
            function dialogTitleClasses(state: BaseUIDialog.Title.State) {
                return cx("bolt-font-heading-s-accent text-primary", addConsumerClasses(state, className));
            },
            [className],
        );
        return <BaseUIDialog.Title className={dialogTitleClassname} render={render ?? <span />} {...rest} ref={ref} />;
});
