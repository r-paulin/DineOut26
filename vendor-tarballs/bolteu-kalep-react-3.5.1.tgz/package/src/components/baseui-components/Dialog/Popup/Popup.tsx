import * as React from "react";

import {Dialog as BaseUIDialog, useRender} from "@base-ui/react";
import type {ComponentRenderFn, HTMLProps} from "@base-ui/react/utils/types";

import {DialogPopupProvider} from "@/components/baseui-components/Dialog/context/DialogPopupProvider";
import type {Indexable} from "@/components/baseui-components/types/common-types";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export type DialogPopupProps = Omit<BaseUIDialog.Popup.Props, "children"> & {
    children: React.ReactNode | React.ReactNode[];
};

type PopupState = Indexable<BaseUIDialog.Popup.State>;

const PopupInner = React.forwardRef(
    (props: BaseUIDialog.Popup.Props & {state: PopupState}, ref: React.ForwardedRef<HTMLDivElement>) => {
        const {state, render, ...otherProps} = props;
        const element = useRender({
            defaultTagName: "div",
            ref,
            render,
            state,
            props: otherProps,
        });
        return <DialogPopupProvider dialogPopupState={state}>{element}</DialogPopupProvider>;
    },
);
PopupInner.displayName = "PopupInner";
export const DialogPopupComponent = React.forwardRef(function DialogPopupComponent(
    props: DialogPopupProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
        const {className, render, ...rest} = props;
        const dialogPopupClassname = React.useCallback(
            (state: BaseUIDialog.Popup.State) => {
                return cx(
                    `
                      fixed left-1/2 top-1/2 z-modal -translate-x-1/2 -translate-y-1/2 rounded-lg
                      focus:outline-none
                    `,
                    "border-0 border-solid",
                    "flex-grow",
                    "text-base font-normal text-primary",
                    "overflow-y-auto",
                    {"animate-contentShow": state.open},
                    "flex max-h-[80vh] max-w-md flex-col rounded-lg bg-layer-floor-2",
                    "max-w-[calc(100vw-1rem)]",
                    addConsumerClasses(state, className),
                );
            },
            [className],
        );

        const defaultRender: ComponentRenderFn<HTMLProps<HTMLDivElement>, BaseUIDialog.Popup.State> = React.useCallback(
            (renderPopupProps, state) => {
                return <PopupInner state={state as PopupState} {...renderPopupProps} render={render} />;
            },
            [render],
        );

        return <BaseUIDialog.Popup render={defaultRender} {...rest} className={dialogPopupClassname} ref={ref} />;
});
