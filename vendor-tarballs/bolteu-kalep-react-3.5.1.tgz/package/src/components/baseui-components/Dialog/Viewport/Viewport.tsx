import {Dialog as BaseUIDialog} from "@base-ui/react";

/**
 * Dialog.Viewport
 *
 * Positioning container that constrains where the dialog popup is rendered.
 */
export const DialogViewportComponent = BaseUIDialog.Viewport;
