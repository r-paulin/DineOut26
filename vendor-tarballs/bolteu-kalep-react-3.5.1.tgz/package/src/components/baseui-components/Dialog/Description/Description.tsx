import * as React from "react";

import {Dialog as BaseUIDialog} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const DialogDescriptionComponent = React.forwardRef(function DialogDescriptionComponent(
    props: BaseUIDialog.Description.Props,
    ref: React.ForwardedRef<HTMLParagraphElement>,
) {
        const {className, render, ...rest} = props;
        const dialogDescriptionClassname = React.useCallback(
            (state: BaseUIDialog.Description.State) => {
                return cx(
                    "border-0 border-solid px-6 py-2",
                    "flex-grow",
                    "text-base font-normal text-primary",
                    "overflow-y-auto",
                    addConsumerClasses(state, className),
                );
            },
            [className],
        );
        return (
            <BaseUIDialog.Description
                className={dialogDescriptionClassname}
                render={render ?? <section />}
                {...rest}
                ref={ref}
            />
        );
});
