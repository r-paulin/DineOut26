import * as React from "react";

import {Dialog as BaseUIDialog} from "@base-ui/react";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {Button} from "@/components/Button";
import {cx} from "@/helpers/utils/cx";

export const DialogTriggerComponent = React.forwardRef(function DialogTriggerComponent(
    props: BaseUIDialog.Trigger.Props,
    ref: React.ForwardedRef<HTMLButtonElement>,
) {
        const {render, ...otherProps} = props;
        const defaultRender = React.useCallback(({className, ...componentProps}: HTMLProps<HTMLButtonElement>) => {
            return <Button {...componentProps} overrideClassName={cx(className)} />;
        }, []);
        return <BaseUIDialog.Trigger render={render ?? defaultRender} {...otherProps} ref={ref} />;
});
