import * as React from "react";

import {expect, userEvent, waitFor, within} from "storybook/test";
import type {BaseUIEvent} from "@base-ui/react/utils/types";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Cross} from "@bolteu/kalep-react-icons";

import {Button} from "@/components/Button";
import {IconButton} from "@/components/IconButton";
import {Typography} from "@/components/Typography";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Dialog} from "./index";

const meta = {
    component: Dialog as unknown as React.ComponentType<any>,
    title: "BaseUI Playground/Dialog",
    subcomponents: {
        "Dialog.Root": Dialog.Root,
        "Dialog.Header": Dialog.Header,
        "Dialog.Footer": Dialog.Footer,
        "Dialog.Trigger": Dialog.Trigger,
        "Dialog.Portal": Dialog.Portal,
        "Dialog.Backdrop": Dialog.Backdrop,
        "Dialog.Popup": Dialog.Popup,
        "Dialog.Title": Dialog.Title,
        "Dialog.Description": Dialog.Description,
        "Dialog.Close": Dialog.Close,
    },
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A primitive Dialog component",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Dialog>;

export default meta;
type Story = StoryObj<typeof meta>;

export const DefaultUncontrolled: Story = {
    args: {},
    play: async ({canvasElement, step}) => {
        // We can be sure this exists here. This is required because of portaling the dialog outside of storybook's canvas.
        const canvas = within(canvasElement.parentNode as HTMLElement);
        await step("There is no dialog mounted initially", async () => {
            const dialog = canvas.queryByRole("dialog");
            await expect(dialog).not.toBeInTheDocument();
        });
        const triggerButton = await canvas.findByRole("button", {name: "Open Dialog"});
        await step("Dialog is opened when trigger is clicked", async () => {
            await userEvent.click(triggerButton);
            const dialog = await canvas.findByRole("dialog");
            await expect(dialog).toBeInTheDocument();
        });
        await step("Dialog is closed when close button is clicked", async () => {
            const closeButton = await canvas.findByRole("button", {name: "Got it"});

            const scope = canvasElement.ownerDocument.body;

            await userEvent.click(closeButton);
            await waitFor(() => {
                expect(within(scope).queryByRole("dialog")).not.toBeInTheDocument();
            });
        });
    },
    render: (args) => {
        return (
            <Dialog.Root {...args}>
                <Dialog.Trigger>Open Dialog</Dialog.Trigger>
                <Dialog.Portal>
                    <Dialog.Backdrop />
                    <Dialog.Popup>
                        <Dialog.Header>
                            <Dialog.Title>The default Dialog</Dialog.Title>
                            <Dialog.Close
                                render={
                                    <IconButton
                                        icon={<Cross />}
                                        size="sm"
                                        aria-label="Close"
                                        overrideClassName="-mt-1 -me-1"
                                    />
                                }
                            />
                        </Dialog.Header>
                        <Dialog.Description>
                            <Typography variant="body-m-regular">
                                Keep your Dialogs simple and concise. Avoid form elements and complex interactions
                                inside Dialogs.
                            </Typography>
                        </Dialog.Description>
                        <Dialog.Footer>
                            <Dialog.Close>Got it</Dialog.Close>
                        </Dialog.Footer>
                    </Dialog.Popup>
                </Dialog.Portal>
            </Dialog.Root>
        );
    },
};
export const DefaultControlled: Story = {
    args: {},
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement.parentNode as HTMLElement);
        const triggerButton = await canvas.findByRole("button", {name: "Open Dialog"});
        await step("Dialog is opened when trigger is clicked", async () => {
            await userEvent.click(triggerButton);
            const dialog = await canvas.findByRole("dialog");
            await expect(dialog).toBeInTheDocument();
        });
        const closeButton = await canvas.findByRole("button", {name: "Close"});
        await step("Dialog is closed when close button is clicked", async () => {
            await userEvent.click(closeButton);
            const scope = canvasElement.ownerDocument.body;

            await userEvent.click(closeButton);
            await waitFor(() => {
                expect(within(scope).queryByRole("dialog")).not.toBeInTheDocument();
            });
        });
    },
    render: (args) => {
        const [isOpen, setIsOpen] = React.useState<boolean>(false);
        const onOpenChange = React.useCallback((open: boolean) => {
            console.log(open);
            setIsOpen(open);
        }, []);
        return (
            <Dialog.Root {...args} open={isOpen} onOpenChange={onOpenChange}>
                <Dialog.Trigger>Open Dialog</Dialog.Trigger>
                <Dialog.Portal>
                    <Dialog.Backdrop />
                    <Dialog.Popup>
                        <Dialog.Header>
                            <Dialog.Title>The default Dialog</Dialog.Title>
                            <Dialog.Close
                                render={
                                    <IconButton
                                        icon={<Cross />}
                                        size="sm"
                                        aria-label="Close"
                                        overrideClassName="-mt-1 -me-1"
                                    />
                                }
                            />
                        </Dialog.Header>
                        <Dialog.Description>
                            <Typography variant="body-m-regular">
                                Keep your Dialogs simple and concise. Avoid form elements and complex interactions
                                inside Dialogs. Use Drawers for more complex use cases instead.
                            </Typography>
                        </Dialog.Description>
                        <Dialog.Footer>
                            <Dialog.Close>Cancel</Dialog.Close>
                            <Dialog.Close render={<Button variant="primary" />}>Got it</Dialog.Close>
                        </Dialog.Footer>
                    </Dialog.Popup>
                </Dialog.Portal>
            </Dialog.Root>
        );
    },
};

type DialogRootType = typeof Dialog.Root;
type OnOpenChangeHandler = React.ComponentProps<DialogRootType>["onOpenChange"];

export const AsyncControlled: Story = {
    render: (args) => {
        const [isOpen, setIsOpen] = React.useState<boolean>(false);
        const [loading, setIsLoading] = React.useState<boolean>(false);
        const delay = (ms: number) =>
            new Promise((resolve) => {
                setTimeout(resolve, ms);
            });
        const onOk = React.useCallback(async (ev: BaseUIEvent<React.MouseEvent<HTMLButtonElement, MouseEvent>>) => {
            ev.preventBaseUIHandler();
            await delay(2500);
            setIsOpen(false);
        }, []);

        const onOpenChange: OnOpenChangeHandler = React.useCallback(async (open: boolean) => {
            setIsLoading(true);
            if (!open) {
                await delay(2500);
            }
            setIsLoading(false);
            setIsOpen(open);
        }, []);

        return (
            <Dialog.Root {...args} open={isOpen} onOpenChange={onOpenChange}>
                <Dialog.Trigger>Open Dialog</Dialog.Trigger>
                <Dialog.Portal>
                    <Dialog.Backdrop />
                    <Dialog.Popup>
                        <Dialog.Header>
                            <Dialog.Title>The default Dialog</Dialog.Title>
                            <Dialog.Close
                                render={
                                    <IconButton
                                        loading={loading}
                                        icon={<Cross />}
                                        size="sm"
                                        aria-label="Close"
                                        overrideClassName="-mt-1 -me-1"
                                    />
                                }
                            />
                        </Dialog.Header>
                        <Dialog.Description>
                            <Typography variant="body-m-regular">
                                Keep your Dialogs simple and concise. Avoid form elements and complex interactions
                                inside Dialogs. Use Drawers for more complex use cases instead.
                            </Typography>
                        </Dialog.Description>
                        <Dialog.Footer>
                            <Dialog.Close
                                render={<Button onClick={onOk} variant="secondary" loading={loading} />}
                                disabled={loading}
                            >
                                Cancel
                            </Dialog.Close>
                            <Dialog.Close render={<Button onClick={onOk} variant="primary" loading={loading} />}>
                                Got it
                            </Dialog.Close>
                        </Dialog.Footer>
                    </Dialog.Popup>
                </Dialog.Portal>
            </Dialog.Root>
        );
    },
};

export const DetachedTrigger: Story = {
    args: {},
    render: (args) => {
        const dialogHandle = Dialog.createHandle();
        return (
            <div>
                <Dialog.Trigger handle={dialogHandle}>Open</Dialog.Trigger>
                <Dialog.Root {...args} handle={dialogHandle}>
                    <Dialog.Portal>
                        <Dialog.Backdrop />
                        <Dialog.Popup>
                            <Dialog.Header>
                                <Dialog.Title>The default Dialog</Dialog.Title>
                                <Dialog.Close
                                    render={
                                        <IconButton
                                            icon={<Cross />}
                                            size="sm"
                                            aria-label="Close"
                                            overrideClassName="-mt-1 -me-1"
                                        />
                                    }
                                />
                            </Dialog.Header>
                            <Dialog.Description>
                                <Typography variant="body-m-regular">
                                    Keep your Dialogs simple and concise. Avoid form elements and complex interactions
                                    inside Dialogs. Use Drawers for more complex use cases instead.
                                </Typography>
                            </Dialog.Description>
                            <Dialog.Footer>
                                <Dialog.Close render={<Button variant="secondary" />}>Cancel</Dialog.Close>
                                <Dialog.Close render={<Button variant="primary" />}>Got it</Dialog.Close>
                            </Dialog.Footer>
                        </Dialog.Popup>
                    </Dialog.Portal>
                </Dialog.Root>
            </div>
        );
    },
};

export const VerticalTop: Story = {
    args: {},
    render: (args) => {
        return (
            <Dialog.Root {...args}>
                <Dialog.Trigger>Open</Dialog.Trigger>
                <Dialog.Portal>
                    <Dialog.Backdrop />
                    <Dialog.Popup className="top-0 translate-y-0 animate-none pt-4">
                        <Dialog.Header>
                            <Dialog.Title>The default Dialog</Dialog.Title>
                            <Dialog.Close
                                render={
                                    <IconButton
                                        icon={<Cross />}
                                        size="sm"
                                        aria-label="Close"
                                        overrideClassName="-mt-1 -me-1"
                                    />
                                }
                            />
                        </Dialog.Header>
                        <Dialog.Description>
                            <Typography variant="body-m-regular">
                                Keep your Dialogs simple and concise. Avoid form elements and complex interactions
                                inside Dialogs. Use Drawers for more complex use cases instead.
                            </Typography>
                        </Dialog.Description>
                        <Dialog.Footer>
                            <Dialog.Close render={<Button variant="secondary" />}>Cancel</Dialog.Close>
                            <Dialog.Close render={<Button variant="primary" />}>Got it</Dialog.Close>
                        </Dialog.Footer>
                    </Dialog.Popup>
                </Dialog.Portal>
            </Dialog.Root>
        );
    },
};
