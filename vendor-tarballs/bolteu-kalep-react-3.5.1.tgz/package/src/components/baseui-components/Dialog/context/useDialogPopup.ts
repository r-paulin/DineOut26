import * as React from "react";

import {DialogPopupContext} from "@/components/baseui-components/Dialog/context/DialogPopupProvider";

export function useDialogPopup() {
    const context = React.useContext(DialogPopupContext);
    if (!context) {
        throw new Error("DialogPopup must be used within a Dialog component");
    }
    return context;
}
