import * as React from "react";

import type {Dialog as BaseUIDialog} from "@base-ui/react";

export type DialogPopupContextType = {
    dialogPopupState: BaseUIDialog.Popup.State;
};

export const DialogPopupContext = React.createContext<DialogPopupContextType | null>(null);

interface DialogPopupProviderProps extends DialogPopupContextType {
    children: React.ReactNode | React.ReactNode[];
}

export function DialogPopupProvider(props: DialogPopupProviderProps) {
    const {children, dialogPopupState} = props;
    const contextValue: DialogPopupContextType = React.useMemo(() => ({dialogPopupState}), [dialogPopupState]);
    return <DialogPopupContext.Provider value={contextValue}>{children}</DialogPopupContext.Provider>;
}
