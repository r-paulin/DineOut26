import {Dialog as BaseUIDialog} from "@base-ui/react";

/**
 * Dialog compound component.
 *
 * Provides a set of subcomponents for building modal dialogs:
 * - `Dialog.Root`: the main container
 * - `Dialog.Header`: header area
 * - `Dialog.Footer`: footer area
 * - `Dialog.Trigger`: element to open the dialog
 * - `Dialog.Portal`: portal for rendering dialog content
 * - `Dialog.Backdrop`: backdrop overlay
 * - `Dialog.Viewport`: A positioning container for the dialog popup.
 * - `Dialog.Popup`: main dialog content area
 * - `Dialog.Title`: dialog title
 * - `Dialog.Description`: dialog content area. Used as a section between the header and footer.
 * - `Dialog.Close`: button to close the dialog
 *
 * ### Composition guide
 * ```tsx
 <Dialog.Root>
     <Dialog.Trigger>Open Dialog</Dialog.Trigger>
     <Dialog.Portal>
         <Dialog.Backdrop />
         <Dialog.Popup>
             <Dialog.Header>
                 <Dialog.Title>The default Dialog</Dialog.Title>
                 <Dialog.Close
                     render={
                         <IconButton
                             icon={<Cross />}
                             size="sm"
                             aria-label="Close"
                             overrideClassName="-mt-1 -me-1"
                         />
                     }
                 />
             </Dialog.Header>
             <Dialog.Description>
                 <Typography variant="body-m-regular">
                     Keep your Dialogs simple and concise. Avoid form elements and complex interactions
                     inside Dialogs.
                 </Typography>
             </Dialog.Description>
             <Dialog.Footer>
                 <Dialog.Close>Got it</Dialog.Close>
             </Dialog.Footer>
         </Dialog.Popup>
     </Dialog.Portal>
 </Dialog.Root>
 */
export const DialogRootComponent = BaseUIDialog.Root;
