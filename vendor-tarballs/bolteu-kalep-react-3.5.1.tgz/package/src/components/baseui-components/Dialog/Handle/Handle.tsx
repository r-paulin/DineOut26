import {Dialog as BaseUIDialog} from "@base-ui/react";

/**
 * Dialog.Handle
 *
 * Imperative handle part used to coordinate programmatic dialog control.
 */
export const DialogHandleComponent = BaseUIDialog.Handle;
