---
name: 06-ui-parity-checklist
description: Create a visual and interaction parity checklist for refactors.
---

# Skill 06 — UI Parity Checklist (Legacy vs Refactor)

## Purpose

Create a repeatable checklist for parity. This is your “manual visual review” codified.

## Inputs

- Legacy component behavior & styling
- New implementation
- Stories or demo pages (preferred)

## Output (required)

Fill out:

## UI Parity Checklist

### Visual states

| State                                    | Legacy reference (where to see it) | New reference (where to see it) | Pass? | Notes |
|------------------------------------------|------------------------------------|---------------------------------|-------|-------|
| Default                                  |                                    |                                 |       |       |
| Typography weight/color                  |                                    |                                 |       |       |
| Hover                                    |                                    |                                 |       |       |
| Focus-visible                            |                                    |                                 |       |       |
| Active/pressed                           |                                    |                                 |       |       |
| Disabled                                 |                                    |                                 |       |       |
| Error/invalid (if applicable)            |                                    |                                 |       |       |
| Loading (if applicable)                  |                                    |                                 |       |       |
| Dense/compact (if applicable)            |                                    |                                 |       |       |
| With icon / without icon (if applicable) |                                    |                                 |       |       |
| Long content / overflow                  |                                    |                                 |       |       |

### Interaction parity

| Interaction            | Expected behavior | Legacy | New | Pass? | Notes |
|------------------------|-------------------|--------|-----|-------|-------|
| Keyboard navigation    |                   |        |     |       |       |
| Enter/Space behavior   |                   |        |     |       |       |
| Escape (if applicable) |                   |        |     |       |       |
| Focus management       |                   |        |     |       |       |
| Screen reader labeling |                   |        |     |       |       |
| Animation smoothness   |                   |        |     |       |       |

### API parity

| Prop/callback | Legacy behavior | New behavior | Pass? | Notes |
|---------------|-----------------|--------------|-------|-------|
|               |                 |              |       |       |

## Rules

- If you can’t find a legacy reference, create one (story/example) before declaring parity.
- If behavior changed intentionally, document it and update Skill 02 scope.
- Parity checks must reference Storybook stories for Default, Variants, States, and Accessibility.
- Base UI props are canonical; parity should focus on behavior and visuals, not preserving legacy prop names.

## Self-check

- Did I cover at least the top 5 visual states: default/hover/focus/active/disabled?
- Did I cover keyboard + labeling parity?
