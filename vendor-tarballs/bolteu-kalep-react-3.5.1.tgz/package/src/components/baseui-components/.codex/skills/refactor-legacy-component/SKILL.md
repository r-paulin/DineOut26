---
name: refactor-legacy-component
description: Refactor a legacy Kalep React component into the Base UI component library standards. Use when asked to migrate or refactor an existing legacy component into a new Base UI-based component with parity checks, documentation, and staged skill outputs.
---

# Refactor Legacy Component

## Overview

Refactor a legacy React component to Base UI composition patterns while documenting scope, parity, and risks. Follow a fixed workflow and stop after planning unless explicitly asked to implement code.
Base UI props are the canonical API unless the user explicitly requests legacy prop preservation.
Wrapper components are allowed only for styling/visual parity, and must not rename or alias Base UI props.

## Styling rules

- When using function-based `className`, define the function with `React.useCallback`.
- Store Tailwind class strings in `const` values prefixed with `CLASSNAME_TW_`.

## Workflow

1) Read and follow `AGENTS.md`.
2) Execute skills in this order and capture required outputs:
   - `.codex/skills/00-refactor-router/SKILL.md`
   - `.codex/skills/01-baseui-docs-ingestion/SKILL.md`
   - `.codex/skills/02-plan-and-scope/SKILL.md`
   - `.codex/skills/03-baseui-primitive-first/SKILL.md`
   - `.codex/skills/04-composition-and-single-element/SKILL.md`
   - `.codex/skills/05-state-and-context-minimization/SKILL.md`
   - `.codex/skills/06-ui-parity-checklist/SKILL.md`
   - `.codex/skills/07-final-review-and-pr-notes/SKILL.md`

## Discovery (mandatory before planning)

- Inspect `../<$LEGACY_COMPONENT>` to understand legacy API, composition model, and behaviors.
- Scan Storybook to find legacy stories and all states/variants covered.
- Search repo usages of the legacy component (imports and JSX usage).

## Output

- Create `./refactor-notes/<$NEW_COMPONENT>-refactor.md`.
- Write all skill outputs into that file under clear headings.
- Note any legacy prop removals or API changes; do not mirror legacy props unless explicitly instructed.

## Stop Point

After completing Skill 02 (Plan & Scope), stop. Do not implement code unless explicitly instructed.
