---
name: 05-state-and-context-minimization
description: Minimize state and context with an explicit inventory.
---

# Skill 05 — State & Context Minimization

## Purpose

Stop state/context bloat by requiring justification for each piece of state and each context field.

## Inputs

- Refactor Plan (Skill 02)
- Draft implementation (or intended logic)

## Output (required)

Complete these tables.

## State Inventory

| State variable | Type | Owned by (component) | Purpose | Why must be state (not derived) | Read by | Writes/updates from |
|----------------|------|----------------------|---------|---------------------------------|---------|---------------------|
|                |      |                      |         |                                 |         |                     |

## Context Inventory (if any)

| Context name | Value fields | Who provides | Who reads | Why context (not props) | How to keep stable (memoization/shape) |
|--------------|--------------|--------------|-----------|-------------------------|----------------------------------------|
|              |              |              |           |                         |                                        |

## Derived Values Inventory

| Derived value | Derived from | Where computed | Why not state |
|---------------|--------------|----------------|---------------|
|               |              |                |               |

## Rules

- Default: no context unless multiple subcomponents genuinely need shared state/handlers.
- No derived state unless unavoidable (rare).
- Avoid storing props in state.
- Prefer styling via classes/data attributes over state for purely visual toggles.

## Self-check

- Can I delete any state row without losing behavior?
- Is any context field unused or only used by one child?
- Are there any “just in case” values stored in state/context?
