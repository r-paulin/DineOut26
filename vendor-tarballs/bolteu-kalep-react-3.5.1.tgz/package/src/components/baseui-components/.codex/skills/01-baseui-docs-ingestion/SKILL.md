---
name: 01-baseui-docs-ingestion
description: Ingest Base UI documentation to anchor the refactor on official primitives and patterns.
---

# Skill 01 — Base UI Documentation Ingestion (Docs-First)

## Purpose

Anchor the refactor on Base UI’s official primitives and composition model
*before* any primitive decision or in-repo reuse happens.

This skill exists to prevent:

- rebuilding Base UI behavior from scratch
- anchoring on existing internal primitives prematurely
- drifting away from Base UI’s intended composition patterns

## Primary Source of Truth

- Base UI documentation indexed at: https://base-ui.com/llms.txt

Internal repo primitives MUST NOT be considered until this skill is complete.

---

## Inputs

- Component name being refactored (e.g. Accordion)
- Legacy component summary (optional)

---

## Procedure (mandatory order)

### Step 1 — Read the Base UI index

- Open `https://base-ui.com/llms.txt`
- Identify:
    - the exact Base UI component page(s) relevant to the refactor
    - any handbook pages that apply (Composition, Customization, Accessibility)

### Step 2 — Open relevant Base UI pages

You MUST open:

- The component-specific page if it exists (e.g. Accordion)
- Any handbook pages that describe:
    - composition patterns
    - slot/subcomponent structure
    - styling/customization constraints
    - accessibility expectations

### Step 3 — Extract only what is relevant

Summarize:

- Provided primitives and subcomponents
- Expected composition structure (Root + parts)
- What Base UI explicitly handles (state, keyboard, ARIA, focus, etc.)
- Any “do not” or “avoid” guidance
- Any extension points intended for custom behavior/styling

Do NOT copy large sections verbatim.
Do NOT include unrelated components.

---

## Output (required)

Paste the following block verbatim and fill it in:

## Base UI Docs Ingestion

### Docs consulted

- Base UI component page(s):
    - <link>
- Handbook / supporting pages:
    - <link>
    - <link>

### Base UI primitive summary

- Primary primitive(s):
    - <name>: <what behavior it provides>
- Subcomponents / slots:
    - <name>: <responsibility>
- Composition expectations:
    - <bullets>

### Behavior owned by Base UI

- <keyboard behavior>
- <focus management>
- <ARIA semantics>
- <state management handled internally>

### Explicit extension points

- <props / slots / render mechanisms intended for extension>
- <styling hooks / data attributes>

### What MUST NOT be reimplemented

- <list derived directly from the docs>

### Notes relevant to our refactor

- <anything that
