---
name: 04-composition-and-single-element
description: Define the composition contract and ensure a single root element.
---

# Skill 04 — Composition & Single-Element Rule

## Purpose

Enforce the compound composition pattern and “each component renders a single HTML element”.

## Inputs

- Refactor Plan (Skill 02)
- Primitive Decision (Skill 03)
- Draft implementation (or planned structure)

## Output (required)

Fill out:

## Composition Contract Check

### 1) Component tree

- Root: <ComponentName> -> renders <single HTML element type or Base UI primitive root>
- Subcomponents:
    - <SubcomponentName> -> renders <single element type>
    - ...

### 2) Single-element proof (required per component)

For each component listed above, answer:

- Component: <name>
- Returns exactly one element? <YES/NO>
- If YES: what element?
- If NO: why, and what is the fix?

### 3) Wrapper policy

- Are there any wrapper elements used only for styling/spacing? <NO is expected>
- If YES: list each wrapper and how to remove it.

### 4) Slot/children policy

- What is allowed as children?
- Which component owns layout vs which owns behavior?
- Are default spacing/typography styles applied in part components (not stories)?

## Rules

- Root and each subcomponent must render exactly one element.
- Each subcomponent must live in its own file (no multi-component files).
- Avoid fragments and wrapper divs unless the element is semantically required.
- Styling must attach to the real element (prefer Tailwind on the actual root).
- Wrapper components are allowed for styling parity but must preserve Base UI props and behavior.
- Do not introduce wrapper components that only map legacy props; use Base UI props directly.
- Inner wrappers are allowed only for animation parity and must be documented in code.

## Self-check

- Did I explicitly verify single-root for every component?
- Did I eliminate wrapper-only elements?
