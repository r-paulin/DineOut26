import type {Toggle as BaseUIToggle} from "@base-ui/react";

import type {ChipSize, ChipVariant} from "@/components/Chip/Chip.types";

export type {ChipSize, ChipVariant} from "@/components/Chip/Chip.types";

export interface ChipProps extends Omit<BaseUIToggle.Props, "children" | "pressed" | "defaultPressed"> {
    children?: React.ReactNode;
    size?: ChipSize;
    variant?: ChipVariant;
    selected?: boolean;
    onRemove?: (event: React.KeyboardEvent | React.MouseEvent) => void;
}
