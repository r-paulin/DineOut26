import * as React from "react";

import {expect, fn, userEvent, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Heart, Lock} from "@bolteu/kalep-react-icons";

import {Chip} from "@/components/baseui-components/Chip";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";

const meta = {
    component: Chip,
    title: "BaseUI Playground/Chip",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A Base UI-backed Chip matching the default Kalep Chip visuals.",
            description: {
                component: [
                    "A composable Chip built on Base UI Toggle. Pass text directly, use",
                    "`Chip.Icon` for leading icons, and `Chip.Remove` for the remove affordance.",
                    "",
                    "### Composition guide",
                    "Regular usage:",
                    "```tsx",
                    "<Chip>",
                    "  Label",
                    "</Chip>",
                    "```",
                    "",
                    "With icon and remove action:",
                    "```tsx",
                    "<Chip onRemove={handleRemove}>",
                    '  <Chip.Icon icon={<Lock size="sm" />} />',
                    "  Secure",
                    "  <Chip.Remove />",
                    "</Chip>",
                    "```",
                    "",
                    "Include `Chip.Remove` when providing `onRemove` so the remove affordance is visible.",
                ].join("\n"),
            },
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Chip>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
    render: (args) => (
        <Chip {...args} onClick={() => {}}>
            <Chip.Icon icon={<Heart size="sm" />} />
            What is Love?
            <Chip.Remove />
        </Chip>
    ),
    args: {},
};

export const Simple: Story = {
    render: (args) => <Chip {...args}> Simple Chip</Chip>,
    args: {},
};

export const WithIcon: Story = {
    render: (args) => (
        <Chip {...args}>
            <Chip.Icon icon={<Lock size="sm" />} />
            With icon
        </Chip>
    ),
    args: {},
};

export const Removable: Story = {
    render: (args) => (
        <Chip {...args}>
            Removable chip
            <Chip.Remove data-testid="chip-remove" />
        </Chip>
    ),
    args: {
        onRemove: fn(),
        onPressedChange: fn(),
    },
    play: async ({canvasElement, step, args}) => {
        const canvas = within(canvasElement);
        const chip = await canvas.findByRole("button");
        const remove = await canvas.findByTestId("chip-remove");

        await step("Remove affordance is rendered", async () => {
            await expect(remove).toBeInTheDocument();
        });

        await step("Clicking remove triggers onRemove", async () => {
            await userEvent.click(remove);
            await expect(args.onRemove).toHaveBeenCalledTimes(1);
        });

        await step("Backspace on chip triggers onRemove", async () => {
            await chip.focus();
            await userEvent.keyboard("{Backspace}");
            await expect(args.onRemove).toHaveBeenCalledTimes(2);
        });
    },
};

export const Composed: Story = {
    render: (args) => (
        <Chip {...args}>
            <Chip.Icon icon={<Lock size="sm" />} />
            Composable chip
            <Chip.Remove />
        </Chip>
    ),
    args: {},
};
