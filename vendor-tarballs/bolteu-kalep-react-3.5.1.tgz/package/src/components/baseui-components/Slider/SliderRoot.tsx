import * as React from "react";

import {Slider as BaseUISlider} from "@base-ui/react/slider";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Slider.Root
 * Provides context for all slider components.
 *
 * ```tsx
 * <Slider.Root defaultValue={35}>
 *   <Slider.Control>
 *     <Slider.Track>
 *       <Slider.Indicator />
 *       <Slider.Thumb />
 *     </Slider.Track>
 *   </Slider.Control>
 *   <Slider.Value />
 * </Slider.Root>
 * ```
 */
export function SliderRoot<Value extends number | readonly number[] = number>(
    props: BaseUISlider.Root.Props<Value>,
): React.JSX.Element {
    const {className, children, ...rest} = props;

    const sliderRootClassName = React.useCallback(
        (state: BaseUISlider.Root.State) => {
            return cx("flex w-full flex-col gap-3", addConsumerClasses(state, className));
        },
        [className],
    );

    return (
        <BaseUISlider.Root {...rest} className={sliderRootClassName}>
            {children}
        </BaseUISlider.Root>
    );
}
