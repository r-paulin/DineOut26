import {SliderControl} from "./SliderControl";
import {SliderIndicator} from "./SliderIndicator";
import {SliderRoot} from "./SliderRoot";
import {SliderThumb} from "./SliderThumb";
import {SliderTrack} from "./SliderTrack";
import {SliderValue} from "./SliderValue";

export const Slider = {
    Root: SliderRoot,
    Control: SliderControl,
    Track: SliderTrack,
    Indicator: SliderIndicator,
    Thumb: SliderThumb,
    Value: SliderValue,
};

Object.assign(Slider.Root, {displayName: "Slider.Root"});
Slider.Control.displayName = "Slider.Control";
Slider.Track.displayName = "Slider.Track";
Slider.Indicator.displayName = "Slider.Indicator";
Slider.Thumb.displayName = "Slider.Thumb";
Slider.Value.displayName = "Slider.Value";
