import {Field as BaseUIField} from "@base-ui/react";

/**
 * Field.Validity
 *
 * Exposes field validity state to render conditional UI based on validation status.
 */
export const Validity = BaseUIField.Validity;
