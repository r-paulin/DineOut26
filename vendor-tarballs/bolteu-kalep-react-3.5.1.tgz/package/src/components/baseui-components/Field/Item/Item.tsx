import {Field as BaseUIField} from "@base-ui/react";

/**
 * Field.Item
 *
 * Wraps option-like controls (such as radio or checkbox items) inside a field context.
 */
export const Item = BaseUIField.Item;
