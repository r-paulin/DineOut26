import * as React from "react";

import {Field as BaseUIField} from "@base-ui/react/field";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface LabelProps extends BaseUIField.Label.Props {
    inline?: boolean;
}
export const Label = React.forwardRef(function Label(props: LabelProps, ref: React.ForwardedRef<HTMLLabelElement>) {
    const {className, inline = false, ...rest} = props;
    const labelClassName = React.useCallback(
        (state: BaseUIField.Label.State) => {
            return cx(
                inline
                    ? `
                      bolt-font-body-m-regular inline-flex cursor-pointer items-center gap-2 leading-loose text-primary
                    `
                    : "bolt-font-body-s-accent w-fit",
                state.disabled && "text-tertiary",
                addConsumerClasses(state, className),
            );
        },
        [className, inline],
    );
    return <BaseUIField.Label className={labelClassName} {...rest} ref={ref} />;
});
