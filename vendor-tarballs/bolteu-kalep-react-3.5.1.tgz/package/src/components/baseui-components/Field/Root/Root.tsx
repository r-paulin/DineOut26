import * as React from "react";

import {Field as BaseUIField} from "@base-ui/react/field";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

export const Root = React.forwardRef(function Field(
    props: BaseUIField.Root.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, id, ...rest} = props;
    const generatedId = useId();
    const inputId = id ?? `kalep-field-${generatedId}`;
    const fieldRootClassName = React.useCallback(
        (state: BaseUIField.Root.State) => {
            return cx("flex w-full flex-col items-start gap-2", addConsumerClasses(state, className));
        },
        [className],
    );
    return <BaseUIField.Root id={inputId} {...rest} className={fieldRootClassName} ref={ref} />;
});
