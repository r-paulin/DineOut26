import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Combobox.Popup
 * Surface that houses `Combobox.List`, `Combobox.Empty`, or custom footers.
 *
 * ```tsx
 * <Combobox.Positioner>
 *   <Combobox.Popup>
 *     <Combobox.Empty>No options found</Combobox.Empty>
 *     <Combobox.List>…</Combobox.List>
 *   </Combobox.Popup>
 * </Combobox.Positioner>
 * ```
 */
export const ComboboxPopup = React.forwardRef(function ComboboxPopup(
    props: BaseUICombobox.Popup.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getComboboxPopupClassNames = React.useCallback(
        (state: BaseUICombobox.Popup.State) =>
            cx(
                `
                  max-h-80 min-w-[var(--anchor-width)] max-w-[var(--anchor-width)] overflow-hidden rounded-md
                  bg-layer-floor-3 shadow-md
                `,
                addConsumerClasses(state, className),
            ),
        [className],
    );

    return <BaseUICombobox.Popup {...rest} ref={forwardedRef} className={getComboboxPopupClassNames} />;
});
