import * as React from "react";

import {expect, userEvent, waitFor, within} from "storybook/test";
import {Form} from "@base-ui/react";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Field} from "@/components/baseui-components/Field";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Combobox} from "./index";

const meta = {
    component: Combobox as unknown as React.ComponentType<any>,
    subcomponents: {
        "Combobox.Root": Combobox.Root,
        "Combobox.Trigger": Combobox.Trigger,
        "Combobox.Control": Combobox.Control,
        "Combobox.Controls": Combobox.Controls,
        "Combobox.ValueArea": Combobox.ValueArea,
        "Combobox.Input": Combobox.Input,
        "Combobox.Portal": Combobox.Portal,
        "Combobox.Positioner": Combobox.Positioner,
        "Combobox.Popup": Combobox.Popup,
        "Combobox.List": Combobox.List,
        "Combobox.Item": Combobox.Item,
        "Combobox.ItemIndicator": Combobox.ItemIndicator,
        "Combobox.CheckboxIndicator": Combobox.CheckboxIndicator,
        "Combobox.Icon": Combobox.Icon,
        "Combobox.Clear": Combobox.Clear,
        "Combobox.Status": Combobox.Status,
    },
    title: "BaseUI Playground/Combobox",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            toc: true,
            page: DocumentationTemplate,
            subtitle: "Anatomy and API for the Base UI Combobox",
            controls: {
                exclude: ["items"],
            },
        },
    },
} satisfies Meta<typeof Combobox.Root>;

const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

export default meta;

type PlaygroundOption = {
    label: string;
    value: string | null;
    secondary?: string;
    disabled?: boolean;
};

const cityOptions: PlaygroundOption[] = [
    {label: "Tallinn", value: "1"},
    {label: "Stockholm", value: "2"},
    {label: "Berlin", value: "3"},
    {label: "Warsaw", value: "4"},
    {label: "Paris", value: "5"},
    {label: "London", value: "6"},
    {label: "Lisbon", value: "7"},
    {label: "Johannesburg", value: "8"},
];

const multilineOption: PlaygroundOption = {
    label: "Just an example entry that can be long and span across multiple lines",
    value: "9",
};

const multilineOptions: PlaygroundOption[] = [multilineOption, ...cityOptions];

type PlaygroundOptionGroup = {
    label: string;
    options: PlaygroundOption[];
};

const groupedCityOptions: PlaygroundOptionGroup[] = [
    {
        label: "Baltics",
        options: [
            {label: "Tallinn", value: "1", secondary: "Estonia"},
            {label: "Riga", value: "riga", secondary: "Latvia"},
            {label: "Vilnius", value: "vilnius", secondary: "Lithuania"},
        ],
    },
    {
        label: "Central Europe",
        options: [
            {label: "Warsaw", value: "4", secondary: "Poland"},
            {label: "Prague", value: "prague", secondary: "Czechia"},
            {label: "Budapest", value: "budapest", secondary: "Hungary"},
        ],
    },
    {
        label: "Southern Hemisphere",
        options: [
            {label: "Johannesburg", value: "8", secondary: "South Africa"},
            {label: "Cape Town", value: "cape-town", secondary: "South Africa"},
        ],
    },
];

const groupedCityOptionsFlat = groupedCityOptions.flatMap((group) => group.options);

type RenderListParams = {
    options: PlaygroundOption[];
    getElementTestId: (part: string) => string | undefined;
};

type RenderListChildren = React.ReactNode | ((option: PlaygroundOption, index: number) => React.ReactNode);

interface PlaygroundComboboxProps {
    label?: string;
    placeholder?: string;
    options?: PlaygroundOption[];
    size?: "sm" | "md" | "lg";
    multiline?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    required?: boolean;
    multiple?: boolean;
    defaultValue?: PlaygroundOption | PlaygroundOption[] | null;
    value?: PlaygroundOption | PlaygroundOption[] | null;
    onValueChange?: (value: PlaygroundOption | PlaygroundOption[] | null) => void;
    errorMessage?: string;
    testId?: string;
    clearable?: boolean;
    inputValue?: string;
    onInputValueChange?: (value: string) => void;
    filteredOptions?: PlaygroundOption[];
    autoComplete?: "list" | "both" | "inline" | "none";
    statusMessage?: string;
    renderList?: (params: RenderListParams) => RenderListChildren;
    renderEmpty?: (params: RenderListParams) => React.ReactNode;
    formActions?: React.ReactNode;
    formProps?: React.ComponentProps<typeof Form>;
}

function getChipKey(option: PlaygroundOption, index: number): string {
    if (option.value !== null && option.value !== undefined) {
        return `chip-${option.value}`;
    }
    if (option.label) {
        return `chip-${option.label}-${index}`;
    }
    return `chip-${index}`;
}

function ComboboxStoryPreview({
    label = "Label",
    placeholder = "Select a city",
    options = cityOptions,
    size = "md",
    multiline = false,
    disabled,
    readOnly,
    required,
    multiple = false,
    defaultValue,
    value,
    onValueChange,
    errorMessage,
    testId,
    clearable,
    inputValue,
    onInputValueChange,
    filteredOptions,
    autoComplete,
    statusMessage,
    renderList,
    renderEmpty,
    formActions,
    formProps,
}: PlaygroundComboboxProps) {
    const chipsContainerRef = React.useRef<HTMLDivElement | null>(null);
    const formErrors = errorMessage ? {[`combobox-${label}`]: errorMessage} : undefined;
    const resolvedFormProps = formProps ?? {};

    const selectionProps = React.useMemo(() => {
        if (value !== undefined) {
            return {value};
        }

        if (defaultValue !== undefined) {
            if (multiple) {
                return {defaultValue: (defaultValue as PlaygroundOption[]) ?? []};
            }
            return {defaultValue: (defaultValue as PlaygroundOption | null) ?? null};
        }

        return {defaultValue: multiple ? [] : null};
    }, [value, defaultValue, multiple]);

    const getElementTestId = React.useCallback((part: string) => (testId ? `${testId}-${part}` : undefined), [testId]);
    const optionsToRender = filteredOptions ?? options;
    const listChildren = React.useMemo<RenderListChildren>(() => {
        if (renderList) {
            return renderList({options: optionsToRender, getElementTestId});
        }

        return (option: PlaygroundOption) => (
            <Combobox.Item
                key={option.value ?? option.label ?? "option"}
                value={option}
                disabled={option.disabled}
                data-testid={
                    option.value === null ? getElementTestId("item-null") : getElementTestId(`item-${option.value}`)
                }
            >
                <div className="flex min-w-0 flex-1 flex-col">
                    <span>{option.label}</span>
                    {option.secondary ? (
                        <span className="bolt-font-body-s-regular text-secondary">{option.secondary}</span>
                    ) : null}
                </div>
                <Combobox.ItemIndicator />
            </Combobox.Item>
        );
    }, [getElementTestId, optionsToRender, renderList]);

    const emptyContent = renderEmpty?.({options: optionsToRender, getElementTestId}) ?? (
        <Combobox.Empty data-testid={getElementTestId("empty-state")}>No options found</Combobox.Empty>
    );

    const statusContent = statusMessage ? (
        <Combobox.Status
            className="bolt-font-body-s-regular mt-2 text-secondary"
            data-testid={getElementTestId("status")}
        >
            {statusMessage}
        </Combobox.Status>
    ) : null;

    const comboboxRootProps: Record<string, unknown> = {
        items: options,
        size,
        multiline,
        disabled,
        readOnly,
        required,
        multiple,
        autoComplete,
        ...selectionProps,
    };

    if (onValueChange) {
        comboboxRootProps.onValueChange = onValueChange;
    }
    if (filteredOptions) {
        comboboxRootProps.filteredItems = filteredOptions;
    }
    if (inputValue !== undefined) {
        comboboxRootProps.inputValue = inputValue;
    }
    if (onInputValueChange) {
        comboboxRootProps.onInputValueChange = onInputValueChange;
    }

    const showClearButton = clearable !== false;

    return (
        <Form {...resolvedFormProps} {...(formErrors ? {errors: formErrors} : {})}>
            <div className="w-96">
                <Field.Root name={`combobox-${label}`} disabled={disabled} invalid={Boolean(errorMessage)}>
                    <Field.Label>{label}</Field.Label>
                    <Combobox.Root {...comboboxRootProps}>
                        {multiple ? (
                            <Combobox.Chips ref={chipsContainerRef}>
                                <Combobox.Input data-testid={getElementTestId("trigger")} placeholder={placeholder}>
                                    <Combobox.ValueArea>
                                        <Combobox.Value>
                                            {(currentValue) => {
                                                const multiValue = Array.isArray(currentValue) ? currentValue : [];
                                                return (
                                                    <>
                                                        {multiValue.map((option, index) => (
                                                            <Combobox.Chip key={getChipKey(option, index)}>
                                                                <span className="max-w-[10rem] truncate">
                                                                    {option?.label ?? option?.value ?? ""}
                                                                </span>
                                                                <Combobox.ChipRemove
                                                                    aria-label={`Remove ${
                                                                        option?.label ?? option?.value ?? "option"
                                                                    }`}
                                                                />
                                                            </Combobox.Chip>
                                                        ))}
                                                        <Combobox.Control
                                                            placeholder={placeholder}
                                                            data-testid={getElementTestId("input")}
                                                        />
                                                    </>
                                                );
                                            }}
                                        </Combobox.Value>
                                    </Combobox.ValueArea>
                                    <Combobox.Controls>
                                        {showClearButton ? (
                                            <Combobox.Clear data-testid={getElementTestId("clear")} />
                                        ) : null}
                                        <Combobox.Trigger>
                                            <Combobox.Icon />
                                        </Combobox.Trigger>
                                    </Combobox.Controls>
                                </Combobox.Input>
                            </Combobox.Chips>
                        ) : (
                            <Combobox.Input data-testid={getElementTestId("trigger")} placeholder={placeholder}>
                                <Combobox.ValueArea>
                                    <Combobox.Control data-testid={getElementTestId("input")} />
                                </Combobox.ValueArea>
                                <Combobox.Controls>
                                    {showClearButton ? (
                                        <Combobox.Clear data-testid={getElementTestId("clear")} />
                                    ) : null}
                                    <Combobox.Trigger>
                                        <Combobox.Icon />
                                    </Combobox.Trigger>
                                </Combobox.Controls>
                            </Combobox.Input>
                        )}

                        <Combobox.Portal>
                            <Combobox.Positioner anchor={multiple ? chipsContainerRef : undefined} sideOffset={4}>
                                <Combobox.Popup>
                                    {emptyContent}
                                    <Combobox.List data-testid={getElementTestId("list")}>{listChildren}</Combobox.List>
                                </Combobox.Popup>
                            </Combobox.Positioner>
                        </Combobox.Portal>
                    </Combobox.Root>
                    {statusContent}
                    <Field.Error />
                    {formActions ? <div className="mt-4 flex flex-wrap gap-3">{formActions}</div> : null}
                </Field.Root>
            </div>
        </Form>
    );
}

const defaultStorySource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
];

function DefaultCombobox() {
  return (
    <Form>
      <Field.Root name="city">
        <Field.Label>Destination</Field.Label>
        <Combobox.Root items={cities}>
          <Combobox.Input placeholder="Select a city">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>

          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      <span className="truncate">{item.label}</span>
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
        <Field.Error />
      </Field.Root>
    </Form>
  );
}
`;

export const Default: Story = {
    render: () => <ComboboxStory placeholder="Select a city" testId="combobox-default" />,
    play: async ({canvasElement, step}) => {
        const getElements = () => {
            const canvas = within(canvasElement);
            const body = within(canvasElement.ownerDocument.body);
            return {
                canvas,
                body,
                trigger: canvas.getByTestId("combobox-default-trigger"),
                input: canvas.getByTestId("combobox-default-input"),
            };
        };

        const resetAndGetElements = async () => {
            const {canvas} = getElements();
            const resetButton = canvas.getByTestId("combobox-default-reset");
            await userEvent.click(resetButton);
            return waitFor(() => getElements());
        };

        await step("Shows placeholder text while no value is selected", async () => {
            const {input} = getElements();
            await expect(input).toHaveValue("");
            await expect(input).toHaveAttribute("placeholder", "Select a city");
        });

        await step("Opens the popup and closes via outside click and Escape", async () => {
            const {body, trigger, input} = await resetAndGetElements();

            await userEvent.click(trigger);
            await waitFor(() => {
                expect(body.getByTestId("combobox-default-list")).toBeVisible();
            });
            await userEvent.click(canvasElement.ownerDocument.body);
            await waitFor(() => {
                expect(body.queryByTestId("combobox-default-list")).not.toBeInTheDocument();
            });

            await userEvent.click(trigger);
            await waitFor(() => {
                expect(body.getByTestId("combobox-default-list")).toBeVisible();
            });
            await userEvent.click(input);
            await userEvent.keyboard("{Escape}");
            await waitFor(() => {
                expect(body.queryByTestId("combobox-default-list")).not.toBeInTheDocument();
            });
        });

        await step("Selects an option via keyboard navigation", async () => {
            const {body, trigger, input} = await resetAndGetElements();

            await userEvent.click(trigger);
            await waitFor(() => {
                expect(body.getByTestId("combobox-default-list")).toBeVisible();
            });
            await userEvent.click(input);
            await userEvent.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}{ArrowUp}{Enter}");
            await waitFor(() => {
                expect(body.queryByTestId("combobox-default-list")).not.toBeInTheDocument();
            });
            await expect(input).toHaveValue("Stockholm");
        });

        await step("Selects via mouse and updates the displayed value", async () => {
            const {body, trigger, input} = await resetAndGetElements();

            await userEvent.click(trigger);
            const berlin = await body.findByText("Berlin");
            await userEvent.click(berlin);
            await waitFor(() => {
                expect(body.queryByTestId("combobox-default-list")).not.toBeInTheDocument();
            });
            await expect(input).toHaveValue("Berlin");
            await expect(input).toHaveAttribute("placeholder", "Select a city");
        });
    },
    ...withSource(defaultStorySource),
};

const multilineStorySource = `
const multilineCities = [
  {
    label: 'Just an example entry that can be long and span across multiple lines',
    value: 'long',
  },
  {label: 'Tallinn', value: '1', secondary: 'Estonia'},
  {label: 'Stockholm', value: '2', secondary: 'Sweden'},
  {label: 'Berlin', value: '3', secondary: 'Germany'},
];

function MultilineCombobox() {
  return (
    <Form>
      <Field.Root name="city">
        <Field.Label>Pick a city</Field.Label>
        <Combobox.Root items={multilineCities} multiline>
          <Combobox.Input placeholder="Pick a city">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>

          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      <div className="flex min-w-0 flex-1 flex-col">
                        <span className="truncate">{item.label}</span>
                        {item.secondary ? (
                          <span className="bolt-font-body-s-regular text-secondary">{item.secondary}</span>
                        ) : null}
                      </div>
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
        <Field.Error />
      </Field.Root>
    </Form>
  );
}
`;

export const Multiline: Story = {
    render: () => (
        <ComboboxStory placeholder="Pick a city" options={multilineOptions} multiline testId="combobox-multiline" />
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const body = within(canvasElement.ownerDocument.body);
        const trigger = await canvas.findByTestId("combobox-multiline-trigger");
        const input = await canvas.findByTestId("combobox-multiline-input");

        await step("Wraps control content for long values", async () => {
            await expect(trigger).toHaveClass("flex-wrap");
            await userEvent.click(trigger);
            const multilineLabel = await body.findByText(
                "Just an example entry that can be long and span across multiple lines",
            );
            await userEvent.click(multilineLabel);
            await waitFor(() => {
                expect(body.queryByTestId("combobox-multiline-list")).not.toBeInTheDocument();
            });
            await expect(input).toHaveValue("Just an example entry that can be long and span across multiple lines");
        });
    },
    ...withSource(multilineStorySource),
};

const multipleStorySource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
];

function MultipleCombobox() {
  const chipsRef = React.useRef<HTMLDivElement | null>(null);

  return (
    <Form>
      <Field.Root name="cities">
        <Field.Label>Select multiple cities</Field.Label>
        <Combobox.Root items={cities} multiple defaultValue={[cities[1], cities[2]]}>
          <Combobox.Chips ref={chipsRef}>
            <Combobox.Input placeholder="Pick multiple cities">
              <Combobox.ValueArea>
                <Combobox.Value>
                  {(currentValue) => {
                    const selected = Array.isArray(currentValue) ? currentValue : [];
                    return (
                      <>
                        {selected.map((option) => (
                          <Combobox.Chip key={option.value}>
                            <span className="max-w-[10rem] truncate">{option.label}</span>
                            <Combobox.ChipRemove aria-label={'Remove ' + (option.label ?? option.value ?? 'option')} />
                          </Combobox.Chip>
                        ))}
                        <Combobox.Control placeholder="Pick multiple cities" />
                      </>
                    );
                  }}
                </Combobox.Value>
              </Combobox.ValueArea>
              <Combobox.Controls>
                <Combobox.Trigger>
                  <Combobox.Icon />
                </Combobox.Trigger>
              </Combobox.Controls>
            </Combobox.Input>
          </Combobox.Chips>

          <Combobox.Portal>
            <Combobox.Positioner anchor={chipsRef} sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      <span className="truncate">{item.label}</span>
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
        <Field.Error />
      </Field.Root>
    </Form>
  );
}
`;

export const Multiple: Story = {
    render: () => (
        <ComboboxStory
            placeholder="Pick multiple cities"
            options={cityOptions.slice(1)}
            multiple
            clearable={false}
            testId="combobox-multiple"
        />
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);

        await step("Hides the clear action when `clearable` is false", async () => {
            expect(canvas.queryByTestId("combobox-multiple-clear")).not.toBeInTheDocument();
        });
    },
    ...withSource(multipleStorySource),
};

type ComboboxStoryProps = PlaygroundComboboxProps & {resetKey?: number};

function ComboboxStory({resetKey, testId, ...props}: ComboboxStoryProps) {
    const [internalResetKey, setInternalResetKey] = React.useState(0);
    const effectiveResetKey = resetKey ?? internalResetKey;
    const shouldRenderResetControl = testId && resetKey === undefined;

    return (
        <>
            {shouldRenderResetControl ? (
                <button
                    type="button"
                    tabIndex={-1}
                    aria-hidden="true"
                    data-testid={`${testId}-reset`}
                    onClick={() => setInternalResetKey((key) => key + 1)}
                    style={{
                        position: "absolute",
                        width: 1,
                        height: 1,
                        padding: 0,
                        margin: 0,
                        opacity: 0,
                        border: 0,
                    }}
                >
                    Reset combobox story
                </button>
            ) : null}
            <div key={effectiveResetKey} className="flex flex-col">
                <ComboboxStoryPreview {...props} testId={testId} />
            </div>
        </>
    );
}

type Story = StoryObj<typeof ComboboxStory>;

function FilterableComboboxStory() {
    const [value, setValue] = React.useState<PlaygroundOption | null>(null);
    const [query, setQuery] = React.useState("");
    const filter = Combobox.useFilter({sensitivity: "base"});

    const filteredOptions = React.useMemo(() => {
        if (!query.trim()) {
            return cityOptions;
        }

        return cityOptions.filter((option) => filter.contains(option, query, (item) => item.label ?? item.value ?? ""));
    }, [filter, query]);

    const status = query.trim()
        ? `${filteredOptions.length} result${filteredOptions.length === 1 ? "" : "s"} found`
        : "Type to filter cities";

    return (
        <ComboboxStory
            label="Filter by city name"
            placeholder="Start typing"
            options={cityOptions}
            filteredOptions={filteredOptions}
            value={value}
            onValueChange={(nextValue) => setValue((nextValue as PlaygroundOption) ?? null)}
            inputValue={query}
            onInputValueChange={(nextValue) => setQuery(nextValue)}
            statusMessage={status}
            autoComplete="list"
            testId="combobox-client-filter"
        />
    );
}

function AsyncComboboxStory() {
    const [options, setOptions] = React.useState<PlaygroundOption[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [value, setValue] = React.useState<PlaygroundOption | null>(null);

    React.useEffect(() => {
        const timeoutId = window.setTimeout(() => {
            setOptions(cityOptions);
            setLoading(false);
        }, 600);

        return () => window.clearTimeout(timeoutId);
    }, []);

    return (
        <ComboboxStory
            label="Async city picker"
            placeholder="Search cities"
            options={options}
            value={value}
            onValueChange={(nextValue) => setValue((nextValue as PlaygroundOption) ?? null)}
            statusMessage={loading ? "Loading cities…" : `${options.length} cities loaded`}
            testId="combobox-async"
        />
    );
}

function ControlledComboboxStory() {
    const [value, setValue] = React.useState<PlaygroundOption | null>(cityOptions[0]);

    return (
        <div className="flex flex-col gap-4">
            <ComboboxStory
                label="Controlled combobox"
                placeholder="Choose a city"
                options={cityOptions}
                value={value}
                onValueChange={(nextValue) => setValue((nextValue as PlaygroundOption) ?? null)}
                testId="combobox-controlled-single"
            />
            <div className="bolt-font-body-s-regular text-secondary">Current selection: {value?.label ?? "None"}</div>
            <div className="flex flex-wrap gap-2">
                <button
                    type="button"
                    className="rounded-md border border-solid border-neutral-secondary px-3 py-2 text-sm"
                    onClick={() => setValue(cityOptions[2])}
                >
                    Pick Berlin
                </button>
                <button
                    type="button"
                    className="rounded-md border border-solid border-neutral-secondary px-3 py-2 text-sm"
                    onClick={() => setValue(null)}
                >
                    Clear selection
                </button>
            </div>
        </div>
    );
}

function ControlledMultipleComboboxStory() {
    const [value, setValue] = React.useState<PlaygroundOption[]>([cityOptions[1], cityOptions[2]]);

    const handleValueChange = React.useCallback((nextValue: PlaygroundOption | PlaygroundOption[] | null) => {
        setValue(Array.isArray(nextValue) ? nextValue : []);
    }, []);

    return (
        <div className="flex flex-col gap-4">
            <ComboboxStory
                label="Controlled multi-select"
                placeholder="Select cities"
                options={cityOptions}
                multiple
                value={value}
                onValueChange={handleValueChange}
                testId="combobox-controlled-multi"
            />
            <div className="bolt-font-body-s-regular text-secondary">
                Selected: {value.length ? value.map((option) => option.label).join(", ") : "None"}
            </div>
            <div className="flex flex-wrap gap-2">
                <button
                    type="button"
                    className="rounded-md border border-solid border-neutral-secondary px-3 py-2 text-sm"
                    onClick={() => setValue([cityOptions[0], cityOptions[3]])}
                >
                    Pick Tallinn & Warsaw
                </button>
                <button
                    type="button"
                    className="rounded-md border border-solid border-neutral-secondary px-3 py-2 text-sm"
                    onClick={() => setValue([])}
                >
                    Clear all
                </button>
            </div>
        </div>
    );
}

function FormIntegrationStory() {
    const label = "Form submission";
    const fieldName = `combobox-${label}`;
    const [errorMessage, setErrorMessage] = React.useState<string | undefined>();
    const [lastSubmit, setLastSubmit] = React.useState("(none)");

    const handleSubmit = React.useCallback(
        (event: React.FormEvent<HTMLFormElement>) => {
            event.preventDefault();
            const formData = new FormData(event.currentTarget);
            const submittedValue = formData.get(fieldName);

            if (!submittedValue) {
                setErrorMessage("Please choose a city before submitting");
                setLastSubmit("(none)");
                return;
            }

            setErrorMessage(undefined);
            setLastSubmit(`${fieldName}: ${submittedValue}`);
        },
        [fieldName],
    );

    return (
        <div className="flex flex-col gap-4">
            <ComboboxStory
                label={label}
                placeholder="Select a city"
                required
                errorMessage={errorMessage}
                formProps={{onSubmitCapture: handleSubmit}}
                formActions={
                    <button
                        type="submit"
                        className={`
                          rounded-md border border-solid border-action-primary px-4 py-2 text-sm text-action-primary
                        `}
                        data-testid="combobox-form-submit"
                    >
                        Submit selection
                    </button>
                }
                testId="combobox-form"
            />
            <div className="bolt-font-body-s-regular text-secondary" data-testid="combobox-form-output">
                Last submitted: {lastSubmit}
            </div>
        </div>
    );
}

const singleSelectSizesSource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
];

function SingleSelectSizes() {
  return (
    <div className="flex flex-col gap-8">
      <Field.Root name="city-sm">
        <Field.Label>Small</Field.Label>
        <Combobox.Root items={cities} size="sm">
          <Combobox.Input placeholder="Select a city">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      <span className="truncate">{item.label}</span>
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
      </Field.Root>

      <Field.Root name="city-md">
        <Field.Label>Medium</Field.Label>
        <Combobox.Root items={cities} size="md">
          <Combobox.Input placeholder="Select a city">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      <span className="truncate">{item.label}</span>
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
      </Field.Root>

      <Field.Root name="city-lg">
        <Field.Label>Large</Field.Label>
        <Combobox.Root items={cities} size="lg">
          <Combobox.Input placeholder="Select a city">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      <span className="truncate">{item.label}</span>
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
      </Field.Root>
    </div>
  );
}
`;

export const SingleSelectSizes: Story = {
    render: () => (
        <div className="flex flex-col gap-8">
            <ComboboxStory label="Small" size="sm" placeholder="Select a city" testId="combobox-size-sm" />
            <ComboboxStory label="Medium" size="md" placeholder="Select a city" testId="combobox-size-md" />
            <ComboboxStory label="Large" size="lg" placeholder="Select a city" testId="combobox-size-lg" />
        </div>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const smallTrigger = await canvas.findByTestId("combobox-size-sm-trigger");
        const mediumTrigger = await canvas.findByTestId("combobox-size-md-trigger");
        const largeTrigger = await canvas.findByTestId("combobox-size-lg-trigger");

        await step("Applies the expected paddings per size", async () => {
            await expect(smallTrigger).toHaveClass("min-h-9");
            await expect(mediumTrigger).toHaveClass("min-h-12");
            await expect(largeTrigger).toHaveClass("min-h-14");
        });
    },
    ...withSource(singleSelectSizesSource),
};

const disabledAndReadOnlySource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
];

function DisabledAndReadOnlyComboboxes() {
  return (
    <div className="flex flex-col gap-8">
      <Field.Root name="city-disabled" disabled>
        <Field.Label>Disabled combobox</Field.Label>
        <Combobox.Root items={cities} disabled>
          <Combobox.Input placeholder="Cannot edit">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      {item.label}
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
      </Field.Root>

      <Field.Root name="city-readonly">
        <Field.Label>Read-only combobox</Field.Label>
        <Combobox.Root items={cities} readOnly defaultValue={cities[2]}>
          <Combobox.Input placeholder="Read only">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      {item.label}
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
      </Field.Root>
    </div>
  );
}
`;

export const DisabledAndReadOnly: Story = {
    render: () => (
        <div className="flex flex-col gap-8">
            <ComboboxStory label="Disabled combobox" placeholder="Cannot edit" disabled testId="combobox-disabled" />
            <ComboboxStory
                label="Read-only combobox"
                placeholder="Read only"
                readOnly
                defaultValue={cityOptions[2]}
                testId="combobox-readonly"
            />
        </div>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const body = within(canvasElement.ownerDocument.body);
        const disabledTrigger = await canvas.findByTestId("combobox-disabled-trigger");
        const disabledInput = await canvas.findByTestId("combobox-disabled-input");
        const readOnlyInput = await canvas.findByTestId("combobox-readonly-input");

        await step("Keeps the disabled combobox inert", async () => {
            await expect(disabledInput).toBeDisabled();
            await userEvent.click(disabledTrigger);
            await waitFor(() => {
                expect(body.queryByTestId("combobox-disabled-list")).not.toBeInTheDocument();
            });
        });

        await step("Prevents editing the read-only combobox value", async () => {
            await expect(readOnlyInput).toHaveAttribute("readonly");
            await expect(readOnlyInput).toHaveValue("Berlin");
            await userEvent.type(readOnlyInput, "Tallinn");
            await expect(readOnlyInput).toHaveValue("Berlin");
        });
    },
    ...withSource(disabledAndReadOnlySource),
};

const requiredStorySource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
];

function RequiredCombobox() {
  return (
    <Form>
      <Field.Root name="city">
        <Field.Label>Required field</Field.Label>
        <Combobox.Root items={cities} required>
          <Combobox.Input placeholder="Select a city">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      {item.label}
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
        <Field.Error />
      </Field.Root>
    </Form>
  );
}
`;

export const Required: Story = {
    render: () => (
        <ComboboxStory label="Required field" placeholder="Select a city" required testId="combobox-required" />
    ),
    ...withSource(requiredStorySource),
};

const fieldErrorStorySource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
];

function FieldErrorCombobox() {
  return (
    <Form errors={{city: 'Please choose a city before continuing'}}>
      <Field.Root name="city" invalid>
        <Field.Label>City</Field.Label>
        <Combobox.Root items={cities}>
          <Combobox.Input placeholder="Select a city">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      {item.label}
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
        <Field.Error />
      </Field.Root>
    </Form>
  );
}
`;

export const FieldError: Story = {
    render: () => (
        <ComboboxStory label="City" placeholder="Select a city" errorMessage="Please choose a city before continuing" />
    ),
    ...withSource(fieldErrorStorySource),
};

const formIntegrationStorySource = `
function ComboboxFormIntegration() {
  const label = 'Form submission';
  const fieldName = 'combobox-' + label;
  const [errorMessage, setErrorMessage] = React.useState<string | undefined>();
  const [lastSubmit, setLastSubmit] = React.useState('(none)');

  const handleSubmit = React.useCallback((event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const submittedValue = formData.get(fieldName);

    if (!submittedValue) {
      setErrorMessage('Please choose a city before submitting');
      setLastSubmit('(none)');
      return;
    }

    setErrorMessage(undefined);
    setLastSubmit(fieldName + ': ' + submittedValue);
  }, [fieldName]);

  return (
    <div className="flex flex-col gap-4">
      <ComboboxStory
        label={label}
        placeholder="Select a city"
        required
        errorMessage={errorMessage}
        formProps={{onSubmitCapture: handleSubmit}}
        formActions={
          <button type="submit" className="rounded-md border border-solid border-action-primary px-4 py-2 text-sm text-action-primary">
            Submit selection
          </button>
        }
      />
      <div className="bolt-font-body-s-regular text-secondary">
        Last submitted: {lastSubmit}
      </div>
    </div>
  );
}
`;

export const FormIntegration: Story = {
    render: () => <FormIntegrationStory />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const body = within(canvasElement.ownerDocument.body);
        const trigger = await canvas.findByTestId("combobox-form-trigger");
        const input = await canvas.findByTestId("combobox-form-input");
        const submitButton = await canvas.findByTestId("combobox-form-submit");
        const output = await canvas.findByTestId("combobox-form-output");
        const formElement = trigger.closest("form");
        const baseCombobox = formElement ? within(formElement) : canvas;

        await step("Prevents submitting when the required selection is empty", async () => {
            await expect(output).toHaveTextContent("Last submitted: (none)");
            await userEvent.click(submitButton);
            await waitFor(() => {
                expect(baseCombobox.getByText("Please choose a city before submitting")).toBeVisible();
            });
        });

        await step("Submits the selected value through the form", async () => {
            await userEvent.click(trigger);
            const paris = await body.findByText("Paris");
            await userEvent.click(paris);
            await waitFor(() => {
                expect(body.queryByTestId("combobox-form-list")).not.toBeInTheDocument();
            });
            await userEvent.click(submitButton);
            await waitFor(() => {
                expect(baseCombobox.queryByText("Please choose a city before submitting")).not.toBeInTheDocument();
            });
            // 5 is the value of Paris in cityOptions
            await expect(output).toHaveTextContent("Last submitted: combobox-Form submission: 5");
        });

        await step("Allows clearing the form value to trigger validation again", async () => {
            const clearButton = await canvas.findByTestId("combobox-form-clear");
            await userEvent.click(clearButton);
            await expect(input).toHaveValue("");
            await userEvent.click(submitButton);
            await waitFor(() => {
                expect(baseCombobox.getByText("Please choose a city before submitting")).toBeVisible();
            });
        });
    },
    ...withSource(formIntegrationStorySource),
};

const clearableSingleSelectSource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
];

function ClearableCombobox() {
  return (
    <Field.Root name="city">
      <Field.Label>Clearable combobox</Field.Label>
      <Combobox.Root items={cities} defaultValue={cities[2]}>
        <Combobox.Input placeholder="Select a city">
          <Combobox.ValueArea>
            <Combobox.Control />
          </Combobox.ValueArea>
          <Combobox.Controls>
            <Combobox.Clear />
            <Combobox.Trigger>
              <Combobox.Icon />
            </Combobox.Trigger>
          </Combobox.Controls>
        </Combobox.Input>
        <Combobox.Portal>
          <Combobox.Positioner sideOffset={4}>
            <Combobox.Popup>
              <Combobox.List>
                {(item) => (
                  <Combobox.Item key={item.value} value={item}>
                    {item.label}
                    <Combobox.ItemIndicator />
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
      <Field.Error />
    </Field.Root>
  );
}
`;

export const ClearableSingleSelect: Story = {
    render: () => (
        <ComboboxStory
            label="Clearable combobox"
            placeholder="Select a city"
            defaultValue={cityOptions[2]}
            testId="combobox-clearable"
        />
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const body = within(canvasElement.ownerDocument.body);
        const trigger = await canvas.findByTestId("combobox-clearable-trigger");
        const input = await canvas.findByTestId("combobox-clearable-input");
        const clearButton = await canvas.findByTestId("combobox-clearable-clear");

        await step("Shows the current selection", async () => {
            await expect(input).toHaveValue("Berlin");
        });

        await step("Clears the value and allows selecting again", async () => {
            await userEvent.click(clearButton);
            await expect(input).toHaveValue("");
            await userEvent.click(trigger);
            const tallinn = await body.findByText("Tallinn");
            await userEvent.click(tallinn);
            await waitFor(() => {
                expect(body.queryByTestId("combobox-clearable-list")).not.toBeInTheDocument();
            });
            await expect(input).toHaveValue("Tallinn");
        });
    },
    ...withSource(clearableSingleSelectSource),
};

const clientFilterStorySource = `
type CityOption = {label: string; value: string};

const cities: CityOption[] = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
  {label: 'Johannesburg', value: '5'},
];

function ClientFilteredCombobox() {
  const [value, setValue] = React.useState<CityOption | null>(null);
  const [query, setQuery] = React.useState('');
  const filter = Combobox.useFilter({sensitivity: 'base'});

  const filteredCities = React.useMemo(() => {
    if (!query.trim()) {
      return cities;
    }

    return cities.filter((city) => filter.contains(city, query, (option) => option.label));
  }, [filter, query]);

  const status = query.trim()
    ? filteredCities.length + ' result' + (filteredCities.length === 1 ? '' : 's') + ' found'
    : 'Type to filter cities';

  return (
    <Form>
      <Field.Root name="city">
        <Field.Label>Filter by city name</Field.Label>
        <Combobox.Root
          items={cities}
          filteredItems={filteredCities}
          value={value}
          onValueChange={(nextValue) => setValue((nextValue as CityOption) ?? null)}
          inputValue={query}
          onInputValueChange={setQuery}
          autoComplete="list"
          statusMessage={status}
        >
          <Combobox.Input placeholder="Start typing">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      {item.label}
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
        <Combobox.Status className="bolt-font-body-s-regular mt-2 text-secondary">{status}</Combobox.Status>
        <Field.Error />
      </Field.Root>
    </Form>
  );
}
`;

export const ClientFilter: Story = {
    render: () => <FilterableComboboxStory />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const body = within(canvasElement.ownerDocument.body);
        const trigger = await canvas.findByTestId("combobox-client-filter-trigger");
        const input = await canvas.findByTestId("combobox-client-filter-input");
        const status = await canvas.findByTestId("combobox-client-filter-status");

        await step("Indicates list auto-complete mode and helper text", async () => {
            await expect(input).toHaveAttribute("aria-autocomplete", "list");
            await expect(status).toHaveTextContent("Type to filter cities");
        });

        await step("Opens list for filtering", async () => {
            await userEvent.click(trigger);
            const list = await body.findByTestId("combobox-client-filter-list");
            await expect(list).toBeVisible();
        });

        await step("Filters down to Johannesburg and selects it", async () => {
            await userEvent.type(input, "jo");
            await waitFor(() => {
                expect(status).toHaveTextContent("1 result");
            });
            const johannesburg = await body.findByText("Johannesburg");
            await userEvent.click(johannesburg);
            await waitFor(() => {
                expect(body.queryByTestId("combobox-client-filter-list")).not.toBeInTheDocument();
            });
            await expect(input).toHaveValue("Johannesburg");
        });
    },
    ...withSource(clientFilterStorySource),
};

const asyncItemsStorySource = `
type CityOption = {label: string; value: string};

const cities: CityOption[] = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
];

function AsyncItemsCombobox() {
  const [options, setOptions] = React.useState<CityOption[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [value, setValue] = React.useState<CityOption | null>(null);

  React.useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      setOptions(cities);
      setLoading(false);
    }, 600);

    return () => window.clearTimeout(timeoutId);
  }, []);

  const status = loading ? 'Loading cities…' : options.length + ' cities loaded';

  return (
    <Form>
      <Field.Root name="city">
        <Field.Label>Async city picker</Field.Label>
        <Combobox.Root
          items={options}
          value={value}
          onValueChange={(nextValue) => setValue((nextValue as CityOption) ?? null)}
          statusMessage={status}
        >
          <Combobox.Input placeholder="Search cities">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                {options.length === 0 ? (
                  <Combobox.Empty>No options loaded yet</Combobox.Empty>
                ) : (
                  <Combobox.List>
                    {(item) => (
                      <Combobox.Item key={item.value} value={item}>
                        {item.label}
                        <Combobox.ItemIndicator />
                      </Combobox.Item>
                    )}
                  </Combobox.List>
                )}
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
        <Combobox.Status className="bolt-font-body-s-regular mt-2 text-secondary">{status}</Combobox.Status>
      </Field.Root>
    </Form>
  );
}
`;

export const AsyncItems: Story = {
    render: () => <AsyncComboboxStory />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const body = within(canvasElement.ownerDocument.body);
        const trigger = await canvas.findByTestId("combobox-async-trigger");
        const input = await canvas.findByTestId("combobox-async-input");
        const status = await canvas.findByTestId("combobox-async-status");

        await step("Indicates loading state", async () => {
            await expect(status).toHaveTextContent("Loading cities…");
        });

        await step("Shows loaded options and selects Lisbon", async () => {
            await waitFor(
                () => {
                    expect(status).toHaveTextContent("8 cities loaded");
                },
                {timeout: 2000},
            );
            await userEvent.click(trigger);
            const lisbon = await body.findByText("Lisbon");
            await userEvent.click(lisbon);
            await waitFor(() => {
                expect(body.queryByTestId("combobox-async-list")).not.toBeInTheDocument();
            });
            await expect(input).toHaveValue("Lisbon");
        });
    },
    ...withSource(asyncItemsStorySource),
};

const multiSelectDefaultStorySource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
];

function MultiSelectCombobox() {
  const chipsRef = React.useRef<HTMLDivElement | null>(null);

  return (
    <Field.Root name="cities">
      <Field.Label>Multiple selections</Field.Label>
      <Combobox.Root items={cities} multiple defaultValue={[cities[0], cities[1]]}>
        <Combobox.Chips ref={chipsRef}>
          <Combobox.Input placeholder="Select cities">
            <Combobox.ValueArea>
              <Combobox.Value>
                {(currentValue) => {
                  const selected = Array.isArray(currentValue) ? currentValue : [];
                  return (
                    <>
                      {selected.map((option) => (
                        <Combobox.Chip key={option.value}>
                          <span className="max-w-[10rem] truncate">{option.label}</span>
                          <Combobox.ChipRemove aria-label={'Remove ' + (option.label ?? option.value ?? 'option')} />
                        </Combobox.Chip>
                      ))}
                      <Combobox.Control placeholder="Select cities" />
                    </>
                  );
                }}
              </Combobox.Value>
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
        </Combobox.Chips>

        <Combobox.Portal>
          <Combobox.Positioner anchor={chipsRef} sideOffset={4}>
            <Combobox.Popup>
              <Combobox.List>
                {(item) => (
                  <Combobox.Item key={item.value} value={item}>
                    {item.label}
                    <Combobox.ItemIndicator />
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
      <Field.Error />
    </Field.Root>
  );
}
`;

export const MultiSelectDefault: Story = {
    render: () => (
        <ComboboxStory
            label="Multiple selections"
            placeholder="Select cities"
            multiple
            defaultValue={[cityOptions[0], cityOptions[1]]}
            testId="combobox-multi-default"
        />
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const body = within(canvasElement.ownerDocument.body);
        const trigger = await canvas.findByTestId("combobox-multi-default-trigger");
        const formElement = trigger.closest("form");
        const baseCombobox = formElement ? within(formElement) : canvas;

        await step("Allows adding extra chips", async () => {
            await userEvent.click(trigger);
            const warsaw = await body.findByText("Warsaw");
            await userEvent.click(warsaw);
            await expect(baseCombobox.getByText("Warsaw")).toBeVisible();
        });

        await step("Supports removing an existing chip", async () => {
            const removeStockholm = await baseCombobox.findByLabelText("Remove Stockholm");
            await userEvent.click(removeStockholm);
            await waitFor(() => {
                expect(baseCombobox.queryByText("Stockholm")).not.toBeInTheDocument();
            });
        });

        await step("Clears all selections with the clear button", async () => {
            const clearButton = await canvas.findByTestId("combobox-multi-default-clear");
            await userEvent.click(clearButton);
            await waitFor(() => {
                expect(baseCombobox.queryByText("Tallinn")).not.toBeInTheDocument();
                expect(baseCombobox.queryByText("Warsaw")).not.toBeInTheDocument();
            });
            const input = await canvas.findByTestId("combobox-multi-default-input");
            await expect(input).toHaveValue("");
        });
    },
    ...withSource(multiSelectDefaultStorySource),
};

const multiSelectMultilineStorySource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
  {label: 'Paris', value: '5'},
];

function MultilineMultiSelect() {
  const chipsRef = React.useRef<HTMLDivElement | null>(null);

  return (
    <Field.Root name="cities">
      <Field.Label>Multiline chips</Field.Label>
      <Combobox.Root
        items={cities}
        multiple
        multiline
        defaultValue={[cities[0], cities[1], cities[2], cities[3]]}
      >
        <Combobox.Chips ref={chipsRef}>
          <Combobox.Input placeholder="Select cities">
            <Combobox.ValueArea>
              <Combobox.Value>
                {(currentValue) => {
                  const selected = Array.isArray(currentValue) ? currentValue : [];
                  return (
                    <>
                      {selected.map((option) => (
                        <Combobox.Chip key={option.value}>
                          <span className="max-w-[10rem] truncate">{option.label}</span>
                          <Combobox.ChipRemove aria-label={'Remove ' + (option.label ?? option.value ?? 'option')} />
                        </Combobox.Chip>
                      ))}
                      <Combobox.Control placeholder="Select cities" />
                    </>
                  );
                }}
              </Combobox.Value>
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
        </Combobox.Chips>
        <Combobox.Portal>
          <Combobox.Positioner anchor={chipsRef} sideOffset={4}>
            <Combobox.Popup>
              <Combobox.List>
                {(item) => (
                  <Combobox.Item key={item.value} value={item}>
                    {item.label}
                    <Combobox.ItemIndicator />
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
    </Field.Root>
  );
}
`;

export const MultiSelectMultiline: Story = {
    render: () => (
        <ComboboxStory
            label="Multiline chips"
            placeholder="Select cities"
            multiple
            multiline
            defaultValue={[cityOptions[0], cityOptions[1], cityOptions[2], cityOptions[3]]}
            testId="combobox-multiline-multi"
        />
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const trigger = await canvas.findByTestId("combobox-multiline-multi-trigger");
        const input = await canvas.findByTestId("combobox-multiline-multi-input");
        const formElement = trigger.closest("form");
        const baseCombobox = formElement ? within(formElement) : canvas;

        await step("Wraps multi-select chips across rows", async () => {
            await expect(trigger).toHaveClass("flex-wrap");
            const removeButtons = baseCombobox.getAllByRole("button", {name: /Remove/});
            expect(removeButtons.length).toBeGreaterThan(3);
        });

        await step("Keeps the input editable after wrapping", async () => {
            await userEvent.click(input);
            await userEvent.type(input, "Ta");
            await expect(input).toHaveValue("Ta");
            await userEvent.keyboard("{Backspace}{Backspace}");
            await expect(input).toHaveValue("");
        });
    },
    ...withSource(multiSelectMultilineStorySource),
};

const multiSelectDisabledStorySource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
];

function DisabledMultiSelect() {
  const chipsRef = React.useRef<HTMLDivElement | null>(null);

  return (
    <Field.Root name="cities" disabled>
      <Field.Label>Disabled multi-select</Field.Label>
      <Combobox.Root items={cities} multiple disabled defaultValue={[cities[0], cities[3]]}>
        <Combobox.Chips ref={chipsRef}>
          <Combobox.Input placeholder="Disabled">
            <Combobox.ValueArea>
              <Combobox.Value>
                {(currentValue) => {
                  const selected = Array.isArray(currentValue) ? currentValue : [];
                  return (
                    <>
                      {selected.map((option) => (
                        <Combobox.Chip key={option.value}>
                          <span className="max-w-[10rem] truncate">{option.label}</span>
                          <Combobox.ChipRemove aria-label={'Remove ' + (option.label ?? option.value ?? 'option')} />
                        </Combobox.Chip>
                      ))}
                      <Combobox.Control placeholder="Disabled" />
                    </>
                  );
                }}
              </Combobox.Value>
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
        </Combobox.Chips>
        <Combobox.Portal>
          <Combobox.Positioner anchor={chipsRef} sideOffset={4}>
            <Combobox.Popup>
              <Combobox.List>
                {(item) => (
                  <Combobox.Item key={item.value} value={item}>
                    {item.label}
                    <Combobox.ItemIndicator />
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
    </Field.Root>
  );
}
`;

export const MultiSelectDisabled: Story = {
    render: () => (
        <ComboboxStory
            label="Disabled multi-select"
            placeholder="Disabled"
            multiple
            disabled
            defaultValue={[cityOptions[0], cityOptions[3]]}
        />
    ),
    ...withSource(multiSelectDisabledStorySource),
};

const multiSelectWithCheckboxesStorySource = `
const cities = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
  {label: 'Paris', value: '5'},
];

function MultiSelectWithCheckboxesCombobox() {
  const chipsRef = React.useRef<HTMLDivElement | null>(null);
  const [value, setValue] = React.useState([cities[0], cities[2]]);

  return (
    <Field.Root name="cities">
      <Field.Label>Select cities</Field.Label>
      <Combobox.Root items={cities} multiple value={value} onValueChange={(next) => setValue(Array.isArray(next) ? next : [])}>
        <Combobox.Chips ref={chipsRef}>
          <Combobox.Input placeholder="Select cities">
            <Combobox.ValueArea>
              <Combobox.Value>
                {(currentValue) => {
                  const selected = Array.isArray(currentValue) ? currentValue : [];
                  return (
                    <>
                      {selected.map((option) => (
                        <Combobox.Chip key={option.value}>
                          <span className="max-w-[10rem] truncate">{option.label}</span>
                          <Combobox.ChipRemove aria-label={'Remove ' + (option.label ?? option.value ?? 'option')} />
                        </Combobox.Chip>
                      ))}
                      <Combobox.Control placeholder="Select cities" />
                    </>
                  );
                }}
              </Combobox.Value>
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
        </Combobox.Chips>

        <Combobox.Portal>
          <Combobox.Positioner anchor={chipsRef} sideOffset={4}>
            <Combobox.Popup>
              <Combobox.List>
                {(item) => (
                  <Combobox.Item key={item.value} value={item}>
                    <Combobox.CheckboxIndicator />
                    <span className="truncate">{item.label}</span>
                  </Combobox.Item>
                )}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
      <Field.Error />
    </Field.Root>
  );
}
`;

function MultiSelectWithCheckboxesStory() {
    const chipsRef = React.useRef<HTMLDivElement | null>(null);
    const [value, setValue] = React.useState<PlaygroundOption[]>([cityOptions[0], cityOptions[2]]);

    return (
        <div className="w-96">
            <Field.Root name="combobox-checkbox-multi">
                <Field.Label>Select cities</Field.Label>
                <Combobox.Root
                    items={cityOptions}
                    multiple
                    value={value}
                    onValueChange={(next) => setValue(Array.isArray(next) ? next : [])}
                >
                    <Combobox.Chips ref={chipsRef}>
                        <Combobox.Input placeholder="Select cities">
                            <Combobox.ValueArea>
                                <Combobox.Value>
                                    {(currentValue) => {
                                        const selected = Array.isArray(currentValue) ? currentValue : [];
                                        return (
                                            <>
                                                {selected.map((option, index) => (
                                                    <Combobox.Chip key={getChipKey(option, index)}>
                                                        <span className="max-w-[10rem] truncate">
                                                            {option?.label ?? option?.value ?? ""}
                                                        </span>
                                                        <Combobox.ChipRemove
                                                            aria-label={`Remove ${
                                                                option?.label ?? option?.value ?? "option"
                                                            }`}
                                                        />
                                                    </Combobox.Chip>
                                                ))}
                                                <Combobox.Control placeholder="Select cities" />
                                            </>
                                        );
                                    }}
                                </Combobox.Value>
                            </Combobox.ValueArea>
                            <Combobox.Controls>
                                <Combobox.Clear />
                                <Combobox.Trigger>
                                    <Combobox.Icon />
                                </Combobox.Trigger>
                            </Combobox.Controls>
                        </Combobox.Input>
                    </Combobox.Chips>

                    <Combobox.Portal>
                        <Combobox.Positioner anchor={chipsRef} sideOffset={4}>
                            <Combobox.Popup>
                                <Combobox.List>
                                    {(item) => (
                                        <Combobox.Item key={item.value ?? item.label ?? "item"} value={item}>
                                            <Combobox.CheckboxIndicator />
                                            <span className="truncate">{item.label}</span>
                                        </Combobox.Item>
                                    )}
                                </Combobox.List>
                            </Combobox.Popup>
                        </Combobox.Positioner>
                    </Combobox.Portal>
                </Combobox.Root>
                <Field.Error />
            </Field.Root>
        </div>
    );
}

export const MultiSelectWithCheckboxes: Story = {
    render: () => <MultiSelectWithCheckboxesStory />,
    ...withSource(multiSelectWithCheckboxesStorySource.trim()),
};

const groupedOptionsStorySource = `
const groupedCities = [
  {
    label: 'Baltics',
    options: [
      {label: 'Tallinn', value: '1', secondary: 'Estonia'},
      {label: 'Riga', value: '2', secondary: 'Latvia'},
      {label: 'Vilnius', value: '3', secondary: 'Lithuania'},
    ],
  },
  {
    label: 'Central Europe',
    options: [
      {label: 'Warsaw', value: '4', secondary: 'Poland'},
      {label: 'Prague', value: '5', secondary: 'Czechia'},
    ],
  },
];

const groupedOptions = groupedCities.flatMap((group) => group.options);

function GroupedOptionsCombobox() {
  return (
    <Field.Root name="city">
      <Field.Label>Cities by region</Field.Label>
      <Combobox.Root items={groupedOptions}>
        <Combobox.Input placeholder="Select a city">
          <Combobox.ValueArea>
            <Combobox.Control />
          </Combobox.ValueArea>
          <Combobox.Controls>
            <Combobox.Clear />
            <Combobox.Trigger>
              <Combobox.Icon />
            </Combobox.Trigger>
          </Combobox.Controls>
        </Combobox.Input>
        <Combobox.Portal>
          <Combobox.Positioner sideOffset={4}>
            <Combobox.Popup>
              <Combobox.List>
                {groupedCities.map((group) => (
                  <Combobox.Group key={group.label} className="px-2 py-1">
                    <Combobox.GroupLabel className="bolt-font-body-s-regular px-2 py-1 uppercase text-secondary">
                      {group.label}
                    </Combobox.GroupLabel>
                    {group.options.map((option) => (
                      <Combobox.Item key={option.value} value={option}>
                        <div className="flex min-w-0 flex-1 flex-col">
                          <span className="truncate">{option.label}</span>
                          <span className="bolt-font-body-s-regular text-secondary">{option.secondary}</span>
                        </div>
                        <Combobox.ItemIndicator />
                      </Combobox.Item>
                    ))}
                  </Combobox.Group>
                ))}
              </Combobox.List>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
    </Field.Root>
  );
}
`;

export const GroupedOptions: Story = {
    render: () => (
        <ComboboxStory
            label="Cities by region"
            placeholder="Select a city"
            options={groupedCityOptionsFlat}
            testId="combobox-grouped"
            renderList={({getElementTestId}) => (
                <>
                    {groupedCityOptions.map((group) => (
                        <Combobox.Group key={group.label} className="px-2 py-1">
                            <Combobox.GroupLabel className="bolt-font-body-s-regular px-2 py-1 uppercase text-secondary">
                                {group.label}
                            </Combobox.GroupLabel>
                            {group.options.map((option) => (
                                <Combobox.Item
                                    key={option.value ?? option.label ?? "group-option"}
                                    value={option}
                                    data-testid={
                                        option.value === null
                                            ? getElementTestId("item-null")
                                            : getElementTestId(`item-${option.value}`)
                                    }
                                >
                                    <div className="flex min-w-0 flex-1 flex-col">
                                        <span className="truncate">{option.label}</span>
                                        {option.secondary ? (
                                            <span className="bolt-font-body-s-regular text-secondary">
                                                {option.secondary}
                                            </span>
                                        ) : null}
                                    </div>
                                    <Combobox.ItemIndicator />
                                </Combobox.Item>
                            ))}
                        </Combobox.Group>
                    ))}
                </>
            )}
        />
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const body = within(canvasElement.ownerDocument.body);
        const trigger = await canvas.findByTestId("combobox-grouped-trigger");
        const input = await canvas.findByTestId("combobox-grouped-input");

        await step("Shows visual group labels inside the popup", async () => {
            await userEvent.click(trigger);
            await waitFor(() => {
                expect(body.getByTestId("combobox-grouped-list")).toBeVisible();
            });
            const baltics = await body.findByText("Baltics");
            await expect(baltics).toBeVisible();
            await userEvent.click(input);
            await userEvent.keyboard("{Escape}");
            await waitFor(() => {
                expect(body.queryByTestId("combobox-grouped-list")).not.toBeInTheDocument();
            });
        });

        await step("Navigates across groups with the keyboard", async () => {
            await userEvent.click(trigger);
            await waitFor(() => {
                expect(body.getByTestId("combobox-grouped-list")).toBeVisible();
            });
            await userEvent.click(input);
            await userEvent.keyboard("{ArrowDown}{ArrowDown}{ArrowDown}{ArrowDown}{ArrowDown}{Enter}");
            await waitFor(() => {
                expect(body.queryByTestId("combobox-grouped-list")).not.toBeInTheDocument();
            });
            await expect(input).toHaveValue("Prague");
        });
    },
    ...withSource(groupedOptionsStorySource),
};

const customEmptyStateStorySource = `
function CustomEmptyStateCombobox() {
  return (
    <Field.Root name="city">
      <Field.Label>Remote lookup</Field.Label>
      <Combobox.Root items={[]}>
        <Combobox.Input placeholder="Search remote dataset">
          <Combobox.ValueArea>
            <Combobox.Control />
          </Combobox.ValueArea>
          <Combobox.Controls>
            <Combobox.Trigger>
              <Combobox.Icon />
            </Combobox.Trigger>
          </Combobox.Controls>
        </Combobox.Input>
        <Combobox.Portal>
          <Combobox.Positioner sideOffset={4}>
            <Combobox.Popup>
              <Combobox.Empty className="flex flex-col items-center gap-3 px-6 py-8 text-center">
                <span className="bolt-font-body-m-regular text-secondary">
                  We couldn't find any matching cities.
                </span>
                <button
                  type="button"
                  className="rounded-md border border-dashed border-action-primary px-4 py-2 text-sm text-action-primary"
                >
                  Add a new city
                </button>
              </Combobox.Empty>
            </Combobox.Popup>
          </Combobox.Positioner>
        </Combobox.Portal>
      </Combobox.Root>
    </Field.Root>
  );
}
`;

export const CustomEmptyState: Story = {
    render: () => (
        <ComboboxStory
            label="Remote lookup"
            placeholder="Search remote dataset"
            options={[]}
            testId="combobox-custom-empty"
            renderEmpty={({getElementTestId}) => (
                <Combobox.Empty
                    data-testid={getElementTestId("empty-state")}
                    className="flex flex-col items-center gap-3 px-6 py-8 text-center"
                >
                    <span className="bolt-font-body-m-regular text-secondary">
                        We couldn&apos;t find any matching cities.
                    </span>
                    <button
                        type="button"
                        className={`
                          rounded-md border border-dashed border-action-primary px-4 py-2 text-sm text-action-primary
                        `}
                    >
                        Add a new city
                    </button>
                </Combobox.Empty>
            )}
        />
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const body = within(canvasElement.ownerDocument.body);
        const trigger = await canvas.findByTestId("combobox-custom-empty-trigger");

        await step("Displays the custom empty content when no options exist", async () => {
            await userEvent.click(trigger);
            const emptyState = await body.findByTestId("combobox-custom-empty-empty-state");
            await expect(emptyState).toHaveTextContent("We couldn't find any matching cities.");
            const addButton = await within(emptyState).findByRole("button", {name: "Add a new city"});
            await expect(addButton).toBeEnabled();
        });
    },
    ...withSource(customEmptyStateStorySource),
};

const controlledValueStorySource = `
type CityOption = {label: string; value: string};

const cities: CityOption[] = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
];

function ControlledCombobox() {
  const [value, setValue] = React.useState<CityOption | null>(cities[0]);

  return (
    <div className="flex flex-col gap-4">
      <Field.Root name="city">
        <Field.Label>Controlled combobox</Field.Label>
        <Combobox.Root
          items={cities}
          value={value}
          onValueChange={(nextValue) => setValue((nextValue as CityOption) ?? null)}
        >
          <Combobox.Input placeholder="Choose a city">
            <Combobox.ValueArea>
              <Combobox.Control />
            </Combobox.ValueArea>
            <Combobox.Controls>
              <Combobox.Clear />
              <Combobox.Trigger>
                <Combobox.Icon />
              </Combobox.Trigger>
            </Combobox.Controls>
          </Combobox.Input>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      {item.label}
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
      </Field.Root>
      <div className="bolt-font-body-s-regular text-secondary">
        Current selection: {value?.label ?? 'None'}
      </div>
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          className="rounded-md border border-solid border-neutral-secondary px-3 py-2 text-sm"
          onClick={() => setValue(cities[2])}
        >
          Pick Berlin
        </button>
        <button
          type="button"
          className="rounded-md border border-solid border-neutral-secondary px-3 py-2 text-sm"
          onClick={() => setValue(null)}
        >
          Clear selection
        </button>
      </div>
    </div>
  );
}
`;

export const ControlledValue: Story = {
    render: () => <ControlledComboboxStory />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const input = await canvas.findByTestId("combobox-controlled-single-input");
        const pickBerlin = await canvas.findByText("Pick Berlin");
        const clearExternal = await canvas.findByText("Clear selection");

        await step("Syncs external updates into the combobox", async () => {
            await expect(input).toHaveValue("Tallinn");
            await userEvent.click(pickBerlin);
            await expect(input).toHaveValue("Berlin");
        });

        await step("Clears controlled value via external action", async () => {
            await userEvent.click(clearExternal);
            await expect(input).toHaveValue("");
        });
    },
    ...withSource(controlledValueStorySource),
};

const controlledMultipleStorySource = `
type CityOption = {label: string; value: string};

const cities: CityOption[] = [
  {label: 'Tallinn', value: '1'},
  {label: 'Stockholm', value: '2'},
  {label: 'Berlin', value: '3'},
  {label: 'Warsaw', value: '4'},
];

function ControlledMultiCombobox() {
  const [value, setValue] = React.useState<CityOption[]>([cities[1], cities[2]]);

  const handleValueChange = React.useCallback((nextValue: CityOption[] | null) => {
    setValue(Array.isArray(nextValue) ? nextValue : []);
  }, []);

  return (
    <div className="flex flex-col gap-4">
      <Field.Root name="cities">
        <Field.Label>Controlled multi-select</Field.Label>
        <Combobox.Root items={cities} multiple value={value} onValueChange={handleValueChange}>
          <Combobox.Chips>
            <Combobox.Input placeholder="Select cities">
              <Combobox.ValueArea>
                <Combobox.Value>
                  {(currentValue) => {
                    const selected = Array.isArray(currentValue) ? currentValue : [];
                    return (
                      <>
                        {selected.map((option) => (
                          <Combobox.Chip key={option.value}>
                            <span className="max-w-[10rem] truncate">{option.label}</span>
                            <Combobox.ChipRemove aria-label={'Remove ' + (option.label ?? option.value ?? 'option')} />
                          </Combobox.Chip>
                        ))}
                        <Combobox.Control placeholder="Select cities" />
                      </>
                    );
                  }}
                </Combobox.Value>
              </Combobox.ValueArea>
              <Combobox.Controls>
                <Combobox.Clear />
                <Combobox.Trigger>
                  <Combobox.Icon />
                </Combobox.Trigger>
              </Combobox.Controls>
            </Combobox.Input>
          </Combobox.Chips>
          <Combobox.Portal>
            <Combobox.Positioner sideOffset={4}>
              <Combobox.Popup>
                <Combobox.List>
                  {(item) => (
                    <Combobox.Item key={item.value} value={item}>
                      {item.label}
                      <Combobox.ItemIndicator />
                    </Combobox.Item>
                  )}
                </Combobox.List>
              </Combobox.Popup>
            </Combobox.Positioner>
          </Combobox.Portal>
        </Combobox.Root>
      </Field.Root>
      <div className="bolt-font-body-s-regular text-secondary">
        Selected: {value.length ? value.map((option) => option.label).join(', ') : 'None'}
      </div>
      <div className="flex flex-wrap gap-2">
        <button
          type="button"
          className="rounded-md border border-solid border-neutral-secondary px-3 py-2 text-sm"
          onClick={() => setValue([cities[0], cities[3]])}
        >
          Pick Tallinn & Warsaw
        </button>
        <button
          type="button"
          className="rounded-md border border-solid border-neutral-secondary px-3 py-2 text-sm"
          onClick={() => setValue([])}
        >
          Clear all
        </button>
      </div>
    </div>
  );
}
`;

export const ControlledMultiple: Story = {
    render: () => <ControlledMultipleComboboxStory />,
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const trigger = await canvas.findByTestId("combobox-controlled-multi-trigger");
        const formElement = trigger.closest("form");
        const baseCombobox = formElement ? within(formElement) : canvas;
        const pickTallinnWarsaw = await canvas.findByText("Pick Tallinn & Warsaw");
        const clearAll = await canvas.findByText("Clear all");

        await step("Applies external selections to the multi-select combobox", async () => {
            await userEvent.click(pickTallinnWarsaw);
            await waitFor(() => {
                expect(baseCombobox.getByText("Tallinn")).toBeVisible();
                expect(baseCombobox.getByText("Warsaw")).toBeVisible();
            });
        });

        await step("Clears all values through the controlling component", async () => {
            await userEvent.click(clearAll);
            await waitFor(() => {
                expect(baseCombobox.queryByText("Tallinn")).not.toBeInTheDocument();
                expect(baseCombobox.queryByText("Warsaw")).not.toBeInTheDocument();
            });
            const input = await canvas.findByTestId("combobox-controlled-multi-input");
            await expect(input).toHaveValue("");
        });
    },
    ...withSource(controlledMultipleStorySource),
};
