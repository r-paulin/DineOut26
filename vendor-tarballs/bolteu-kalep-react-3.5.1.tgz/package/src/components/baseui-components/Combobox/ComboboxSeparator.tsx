import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

/**
 * Combobox.Separator
 *
 * Visual divider used to separate grouped sections in the combobox popup.
 */
export const ComboboxSeparator = BaseUICombobox.Separator;
