import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";
import type {BaseUIEvent, HTMLProps} from "@base-ui/react/utils/types";

import Clear from "@bolteu/kalep-react-icons/dist/Clear";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useComboboxContextSelector, useComboboxInputContextSelector} from "./context";

/**
 * ### Combobox.Clear
 * Optional affordance for clearing the current selection(s).
 * Applies only if any value is selected.
 *
 * ```tsx
 * <Combobox.Controls>
 *   <Combobox.Clear aria-label="Clear selection" />
 *   <Combobox.Trigger>…</Combobox.Trigger>
 * </Combobox.Controls>
 * ```
 */
export const ComboboxClear = React.forwardRef(function ComboboxClear(
    props: BaseUICombobox.Clear.Props,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {"aria-label": ariaLabel, className, render, ...rest} = props;

    const size = useComboboxContextSelector((context) => context.customComboboxProps.size);
    // We don't have readonly in the Clear.State, so we get it from the Input props
    const readonly = useComboboxInputContextSelector((context) => context.comboboxInputProps?.readOnly ?? false);

    const getComboboxClearClassNames = React.useCallback(
        (state: BaseUICombobox.Clear.State) =>
            cx(
                "block text-tertiary",
                state.disabled
                    ? "cursor-not-allowed"
                    : `
                      cursor-pointer
                      hover:text-primary
                    `,
                addConsumerClasses(state, className),
            ),
        [className],
    );

    const renderDefault = React.useCallback(
        (renderProps: HTMLProps<HTMLButtonElement>, state: BaseUICombobox.Clear.State) => {
            const {onMouseDown, onClick, className: clearClassName, ...remainingRenderProps} = renderProps;

            // We need to prevent the default onMouseDown behavior to avoid focus jumps in single select mode
            const handleMouseDown = (event: BaseUIEvent<React.MouseEvent<HTMLButtonElement>>) => {
                event.preventDefault();
                event.stopPropagation();
                onMouseDown?.(event);
            };

            // Stop click from bubbling to the Input wrapper's onClick handler
            const handleClick = (event: BaseUIEvent<React.MouseEvent<HTMLButtonElement>>) => {
                event.stopPropagation();
                onClick?.(event);
            };

            if (state.disabled || readonly) {
                return <></>;
            }

            return (
                <button
                    {...remainingRenderProps}
                    aria-hidden="true"
                    type="button"
                    className={cx("border-0 bg-transparent p-0")}
                    onMouseDown={handleMouseDown}
                    onClick={handleClick}
                >
                    <Clear aria-hidden="true" className={clearClassName} size={size === "sm" ? "md" : "lg"} />
                </button>
            );
        },
        [size, readonly],
    );

    return (
        <BaseUICombobox.Clear
            {...rest}
            aria-label={ariaLabel ?? "Clear selection"}
            ref={forwardedRef}
            className={getComboboxClearClassNames}
            render={render ?? renderDefault}
        />
    );
});
