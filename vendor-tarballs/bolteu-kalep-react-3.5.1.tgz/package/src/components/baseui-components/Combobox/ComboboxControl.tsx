import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";
import type {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {
    useComboboxContextSelector,
    useComboboxInputContextSelector,
} from "@/components/baseui-components/Combobox/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import type {Indexable} from "../types/common-types";

/**
 * ### Combobox.Control
 * The actual `<input />` element used inside `Combobox.ValueArea`.
 *
 * ```tsx
 * <Combobox.ValueArea>
 *   <Combobox.Control placeholder="Select a city" />
 * </Combobox.ValueArea>
 * ```
 */
export const ComboboxControl = React.forwardRef(function ComboboxControl(
    props: BaseUICombobox.Input.Props,
    forwardedRef: React.ForwardedRef<HTMLInputElement>,
) {
    const {className, render, ...rest} = props;
    const controlState = useComboboxInputContextSelector((context) => context.comboboxInputState);
    const controlProps = useComboboxInputContextSelector((context) => context.comboboxInputProps);
    const inputSavedRef = useComboboxInputContextSelector((context) => context.inputRef);
    const multiple = useComboboxContextSelector((context) => context.customComboboxProps.multiple);

    const ownProps = {
        className: cx(
            `
              m-0 h-full min-w-0 flex-grow border-0 border-solid bg-transparent p-0 text-size-inherit outline-none
              [color:inherit]
              input-clear-button:hidden
            `,
            controlState.disabled
                ? "cursor-not-allowed placeholder-tertiary"
                : controlState.readOnly
                  ? "cursor-default placeholder-secondary"
                  : "placeholder-secondary",
            multiple ? "w-0 min-w-10" : "w-full",
            addConsumerClasses(controlState, className),
        ),
        type: "text",
    };

    return useRender<Indexable<BaseUICombobox.Input.State>, HTMLInputElement>({
        defaultTagName: "input",
        render,
        ref: [inputSavedRef, forwardedRef],
        state: controlState,
        props: mergeProps(controlProps ?? {}, ownProps, rest),
    });
});
