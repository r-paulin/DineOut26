import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {ComboboxCheckboxIndicator} from "./ComboboxCheckboxIndicator";
import {ComboboxChip} from "./ComboboxChip";
import {ComboboxChipRemove} from "./ComboboxChipRemove";
import {ComboboxChips} from "./ComboboxChips";
import {ComboboxClear} from "./ComboboxClear";
import {ComboboxControl} from "./ComboboxControl";
import {ComboboxControls} from "./ComboboxControls";
import {ComboboxEmpty} from "./ComboboxEmpty";
import {ComboboxGroup} from "./ComboboxGroup";
import {ComboboxGroupLabel} from "./ComboboxGroupLabel";
import {ComboboxIcon} from "./ComboboxIcon";
import {ComboboxInput} from "./ComboboxInput";
import {ComboboxItem} from "./ComboboxItem";
import {ComboboxItemIndicator} from "./ComboboxItemIndicator";
import {ComboboxList} from "./ComboboxList";
import {ComboboxPopup} from "./ComboboxPopup";
import {ComboboxPortal} from "./ComboboxPortal";
import {ComboboxPositioner} from "./ComboboxPositioner";
import {ComboboxRoot} from "./ComboboxRoot";
import {ComboboxSeparator} from "./ComboboxSeparator";
import {ComboboxStatus} from "./ComboboxStatus";
import {ComboboxTrigger} from "./ComboboxTrigger";
import {ComboboxValue} from "./ComboboxValue";
import {ComboboxValueArea} from "./ComboboxValueArea";

export const Combobox = {
    Root: ComboboxRoot,
    Trigger: ComboboxTrigger,
    Control: ComboboxControl,
    Controls: ComboboxControls,
    ValueArea: ComboboxValueArea,
    Input: ComboboxInput,
    Icon: ComboboxIcon,
    Clear: ComboboxClear,
    Chips: ComboboxChips,
    Chip: ComboboxChip,
    ChipRemove: ComboboxChipRemove,
    List: ComboboxList,
    Item: ComboboxItem,
    ItemIndicator: ComboboxItemIndicator,
    CheckboxIndicator: ComboboxCheckboxIndicator,
    Portal: ComboboxPortal,
    Positioner: ComboboxPositioner,
    Popup: ComboboxPopup,
    Value: ComboboxValue,
    Group: ComboboxGroup,
    GroupLabel: ComboboxGroupLabel,
    Empty: ComboboxEmpty,
    Separator: ComboboxSeparator,
    Status: ComboboxStatus,
    useFilter: BaseUICombobox.useFilter,
};

// Components without render implementation by typings not allowing displayName assignment
Object.assign(Combobox.Root, {displayName: "Combobox.Root"});
Object.assign(Combobox.Value, {displayName: "Combobox.Value"});

Combobox.Trigger.displayName = "Combobox.Trigger";
Combobox.Control.displayName = "Combobox.Control";
Combobox.Controls.displayName = "Combobox.Controls";
Combobox.ValueArea.displayName = "Combobox.ValueArea";
Combobox.Input.displayName = "Combobox.Input";
Combobox.Icon.displayName = "Combobox.Icon";
Combobox.Clear.displayName = "Combobox.Clear";
Combobox.Chips.displayName = "Combobox.Chips";
Combobox.Chip.displayName = "Combobox.Chip";
Combobox.ChipRemove.displayName = "Combobox.ChipRemove";
Combobox.List.displayName = "Combobox.List";
Combobox.Item.displayName = "Combobox.Item";
Combobox.ItemIndicator.displayName = "Combobox.ItemIndicator";
Combobox.CheckboxIndicator.displayName = "Combobox.CheckboxIndicator";
Combobox.Portal.displayName = "Combobox.Portal";
Combobox.Positioner.displayName = "Combobox.Positioner";
Combobox.Popup.displayName = "Combobox.Popup";
Combobox.Group.displayName = "Combobox.Group";
Combobox.GroupLabel.displayName = "Combobox.GroupLabel";
Combobox.Empty.displayName = "Combobox.Empty";
Combobox.Separator.displayName = "Combobox.Separator";
Combobox.Status.displayName = "Combobox.Status";

export {useComboboxContextSelector} from "./context";
