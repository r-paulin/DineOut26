import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

/**
 * ### Combobox.Status
 * Displays a live-region status message announced politely to assistive technologies.
 * Useful for conveying the status of an asynchronously loaded list (e.g. loading,
 * error, or result count). Renders a `<div>` element.
 *
 * The component must stay **always mounted** so the ARIA live region is present in
 * the DOM when content changes — conditionally mounting/unmounting the container
 * causes screen readers to miss announcements. Update the *children* instead.
 *
 * ```tsx
 * <Combobox.Popup>
 *   <Combobox.Status>
 *     {statusMessage && (
 *       <div className="text-sm text-secondary">{statusMessage}</div>
 *     )}
 *   </Combobox.Status>
 *   <Combobox.List>{(item) => …}</Combobox.List>
 * </Combobox.Popup>
 * ```
 */
export const ComboboxStatus = BaseUICombobox.Status;
