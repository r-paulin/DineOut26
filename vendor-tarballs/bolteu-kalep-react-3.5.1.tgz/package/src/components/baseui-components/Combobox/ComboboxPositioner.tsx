import * as React from "react";

import {useRender} from "@base-ui/react";
import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {useComboboxContextSelector} from "@/components/baseui-components/Combobox/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import type {Indexable} from "../types/common-types";
import {ComboboxPositionerContextProvider} from "./context/ComboboxPositionerContextProvider";

function PositionerElement(
    props: BaseUICombobox.Positioner.Props & {
        state: BaseUICombobox.Positioner.State;
        wrapperRef: React.Ref<HTMLDivElement>;
        baseUIInternalRef?: React.Ref<HTMLDivElement>;
    },
) {
    const {render, state, baseUIInternalRef, wrapperRef, ...rest} = props;

    const refs = [baseUIInternalRef, wrapperRef].filter((ref): ref is React.Ref<HTMLDivElement> => ref !== undefined);

    return useRender<Indexable<BaseUICombobox.Positioner.State>, HTMLDivElement>({
        defaultTagName: "section",
        render,
        ref: refs,
        state,
        props: rest,
    });
}

/**
 * ### Combobox.Positioner
 * Anchors `Combobox.Popup` relative to the input wrapper or a custom anchor (like the chips container).
 *
 * ```tsx
 * <Combobox.Portal>
 *   <Combobox.Positioner anchor={chipsRef} sideOffset={4}>
 *     <Combobox.Popup>…</Combobox.Popup>
 *   </Combobox.Positioner>
 * </Combobox.Portal>
 * ```
 *
 * Override `anchor` when chips should control placement; otherwise it falls back to the input wrapper.
 */
export const ComboboxPositioner = React.forwardRef(function ComboboxPositioner(
    props: BaseUICombobox.Positioner.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, anchor, render: userRender, ...rest} = props;
    const controlRef = useComboboxContextSelector((context) => context.inputWrapperRef);

    const getComboboxPositionerClassNames = React.useCallback(
        (state: BaseUICombobox.Positioner.State) =>
            cx("max-h-80 w-max rounded-md shadow-md", addConsumerClasses(state, className)),
        [className],
    );

    const defaultRender = React.useCallback(
        (positionerProps: HTMLProps<HTMLDivElement>, state: BaseUICombobox.Positioner.State) => {
            const {ref, ...restPositionerProps} = positionerProps;

            return (
                <ComboboxPositionerContextProvider comboboxPositionerState={state}>
                    <PositionerElement
                        {...restPositionerProps}
                        render={userRender}
                        baseUIInternalRef={ref}
                        wrapperRef={forwardedRef}
                        state={state}
                    />
                </ComboboxPositionerContextProvider>
            );
        },
        [forwardedRef, userRender],
    );

    return (
        <BaseUICombobox.Positioner
            sideOffset={5}
            {...rest}
            ref={forwardedRef}
            anchor={anchor ?? controlRef}
            className={getComboboxPositionerClassNames}
            render={defaultRender}
        />
    );
});
