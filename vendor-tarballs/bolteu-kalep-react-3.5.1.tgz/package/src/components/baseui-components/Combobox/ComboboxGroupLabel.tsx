import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

/**
 * Combobox.GroupLabel
 *
 * Accessible label for a `Combobox.Group` section in the options list.
 */
export const ComboboxGroupLabel = BaseUICombobox.GroupLabel;
