import * as React from "react";

import type {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

export interface ComboboxInputContextType {
    comboboxInputState: BaseUICombobox.Input.State;
    comboboxInputProps: Omit<BaseUICombobox.Input.Props, "children"> | null;
    inputRef: React.RefCallback<HTMLInputElement | null>;
}

const ComboboxInputContext = React.createContext<ComboboxInputContextType | null>(null);

interface ComboboxInputContextProviderProps extends Omit<ComboboxInputContextType, "controlRef"> {
    children: React.ReactNode;
}

export function ComboboxInputContextProvider({
    children,
    comboboxInputProps,
    comboboxInputState,
    inputRef,
}: ComboboxInputContextProviderProps) {
    const contextValue = React.useMemo(
        () => ({
            comboboxInputProps,
            comboboxInputState,
            inputRef,
        }),
        [comboboxInputProps, comboboxInputState, inputRef],
    );

    return <ComboboxInputContext.Provider value={contextValue}>{children}</ComboboxInputContext.Provider>;
}

export function useComboboxInputContext() {
    const context = React.useContext(ComboboxInputContext);

    if (!context) {
        throw new Error("Combobox parts must be rendered within Combobox.Input");
    }

    return context;
}

// TODO: implement deep readonly support
type ComboboxInputContextReadonly = ComboboxInputContextType & {
    readonly comboboxInputProps: Readonly<ComboboxInputContextType["comboboxInputProps"]>;
    readonly comboboxInputState: Readonly<ComboboxInputContextType["comboboxInputState"]>;
};

export function useComboboxInputContextSelector<T>(selector: (context: ComboboxInputContextReadonly) => T): T {
    const context = useComboboxInputContext();

    return selector(context);
}
