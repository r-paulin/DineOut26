import * as React from "react";

import type {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

export interface ComboboxPositionerContextType {
    comboboxPositionerState: BaseUICombobox.Positioner.State;
}

const ComboboxPositionerContext = React.createContext<ComboboxPositionerContextType | null>(null);

interface ComboboxPositionerContextProviderProps extends ComboboxPositionerContextType {
    children: React.ReactNode;
}

export function ComboboxPositionerContextProvider({
    children,
    comboboxPositionerState,
}: ComboboxPositionerContextProviderProps) {
    const contextValue = React.useMemo(
        () => ({
            comboboxPositionerState,
        }),
        [comboboxPositionerState],
    );

    return <ComboboxPositionerContext.Provider value={contextValue}>{children}</ComboboxPositionerContext.Provider>;
}

export function useComboboxPositionerContext() {
    const context = React.useContext(ComboboxPositionerContext);

    if (!context) {
        throw new Error("Combobox parts must be rendered within Combobox.Positioner");
    }

    return context;
}

// TODO: implement deep readonly support
type ComboboxPositionerContextReadonly = ComboboxPositionerContextType & {
    readonly comboboxPositionerState: Readonly<ComboboxPositionerContextType["comboboxPositionerState"]>;
};

export function useComboboxPositionerContextSelector<T>(
    selector: (context: ComboboxPositionerContextReadonly) => T,
): T {
    const context = useComboboxPositionerContext();

    return selector(context);
}
