import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useComboboxContextSelector} from "./context";

const sizes = {
    base: "py-3 min-h-12",
    sm: "py-[6px] min-h-9",
} as const;

/**
 * ### Combobox.Item
 * Single option row rendered inside `Combobox.List`.
 *
 * ```tsx
 * <Combobox.Item value={option}>
 *   <div className="flex-1">
 *     <span>{option.label}</span>
 *     <span className="text-secondary">{option.secondary}</span>
 *   </div>
 *   <Combobox.ItemIndicator />
 * </Combobox.Item>
 * ```
 */
export const ComboboxItem = React.forwardRef(function ComboboxItem(
    props: BaseUICombobox.Item.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, children, ...rest} = props;

    const size = useComboboxContextSelector((context) => context.customComboboxProps.size);

    const getComboboxItemClassNames = React.useCallback(
        (state: BaseUICombobox.Item.State) =>
            cx(
                `flex w-full items-center gap-3 px-4 text-left outline-none transition-colors duration-100 ease-linear`,
                size === "sm" ? "bolt-font-body-s-regular" : "bolt-font-body-m-regular",
                sizes[size === "sm" ? "sm" : "base"],
                {
                    "cursor-not-allowed text-tertiary": state.disabled,
                    "bg-neutral-secondary": state.highlighted,
                    "text-primary": !state.disabled,
                },
                addConsumerClasses(state, className),
            ),
        [className, size],
    );

    return (
        <BaseUICombobox.Item {...rest} ref={forwardedRef} className={getComboboxItemClassNames}>
            {children}
        </BaseUICombobox.Item>
    );
});
