import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import type {ComboboxSize} from "@/components/baseui-components/Combobox/combobox.types";
import {ComboboxContextProvider} from "@/components/baseui-components/Combobox/context/ComboboxContextProvider";

interface ComboboxRootCustomProps {
    /**
     * Size of the combobox components.
     *
     * @default md
     */
    size?: ComboboxSize;
    multiple?: boolean;
    /**
     * Whether the input can span multiple lines.
     *
     * @default false
     */
    multiline?: boolean;
    /** Placeholder text for the input field. */

    placeholder?: string;
}

/**
 * ### Combobox.Root
 * Top-level provider for every other combobox primitive. Define sizing, placeholder, `multiple`, and
 * value props here so the rest of the composition stays in sync.
 *
 * ```tsx
 * <Combobox.Root items={cities} size="md">
 *   <Combobox.Input placeholder="Select a city">
 *     <Combobox.ValueArea>
 *       <Combobox.Control />
 *     </Combobox.ValueArea>
 *     <Combobox.Controls>
 *       <Combobox.Clear />
 *       <Combobox.Trigger>
 *         <Combobox.Icon />
 *       </Combobox.Trigger>
 *     </Combobox.Controls>
 *   </Combobox.Input>
 *   <Combobox.Portal>
 *     <Combobox.Positioner sideOffset={4}>
 *       <Combobox.Popup>
 *         <Combobox.Status>
 *           {statusMessage && <div>{statusMessage}</div>}
 *         </Combobox.Status>
 *         <Combobox.Empty>No cities found</Combobox.Empty>
 *         <Combobox.List>
 *           {(item) => (
 *             <Combobox.Item key={item.value} value={item}>
 *               <span>{item.label}</span>
 *               <Combobox.ItemIndicator />
 *             </Combobox.Item>
 *           )}
 *         </Combobox.List>
 *       </Combobox.Popup>
 *     </Combobox.Positioner>
 *   </Combobox.Portal>
 * </Combobox.Root>
 * ```
 */
export function ComboboxRoot<ItemValue, Multiple extends boolean | undefined = false>(
    props: BaseUICombobox.Root.Props<ItemValue, Multiple> & ComboboxRootCustomProps,
): React.JSX.Element {
    const {size = "md", multiline = false, placeholder, children, ...rest} = props;

    const customComboboxProps = React.useMemo(
        () => ({
            size,
            multiline,
            placeholder,
            multiple: props.multiple ?? false,
        }),
        [size, multiline, placeholder, props.multiple],
    );

    return (
        <BaseUICombobox.Root {...rest}>
            <ComboboxContextProvider customComboboxProps={customComboboxProps}>{children}</ComboboxContextProvider>
        </BaseUICombobox.Root>
    );
}
