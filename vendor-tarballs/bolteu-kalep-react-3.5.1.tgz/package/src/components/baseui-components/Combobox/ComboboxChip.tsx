import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useComboboxContextSelector} from "./context";

/**
 * ### Combobox.Chip
 * Visual pill that represents a selected value inside `Combobox.Value`.
 *
 * ```tsx
 * <Combobox.Value>
 *   {(currentValue) => {
 *     const selected = Array.isArray(currentValue) ? currentValue : [];
 *     return (
 *       <>
 *         {selected.map((option) => (
 *           <Combobox.Chip key={option.value}>
 *             {option.label}
 *             <Combobox.ChipRemove aria-label={`Remove ${option.label}`} />
 *           </Combobox.Chip>
 *         ))}
 *         <Combobox.Control />
 *       </>
 *     );
 *   }}
 * </Combobox.Value>
 * ```
 */
export const ComboboxChip = React.forwardRef(function ComboboxChip(
    props: BaseUICombobox.Chip.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const size = useComboboxContextSelector((state) => state.customComboboxProps.size);

    const getComboboxChipClassNames = React.useCallback(
        (state: BaseUICombobox.Chip.State) => {
            return cx(
                `
                  box-border flex items-center gap-1.5 overflow-y-hidden rounded-md border-2 border-solid
                  border-neutral-secondary px-1.5 py-0.5
                  focus-visible:border-action-primary focus-visible:outline-none
                `,
                size === "sm" ? "bolt-font-body-xs-regular" : "bolt-font-body-s-regular",
                state.disabled ? "text-tertiary" : "bg-neutral-secondary text-primary",
                addConsumerClasses(state, className),
            );
        },
        [className, size],
    );

    return <BaseUICombobox.Chip {...rest} ref={forwardedRef} className={getComboboxChipClassNames} />;
});
