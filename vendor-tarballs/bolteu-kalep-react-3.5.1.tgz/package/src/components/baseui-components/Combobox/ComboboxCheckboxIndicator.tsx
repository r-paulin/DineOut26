import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {
    CLASSNAME_TW_CHECKBOX_INDICATOR_BASE,
    getCheckboxIndicatorStateClass,
    renderCheckboxIndicatorDefault,
} from "@/components/baseui-components/utils/checkbox-indicator";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Combobox.CheckboxIndicator
 * Checkbox-style selection indicator for use inside `Combobox.Item` in
 * multi-select scenarios. Renders a filled square with a `Check` icon when
 * selected, and an outlined square when unselected. Stays mounted in the DOM
 * regardless of selection state to enable CSS transitions.
 */
export const ComboboxCheckboxIndicator = React.forwardRef(function ComboboxCheckboxIndicator(
    props: BaseUICombobox.ItemIndicator.Props,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {render, className, ...rest} = props;

    const getCheckboxIndicatorClassNames = React.useCallback(
        (state: BaseUICombobox.ItemIndicator.State) =>
            cx(
                CLASSNAME_TW_CHECKBOX_INDICATOR_BASE,
                getCheckboxIndicatorStateClass(state.selected),
                addConsumerClasses(state, className),
            ),
        [className],
    );

    const defaultRender = React.useCallback(
        (renderProps: HTMLProps<HTMLSpanElement>, state: BaseUICombobox.ItemIndicator.State) =>
            renderCheckboxIndicatorDefault(renderProps, state.selected),
        [],
    );

    return (
        <BaseUICombobox.ItemIndicator
            keepMounted
            {...rest}
            ref={ref}
            className={getCheckboxIndicatorClassNames}
            render={render ?? defaultRender}
        />
    );
});
