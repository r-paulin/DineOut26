import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useComboboxInputContextSelector} from "./context";

/**
 * ### Combobox.Trigger
 * Button used to toggle the popup, typically wrapping `Combobox.Icon`.
 *
 * ```tsx
 * <Combobox.Controls>
 *   <Combobox.Trigger>
 *     <Combobox.Icon />
 *   </Combobox.Trigger>
 * </Combobox.Controls>
 * ```
 */
export const ComboboxTrigger = React.forwardRef(function ComboboxTrigger(
    props: BaseUICombobox.Trigger.Props,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {className, children, render, ...rest} = props;

    const readOnly = useComboboxInputContextSelector((context) => context.comboboxInputProps?.readOnly ?? false);

    const defaultRender = React.useCallback(
        (triggerProps: HTMLProps<HTMLButtonElement>, state: BaseUICombobox.Trigger.State) => {
            const comboboxTriggerClassNames = cx(
                "flex items-center border-0 bg-transparent p-0",
                state.disabled
                    ? "pointer-events-none cursor-not-allowed"
                    : readOnly
                      ? "cursor-default"
                      : "cursor-pointer",
                addConsumerClasses(state, className),
            );
            return (
                <button
                    {...triggerProps}
                    aria-hidden={readOnly}
                    className={comboboxTriggerClassNames}
                    ref={triggerProps.ref}
                    type="button"
                >
                    {children}
                </button>
            );
        },
        [children, className, readOnly],
    );

    return (
        <BaseUICombobox.Trigger {...rest} render={render ?? defaultRender} ref={forwardedRef}>
            {children}
        </BaseUICombobox.Trigger>
    );
});
