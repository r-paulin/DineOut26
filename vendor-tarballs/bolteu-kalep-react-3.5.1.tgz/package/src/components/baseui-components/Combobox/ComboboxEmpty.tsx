import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useComboboxPositionerContextSelector} from "./context";

/**
 * ### Combobox.Empty
 * Placeholder content shown when the list has zero items.
 *
 * ```tsx
 * <Combobox.Popup>
 *   <Combobox.Empty>No cities found</Combobox.Empty>
 *   <Combobox.List>…</Combobox.List>
 * </Combobox.Popup>
 * ```
 *
 * Combine with actions or hints to guide the user toward the next step.
 */
export const ComboboxEmpty = React.forwardRef(function ComboboxEmpty(
    props: BaseUICombobox.Empty.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, children, ...rest} = props;

    const empty = useComboboxPositionerContextSelector((context) => context.comboboxPositionerState?.empty);

    const getComboboxEmptyClassNames = React.useCallback(
        (state: BaseUICombobox.Empty.State) =>
            cx(`flex items-center px-6 py-2 text-primary`, addConsumerClasses(state, className)),
        [className],
    );

    return (
        empty && (
            <BaseUICombobox.Empty {...rest} ref={forwardedRef} className={getComboboxEmptyClassNames}>
                {children}
            </BaseUICombobox.Empty>
        )
    );
});
