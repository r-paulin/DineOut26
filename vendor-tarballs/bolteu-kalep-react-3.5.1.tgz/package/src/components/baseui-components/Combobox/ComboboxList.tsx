import * as React from "react";

import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Combobox.List
 * Scrollable container for option rows inside `Combobox.Popup`. Provide a function child to render each
 * item from the underlying collection.
 *
 * ```tsx
 * <Combobox.Portal>
 *   <Combobox.Positioner>
 *     <Combobox.Popup>
 *       <Combobox.List>
 *         {(item) => (
 *           <Combobox.Item key={item.value} value={item}>
 *             <span>{item.label}</span>
 *             <Combobox.ItemIndicator />
 *           </Combobox.Item>
 *         )}
 *       </Combobox.List>
 *     </Combobox.Popup>
 *   </Combobox.Positioner>
 * </Combobox.Portal>
 * ```
 */
export const ComboboxList = React.forwardRef(function ComboboxList(
    props: BaseUICombobox.List.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getComboboxListClassNames = React.useCallback(
        (state: BaseUICombobox.List.State) =>
            cx(
                `
                  m-0 max-h-80 cursor-pointer list-none overflow-y-auto overscroll-none px-0 py-1
                  empty:py-0
                `,
                addConsumerClasses(state, className),
            ),
        [className],
    );

    return <BaseUICombobox.List {...rest} ref={forwardedRef} className={getComboboxListClassNames} />;
});
