import * as React from "react";

import {useRender} from "@base-ui/react";
import {Combobox as BaseUICombobox} from "@base-ui/react/combobox";
import type {BaseUIEvent, HTMLProps} from "@base-ui/react/utils/types";

import type {ComboboxSize} from "@/components/baseui-components/Combobox/combobox.types";
import {useComboboxContextSelector} from "@/components/baseui-components/Combobox/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";

import type {Indexable} from "../types/common-types";
import {ComboboxInputContextProvider} from "./context/ComboboxInputContextProvider";

const CLASSNAME_TW_SIZES: Record<ComboboxSize, string> = {
    sm: "bolt-font-body-s-regular min-h-9 gap-2 px-3 py-1",
    md: "bolt-font-body-m-regular min-h-12 gap-3 px-3 py-2",
    lg: "bolt-font-body-m-regular min-h-14 gap-3 px-4 py-3",
} as const;

const CLASSNAME_TW_VISUAL_STATE = {
    idle: `
      border-special-nulled text-primary
      focus-within:border-action-primary
    `,
    disabled: "cursor-not-allowed border-neutral-secondary bg-special-nulled text-tertiary placeholder-tertiary",
    readOnly: `
      cursor-default border-special-nulled text-primary
      focus-within:bg-neutral-secondary
    `,
    error: "border-danger-primary",
    open: "border-action-primary bg-special-nulled",
} as const;

type ComboboxInnerProps = BaseUICombobox.Input.Props & {state: BaseUICombobox.Input.State} & {
    baseUIInternalRef?: React.Ref<HTMLInputElement>;
    wrapperRef?: React.Ref<HTMLDivElement>;
    // property for testing purposes
    "data-testid"?: string;
};

const ComboboxInner = function ComboboxInner(props: ComboboxInnerProps) {
    const {
        render,
        state,
        baseUIInternalRef,
        wrapperRef,
        children,
        className,
        onClick,
        onMouseDown,
        "data-testid": dataTestId,
        ...restProps
    } = props;
    const inputRef = React.useRef<HTMLInputElement | null>(null);
    const mergedInputRef = mergeRefs([inputRef, baseUIInternalRef]);
    const inputWrapperRef = useComboboxContextSelector((context) => context.inputWrapperRef);

    const comboboxWrapper = useRender<Indexable<BaseUICombobox.Input.State>, HTMLDivElement>({
        defaultTagName: "div",
        render,
        ref: [inputWrapperRef, wrapperRef ?? null],
        state,
        props: {
            role: "presentation",
            children,
            className,
            onClick: (event: BaseUIEvent<React.MouseEvent<HTMLInputElement>>) => {
                if (state.disabled || state.readOnly) {
                    event.preventDefault();
                    return;
                }
                // Focus the input when the wrapper is clicked
                if (inputRef.current && document.activeElement !== inputRef.current) {
                    inputRef.current.focus();
                }

                onClick?.(event);
            },
            onMouseDown(event: BaseUIEvent<React.MouseEvent<HTMLInputElement>>) {
                onMouseDown?.(event);
            },
            "data-testid": dataTestId,
        },
    });

    return (
        <ComboboxInputContextProvider
            comboboxInputProps={restProps}
            comboboxInputState={state}
            inputRef={mergedInputRef}
        >
            {comboboxWrapper}
        </ComboboxInputContextProvider>
    );
};

/**
 * ### Combobox.Input
 * Container element for the interactive control. Nest `Combobox.ValueArea`, `Combobox.Control`, `Combobox.Controls`,
 * and chips inside it to keep focus/spacing behavior consistent.
 *
 * ```tsx
 * <Combobox.Root items={cities}>
 *   <Combobox.Input placeholder="Select a city">
 *     <Combobox.ValueArea>
 *       <Combobox.Control />
 *     </Combobox.ValueArea>
 *     <Combobox.Controls>
 *       <Combobox.Clear />
 *       <Combobox.Trigger>
 *         <Combobox.Icon />
 *       </Combobox.Trigger>
 *     </Combobox.Controls>
 *   </Combobox.Input>
 * </Combobox.Root>
 * ```
 */
export const ComboboxInput = React.forwardRef(function ComboboxInput(
    props: BaseUICombobox.Input.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const customComboboxProps = useComboboxContextSelector((context) => context.customComboboxProps);
    const {size, multiline, multiple, placeholder: contextPlaceholder} = customComboboxProps;

    const {className, placeholder, ...rest} = props;
    const resolvedPlaceholder = placeholder ?? contextPlaceholder;

    const getComboboxInputClassNames = React.useCallback(
        (state: BaseUICombobox.Input.State) =>
            cx(
                `
                  group/combobox-trigger flex w-full cursor-text items-center justify-between overflow-hidden rounded-md
                  border-2 border-solid bg-neutral-secondary text-left outline-none
                  transition-[color,background-color,border-color] duration-100 ease-linear
                  focus-within:bg-special-nulled
                `,
                CLASSNAME_TW_SIZES[size],
                {
                    "flex-wrap": multiline,
                    [CLASSNAME_TW_VISUAL_STATE.disabled]: state.disabled,
                    [CLASSNAME_TW_VISUAL_STATE.readOnly]: state.readOnly && !state.disabled,
                    [CLASSNAME_TW_VISUAL_STATE.error]: !state.disabled && !state.readOnly && state.valid === false,
                    [CLASSNAME_TW_VISUAL_STATE.idle]: !state.disabled && !state.readOnly && state.valid !== false,
                    [CLASSNAME_TW_VISUAL_STATE.open]: state.open && !state.disabled && !state.readOnly,
                    "gap-1": multiple && size === "sm",
                    "gap-2": multiple && size !== "sm",
                },
                addConsumerClasses(state, className),
            ),
        [className, multiline, size, multiple],
    );

    const defaultRender = React.useCallback(
        ({ref, ...restProps}: HTMLProps<HTMLInputElement>, state: BaseUICombobox.Input.State) => (
            <ComboboxInner {...restProps} baseUIInternalRef={ref} wrapperRef={forwardedRef} state={state} />
        ),
        [forwardedRef],
    );

    return (
        <BaseUICombobox.Input
            {...rest}
            placeholder={resolvedPlaceholder}
            render={props.render ?? defaultRender}
            className={getComboboxInputClassNames}
        />
    );
});
