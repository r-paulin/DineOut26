import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import type {Indexable} from "../types/common-types";
import type {TypographyLineClampValues,TypographyProps as TypographyProps, TypographyState} from "./types";

const lineClamp: Record<TypographyLineClampValues, string> = {
    1: "line-clamp-1",
    2: "line-clamp-2",
    3: "line-clamp-3",
    4: "line-clamp-4",
    none: "line-clamp-none",
};

/**
 * Typography primitive.
 *
 * Provides a className-first API so consumers control all typographic styling through Tailwind utilities.
 * - Defaults to `bolt-font-body-m-regular`, `text-left`, and block display
 * - Supply `className` with Tailwind utilities (alignment, colors, spacing, inline, etc.)
 * - Use `defaultTag` to change the rendered element while keeping the same styling
 *
 * ### Composition guide
 * ```tsx
 * <Typography className="text-sm text-secondary">Supporting copy</Typography>
 * <Typography defaultTag="p" className="bolt-font-heading-m-accent">
 *   Heading rendered as a paragraph tag
 * </Typography>
 * ```
 */
export const Typography = React.forwardRef(function Typography(
    props: TypographyProps,
    ref: React.ForwardedRef<HTMLElement>,
) {
    const {children, className, defaultTag = "span", lines, render, ...rest} = props;

    const state: TypographyState = {
        lines,
    };

    const defaultProps: useRender.ElementProps<"span"> = {
        className: cx(
            `bolt-font-body-m-regular m-0 block text-left text-primary`,
            lines && lineClamp[lines],
            addConsumerClasses(state, className),
        ),
        children,
    };

    return useRender<Indexable<TypographyState>, HTMLSpanElement>({
        ref,
        render,
        defaultTagName: defaultTag,
        state,
        props: mergeProps<"span">(defaultProps, rest),
    });
});

Typography.displayName = "Typography";
