import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import type {Indexable} from "../types/common-types";
import {TypographyStackProvider} from "./context/TypographyStackContext";
import type {TypographyStackProps, TypographyStackState} from "./types";

export const TypographyStackRoot = React.forwardRef(function TypographyStackRoot(
    props: TypographyStackProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {children, className, render, variant = "base", ...otherComponentProps} = props;

    const state: TypographyStackState = React.useMemo(
        () => ({
            variant,
        }),
        [variant],
    );

    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx("flex flex-col", {"gap-1": variant === "sm-expressive"}, addConsumerClasses(state, className)),
        children: <TypographyStackProvider value={{variant}}>{children}</TypographyStackProvider>,
    };

    return useRender<Indexable<TypographyStackState>, HTMLDivElement>({
        ref,
        render,
        defaultTagName: "div",
        state,
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });
});

TypographyStackRoot.displayName = "TypographyStack.Root";
