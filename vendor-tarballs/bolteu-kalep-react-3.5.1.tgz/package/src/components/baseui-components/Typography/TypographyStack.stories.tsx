import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Alert} from "@/components/baseui-components/Alert";
import {TypographyStack} from "@/components/baseui-components/Typography";
import {expect, within} from "storybook/test";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";

const meta = {
    component: TypographyStack,
    title: "BaseUI Playground/TypographyStack",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "Vertically stacked typography presets",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof TypographyStack>;

export default meta;
type Story = StoryObj<typeof meta>;

const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
                language: "tsx",
            },
        },
    },
});

const defaultStackSource = `
import {TypographyStack} from "@/components/baseui-components/Typography";

export function DefaultTypographyStack() {
  return (
    <TypographyStack>
      <TypographyStack.Primary>Primary text</TypographyStack.Primary>
      <TypographyStack.Secondary>Supporting copy</TypographyStack.Secondary>
    </TypographyStack>
  );
}
`;

const reversedStackSource = `
import {TypographyStack} from "@/components/baseui-components/Typography";

export function ReversedTypographyStack() {
  return (
    <TypographyStack>
      <TypographyStack.Secondary>Secondary copy</TypographyStack.Secondary>
      <TypographyStack.Primary>Newest at the top</TypographyStack.Primary>
    </TypographyStack>
  );
}
`;

const variantsStackSource = `
import {TypographyStack} from "@/components/baseui-components/Typography";

const variants = ["base", "sm", "sm-expressive"] as const;

export function TypographyStackVariants() {
  return (
    <div className="flex flex-col gap-4">
      {variants.map((variant) => (
        <TypographyStack key={variant} variant={variant}>
          <TypographyStack.Primary>Primary text</TypographyStack.Primary>
          <TypographyStack.Secondary>Supporting copy</TypographyStack.Secondary>
        </TypographyStack>
      ))}
    </div>
  );
}
`;

const typographyPropsSource = `
import {TypographyStack} from "@/components/baseui-components/Typography";

export function TypographyStackOverrides() {
  return (
    <div className="flex flex-col gap-4">
      <TypographyStack>
        <TypographyStack.Primary lines={2}>
          Clamp me to two lines
        </TypographyStack.Primary>
        <TypographyStack.Secondary>I stay single line</TypographyStack.Secondary>
      </TypographyStack>
      <TypographyStack>
        <TypographyStack.Primary className="text-action-primary">Accent color</TypographyStack.Primary>
        <TypographyStack.Secondary>Secondary text</TypographyStack.Secondary>
      </TypographyStack>
    </div>
  );
}
`;

export const Default: Story = {
    render: (args) => (
        <TypographyStack {...args}>
            <TypographyStack.Primary data-testid="stack-default-primary">This is primary</TypographyStack.Primary>
            <TypographyStack.Secondary data-testid="stack-default-secondary">This is secondary</TypographyStack.Secondary>
        </TypographyStack>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const primary = await canvas.findByTestId("stack-default-primary");
        const secondary = await canvas.findByTestId("stack-default-secondary");
        await step("Applies default primary typography", async () => {
            await expect(primary).toHaveClass("bolt-font-body-m-regular");
        });
        await step("Applies default secondary typography", async () => {
            await expect(secondary).toHaveClass("bolt-font-body-s-regular");
        });
    },
    ...withSource(defaultStackSource),
};

export const Reversed: Story = {
    render: () => (
        <TypographyStack data-testid="stack-reversed">
            <TypographyStack.Secondary>Secondary first</TypographyStack.Secondary>
            <TypographyStack.Primary>Primary second</TypographyStack.Primary>
        </TypographyStack>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const stack = await canvas.findByTestId("stack-reversed");
        await step("Maintains custom order", async () => {
            await expect(stack.firstElementChild).toHaveTextContent("Secondary first");
        });
    },
    ...withSource(reversedStackSource),
};

export const Variants: Story = {
    render: () => (
        <>
            {(["base", "sm", "sm-expressive"] as const).map((variant) => (
                <div key={variant} className="mb-4">
                    <div className="mb-2 font-mono text-sm text-secondary">{variant}</div>
                    <TypographyStack variant={variant}>
                        <TypographyStack.Primary data-testid={`stack-variant-${variant}-primary`}>
                            This is primary
                        </TypographyStack.Primary>
                        <TypographyStack.Secondary data-testid={`stack-variant-${variant}-secondary`}>
                            This is secondary
                        </TypographyStack.Secondary>
                    </TypographyStack>
                </div>
            ))}
        </>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const smPrimary = await canvas.findByTestId("stack-variant-sm-primary");
        const smSecondary = await canvas.findByTestId("stack-variant-sm-secondary");
        await step("Sm variant primary uses body-s font", async () => {
            await expect(smPrimary).toHaveClass("bolt-font-body-s-regular");
        });
        await step("Sm variant secondary uses body-xs font", async () => {
            await expect(smSecondary).toHaveClass("bolt-font-body-xs-regular");
        });
    },
    ...withSource(variantsStackSource),
};

export const TypographyProps: Story = {
    render: () => (
        <>
            <Alert.Root severity="info">
                <Alert.Icon />
                <Alert.Content>
                    <Alert.Description>
                        Pass props directly to <code>TypographyStack.Primary</code> or{" "}
                        <code>TypographyStack.Secondary</code> to override typography styles.
                    </Alert.Description>
                </Alert.Content>
            </Alert.Root>
            <div className="mt-8 flex w-96 flex-col gap-4">
                <TypographyStack>
                    <TypographyStack.Primary data-testid="stack-props-clamp" lines={2}>
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Tempora eaque quibusdam nemo ullam amet? Sed maxime culpa ab officiis minima eveniet asperiores explicabo quidem, iure est obcaecati itaque ut accusamus
                    </TypographyStack.Primary>
                    <TypographyStack.Secondary data-testid="stack-props-secondary">
                        I stay single line
                    </TypographyStack.Secondary>
                </TypographyStack>
                <TypographyStack>
                    <TypographyStack.Primary data-testid="stack-props-accent" className="text-action-primary">
                        Accent color
                    </TypographyStack.Primary>
                    <TypographyStack.Secondary data-testid="stack-props-neutral">Secondary text</TypographyStack.Secondary>
                </TypographyStack>
            </div>
        </>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const clamp = await canvas.findByTestId("stack-props-clamp");
        const accent = await canvas.findByTestId("stack-props-accent");
        await step("Supports line clamping", async () => {
            await expect(clamp).toHaveClass("line-clamp-2");
        });
        await step("Supports className overrides", async () => {
            await expect(accent).toHaveClass("text-action-primary");
        });
    },
    ...withSource(typographyPropsSource),
};
