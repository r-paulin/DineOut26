import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Alert} from "@/components/Alert";
import {Link} from "@/components/Link";
import type {BoltFontStyles, TypographySize} from "@/components/baseui-components/Typography/types";
import {Typography} from "@/components/baseui-components/Typography";
import {expect, within} from "storybook/test";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";

const meta = {
    component: Typography,
    title: "BaseUI Playground/Typography",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "Typography primitives mapped to Bolt font tokens",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Typography>;

export default meta;
type Story = StoryObj<typeof meta>;

const withSource = (code: string, description?: string) => ({
    parameters: {
        docs: {
            source: {
                code,
                language: "tsx",
            },
            description: {
                story: description || "",
            },
        },
    },
});

const defaultSource = `
import {Typography} from "@/components/baseui-components/Typography";

export function DefaultTypography() {
  return <Typography>The quick fox jumps over the lazy dog</Typography>;
}
`;

const variantsSource = `
import {Typography} from "@/components/baseui-components/Typography";

const variants = ["heading-l-accent", "body-m-regular", "caps-m-accent"];

export function VariantPreview() {
  return (
    <div className="flex flex-col">
      {variants.map((variant) => (
        <Typography key={variant} className={\`bolt-font-\${variant}\`}>
          The quick brown fox jumps over the lazy dog
        </Typography>
      ))}
    </div>
  );
}
`;

const alignmentSource = `
import {Typography} from "@/components/baseui-components/Typography";

export function AlignmentPreview() {
  return (
    <div className="flex flex-col gap-4">
      {(["text-left", "text-center", "text-right", "text-justify"] as const).map((align) => (
        <Typography key={align} className={align}>
          This paragraph uses the "{align}" alignment.
        </Typography>
      ))}
    </div>
  );
}
`;

const fontSizesSource = `
import {Typography} from "@/components/baseui-components/Typography";

const sizes = ["text-sm", "text-base", "text-lg"];

export function CustomFontSizes() {
  return (
    <div className="flex flex-col">
      {sizes.map((size) => (
        <Typography key={size} className={size}>
          This text is {size}.
        </Typography>
      ))}
    </div>
  );
}
`;

const inlineTextSource = `
import {Typography} from "@/components/baseui-components/Typography";

export function InlineText() {
  return (
    <Typography>
      Use <Typography className="inline font-semibold">inline</Typography> to keep nested text inline.
    </Typography>
  );
}
`;

const noWrapSource = `
import {Typography} from "@/components/baseui-components/Typography";

export function ClampedTypography() {
  return (
    <div className="w-64">
      <Typography className="truncate">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
      </Typography>
    </div>
  );
}
`;

const fontSettingsSource = `
import {Typography} from "@/components/baseui-components/Typography";

export function FontSettingsExample() {
  return (
    <>
      <Typography>
        0 → <Typography className="inline [font-feature-settings:'zero']">0</Typography>
      </Typography>
      <Typography>
        Fractions → <Typography className="inline [font-variant-numeric:diagonal-fractions]">1/2</Typography>
      </Typography>
    </>
  );
}
`;

export const Default: Story = {
    args: {
        children: "The quick fox jumps over the lazy dog",
    },
    render: (args) => <Typography data-testid="typography-default" {...args} />,
    play: async ({canvasElement, step, args}) => {
        const canvas = within(canvasElement);
        const element = await canvas.findByTestId("typography-default");
        await step("Renders Typography content", async () => {
            await expect(element).toHaveTextContent(args.children as string);
        });
        await step("Applies default Bolt font", async () => {
            await expect(element).toHaveClass("bolt-font-body-m-regular");
        });
    },
    ...withSource(defaultSource),
};

export const Variants: Story = {
    render: () => {
        const phrase = "The quick brown fox jumps over the lazy dog";
        const variants: BoltFontStyles[] = [
            "heading-l-accent",
            "heading-m-accent",
            "heading-s-accent",
            "heading-xs-accent",
            "heading-xs-regular",
            "body-l-regular",
            "body-l-accent",
            "body-l-compact-regular",
            "body-l-compact-accent",
            "body-m-regular",
            "body-m-accent",
            "body-m-compact-regular",
            "body-m-compact-accent",
            "body-s-regular",
            "body-s-accent",
            "body-s-compact-regular",
            "body-s-compact-accent",
            "body-xs-regular",
            "body-xs-accent",
            "body-xs-compact-regular",
            "body-xs-compact-accent",
            "body-tabular-l-regular",
            "body-tabular-l-accent",
            "body-tabular-l-compact-regular",
            "body-tabular-l-compact-accent",
            "body-tabular-m-regular",
            "body-tabular-m-accent",
            "body-tabular-m-compact-regular",
            "body-tabular-m-compact-accent",
            "body-tabular-s-regular",
            "body-tabular-s-accent",
            "body-tabular-s-compact-regular",
            "body-tabular-s-compact-accent",
            "body-tabular-xs-regular",
            "body-tabular-xs-accent",
            "body-tabular-xs-compact-regular",
            "body-tabular-xs-compact-accent",
            "caps-l-accent",
            "caps-m-accent",
            "caps-s-accent",
            "display-m-regular",
        ];
        return (
            <div className="flex flex-col">
                {variants.map((variant) => (
                    <div key={variant} className="p-4">
                        <div className="font-mono text-sm text-secondary">{variant}</div>
                        <Typography
                            data-testid={`typography-variant-${variant}`}
                            className={`
                              bolt-font-${variant}
                              pt-2
                            `}
                        >
                            {phrase}
                        </Typography>
                    </div>
                ))}
            </div>
        );
    },
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const headingVariant = await canvas.findByTestId("typography-variant-heading-l-accent");
        await step("Applies variant class names", async () => {
            await expect(headingVariant).toHaveClass("bolt-font-heading-l-accent");
        });
    },
    ...withSource(variantsSource),
};

export const Alignment: Story = {
    render: () => (
        <div className="flex flex-col gap-2 p-4">
            {(["text-left", "text-center", "text-right", "text-justify"] as const).map((alignment) => (
                <React.Fragment key={alignment}>
                    <Typography className={`
                      bolt-font-heading-m-accent
                      ${alignment}
                    `}>
                        {alignment.replace("text-", "").replace("-", " ")}
                    </Typography>
                    <Typography data-testid={`alignment-${alignment}`} className={`
                      ${alignment}
                      pb-8
                    `}>
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, atque! Qui exercitationem,
                        numquam doloremque provident nobis soluta eligendi dolorum, magni aperiam aut laborum architecto
                        quibusdam odit molestiae, culpa illum ea.
                    </Typography>
                </React.Fragment>
            ))}
        </div>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const leftParagraph = await canvas.findByTestId("alignment-text-left");
        await step("Applies alignment utility", async () => {
            await expect(leftParagraph).toHaveClass("text-left");
        });
    },
    ...withSource(alignmentSource),
};

export const FontSizes: Story = {
    render: () => {
        const sizes: TypographySize[] = [
            "text-xs",
            "text-sm",
            "text-base",
            "text-md",
            "text-lg",
            "text-xl",
            "text-2xl",
            "text-3xl",
            "text-4xl",
            "text-5xl",
            "text-6xl",
        ];
        return (
            <div className="flex flex-col">
                {sizes.map((size) => (
                    <Typography
                        key={size}
                        className={`
                          ${size}
                          pb-2
                        `}
                    >
                        This text is {size} size
                    </Typography>
                ))}
            </div>
        );
    },
    ...withSource(fontSizesSource),
};

export const InlineText: Story = {
    render: () => (
        <Typography className="font-normal">
            You can nest Typography elements to make them look different like{" "}
            <Typography data-testid="typography-inline-accent" className="inline font-semibold">
                this semibold part
            </Typography>{" "}
            to enrich your texts or stress some parts. Just use the{" "}
            <Typography className="inline font-semibold">inline</Typography> class to avoid creating a new block
            element.
        </Typography>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const inlineAccent = await canvas.findByTestId("typography-inline-accent");
        await step("Nested Typography is inline", async () => {
            await expect(inlineAccent).toHaveClass("inline");
        });
    },
    ...withSource(
        inlineTextSource,
        "Typography renders as a block by default. Apply Tailwind's `inline` utility to keep nested text inline.",
    ),
};

export const NoWrapping: Story = {
    render: () => (
        <div className="w-64 resize-x overflow-hidden border border-solid border-separator p-4">
            <Typography data-testid="typography-truncate" className="truncate">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsam nemo ut nobis eius sunt esse quod dicta
                commodi quos neque labore soluta quam doloribus id sed sequi rerum, nihil sit.
            </Typography>
        </div>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const truncated = await canvas.findByTestId("typography-truncate");
        await step("Applies truncate utility", async () => {
            await expect(truncated).toHaveClass("truncate");
        });
    },
    ...withSource(noWrapSource),
};

export const FontSettings: Story = {
    render: () => (
        <div className="flex flex-col gap-4">
            <Alert severity="info" title="Use font-feature-settings to control advanced typographic features">
                Use CSS classes to enable advanced typographic features such as small caps, ligatures, and swashes. See{" "}
                <Link href="https://developer.mozilla.org/en-US/docs/Web/CSS/font-feature-settings" target="_blank">
                    MDN docs
                </Link>{" "}
                for more info about <code>font-feature-settings</code> and check{" "}
                <Link href="https://rsms.me/inter/lab/" target="_blank">
                    Inter lab
                </Link>{" "}
                where you can play around with all the font features.
            </Alert>
            <div className="font-mono text-sm text-secondary">zero</div>
            <Typography>
                0 →{" "}
                <Typography data-testid="typography-zero" className={`
                  inline
                  [font-feature-settings:'zero']
                `}>
                    0
                </Typography>
            </Typography>
            <div className="font-mono text-sm text-secondary">diagonal-fractions</div>
            <Typography>
                Make fractions fancier: 1/2 →{" "}
                <Typography
                    data-testid="typography-fraction"
                    className={`
                      inline
                      [font-variant-numeric:diagonal-fractions]
                    `}
                >
                    1/2
                </Typography>
            </Typography>
        </div>
    ),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const zero = await canvas.findByTestId("typography-zero");
        const fraction = await canvas.findByTestId("typography-fraction");
        await step("Zero typography uses font-feature class", async () => {
            await expect(zero).toHaveClass("[font-feature-settings:'zero']");
        });
        await step("Fraction typography uses numeric variant class", async () => {
            await expect(fraction).toHaveClass("[font-variant-numeric:diagonal-fractions]");
        });
    },
    ...withSource(fontSettingsSource),
};
