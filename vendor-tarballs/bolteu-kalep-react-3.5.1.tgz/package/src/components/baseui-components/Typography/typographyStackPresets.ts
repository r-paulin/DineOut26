import type {TypographyStackVariant} from "./types";

export interface TypographyStackPreset {
    primary: {
        className: string;
    };
    secondary: {
        className: string;
    };
}

export const typographyStackPresets: Record<TypographyStackVariant, TypographyStackPreset> = {
    base: {
        primary: {className: "bolt-font-body-m-regular"},
        secondary: {className: "bolt-font-body-s-regular text-secondary"},
    },
    sm: {
        primary: {className: "bolt-font-body-s-regular"},
        secondary: {className: "bolt-font-body-xs-regular text-secondary"},
    },
    "sm-expressive": {
        primary: {className: "bolt-font-body-s-regular"},
        secondary: {className: "bolt-font-body-s-regular"},
    },
};
