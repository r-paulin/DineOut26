import * as React from "react";

import type {TypographyStackContextValue} from "../types";

export const TypographyStackContext = React.createContext<TypographyStackContextValue | null>(null);

export function TypographyStackProvider(props: {value: TypographyStackContextValue; children: React.ReactNode}) {
    return <TypographyStackContext.Provider value={props.value}>{props.children}</TypographyStackContext.Provider>;
}

export function useTypographyStackContext() {
    const context = React.useContext(TypographyStackContext);
    if (!context) {
        throw new Error("TypographyStack components must be used within TypographyStack");
    }
    return context;
}
