import {TypographyStackPrimary} from "./TypographyStackPrimary";
import {TypographyStackRoot} from "./TypographyStackRoot";
import {TypographyStackSecondary} from "./TypographyStackSecondary";

/**
 * TypographyStack compound component.
 *
 * Provides a preset pair of Typography elements stacked vertically for primary/secondary content.
 * - `TypographyStack` renders the wrapper and applies variant-specific spacing
 * - `TypographyStack.Primary` / `.Secondary` render Typography with the preset Bolt font classes
 * - Order is fully controlled via composition (swap the child order to change layout)
 *
 * ### Composition guide
 * ```tsx
 * <TypographyStack variant="sm">
 *   <TypographyStack.Primary className="truncate">Primary text</TypographyStack.Primary>
 *   <TypographyStack.Secondary className="text-secondary">Supporting copy</TypographyStack.Secondary>
 * </TypographyStack>
 * ```
 */
export const TypographyStack = Object.assign(TypographyStackRoot, {
    Primary: TypographyStackPrimary,
    Secondary: TypographyStackSecondary,
});

TypographyStack.displayName = "TypographyStack";
TypographyStack.Primary.displayName = "TypographyStack.Primary";
TypographyStack.Secondary.displayName = "TypographyStack.Secondary";
