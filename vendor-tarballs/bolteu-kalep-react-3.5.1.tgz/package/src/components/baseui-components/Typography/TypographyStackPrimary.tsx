import * as React from "react";

import {Typography} from "./Typography";
import {useTypographyStackContext} from "./context/TypographyStackContext";
import {typographyStackPresets} from "./typographyStackPresets";
import type {TypographyStackItemProps} from "./types";
import {cx} from "@/helpers/utils/cx";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";

export const TypographyStackPrimary = React.forwardRef(function TypographyStackPrimary(
    props: TypographyStackItemProps,
    ref: React.ForwardedRef<HTMLElement>,
) {
    const {className, ...restProps} = props;

    const {variant} = useTypographyStackContext();

    const defaultClassName = typographyStackPresets[variant].primary.className;
    const combinedClassName = addConsumerClasses({variant}, cx(defaultClassName, className));

    return <Typography {...restProps} className={combinedClassName} ref={ref} />;
});
