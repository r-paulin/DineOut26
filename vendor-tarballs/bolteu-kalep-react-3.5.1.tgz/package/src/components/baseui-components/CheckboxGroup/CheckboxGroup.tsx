import * as React from "react";

import {CheckboxGroup as BaseUICheckboxGroup} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * Checkbox Group is composed together with Checkbox. Import the components and place them together:
 *
 * ```tsx
 * <CheckboxGroup>
 *   <Checkbox
 *     name="field-name"
 *     value="option-1"
 *   />
 *   <Checkbox
 *     name="field-name"
 *     value="option-2"
 *   />
 *   <Checkbox
 *     name="field-name"
 *     value="option-3"
 *   />
 * </CheckboxGroup>
 * ```
 * A `render` prop is provided for the `CheckboxGroup` component to
 * allow custom rendering of the component.
 *
 * See `Field` and `Form` component documentation for better understanding of the field composition in a form.
 */
export const CheckboxGroup = React.forwardRef(function CheckboxGroup(
    props: BaseUICheckboxGroup.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {children, className, ...restProps} = props;
    const checkboxGroupClassname = React.useCallback(
        (state: BaseUICheckboxGroup.State) => {
            return cx("flex flex-col items-start gap-2", addConsumerClasses(state, className));
        },
        [className],
    );
    return (
        <BaseUICheckboxGroup {...restProps} className={checkboxGroupClassname} ref={ref}>
            {children}
        </BaseUICheckboxGroup>
    );
});
