import * as React from "react";

import {expect, screen, userEvent, waitFor, within} from "storybook/test";
import {Form} from "@base-ui/react";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Field} from "@/components/baseui-components/Field";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Select} from "./index";

const meta = {
    component: Select as unknown as React.ComponentType<any>,
    subcomponents: {
        "Select.Root": Select.Root,
        "Select.Trigger": Select.Trigger,
        "Select.Value": Select.Value,
        "Select.Portal": Select.Portal,
        "Select.Positioner": Select.Positioner,
        "Select.Popup": Select.Popup,
        "Select.List": Select.List,
        "Select.Item": Select.Item,
        "Select.ItemText": Select.ItemText,
        "Select.ItemIndicator": Select.ItemIndicator,
        "Select.Icon": Select.Icon,
        "Select.CheckboxIndicator": Select.CheckboxIndicator,
    },
    title: "BaseUI Playground/Select",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            toc: true,
            page: DocumentationTemplate,
            subtitle: "Anatomy and API for the Base UI Select",
            controls: {
                exclude: ["items"],
            },
        },
    },
} satisfies Meta<typeof Select.Root>;

export default meta;

const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

type Story = StoryObj<typeof meta>;

type CityOption = {label: string; value: string; secondary?: string; disabled?: boolean};
type PlaygroundOption = {label: string; value: string | null; secondary?: string; disabled?: boolean};

type PlaygroundArgTypes = Pick<React.ComponentProps<typeof Select.Root>, "size" | "disabled" | "readOnly" | "multiple">;

const cityItems: CityOption[] = [
    {label: "Tallinn", value: "1"},
    {label: "Stockholm", value: "2"},
    {label: "Berlin", value: "3"},
    {label: "Warsaw", value: "4"},
    {label: "Paris", value: "5"},
    {label: "London", value: "6"},
    {label: "Lisbon", value: "7"},
    {label: "Johannesburg", value: "8"},
];

// Includes the null-value placeholder entry for single-select stories that render
// an explicit "no selection" item inside the list.
const cityOptions: PlaygroundOption[] = [{label: "Placeholder option", value: null}, ...cityItems];

const multilineOption: CityOption = {
    label: "Just an example entry that can be long and span across multiple lines",
    value: "9",
};

const multilineOptions: PlaygroundOption[] = [multilineOption, ...cityOptions];

const secondaryItems: CityOption[] = [
    {label: "Tallinn", value: "1", secondary: "Capital of Estonia"},
    {label: "Stockholm", value: "2", secondary: "Capital of Sweden"},
    {label: "Berlin", value: "3", secondary: "Capital of Germany"},
    {label: "Warsaw", value: "4", secondary: "Capital of Poland"},
    {label: "Paris", value: "5", secondary: "Capital of France"},
    {
        label: "London",
        value: "6",
        secondary: "Capital of the United Kingdom of Great Britain and Northern Ireland (and long country names)",
    },
    {label: "Lisbon", value: "7", secondary: "Capital of Portugal"},
    {label: "Johannesburg", value: "8", secondary: "Capital of South Africa"},
];

// Includes the null-value placeholder entry for single-select stories.
const optionsWithSecondary: PlaygroundOption[] = [{label: "Placeholder option", value: null}, ...secondaryItems];

interface PlaygroundSelectProps {
    label?: string;
    placeholder?: string;
    options?: PlaygroundOption[];
    size?: "sm" | "md" | "lg";
    multiline?: boolean;
    disabled?: boolean;
    readOnly?: boolean;
    required?: boolean;
    defaultValue?: string | string[] | null;
    value?: string | null | undefined;
    onValueChange?: (nextValue: string | null) => void;
    errorMessage?: string;
    testId?: string;
}

function BaseUISelectPreview({
    label = "Label",
    options = cityOptions,
    size = "md",
    multiline = false,
    disabled,
    readOnly,
    required,
    defaultValue,
    value,
    onValueChange,
    errorMessage,
    testId,
}: PlaygroundSelectProps) {
    const selectionProps =
        value !== undefined
            ? {value}
            : {
                  defaultValue: defaultValue ?? null,
              };

    const getElementTestId = React.useCallback((part: string) => (testId ? `${testId}-${part}` : undefined), [testId]);

    return (
        <Form {...(errorMessage ? {errors: {[`select-${label}`]: errorMessage}} : {})}>
            <div className="max-w-96">
                <Field.Root name={`select-${label}`} disabled={disabled} invalid={Boolean(errorMessage)}>
                    <Field.Label>{label}</Field.Label>
                    <Select.Root
                        items={options}
                        size={size}
                        multiline={multiline}
                        disabled={disabled}
                        readOnly={readOnly}
                        required={required}
                        onValueChange={onValueChange}
                        defaultValue={null}
                        {...(selectionProps as Record<string, unknown>)}
                    >
                        <Select.Trigger data-testid={getElementTestId("trigger")}>
                            <Select.Value data-testid={getElementTestId("value")} />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List data-testid={getElementTestId("list")}>
                                        {options.map((option) => (
                                            <Select.Item
                                                key={option.value ?? "placeholder"}
                                                value={option.value}
                                                data-testid={
                                                    option.value === null
                                                        ? getElementTestId("item-null")
                                                        : getElementTestId(`item-${option.value}`)
                                                }
                                            >
                                                {option.secondary ? (
                                                    <div className="flex min-w-0 flex-1 flex-col">
                                                        <Select.ItemText>{option.label}</Select.ItemText>
                                                        <span className="bolt-font-body-s-regular m-0 text-secondary">
                                                            {option.secondary}
                                                        </span>
                                                    </div>
                                                ) : (
                                                    <Select.ItemText>{option.label}</Select.ItemText>
                                                )}
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                    <Field.Error />
                </Field.Root>
            </div>
        </Form>
    );
}

const playgroundStorySource = `
const options = [
    {label: "Tallinn", value: "1"},
    {label: "Stockholm", value: "2"},
    {label: "Berlin", value: "3"},
    {label: "Warsaw", value: "4"},
    {label: "Paris", value: "5"},
    {label: "London", value: "6"},
    {label: "Lisbon", value: "7"},
    {label: "Johannesburg", value: "8"},
];

// Single-select
const [value, setValue] = React.useState<string | null>(null);

<Field.Root>
    <Field.Label>Label</Field.Label>
    <Select.Root items={options} value={value} onValueChange={setValue}>
        <Select.Trigger>
            <Select.Value placeholder="Placeholder" />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * Interactive playground. Toggle `multiple` in the Controls panel to switch between
 * single-select and multi-select modes. All other props apply to both modes.
 *
 * When `multiple` is `true` the trigger displays all selected labels joined by commas.
 */
export const Playground: Story = {
    render: (args: PlaygroundArgTypes) => {
        const {multiple, ...restArgs} = args;
        const isMultiple = multiple === true;
        const [singleValue, setSingleValue] = React.useState<string | null>(null);
        const [multiValue, setMultiValue] = React.useState<string[] | null>([]);

        if (isMultiple) {
            return (
                <div className="max-w-96">
                    <Field.Root>
                        <Field.Label>Label</Field.Label>
                        <Select.Root
                            multiple={true}
                            items={cityItems}
                            value={multiValue}
                            onValueChange={setMultiValue}
                            {...restArgs}
                        >
                            <Select.Trigger>
                                <Select.Value placeholder="Placeholder" />
                                <Select.Icon />
                            </Select.Trigger>
                            <Select.Portal>
                                <Select.Positioner>
                                    <Select.Popup>
                                        <Select.List>
                                            {cityItems.map((option) => (
                                                <Select.Item key={option.value} value={option.value}>
                                                    <Select.ItemText>{option.label}</Select.ItemText>
                                                    <Select.ItemIndicator />
                                                </Select.Item>
                                            ))}
                                        </Select.List>
                                    </Select.Popup>
                                </Select.Positioner>
                            </Select.Portal>
                        </Select.Root>
                    </Field.Root>
                </div>
            );
        }

        return (
            <div className="max-w-96">
                <Field.Root>
                    <Field.Label>Label</Field.Label>
                    <Select.Root value={singleValue} onValueChange={setSingleValue} {...restArgs}>
                        <Select.Trigger>
                            <Select.Value placeholder="Placeholder" />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List>
                                        {cityOptions.map((option) => (
                                            <Select.Item key={option.value ?? "null"} value={option.value}>
                                                <Select.ItemText>{option.label}</Select.ItemText>
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
            </div>
        );
    },
    args: {
        multiple: false,
        disabled: false,
        readOnly: false,
    },
    argTypes: {
        multiple: {
            control: "boolean",
            description:
                "Enable multi-value selection mode. When true, `value` is `Value[]` and the trigger shows all selected labels joined by commas.",
        },
        disabled: {control: "boolean"},
        readOnly: {control: "boolean"},
        size: {
            control: "radio",
            options: ["sm", "md", "lg"],
        },
    },
    ...withSource(playgroundStorySource.trim()),
};

const defaultStorySource = `
const options = [
    {label: "Placeholder option", value: null},
    {label: "Tallinn", value: "1"},
    {label: "Stockholm", value: "2"},
    {label: "Berlin", value: "3"},
    {label: "Warsaw", value: "4"},
    {label: "Paris", value: "5"},
    {label: "London", value: "6"},
    {label: "Lisbon", value: "7"},
    {label: "Johannesburg", value: "8"},
];

<Field.Root name="city">
    <Field.Label>Label</Field.Label>
    <Select.Root items={options} defaultValue={null}>
        <Select.Trigger>
            <Select.Value placeholder="Placeholder" />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value ?? "placeholder"} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
    <Field.Error />
</Field.Root>
`;

/**
 * The standard single-select with a null-value placeholder option. The trigger
 * displays the placeholder until an item is chosen, then shows the selected label.
 *
 * Pass the `items` array to `Select.Root` so Base UI can resolve labels natively.
 * Include a null-valued item to represent the "no selection" state.
 */
export const Default: Story = {
    render: () => <BaseUISelectPreview placeholder="Placeholder" testId="select-default" />,
    play: async ({canvas, step}) => {
        await step("Shows placeholder option", async () => {
            const value = await canvas.findByTestId("select-default-value");
            await expect(value).toHaveTextContent("Placeholder option");
        });

        await step("Opens popup and selects Berlin", async () => {
            const trigger = await canvas.findByTestId("select-default-trigger");
            const value = await canvas.findByTestId("select-default-value");
            await userEvent.click(trigger);
            const list = await screen.findByTestId("select-default-list", {}, {timeout: 3000});
            const berlin = await within(list).findByRole("option", {name: /Berlin/i});
            await expect(berlin).toBeVisible();
            await userEvent.click(berlin);
            await waitFor(
                () => {
                    expect(screen.queryByTestId("select-default-list")).not.toBeVisible();
                },
                {timeout: 3000},
            );
            await expect(value).toHaveTextContent("Berlin");
        });
    },
    ...withSource(defaultStorySource.trim()),
};

const sizesStorySource = `
<div className="flex flex-col gap-8">
    <Field.Root name="city-sm">
        <Field.Label>Small</Field.Label>
        <Select.Root items={options} size="sm" defaultValue={null}>
            <Select.Trigger>
                <Select.Value placeholder="City" />
                <Select.Icon />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List>
                            {options.map((option) => (
                                <Select.Item key={option.value ?? "placeholder"} value={option.value}>
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    <Select.ItemIndicator />
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>
    </Field.Root>

    <Field.Root name="city-md">
        <Field.Label>Medium (default)</Field.Label>
        <Select.Root items={options} defaultValue={null}>
            <Select.Trigger>
                <Select.Value placeholder="City" />
                <Select.Icon />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List>
                            {options.map((option) => (
                                <Select.Item key={option.value ?? "placeholder"} value={option.value}>
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    <Select.ItemIndicator />
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>
    </Field.Root>

    <Field.Root name="city-lg">
        <Field.Label>Large</Field.Label>
        <Select.Root items={options} size="lg" defaultValue={null}>
            <Select.Trigger>
                <Select.Value placeholder="City" />
                <Select.Icon />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List>
                            {options.map((option) => (
                                <Select.Item key={option.value ?? "placeholder"} value={option.value}>
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    <Select.ItemIndicator />
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>
    </Field.Root>
</div>
`;

/**
 * Three trigger heights controlled by the `size` prop: `"sm"` (36 px), `"md"` (48 px, default),
 * and `"lg"` (56 px). Pass `size` to `Select.Root` — all child parts inherit it via context.
 */
export const Sizes: Story = {
    render: () => (
        <div className="flex flex-col gap-8">
            <BaseUISelectPreview label="Small" size="sm" placeholder="City" testId="select-sizes-small" />
            <BaseUISelectPreview label="Medium (default)" placeholder="City" testId="select-sizes-medium" />
            <BaseUISelectPreview label="Large" size="lg" placeholder="City" testId="select-sizes-large" />
        </div>
    ),
    play: async ({canvas, step}) => {
        await step("Applies size specific classes", async () => {
            const smallTrigger = await canvas.findByTestId("select-sizes-small-trigger");
            const mediumTrigger = await canvas.findByTestId("select-sizes-medium-trigger");
            const largeTrigger = await canvas.findByTestId("select-sizes-large-trigger");

            await expect(smallTrigger).toHaveClass("min-h-9");
            await expect(mediumTrigger).toHaveClass("min-h-12");
            await expect(largeTrigger).toHaveClass("min-h-14");
        });

        await step("Medium select opens and updates value", async () => {
            const mediumTrigger = await canvas.findByTestId("select-sizes-medium-trigger");
            await userEvent.click(mediumTrigger);
            const list = await screen.findByTestId("select-sizes-medium-list", {}, {timeout: 3000});
            const warsaw = await within(list).findByText("Warsaw");
            await userEvent.click(warsaw);
            await waitFor(
                () => {
                    expect(screen.queryByTestId("select-sizes-medium-list")).not.toBeVisible();
                },
                {timeout: 3000},
            );
            const mediumValue = await canvas.findByTestId("select-sizes-medium-value");
            await expect(mediumValue).toHaveTextContent("Warsaw");
        });
    },
    ...withSource(sizesStorySource.trim()),
};

const multilineStorySource = `
const options = [
    {label: "Just an example entry that can be long and span across multiple lines", value: "9"},
    {label: "Tallinn", value: "1"},
    {label: "Stockholm", value: "2"},
    // ...
];

<Field.Root name="city">
    <Field.Label>Label</Field.Label>
    <Select.Root items={options} multiline defaultValue="9">
        <Select.Trigger>
            <Select.Value />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * When `multiline` is set on `Select.Root`, the trigger grows vertically to fit long labels
 * instead of truncating them. Useful when option text may span several words or wrap naturally.
 */
export const Multiline: Story = {
    render: () => (
        <BaseUISelectPreview
            options={multilineOptions}
            multiline
            defaultValue={multilineOption.value}
            testId="select-multiline"
        />
    ),
    play: async ({canvas, step}) => {
        const value = await canvas.findByTestId("select-multiline-value");
        const trigger = await canvas.findByTestId("select-multiline-trigger");

        await step("Value wraps across multiple lines", async () => {
            await expect(value).toHaveClass("whitespace-normal");
            await expect(value).toHaveTextContent(multilineOption.label);
        });

        await step("Popup shows multiline option", async () => {
            await userEvent.click(trigger);
            const popup = await screen.findByTestId("select-multiline-list", {}, {timeout: 3000});
            const {findByText} = within(popup);
            const option = await findByText(multilineOption.label);
            await expect(option).toBeVisible();
            await userEvent.click(option);
            await waitFor(
                () => {
                    expect(screen.queryByTestId("select-multiline-list")).not.toBeVisible();
                },
                {timeout: 3000},
            );
        });
    },
    ...withSource(multilineStorySource.trim()),
};

const disabledStorySource = `
<Field.Root name="city" disabled>
    <Field.Label>Label</Field.Label>
    <Select.Root items={options} disabled defaultValue={null}>
        <Select.Trigger>
            <Select.Value placeholder="Placeholder" />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value ?? "placeholder"} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * A disabled Select whose trigger is non-interactive. The trigger exposes
 * `data-disabled` for styling. Pass `disabled` to `Select.Root` or to the
 * wrapping `Field.Root` to disable the entire field including its label.
 */
export const Disabled: Story = {
    render: () => <BaseUISelectPreview disabled defaultValue={null} testId="select-disabled" />,
    play: async ({canvas, step}) => {
        await step("Trigger exposes disabled data attribute", async () => {
            const trigger = await canvas.findByTestId("select-disabled-trigger");
            await expect(trigger).toHaveAttribute("data-disabled");
        });

        await step("Click does not open the popup", async () => {
            const trigger = await canvas.findByTestId("select-disabled-trigger");
            await userEvent.click(trigger);
            await waitFor(() => {
                const list = screen.queryByTestId("select-disabled-list");
                if (list) expect(list).not.toBeVisible();
            });
        });
    },
    ...withSource(disabledStorySource.trim()),
};

const errorStorySource = `
<Form errors={{city: "Please pick a valid city"}}>
    <Field.Root name="city" invalid>
        <Field.Label>Label</Field.Label>
        <Select.Root items={options} defaultValue={null}>
            <Select.Trigger>
                <Select.Value placeholder="Placeholder" />
                <Select.Icon />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List>
                            {options.map((option) => (
                                <Select.Item key={option.value ?? "placeholder"} value={option.value}>
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    <Select.ItemIndicator />
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>
        <Field.Error />
    </Field.Root>
</Form>
`;

/**
 * An invalid Select integrated with Base UI `Form` and `Field`. The trigger
 * exposes `data-invalid` and `Field.Error` renders the validation message below it.
 * Pass `errors` to `Form` with the field name as the key to surface server-side errors.
 */
export const Error: Story = {
    render: () => (
        <BaseUISelectPreview errorMessage="Please pick a valid city" defaultValue={null} testId="select-error" />
    ),
    play: async ({canvas, step}) => {
        await step("Trigger is marked invalid", async () => {
            const trigger = await canvas.findByTestId("select-error-trigger");
            await expect(trigger).toHaveAttribute("data-invalid");
        });

        await step("Error message is visible", async () => {
            const error = await canvas.findByText("Please pick a valid city");
            await expect(error).toBeVisible();
        });
    },
    ...withSource(errorStorySource.trim()),
};

const readonlyStorySource = `
<Field.Root name="city">
    <Field.Label>Label</Field.Label>
    <Select.Root items={options} readOnly defaultValue="3">
        <Select.Trigger>
            <Select.Value placeholder="Placeholder" />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * A readonly single-select. The trigger is a focusable button that cannot open
 * the popup. The chevron icon is hidden and the selected value is displayed as
 * plain text. The field participates in form submission but cannot be changed by the user.
 */
export const Readonly: Story = {
    render: () => (
        <div className="flex flex-col gap-8">
            <BaseUISelectPreview
                label="Readonly (value selected)"
                readOnly
                defaultValue={cityItems[2].value}
                testId="select-readonly-single"
            />
            <BaseUISelectPreview
                label="Readonly (no value)"
                readOnly
                defaultValue={null}
                testId="select-readonly-single-empty"
            />
        </div>
    ),
    play: async ({canvas, step}) => {
        await step("Readonly trigger has data-readonly attribute", async () => {
            const trigger = await canvas.findByTestId("select-readonly-single-trigger");
            await expect(trigger).toHaveAttribute("data-readonly");
        });

        await step("Click does not open popup", async () => {
            const trigger = await canvas.findByTestId("select-readonly-single-trigger");
            await userEvent.click(trigger);
            await waitFor(() => {
                const list = screen.queryByTestId("select-readonly-single-list");
                if (list) expect(list).not.toBeVisible();
            });
        });
    },
    ...withSource(readonlyStorySource.trim()),
};

const readonlyMultipleStorySource = `
<Field.Root>
    <Field.Label>Label</Field.Label>
    <Select.Root multiple items={options} readOnly defaultValue={options.map((o) => o.value)}>
        <Select.Trigger>
            <Select.Value placeholder="Select cities..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * Readonly multi-select with all 8 cities selected. The trigger height stays stable
 * (same as the interactive trigger) and the value area scrolls horizontally to reveal
 * all selected labels on a single line. Text is selectable for easy copying.
 */
export const ReadonlyMultiple: Story = {
    render: () => (
        <div className="flex flex-col gap-8">
            <div className="max-w-96">
                <Field.Root>
                    <Field.Label>Readonly multi (all 8 selected — sm)</Field.Label>
                    <Select.Root
                        multiple
                        items={cityItems}
                        size="sm"
                        readOnly
                        defaultValue={cityItems.map((c) => c.value)}
                    >
                        <Select.Trigger data-testid="readonly-multi-sm-trigger">
                            <Select.Value data-testid="readonly-multi-sm-value" />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List>
                                        {cityItems.map((option) => (
                                            <Select.Item key={option.value} value={option.value}>
                                                <Select.ItemText>{option.label}</Select.ItemText>
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
            </div>

            <div className="max-w-96">
                <Field.Root>
                    <Field.Label>Readonly multi (all 8 selected — md)</Field.Label>
                    <Select.Root multiple items={cityItems} readOnly defaultValue={cityItems.map((c) => c.value)}>
                        <Select.Trigger data-testid="readonly-multi-md-trigger">
                            <Select.Value data-testid="readonly-multi-md-value" />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List>
                                        {cityItems.map((option) => (
                                            <Select.Item key={option.value} value={option.value}>
                                                <Select.ItemText>{option.label}</Select.ItemText>
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
            </div>

            <div className="max-w-96">
                <Field.Root>
                    <Field.Label>Readonly multi (all 8 selected — lg)</Field.Label>
                    <Select.Root
                        multiple
                        items={cityItems}
                        size="lg"
                        readOnly
                        defaultValue={cityItems.map((c) => c.value)}
                    >
                        <Select.Trigger data-testid="readonly-multi-lg-trigger">
                            <Select.Value data-testid="readonly-multi-lg-value" />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List>
                                        {cityItems.map((option) => (
                                            <Select.Item key={option.value} value={option.value}>
                                                <Select.ItemText>{option.label}</Select.ItemText>
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
            </div>
        </div>
    ),
    play: async ({canvas, step}) => {
        await step("All 8 labels are present in the md value element", async () => {
            const value = await canvas.findByTestId("readonly-multi-md-value");
            for (const city of cityItems) {
                await expect(value).toHaveTextContent(city.label);
            }
        });

        await step("Value span has whitespace-nowrap and overflow-x-auto classes (horizontal scroll)", async () => {
            const value = await canvas.findByTestId("readonly-multi-md-value");
            await expect(value).toHaveClass("whitespace-nowrap");
            await expect(value).toHaveClass("overflow-x-auto");
        });

        await step("Value span has select-text class (text is selectable)", async () => {
            const value = await canvas.findByTestId("readonly-multi-md-value");
            await expect(value).toHaveClass("select-text");
        });

        await step("Click does not open popup", async () => {
            const trigger = await canvas.findByTestId("readonly-multi-md-trigger");
            await userEvent.click(trigger);
            await waitFor(() => {
                const list = screen.queryByRole("listbox");
                if (list) expect(list).not.toBeVisible();
            });
        });
    },
    ...withSource(readonlyMultipleStorySource.trim()),
};

const readonlyMultipleFewValuesStorySource = `
<Field.Root>
    <Field.Label>Label</Field.Label>
    <Select.Root multiple items={options} readOnly defaultValue={["1", "3"]}>
        <Select.Trigger>
            <Select.Value placeholder="Select cities..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * Readonly multi-select with only 2–3 items selected. Demonstrates that the trigger
 * height is stable even when the value fits on a single line.
 */
export const ReadonlyMultipleFewValues: Story = {
    render: () => (
        <div className="max-w-96">
            <Field.Root>
                <Field.Label>Readonly multi (2 selected)</Field.Label>
                <Select.Root
                    multiple
                    items={cityItems}
                    readOnly
                    defaultValue={[cityItems[0].value, cityItems[2].value]}
                >
                    <Select.Trigger data-testid="readonly-multi-few-trigger">
                        <Select.Value data-testid="readonly-multi-few-value" />
                        <Select.Icon />
                    </Select.Trigger>
                    <Select.Portal>
                        <Select.Positioner>
                            <Select.Popup>
                                <Select.List>
                                    {cityItems.map((option) => (
                                        <Select.Item key={option.value} value={option.value}>
                                            <Select.ItemText>{option.label}</Select.ItemText>
                                            <Select.ItemIndicator />
                                        </Select.Item>
                                    ))}
                                </Select.List>
                            </Select.Popup>
                        </Select.Positioner>
                    </Select.Portal>
                </Select.Root>
            </Field.Root>
        </div>
    ),
    play: async ({canvas, step}) => {
        await step("Shows both selected labels", async () => {
            const value = await canvas.findByTestId("readonly-multi-few-value");
            await expect(value).toHaveTextContent("Tallinn");
            await expect(value).toHaveTextContent("Berlin");
        });

        await step("Trigger has data-readonly attribute", async () => {
            const trigger = await canvas.findByTestId("readonly-multi-few-trigger");
            await expect(trigger).toHaveAttribute("data-readonly");
        });
    },
    ...withSource(readonlyMultipleFewValuesStorySource.trim()),
};

const controlledStorySource = `
const [value, setValue] = React.useState<string | null>("1");

<Field.Root name="city">
    <Field.Label>Label</Field.Label>
    <Select.Root items={options} value={value} onValueChange={setValue}>
        <Select.Trigger>
            <Select.Value placeholder="Placeholder" />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value ?? "placeholder"} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * A fully controlled single-select where the parent owns the value state.
 * Pass `value` and `onValueChange` to `Select.Root`. The helper text below
 * re-renders on every selection to confirm the controlled binding works.
 */
export const Controlled: Story = {
    render: () => {
        const [value, setValue] = React.useState<string | null>(cityItems[0].value);
        const selectedLabel = cityItems.find((option) => option.value === value)?.label;
        const helperMessage = selectedLabel
            ? `${selectedLabel} has been picked`
            : "Pick something to see this text change";
        const handleControlledValueChange = React.useCallback(
            (nextValue: string | null) => {
                if (typeof nextValue === "string") {
                    setValue(nextValue);
                }
            },
            [setValue],
        );

        return (
            <div className="flex flex-col gap-2">
                <BaseUISelectPreview
                    value={value}
                    onValueChange={handleControlledValueChange}
                    testId="select-controlled"
                />
                <p className="bolt-font-body-s-regular text-secondary">{helperMessage}</p>
            </div>
        );
    },
    play: async ({canvas, step}) => {
        await step("Initial helper reflects the selected city", async () => {
            const helper = await canvas.findByText(/has been picked/i);
            await expect(helper).toHaveTextContent("Tallinn has been picked");
        });

        await step("Selecting another value updates helper text", async () => {
            const trigger = await canvas.findByTestId("select-controlled-trigger");
            const helper = await canvas.findByText(/has been picked/i);
            await userEvent.click(trigger);
            const list = await screen.findByTestId("select-controlled-list", {}, {timeout: 3000});
            const paris = await within(list).findByText("Paris");
            await userEvent.click(paris);
            await waitFor(
                () => {
                    expect(screen.queryByTestId("select-controlled-list")).not.toBeVisible();
                },
                {timeout: 3000},
            );
            await waitFor(
                () => {
                    expect(helper).toHaveTextContent("Paris has been picked");
                },
                {timeout: 3000},
            );
        });
    },
    ...withSource(controlledStorySource.trim()),
};

const secondaryDescriptionStorySource = `
const options = [
    {label: "Placeholder option", value: null},
    {label: "Tallinn", value: "1", secondary: "Capital of Estonia"},
    {label: "Stockholm", value: "2", secondary: "Capital of Sweden"},
    // ...
];

<Field.Root name="city">
    <Field.Label>Label</Field.Label>
    <Select.Root items={options} defaultValue={null}>
        <Select.Trigger>
            <Select.Value placeholder="Placeholder" />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value ?? "placeholder"} value={option.value}>
                                <div className="flex min-w-0 flex-1 flex-col">
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    {option.secondary && (
                                        <span className="bolt-font-body-s-regular m-0 text-secondary">
                                            {option.secondary}
                                        </span>
                                    )}
                                </div>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * Items with a secondary line of descriptive text below the main label.
 * Compose `Select.ItemText` with an additional `<span>` inside `Select.Item`
 * to add the secondary content — no extra props required on the Select itself.
 */
export const SecondaryDescription: Story = {
    render: () => <BaseUISelectPreview options={optionsWithSecondary} defaultValue={null} testId="select-secondary" />,
    play: async ({canvas, step}) => {
        await step("Descriptions are rendered in the popup", async () => {
            const trigger = await canvas.findByTestId("select-secondary-trigger");
            await userEvent.click(trigger);

            const list = await screen.findByTestId("select-secondary-list", {}, {timeout: 3000});
            const description = await within(list).findByRole("option", {name: /Tallinn/i});
            await expect(description).toBeVisible();

            const tallinn = await within(list).findByText("Tallinn");
            await userEvent.click(tallinn);

            await waitFor(
                () => {
                    expect(screen.queryByTestId("select-secondary-list")).not.toBeVisible();
                },
                {timeout: 3000},
            );
        });

        await step("Selected label is updated", async () => {
            const value = await canvas.findByTestId("select-secondary-value");
            await expect(value).toHaveTextContent("Tallinn");
        });
    },
    ...withSource(secondaryDescriptionStorySource.trim()),
};

const multipleSelectBasicStorySource = `
const [value, setValue] = React.useState<string[]>(["1", "3"]);

<Field.Root>
    <Field.Label>Select cities</Field.Label>
    <Select.Root multiple items={options} value={value} onValueChange={setValue}>
        <Select.Trigger>
            <Select.Value placeholder="Select cities..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * Basic multi-select example with uncontrolled state. Users can select multiple options
 * and the trigger displays all selected labels joined by commas.
 *
 * - Click items to toggle selection
 * - Dropdown stays open after selection
 * - Default check mark indicator for selected items
 */
export const MultipleSelectBasic: Story = {
    render: () => {
        const [value, setValue] = React.useState<string[]>(["1", "3"]);

        return (
            <div className="max-w-96">
                <Field.Root>
                    <Field.Label>Select cities</Field.Label>
                    <Select.Root multiple items={cityItems} value={value} onValueChange={setValue}>
                        <Select.Trigger data-testid="multi-basic-trigger">
                            <Select.Value placeholder="Select cities..." data-testid="multi-basic-value" />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List data-testid="multi-basic-list">
                                        {cityItems.map((option) => (
                                            <Select.Item key={option.value} value={option.value}>
                                                <Select.ItemText>{option.label}</Select.ItemText>
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
                <div className="mt-4 text-sm text-secondary">
                    Selected values: {value.length === 0 ? "none" : value.join(", ")}
                </div>
            </div>
        );
    },
    play: async ({canvas, step}) => {
        await step("Trigger shows first 2 selected items (Tallinn, Berlin)", async () => {
            const value = await canvas.findByTestId("multi-basic-value");
            await expect(value).toHaveTextContent("Tallinn, Berlin");
        });

        await step("Dropdown opens on trigger click", async () => {
            const trigger = await canvas.findByTestId("multi-basic-trigger");
            await userEvent.click(trigger);
            const list = await screen.findByTestId("multi-basic-list", {}, {timeout: 3000});
            await expect(list).toBeVisible();
        });

        await step("Dropdown stays open after selecting an item", async () => {
            const list = await screen.findByTestId("multi-basic-list", {}, {timeout: 3000});
            const warsaw = await within(list).findByText("Warsaw");
            await userEvent.click(warsaw);
            // Dropdown must still be visible after selection
            await expect(list).toBeVisible();
        });

        await step("Value updates to show 3 selections joined by comma", async () => {
            const valueEl = await canvas.findByTestId("multi-basic-value");
            await expect(valueEl).toHaveTextContent("Tallinn, Berlin, Warsaw");
        });

        await step("Escape closes the dropdown", async () => {
            await userEvent.keyboard("{Escape}");
            await waitFor(
                () => {
                    expect(screen.queryByTestId("multi-basic-list")).not.toBeVisible();
                },
                {timeout: 3000},
            );
        });

        await step("Keyboard: Space toggles selection without closing dropdown", async () => {
            const trigger = await canvas.findByTestId("multi-basic-trigger");
            await userEvent.click(trigger);
            const list = await screen.findByTestId("multi-basic-list", {}, {timeout: 3000});
            // Navigate to first item with ArrowDown and toggle with Space
            await userEvent.keyboard("{ArrowDown}");
            await userEvent.keyboard(" ");
            // Dropdown must still be open
            await expect(list).toBeVisible();
            // Close cleanly
            await userEvent.keyboard("{Escape}");
        });
    },
    ...withSource(multipleSelectBasicStorySource.trim()),
};

const multipleSelectManyValuesStorySource = `
const [value, setValue] = React.useState<string[]>(["1", "2", "3", "4", "5"]);

<Field.Root>
    <Field.Label>Select cities (5 selected)</Field.Label>
    <Select.Root multiple items={options} value={value} onValueChange={setValue}>
        <Select.Trigger>
            <Select.Value placeholder="Select cities..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * Demonstrates multi-select behavior when many items are selected.
 * The trigger shows all selected item labels joined by commas.
 */
export const MultipleSelectManyValues: Story = {
    render: () => {
        const [value, setValue] = React.useState<string[]>(["1", "2", "3", "4", "5"]);

        return (
            <div className="max-w-96">
                <Field.Root>
                    <Field.Label>Select cities (5 selected)</Field.Label>
                    <Select.Root multiple items={cityItems} value={value} onValueChange={setValue}>
                        <Select.Trigger>
                            <Select.Value placeholder="Select cities..." />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List>
                                        {cityItems.map((option) => (
                                            <Select.Item key={option.value} value={option.value}>
                                                <Select.ItemText>{option.label}</Select.ItemText>
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
                <div className="mt-4 text-sm text-secondary">Selected: {value.length} cities</div>
            </div>
        );
    },
    ...withSource(multipleSelectManyValuesStorySource.trim()),
};

const multipleSelectControlledStorySource = `
const [value, setValue] = React.useState<string[]>(["2", "5"]);

<Field.Root>
    <Field.Label>Select cities (controlled)</Field.Label>
    <Select.Root multiple items={options} value={value} onValueChange={setValue}>
        <Select.Trigger>
            <Select.Value placeholder="Select cities..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * Fully controlled multi-select where parent owns the selection state. Every value change
 * fires `onValueChange` with the full updated `Value[]` array. This pattern is required
 * when you need to synchronise selections with external state (e.g. form libraries,
 * URL params, or server-driven data).
 *
 * The helper text below the select re-renders on every `onValueChange` call to confirm
 * that the controlled binding works correctly.
 */
export const MultipleSelectControlled: Story = {
    render: () => {
        const [value, setValue] = React.useState<string[]>(["2", "5"]);

        const selectedLabels = cityItems.filter((opt) => value.includes(opt.value)).map((opt) => opt.label);

        return (
            <div className="flex max-w-96 flex-col gap-4">
                <Field.Root>
                    <Field.Label>Select cities (controlled)</Field.Label>
                    <Select.Root
                        multiple
                        items={cityItems}
                        value={value}
                        onValueChange={setValue}
                        data-testid="multi-controlled-trigger"
                    >
                        <Select.Trigger>
                            <Select.Value placeholder="Select cities..." />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List>
                                        {cityItems.map((option) => (
                                            <Select.Item key={option.value} value={option.value}>
                                                <Select.ItemText>{option.label}</Select.ItemText>
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
                <p className="bolt-font-body-s-regular text-secondary">
                    {selectedLabels.length === 0 ? "Nothing selected yet." : `Selected: ${selectedLabels.join(", ")}`}
                </p>
                <div className="flex gap-2">
                    <button
                        type="button"
                        className={`
                          bolt-font-body-s-regular rounded border border-solid border-neutral-primary px-3 py-1
                          text-primary
                          hover:bg-neutral-secondary
                        `}
                        onClick={() => setValue([])}
                    >
                        Clear all
                    </button>
                    <button
                        type="button"
                        className={`
                          bolt-font-body-s-regular rounded border border-solid border-neutral-primary px-3 py-1
                          text-primary
                          hover:bg-neutral-secondary
                        `}
                        onClick={() => setValue(cityItems.map((o) => o.value))}
                    >
                        Select all
                    </button>
                </div>
            </div>
        );
    },
    ...withSource(multipleSelectControlledStorySource.trim()),
};

const multipleSelectWithSecondaryTextStorySource = `
const [value, setValue] = React.useState<string[]>(["1", "3"]);

<Field.Root>
    <Field.Label>Select cities</Field.Label>
    <Select.Root multiple items={options} value={value} onValueChange={setValue}>
        <Select.Trigger>
            <Select.Value placeholder="Select cities..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <div className="flex min-w-0 flex-1 flex-col">
                                    <Select.ItemText>{option.label}</Select.ItemText>
                                    {option.secondary && (
                                        <span className="bolt-font-body-s-regular m-0 text-secondary">
                                            {option.secondary}
                                        </span>
                                    )}
                                </div>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * Multi-select items with secondary description text below the main label.
 * Demonstrates that the secondary text layout works correctly alongside the
 * selection indicator in multi-select mode.
 */
export const MultipleSelectWithSecondaryText: Story = {
    render: () => {
        const [value, setValue] = React.useState<string[]>(["1", "3"]);

        return (
            <div className="max-w-96">
                <Field.Root>
                    <Field.Label>Select cities</Field.Label>
                    <Select.Root multiple items={secondaryItems} value={value} onValueChange={setValue}>
                        <Select.Trigger>
                            <Select.Value placeholder="Select cities..." />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List>
                                        {secondaryItems.map((option) => (
                                            <Select.Item key={option.value} value={option.value}>
                                                <div className="flex min-w-0 flex-1 flex-col">
                                                    <Select.ItemText>{option.label}</Select.ItemText>
                                                    {option.secondary && (
                                                        <span className="bolt-font-body-s-regular m-0 text-secondary">
                                                            {option.secondary}
                                                        </span>
                                                    )}
                                                </div>
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
            </div>
        );
    },
    ...withSource(multipleSelectWithSecondaryTextStorySource.trim()),
};

const multipleSelectDisabledStorySource = `
<Field.Root disabled>
    <Field.Label>Select cities (disabled)</Field.Label>
    <Select.Root multiple items={options} disabled defaultValue={[]}>
        <Select.Trigger>
            <Select.Value placeholder="Select cities..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {options.map((option) => (
                            <Select.Item key={option.value} value={option.value}>
                                <Select.ItemText>{option.label}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

/**
 * Multi-select in disabled state. The trigger is non-interactive and no popup
 * can be opened.
 */
export const MultipleSelectDisabled: Story = {
    render: () => (
        <div className="flex max-w-96 flex-col gap-6">
            <Field.Root disabled>
                <Field.Label>Select cities (disabled, nothing selected)</Field.Label>
                <Select.Root multiple items={cityItems} disabled defaultValue={[]}>
                    <Select.Trigger>
                        <Select.Value placeholder="Select cities..." />
                        <Select.Icon />
                    </Select.Trigger>
                    <Select.Portal>
                        <Select.Positioner>
                            <Select.Popup>
                                <Select.List>
                                    {cityItems.map((option) => (
                                        <Select.Item key={option.value} value={option.value}>
                                            <Select.ItemText>{option.label}</Select.ItemText>
                                            <Select.ItemIndicator />
                                        </Select.Item>
                                    ))}
                                </Select.List>
                            </Select.Popup>
                        </Select.Positioner>
                    </Select.Portal>
                </Select.Root>
            </Field.Root>

            <Field.Root disabled>
                <Field.Label>Select cities (disabled, with pre-selections)</Field.Label>
                <Select.Root multiple items={cityItems} disabled defaultValue={["1", "3", "5"]}>
                    <Select.Trigger>
                        <Select.Value placeholder="Select cities..." />
                        <Select.Icon />
                    </Select.Trigger>
                    <Select.Portal>
                        <Select.Positioner>
                            <Select.Popup>
                                <Select.List>
                                    {cityItems.map((option) => (
                                        <Select.Item key={option.value} value={option.value}>
                                            <Select.ItemText>{option.label}</Select.ItemText>
                                            <Select.ItemIndicator />
                                        </Select.Item>
                                    ))}
                                </Select.List>
                            </Select.Popup>
                        </Select.Positioner>
                    </Select.Portal>
                </Select.Root>
            </Field.Root>
        </div>
    ),
    play: async ({canvas, step}) => {
        await step("Disabled trigger exposes data-disabled attribute", async () => {
            const triggers = await canvas.findAllByRole("combobox");
            for (const trigger of triggers) {
                await expect(trigger).toHaveAttribute("data-disabled");
            }
        });
    },
    ...withSource(multipleSelectDisabledStorySource.trim()),
};

const multipleSelectWithCheckboxesStorySource = `
const [value, setValue] = React.useState<string[]>(["1", "3"]);

return (
    <div className="max-w-96">
        <Field.Root>
            <Field.Label>Select cities</Field.Label>
            <Select.Root multiple items={options} value={value} onValueChange={setValue}>
                <Select.Trigger>
                    <Select.Value placeholder="Select cities..." />
                    <Select.Icon />
                </Select.Trigger>
                <Select.Portal>
                    <Select.Positioner>
                        <Select.Popup>
                            <Select.List>
                                {options.map((option) => (
                                    <Select.Item key={option.value} value={option.value}>
                                        <Select.CheckboxIndicator />
                                        <Select.ItemText>{option.label}</Select.ItemText>
                                    </Select.Item>
                                ))}
                            </Select.List>
                        </Select.Popup>
                    </Select.Positioner>
                </Select.Portal>
            </Select.Root>
        </Field.Root>
    </div>
);
`;

/**
 * Multi-select with checkbox-styled indicators instead of check marks.
 * This provides clearer visual affordance that multiple selections are possible.
 *
 * **Design Decision:** The default multi-select uses check marks (consistent with Combobox).
 * Checkboxes are available via the `<Select.CheckboxIndicator>` render prop for consumers who want
 * clearer multi-select affordance.
 */
export const MultipleSelectWithCheckboxes: Story = {
    render: () => {
        const [value, setValue] = React.useState<string[]>(["1", "3"]);

        return (
            <div className="max-w-96">
                <Field.Root>
                    <Field.Label>Select cities</Field.Label>
                    <Select.Root multiple items={cityItems} value={value} onValueChange={setValue}>
                        <Select.Trigger>
                            <Select.Value placeholder="Select cities..." />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List>
                                        {cityItems.map((option) => (
                                            <Select.Item key={option.value} value={option.value}>
                                                <Select.CheckboxIndicator />
                                                <Select.ItemText>{option.label}</Select.ItemText>
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
            </div>
        );
    },
    ...withSource(multipleSelectWithCheckboxesStorySource.trim()),
};

// ---------------------------------------------------------------------------
// Semantic prop stories — object-valued Select with itemToStringLabel,
// itemToStringValue, and isItemEqualToValue
// ---------------------------------------------------------------------------

/**
 * Object-valued city fixture. Intentionally does NOT have a top-level `label`
 * property so Base UI's automatic fallback does not apply — requiring
 * `itemToStringLabel` for display resolution.
 */
type City = {id: number; code: string; name: string};

const cityObjectItems: City[] = [
    {id: 1, code: "TLL", name: "Tallinn"},
    {id: 2, code: "ARN", name: "Stockholm"},
    {id: 3, code: "BER", name: "Berlin"},
    {id: 4, code: "WAW", name: "Warsaw"},
    {id: 5, code: "CDG", name: "Paris"},
];

/** Converts a City value to its human-readable name for display in the trigger. */
const cityItemToStringLabel = (value: City) => value.name;

/** Converts a City value to its IATA code for form submission. */
const cityItemToStringValue = (value: City) => value.code;

/** Matches cities by numeric id — not by object reference. */
const cityIsItemEqualToValue = (item: City, value: City) => item.id === value.id;

function SemanticSelectShell({children, testId}: {children: React.ReactNode; testId?: string}) {
    return (
        <div className="max-w-96" data-testid={testId}>
            <Field.Root>
                <Field.Label>Select a city</Field.Label>
                {children}
            </Field.Root>
        </div>
    );
}

function CityItemList() {
    return (
        <>
            {cityObjectItems.map((city) => (
                <Select.Item key={city.id} value={city}>
                    <Select.ItemText>{city.name}</Select.ItemText>
                    <Select.ItemIndicator />
                </Select.Item>
            ))}
        </>
    );
}

/**
 * Demonstrates `itemToStringLabel` with object-valued Select items.
 *
 * **When to use:** When your item values are plain objects that do **not** have a
 * top-level `label` property (e.g. `{ id, name, code }`). Without `itemToStringLabel`,
 * Base UI cannot resolve a display string and the trigger shows `[object Object]`.
 *
 * Pass `itemToStringLabel={(city) => city.name}` so both Base UI's native
 * `Select.Value` rendering and the custom value model adapter use the same
 * conversion function.
 */
const objectValuesWithItemToStringLabelStorySource = `
type City = {id: number; code: string; name: string};

const cities: City[] = [
    {id: 1, code: "TLL", name: "Tallinn"},
    {id: 2, code: "ARN", name: "Stockholm"},
    {id: 3, code: "BER", name: "Berlin"},
    {id: 4, code: "WAW", name: "Warsaw"},
    {id: 5, code: "CDG", name: "Paris"},
];

const [value, setValue] = React.useState<City | null>(null);

<Field.Root>
    <Field.Label>Select a city</Field.Label>
    <Select.Root
        value={value}
        onValueChange={setValue}
        itemToStringLabel={(city) => city.name}
    >
        <Select.Trigger>
            <Select.Value placeholder="Select a city..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {cities.map((city) => (
                            <Select.Item key={city.id} value={city}>
                                <Select.ItemText>{city.name}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

export const ObjectValuesWithItemToStringLabel: Story = {
    render: () => {
        const [value, setValue] = React.useState<City | null>(null);

        return (
            <SemanticSelectShell testId="semantic-label">
                <Select.Root value={value} onValueChange={setValue} itemToStringLabel={cityItemToStringLabel}>
                    <Select.Trigger data-testid="semantic-label-trigger">
                        <Select.Value placeholder="Select a city..." data-testid="semantic-label-value" />
                        <Select.Icon />
                    </Select.Trigger>
                    <Select.Portal>
                        <Select.Positioner>
                            <Select.Popup>
                                <Select.List data-testid="semantic-label-list">
                                    <CityItemList />
                                </Select.List>
                            </Select.Popup>
                        </Select.Positioner>
                    </Select.Portal>
                </Select.Root>
            </SemanticSelectShell>
        );
    },
    parameters: {
        docs: {
            source: {code: objectValuesWithItemToStringLabelStorySource.trim()},
            description: {
                story:
                    "Use `itemToStringLabel` when item values are objects without a `.label` property. " +
                    "The function converts the object to a display string for the trigger.",
            },
        },
    },
    play: async ({canvas, step}) => {
        await step("Placeholder shows initially", async () => {
            const value = await canvas.findByTestId("semantic-label-value");
            await expect(value).toHaveTextContent("Select a city...");
        });

        await step("Opening and selecting Berlin", async () => {
            const trigger = await canvas.findByTestId("semantic-label-trigger");
            await userEvent.click(trigger);
            const list = await screen.findByTestId("semantic-label-list", {}, {timeout: 3000});
            const berlin = await within(list).findByText("Berlin");
            await userEvent.click(berlin);
            await waitFor(() => expect(screen.queryByTestId("semantic-label-list")).not.toBeVisible(), {timeout: 3000});
        });

        await step("Trigger shows label from itemToStringLabel (city name)", async () => {
            const value = await canvas.findByTestId("semantic-label-value");
            await expect(value).toHaveTextContent("Berlin");
        });

        await step("Trigger does not show [object Object]", async () => {
            const value = await canvas.findByTestId("semantic-label-value");
            await expect(value).not.toHaveTextContent("[object Object]");
        });
    },
};

/**
 * Demonstrates `isItemEqualToValue` with a controlled Select whose externally
 * provided `value` object is **not reference-equal** to any item in the list.
 *
 * **When to use:** When you receive value objects from an API or Redux store that
 * are freshly constructed on every render. Without `isItemEqualToValue`, `Object.is`
 * comparison fails (different references) so no item appears selected. Pass
 * `isItemEqualToValue={(item, val) => item.id === val.id}` to match by identity field.
 *
 * Click **"Reassign value"** to simulate receiving a new object reference with the
 * same logical identity — the correct item must remain selected.
 */
const controlledWithIsItemEqualToValueStorySource = `
type City = {id: number; code: string; name: string};

const cities: City[] = [
    {id: 1, code: "TLL", name: "Tallinn"},
    {id: 2, code: "ARN", name: "Stockholm"},
    {id: 3, code: "BER", name: "Berlin"},
    {id: 4, code: "WAW", name: "Warsaw"},
    {id: 5, code: "CDG", name: "Paris"},
];

// Value may be a freshly-constructed object — not reference-equal to items.
const [value, setValue] = React.useState<City | null>(cities[0]);

<Field.Root>
    <Field.Label>Select a city</Field.Label>
    <Select.Root
        value={value}
        onValueChange={setValue}
        itemToStringLabel={(city) => city.name}
        isItemEqualToValue={(item, val) => item.id === val.id}
    >
        <Select.Trigger>
            <Select.Value placeholder="Select a city..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {cities.map((city) => (
                            <Select.Item key={city.id} value={city}>
                                <Select.ItemText>{city.name}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

export const ControlledWithIsItemEqualToValue: Story = {
    render: () => {
        // Start with a reference to the actual item object
        const [value, setValue] = React.useState<City | null>(cityObjectItems[0]);

        const handleReassign = React.useCallback(() => {
            // Simulate receiving a freshly-constructed object from an API (not reference-equal)
            setValue({id: 1, code: "TLL", name: "Tallinn"});
        }, []);

        return (
            <div className="flex max-w-96 flex-col gap-4">
                <SemanticSelectShell testId="semantic-eq">
                    <Select.Root
                        value={value}
                        onValueChange={setValue}
                        itemToStringLabel={cityItemToStringLabel}
                        isItemEqualToValue={cityIsItemEqualToValue}
                    >
                        <Select.Trigger data-testid="semantic-eq-trigger">
                            <Select.Value placeholder="Select a city..." data-testid="semantic-eq-value" />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List data-testid="semantic-eq-list">
                                        <CityItemList />
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </SemanticSelectShell>

                <button
                    type="button"
                    data-testid="semantic-eq-reassign"
                    className={`
                      bolt-font-body-s-regular w-fit rounded border border-solid border-neutral-primary px-3 py-1
                      text-primary
                      hover:bg-neutral-secondary
                    `}
                    onClick={handleReassign}
                >
                    Reassign value (new object reference, same id)
                </button>
                <p className="bolt-font-body-s-regular text-secondary">
                    After clicking, Tallinn must remain selected despite the new object reference.
                </p>
            </div>
        );
    },
    parameters: {
        docs: {
            source: {code: controlledWithIsItemEqualToValueStorySource.trim()},
            description: {
                story:
                    "Use `isItemEqualToValue` when value objects are not stable references " +
                    "(e.g. reconstructed from API responses). The comparator matches by identity field " +
                    "instead of `Object.is`, keeping the correct item highlighted.",
            },
        },
    },
    play: async ({canvas, step}) => {
        await step("Initial value shows Tallinn", async () => {
            const value = await canvas.findByTestId("semantic-eq-value");
            await expect(value).toHaveTextContent("Tallinn");
        });

        await step("Clicking Reassign creates a new object reference", async () => {
            const btn = await canvas.findByTestId("semantic-eq-reassign");
            await userEvent.click(btn);
        });

        await step("Trigger still shows Tallinn after non-reference-equal reassign", async () => {
            const value = await canvas.findByTestId("semantic-eq-value");
            await expect(value).toHaveTextContent("Tallinn");
        });

        await step("Opening dropdown — Tallinn item is marked selected", async () => {
            const trigger = await canvas.findByTestId("semantic-eq-trigger");
            await userEvent.click(trigger);
            const list = await screen.findByTestId("semantic-eq-list", {}, {timeout: 3000});
            const tallinnOption = await within(list).findByRole("option", {name: /Tallinn/i});
            await expect(tallinnOption).toHaveAttribute("aria-selected", "true");
            await userEvent.keyboard("{Escape}");
        });

        await step("Trigger label is not a raw object serialization", async () => {
            const value = await canvas.findByTestId("semantic-eq-value");
            await expect(value).not.toHaveTextContent("[object Object]");
        });
    },
};

/**
 * Demonstrates multi-select with object-valued items where `itemToStringLabel`
 * and `isItemEqualToValue` are provided.
 *
 * The trigger display uses `itemToStringLabel` to resolve each selected object's
 * display label and shows all selected labels joined by commas.
 */
const multiSelectObjectValuesStorySource = `
type City = {id: number; code: string; name: string};

const cities: City[] = [
    {id: 1, code: "TLL", name: "Tallinn"},
    {id: 2, code: "ARN", name: "Stockholm"},
    {id: 3, code: "BER", name: "Berlin"},
    {id: 4, code: "WAW", name: "Warsaw"},
    {id: 5, code: "CDG", name: "Paris"},
];

const [value, setValue] = React.useState<City[]>([cities[0], cities[2]]);

<Field.Root>
    <Field.Label>Select cities</Field.Label>
    <Select.Root
        multiple
        value={value}
        onValueChange={setValue}
        itemToStringLabel={(city) => city.name}
        isItemEqualToValue={(item, val) => item.id === val.id}
    >
        <Select.Trigger>
            <Select.Value placeholder="Select cities..." />
            <Select.Icon />
        </Select.Trigger>
        <Select.Portal>
            <Select.Positioner>
                <Select.Popup>
                    <Select.List>
                        {cities.map((city) => (
                            <Select.Item key={city.id} value={city}>
                                <Select.ItemText>{city.name}</Select.ItemText>
                                <Select.ItemIndicator />
                            </Select.Item>
                        ))}
                    </Select.List>
                </Select.Popup>
            </Select.Positioner>
        </Select.Portal>
    </Select.Root>
</Field.Root>
`;

export const MultiSelectObjectValues: Story = {
    render: () => {
        const [value, setValue] = React.useState<City[]>([cityObjectItems[0], cityObjectItems[2]]);

        return (
            <div className="flex max-w-96 flex-col gap-4">
                <Field.Root>
                    <Field.Label>Select cities</Field.Label>
                    <Select.Root
                        multiple
                        value={value}
                        onValueChange={setValue}
                        itemToStringLabel={cityItemToStringLabel}
                        isItemEqualToValue={cityIsItemEqualToValue}
                    >
                        <Select.Trigger data-testid="semantic-multi-trigger">
                            <Select.Value placeholder="Select cities..." data-testid="semantic-multi-value" />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List data-testid="semantic-multi-list">
                                        {cityObjectItems.map((city) => (
                                            <Select.Item key={city.id} value={city}>
                                                <Select.ItemText>{city.name}</Select.ItemText>
                                                <Select.ItemIndicator />
                                            </Select.Item>
                                        ))}
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
                <p className="bolt-font-body-s-regular text-secondary">
                    Selected: {value.map((c) => c.name).join(", ") || "none"}
                </p>
            </div>
        );
    },
    parameters: {
        docs: {
            source: {code: multiSelectObjectValuesStorySource.trim()},
            description: {
                story:
                    "Multi-select with object values. `itemToStringLabel` drives the trigger " +
                    "display (all selected labels joined by commas). `isItemEqualToValue` ensures " +
                    "items are correctly matched even when value references change.",
            },
        },
    },
    play: async ({canvas, step}) => {
        await step("Trigger shows first two selected cities (Tallinn, Berlin)", async () => {
            const value = await canvas.findByTestId("semantic-multi-value");
            await expect(value).toHaveTextContent("Tallinn, Berlin");
        });

        await step("Opening dropdown and selecting a third city (Warsaw)", async () => {
            const trigger = await canvas.findByTestId("semantic-multi-trigger");
            await userEvent.click(trigger);
            const list = await screen.findByTestId("semantic-multi-list", {}, {timeout: 3000});
            const warsaw = await within(list).findByText("Warsaw");
            await userEvent.click(warsaw);
            await expect(list).toBeVisible();
            await userEvent.keyboard("{Escape}");
            await waitFor(() => expect(screen.queryByTestId("semantic-multi-list")).not.toBeVisible(), {timeout: 3000});
        });

        await step("Collapsed text uses itemToStringLabel: Tallinn, Berlin, Warsaw", async () => {
            const value = await canvas.findByTestId("semantic-multi-value");
            await expect(value).toHaveTextContent("Tallinn, Berlin, Warsaw");
        });

        await step("Trigger does not contain [object Object]", async () => {
            const value = await canvas.findByTestId("semantic-multi-value");
            await expect(value).not.toHaveTextContent("[object Object]");
        });
    },
};

/**
 * Demonstrates a Select configured with all three Base UI semantic props together:
 *
 * | Prop | Purpose |
 * |------|---------|
 * | `itemToStringLabel` | Display string in trigger and collapsed multi-select text |
 * | `itemToStringValue` | Stable string written to the hidden `<input>` for form submission |
 * | `isItemEqualToValue` | Object identity comparison (replaces `Object.is`) |
 *
 * **This is the recommended pattern for object-valued Selects.** Providing all three
 * props ensures display, form submission, and selection state all behave correctly.
 */
const allSemanticPropsStorySource = `
type City = {id: number; code: string; name: string};

const cities: City[] = [
    {id: 1, code: "TLL", name: "Tallinn"},
    {id: 2, code: "ARN", name: "Stockholm"},
    {id: 3, code: "BER", name: "Berlin"},
    {id: 4, code: "WAW", name: "Warsaw"},
    {id: 5, code: "CDG", name: "Paris"},
];

const [value, setValue] = React.useState<City | null>(null);

<Form>
    <Field.Root name="city">
        <Field.Label>Select a city</Field.Label>
        <Select.Root
            value={value}
            onValueChange={setValue}
            name="city"
            itemToStringLabel={(city) => city.name}
            itemToStringValue={(city) => city.code}
            isItemEqualToValue={(item, val) => item.id === val.id}
        >
            <Select.Trigger>
                <Select.Value placeholder="Select a city..." />
                <Select.Icon />
            </Select.Trigger>
            <Select.Portal>
                <Select.Positioner>
                    <Select.Popup>
                        <Select.List>
                            {cities.map((city) => (
                                <Select.Item key={city.id} value={city}>
                                    <Select.ItemText>{city.name}</Select.ItemText>
                                    <Select.ItemIndicator />
                                </Select.Item>
                            ))}
                        </Select.List>
                    </Select.Popup>
                </Select.Positioner>
            </Select.Portal>
        </Select.Root>
    </Field.Root>
</Form>
`;

export const AllSemanticProps: Story = {
    render: () => {
        const [value, setValue] = React.useState<City | null>(null);

        return (
            <div className="flex max-w-96 flex-col gap-4">
                <Field.Root name="city">
                    <Field.Label>Select a city</Field.Label>
                    <Select.Root
                        value={value}
                        onValueChange={setValue}
                        name="city"
                        itemToStringLabel={cityItemToStringLabel}
                        itemToStringValue={cityItemToStringValue}
                        isItemEqualToValue={cityIsItemEqualToValue}
                    >
                        <Select.Trigger data-testid="semantic-all-trigger">
                            <Select.Value placeholder="Select a city..." data-testid="semantic-all-value" />
                            <Select.Icon />
                        </Select.Trigger>
                        <Select.Portal>
                            <Select.Positioner>
                                <Select.Popup>
                                    <Select.List data-testid="semantic-all-list">
                                        <CityItemList />
                                    </Select.List>
                                </Select.Popup>
                            </Select.Positioner>
                        </Select.Portal>
                    </Select.Root>
                </Field.Root>
                {value && (
                    <p className="bolt-font-body-s-regular text-secondary">
                        Display label: <strong>{cityItemToStringLabel(value)}</strong> — Form value:{" "}
                        <strong>{cityItemToStringValue(value)}</strong>
                    </p>
                )}
            </div>
        );
    },
    parameters: {
        docs: {
            source: {code: allSemanticPropsStorySource.trim()},
            description: {
                story:
                    "Full configuration with all three semantic props. " +
                    "`itemToStringLabel` drives display, `itemToStringValue` drives form submission " +
                    "(the hidden input), and `isItemEqualToValue` handles object identity matching.",
            },
        },
    },
    play: async ({canvas, step}) => {
        await step("Opening dropdown and selecting Paris", async () => {
            const trigger = await canvas.findByTestId("semantic-all-trigger");
            await userEvent.click(trigger);
            const list = await screen.findByTestId("semantic-all-list", {}, {timeout: 3000});
            const paris = await within(list).findByText("Paris");
            await userEvent.click(paris);
            await waitFor(() => expect(screen.queryByTestId("semantic-all-list")).not.toBeVisible(), {timeout: 3000});
        });

        await step("Trigger shows label from itemToStringLabel (Paris)", async () => {
            const value = await canvas.findByTestId("semantic-all-value");
            await expect(value).toHaveTextContent("Paris");
        });

        await step("Trigger does not show [object Object]", async () => {
            const value = await canvas.findByTestId("semantic-all-value");
            await expect(value).not.toHaveTextContent("[object Object]");
        });

        await step("Hidden input value reflects itemToStringValue (IATA code CDG)", async () => {
            const hiddenInput = await canvas.findByDisplayValue("CDG");
            await expect(hiddenInput).toBeInTheDocument();
        });
    },
};
