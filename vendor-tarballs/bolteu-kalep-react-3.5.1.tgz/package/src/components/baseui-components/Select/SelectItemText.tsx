import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Select.ItemText
 * Primary text label inside a `Select.Item`. Its content is also mirrored into
 * `Select.Value` when the item is selected, so it should contain the
 * human-readable display string for the option.
 */
export const SelectItemText = React.forwardRef(function SelectItemText(
    props: BaseUISelect.ItemText.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getSelectItemTextClassNames = React.useCallback(
        (state: BaseUISelect.ItemText.State) =>
            cx("bolt-font-body-m-regular m-0 min-w-0 flex-1 text-primary", addConsumerClasses(state, className)),
        [className],
    );

    return <BaseUISelect.ItemText {...rest} ref={forwardedRef} className={getSelectItemTextClassNames} />;
});
