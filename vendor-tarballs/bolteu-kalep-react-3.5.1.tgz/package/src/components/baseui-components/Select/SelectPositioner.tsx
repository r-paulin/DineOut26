import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Select.Positioner
 * Floating positioner that anchors the popup relative to the trigger. Defaults
 * to a 5 px side offset with item-alignment disabled so the popup aligns to the
 * trigger edge rather than the selected item.
 */
export const SelectPositioner = React.forwardRef(function SelectPositioner(
    props: BaseUISelect.Positioner.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getSelectPositionerClassNames = React.useCallback(
        (state: BaseUISelect.Positioner.State) =>
            cx("max-h-80 w-max rounded-md shadow-md", addConsumerClasses(state, className)),
        [className],
    );
    return (
        <BaseUISelect.Positioner
            alignItemWithTrigger={false}
            sideOffset={5}
            {...rest}
            ref={forwardedRef}
            className={getSelectPositionerClassNames}
        />
    );
});
