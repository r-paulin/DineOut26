import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import {SelectContextProvider} from "./context/SelectContextProvider";

interface SelectRootCustomProps {
    size?: "sm" | "md" | "lg";
    multiline?: boolean;
}

/**
 * ### Select.Root
 * Root provider for the Select compound component. Accepts all Base UI `Select.Root` props
 * plus two custom props: `size` (`"sm" | "md" | "lg"`, default `"md"`) controls trigger
 * height and typography, and `multiline` (default `false`) allows the selected value to wrap
 * across multiple lines.
 *
 * ```tsx
 * <Select.Root>
 *   <Select.Trigger>
 *     <Select.Value placeholder="Pick an option" />
 *     <Select.Icon />
 *   </Select.Trigger>
 *   <Select.Portal>
 *     <Select.Positioner>
 *       <Select.Popup>
 *         <Select.List>
 *           <Select.Item value="a">
 *             <Select.ItemText>Option A</Select.ItemText>
 *             <Select.ItemIndicator />
 *           </Select.Item>
 *         </Select.List>
 *       </Select.Popup>
 *     </Select.Positioner>
 *   </Select.Portal>
 * </Select.Root>
 * ```
 */
export function SelectRoot<Value, Multiple extends boolean | undefined = false>(
    props: BaseUISelect.Root.Props<Value, Multiple> & SelectRootCustomProps,
): React.JSX.Element {
    const {size = "md", multiline = false, disabled, readOnly = false, multiple, ...rest} = props;

    return (
        <BaseUISelect.Root disabled={disabled} readOnly={readOnly} multiple={multiple} {...rest}>
            <SelectContextProvider
                customSelectProps={{size, multiline, multiple: multiple === true}}
                selectOwnProps={{disabled, readOnly}}
            >
                {props.children}
            </SelectContextProvider>
        </BaseUISelect.Root>
    );
}
