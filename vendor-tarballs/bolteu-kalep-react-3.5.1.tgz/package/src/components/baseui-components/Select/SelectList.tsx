import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Select.List
 * Scrollable list that wraps all `Select.Item` elements inside the popup.
 * Handles overflow scrolling and collapses its vertical padding when empty.
 */
export const SelectList = React.forwardRef(function SelectList(
    props: BaseUISelect.List.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getSelectListClassNames = React.useCallback(
        (state: BaseUISelect.List.State) =>
            cx(
                `
                  m-0 max-h-80 cursor-pointer list-none overflow-y-auto overscroll-none px-0 py-1
                  empty:py-0
                `,
                addConsumerClasses(state, className),
            ),
        [className],
    );
    return <BaseUISelect.List {...rest} className={getSelectListClassNames} ref={forwardedRef} />;
});
