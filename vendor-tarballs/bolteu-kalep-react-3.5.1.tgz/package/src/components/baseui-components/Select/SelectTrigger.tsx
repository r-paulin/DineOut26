import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import {useSelectContextSelector} from "@/components/baseui-components/Select/context/useSelectContext";
import type {Size} from "@/components/baseui-components/Select/select.types";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

const CLASSNAME_TW_TRIGGER_BASE = `
  group/trigger flex w-full items-center rounded-md border-2 border-solid bg-neutral-secondary text-left outline-none
`;

const CLASSNAME_TW_TRIGGER_SIZE: Record<Size, string> = {
    sm: "bolt-font-body-s-regular min-h-9 gap-2 py-1 pl-3 pr-2",
    md: "bolt-font-body-m-regular min-h-12 gap-2 py-2 pl-3 pr-2",
    lg: "bolt-font-body-m-regular min-h-14 gap-2 py-3 pl-3 pr-2",
} as const;

type VisualState = "disabled" | "idle" | "error" | "open" | "readonly";
const CLASSNAME_TW_TRIGGER_STATE: Record<VisualState, string> = {
    idle: `
      border-special-nulled
      focus:border-action-primary
    `,
    error: "border-danger-primary",
    disabled: "cursor-not-allowed border-neutral-secondary bg-special-nulled text-tertiary placeholder-tertiary",
    open: "border-action-primary bg-special-nulled",
    readonly: "cursor-default border-neutral-secondary bg-neutral-secondary",
};

/**
 * ### Select.Trigger
 * The button that opens and closes the select dropdown. Applies size-aware height,
 * padding, and typography, and renders focus, open, error, disabled, and readonly
 * visual states automatically.
 *
 * In readonly mode the trigger renders as a non-interactive `<div>` with no chevron,
 * and multi-select values are displayed on a single line.
 */
export const SelectTrigger = React.forwardRef(function SelectTrigger(
    props: BaseUISelect.Trigger.Props,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const size = useSelectContextSelector((ctx) => ctx.customSelectProps.size);

    const {className, children, render, ...rest} = props;

    const getSelectTriggerClassNames = React.useCallback(
        (state: BaseUISelect.Trigger.State) => {
            const invalid = state.valid === false;

            if (state.readOnly) {
                return cx(
                    CLASSNAME_TW_TRIGGER_BASE,
                    CLASSNAME_TW_TRIGGER_STATE.readonly,
                    CLASSNAME_TW_TRIGGER_SIZE[size],
                    addConsumerClasses(state, className),
                );
            }

            return cx(
                CLASSNAME_TW_TRIGGER_BASE,
                `
                  cursor-pointer justify-end overflow-hidden duration-100 ease-linear
                  focus-within:bg-special-nulled
                `,
                {
                    [CLASSNAME_TW_TRIGGER_STATE.disabled]: state.disabled,
                    [CLASSNAME_TW_TRIGGER_STATE.idle]: !state.disabled && !invalid,
                    [CLASSNAME_TW_TRIGGER_STATE.open]: state.open,
                    [CLASSNAME_TW_TRIGGER_STATE.error]: invalid,
                },
                CLASSNAME_TW_TRIGGER_SIZE[size],
                addConsumerClasses(state, className),
            );
        },
        [className, size],
    );

    return (
        <BaseUISelect.Trigger {...rest} className={getSelectTriggerClassNames} ref={forwardedRef} render={render}>
            {children}
        </BaseUISelect.Trigger>
    );
});
