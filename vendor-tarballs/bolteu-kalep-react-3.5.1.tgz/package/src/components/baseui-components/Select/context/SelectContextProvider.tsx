import * as React from "react";

import type {Select as BaseUISelect} from "@base-ui/react/select";

import type {Size} from "@/components/baseui-components/Select/select.types";

export interface SelectContextType {
    customSelectProps: {
        size: Size;
        multiline: boolean;
        multiple: boolean;
    };
    selectOwnProps: Pick<BaseUISelect.Root.Props<unknown, boolean>, "disabled" | "readOnly">;
}

export const SelectContext = React.createContext<SelectContextType | null>(null);

interface SelectProviderProps extends SelectContextType {
    children: React.ReactNode;
}
export function SelectContextProvider({children, customSelectProps, selectOwnProps}: SelectProviderProps) {
    const contextValue: SelectContextType = React.useMemo(
        () => ({customSelectProps, selectOwnProps}),
        [customSelectProps, selectOwnProps],
    );

    return <SelectContext.Provider value={contextValue}>{children}</SelectContext.Provider>;
}
