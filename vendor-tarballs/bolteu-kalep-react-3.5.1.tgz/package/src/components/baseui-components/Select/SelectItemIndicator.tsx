import * as React from "react";

import {Select as BaseUISelect} from "@base-ui/react/select";

import Check from "@bolteu/kalep-react-icons/dist/Check";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Select.ItemIndicator
 * Renders a `Check` icon inside a `Select.Item` when that item is selected,
 * styled in the positive-primary color.
 */
export const SelectItemIndicator = React.forwardRef(function SelectItemIndicator(
    props: BaseUISelect.ItemIndicator.Props,
    forwardedRef: React.ForwardedRef<HTMLSpanElement>,
) {
    const {render, className, ...rest} = props;

    const getSelectItemIndicatorClassNames = React.useCallback(
        (state: BaseUISelect.ItemIndicator.State) =>
            cx("flex-shrink-0 text-action-secondary", addConsumerClasses(state, className)),
        [className],
    );

    const renderDefault = React.useCallback((props: BaseUISelect.ItemIndicator.Props) => {
        // ref is not forwarded to the Kalep icons
        const {ref: _ref, ...rest} = props;

        return <Check aria-hidden="true" size="md" {...rest} />;
    }, []);

    return (
        <BaseUISelect.ItemIndicator
            {...rest}
            ref={forwardedRef}
            render={render ?? renderDefault}
            className={getSelectItemIndicatorClassNames}
        />
    );
});
