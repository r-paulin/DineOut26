import * as React from "react";

import type {Input} from "@base-ui/react";
import {mergeProps, useRender} from "@base-ui/react";

import {useInput} from "@/components/baseui-components/Input/context/useInput";
import type {Indexable} from "@/components/baseui-components/types/common-types";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

type InputControlState = Indexable<Input.State>;
export interface InputControlProps extends Omit<useRender.ComponentProps<"input", InputControlState>, "className"> {
    className?: string | ((state: InputControlState) => string);
}

export const InputControl = React.forwardRef(
    (props: InputControlProps, forwardedRef: React.ForwardedRef<HTMLInputElement>) => {
        const {render, className, ...otherProps} = props;
        const context = useInput();

        const {inputProps, inputState} = context;
        const {
            ref: refFromContext,
            className: _ctxCn, // Removing props from parent, that will not be passed to the input element
            ...ctxProps
        } = inputProps;

        const inputControlState: InputControlState = {...inputState};

        const defaultProps: useRender.ElementProps<"input"> = {
            className: cx(
                `
                  m-0 h-full w-full min-w-0 flex-grow border-0 border-solid bg-transparent p-0 text-size-inherit
                  outline-none
                  [color:inherit]
                  input-clear-button:hidden
                `,
                inputControlState.disabled ? "cursor-not-allowed placeholder-tertiary" : "placeholder-secondary",
                addConsumerClasses(inputControlState, className),
            ),
            ...ctxProps,
        };
        return useRender({
            defaultTagName: "input",
            render,
            ref: refFromContext ? [refFromContext, forwardedRef] : forwardedRef,
            state: inputControlState,
            props: mergeProps<"input">(defaultProps, otherProps),
        });
    },
);

InputControl.displayName = "Input.Control";
