import {InputControl} from "@/components/baseui-components/Input/Control/InputControl";
import {InputComponent} from "@/components/baseui-components/Input/Input";
import {InputSlot} from "@/components/baseui-components/Input/Slot/InputSlot";

export {useInput} from "./context/useInput";

export const Input = Object.assign(InputComponent, {
    Slot: InputSlot,
    Control: InputControl,
});
