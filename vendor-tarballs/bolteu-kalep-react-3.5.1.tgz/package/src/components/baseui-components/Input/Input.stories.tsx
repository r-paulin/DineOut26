import * as React from "react";

import {expect, fn, userEvent, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Spinner} from "@/components/baseui-components/Spinner";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Input} from "./index";

const meta = {
    component: Input,
    subcomponents: {"Input.Control": Input.Control, "Input.Slot": Input.Slot},
    title: "BaseUI Playground/Input",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A primitive Input component",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Input>;

export default meta;

type Story = StoryObj<typeof meta>;
export const Default: Story = {
    args: {
        placeholder: "Enter text",
        onValueChange: fn(),
        onChange: fn(),
    },
    play: async ({canvasElement, step, args}) => {
        const canvas = within(canvasElement);
        const input = await canvas.findByRole("textbox");
        await step("Input is rendered", async () => {
            await expect(input).toBeInTheDocument();
        });
        await step("Input displays a correct placeholder", async () => {
            await expect(input).toHaveAttribute("placeholder", args.placeholder);
        });
        await step("Type into input", async () => {
            await userEvent.clear(input);
            await userEvent.type(input, "Hello");
            await expect(input).toHaveValue("Hello");
        });
    },
};

export const WithStringBasedClassName: Story = {
    args: {
        className: "shadow-lg",
        placeholder: "Input with custom class",
    },
    play: async ({canvasElement, step, args}) => {
        const canvas = within(canvasElement);
        const input = await canvas.findByRole("textbox");
        const wrapper = input.closest('[role="presentation"]') as HTMLElement;

        await step("Wrapper has custom class", async () => {
            if (typeof args.className === "string") {
                await expect(wrapper).toHaveClass(args.className);
            }
        });
    },
};

export const Disabled: Story = {
    args: {
        placeholder: "I'm a disabled field",
        disabled: true,
    },
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const input = await canvas.findByRole("textbox");

        await step("Input is disabled", async () => {
            await expect(input).toBeDisabled();
        });

        await step("Typing has no effect", async () => {
            await userEvent.type(input, "Should not type");
            await expect(input).toHaveValue("");
        });
    },
};

export const ElementSlots: Story = {
    args: {
        disabled: true,
        placeholder: "Element Slots",
        children: [<Input.Control />, <Input.Slot render={<Spinner />} />],
    },
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const input = await canvas.findByRole("textbox");
        const spinner = await canvas.findByRole("status");

        await step("Spinner is rendered in slot", async () => {
            await expect(spinner).toBeInTheDocument();
        });

        await step("Spinner appears after input", async () => {
            const relation = spinner.compareDocumentPosition(input);
            await expect(relation).toBe(Node.DOCUMENT_POSITION_PRECEDING);
        });

        await step("Clicking spinner does not focus disabled input", async () => {
            await userEvent.click(spinner);
            await expect(input).not.toHaveFocus();
            await expect(input).toBeDisabled();
        });
    },
};

export const StringSlots: Story = {
    args: {
        placeholder: "example",
        children: [<Input.Slot>www.</Input.Slot>, <Input.Control />, <Input.Slot>.com</Input.Slot>],
        onValueChange: fn(),
        onChange: fn(),
    },
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const input = await canvas.findByRole("textbox");
        const prefix = canvas.getByText("www.");
        const suffix = canvas.getByText(".com");

        await step("Prefix and suffix are visible", async () => {
            await expect(prefix).toBeInTheDocument();
            await expect(suffix).toBeInTheDocument();
        });

        await step("Prefix is before input; suffix after", async () => {
            const relPrefix = prefix.compareDocumentPosition(input);
            const relSuffix = suffix.compareDocumentPosition(input);
            await expect(relPrefix).toBe(Node.DOCUMENT_POSITION_FOLLOWING);
            await expect(relSuffix).toBe(Node.DOCUMENT_POSITION_PRECEDING);
        });

        await step("Clicking slots focuses input", async () => {
            await userEvent.click(prefix);
            await expect(input).toHaveFocus();
            await userEvent.keyboard("{Tab}"); // Move focus away
            await expect(input).not.toHaveFocus();
            await userEvent.click(suffix);
            await expect(input).toHaveFocus();
        });

        await step("Typing updates only the input value", async () => {
            await userEvent.clear(input);
            await userEvent.type(input, "example");
            await expect(input).toHaveValue("example");
            await expect(prefix).toHaveTextContent("www.");
            await expect(suffix).toHaveTextContent(".com");
        });
    },
};
