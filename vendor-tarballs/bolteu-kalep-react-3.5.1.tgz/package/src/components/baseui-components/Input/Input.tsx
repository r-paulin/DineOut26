import type {HTMLProps} from "react";
import * as React from "react";

import {Input as BaseUIInput, useRender} from "@base-ui/react";
import type {BaseUIEvent} from "@base-ui/react/utils/types";

import Alert from "@bolteu/kalep-react-icons/dist/Alert";

import {InputProvider} from "@/components/baseui-components/Input/context/InputProvider";
import {InputControl} from "@/components/baseui-components/Input/Control/InputControl";
import {InputSlot} from "@/components/baseui-components/Input/Slot/InputSlot";
import type {FieldSize, Indexable, PropsWithFieldSize} from "@/components/baseui-components/types/common-types";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";

const sizes: Record<FieldSize, string> = {
    sm: "h-9 px-2 text-sm gap-2",
    md: "h-12 px-3 text-base gap-3",
    lg: "h-14 px-4 text-base gap-3",
};

export type State = "disabled" | "idle" | "error";

const states: Record<State, string> = {
    idle: "border-special-nulled focus-within:!border-action-primary text-primary",
    disabled: "border-neutral-secondary cursor-not-allowed text-tertiary bg-special-nulled",
    error: "border-danger-primary text-primary caret-danger-primary",
};

export type InputState = Indexable<BaseUIInput.State>;

function InputInner(
    props: PropsWithFieldSize<BaseUIInput.Props> & {state: InputState} & {
        consumerRef?: React.ForwardedRef<HTMLInputElement>;
    },
) {
    const {state, render, children, fieldSize, onClick, className, consumerRef, ...otherProps} = props;
    const invalid = state.valid === false;
    const internalInputRef = React.useRef<HTMLInputElement | null>(null);
    const element = useRender({
        defaultTagName: "div",
        render,
        state,
        props: {
            className,
            onClick(ev: BaseUIEvent<React.MouseEvent<HTMLInputElement>>) {
                if (!props.disabled) {
                    if (internalInputRef?.current && document.activeElement !== internalInputRef?.current) {
                        internalInputRef.current.focus();
                    }
                    onClick?.(ev);
                }
            },
            role: "presentation",
            children: (
                <>
                    {children || <InputControl />}
                    {invalid ? (
                        <InputSlot
                            data-testid="input-error-icon"
                            aria-hidden="true"
                            className={cx("flex-none text-danger-secondary")}
                            render={<Alert size={fieldSize === "sm" ? "sm" : "lg"} />}
                        />
                    ) : null}
                </>
            ),
        },
    });

    const controlRefWithInternal = mergeRefs([consumerRef, internalInputRef]);
    return (
        <InputProvider inputProps={{...otherProps, ref: controlRefWithInternal}} inputState={state}>
            {element}
        </InputProvider>
    );
}
/**
 * ### Composition guide
 * Regular usage:
 *
 * ```tsx
 * <Input />
 * ```
 *
 * Composed with subcomponents:
 * ```tsx
 * <Input>
 *     <Input.Slot>some string slot</Input.Slot>
 *     <Input.Control />
 *     <Input.Slot render={<SomeIcon />} />
 * </Input>
 * ```
 * A `render` prop is provided for the `Input`, `Input.Slot` and `Input.Control` components to
 * allow custom rendering of the components respectively.
 *
 * See `Field` and `Form` component documentation for better understanding of the field composition in a form.
 */
export const InputComponent = React.forwardRef(function InputWrapper(
    props: PropsWithFieldSize<BaseUIInput.Props>,
    consumerInputRef: React.ForwardedRef<HTMLInputElement>,
) {
    const {fieldSize = "md", render, className, ...rest} = props;

    const generatedId = useId();
    const inputId = props.id ?? `kalep-input-${generatedId}`;

    const inputClassName = React.useCallback(
        function inputClassname(state: BaseUIInput.State) {
            const invalid = state.valid === false;
            return cx(
                "flex w-full items-center justify-end",
                "rounded-md border-2 border-solid",
                "bg-neutral-secondary caret-action-primary",
                "duration-100 ease-linear",
                "focus-within:bg-special-nulled",
                state.disabled ? "cursor-not-allowed" : "cursor-text",
                {
                    [states.disabled]: state.disabled,
                    [states.error]: invalid,
                    [states.idle]: !state.disabled && !invalid,
                },
                sizes[fieldSize],
                addConsumerClasses(state, className),
            );
        },
        [className, fieldSize],
    );

    const defaultRender = React.useCallback(
        function defaultInputRender({ref, ...renderProps}: HTMLProps<HTMLInputElement>, state: BaseUIInput.State) {
            const inputRef = mergeRefs([ref, consumerInputRef]);
            return (
                <InputInner
                    state={state as InputState}
                    fieldSize={fieldSize}
                    consumerRef={inputRef}
                    {...renderProps}
                    render={render}
                />
            );
        },
        [fieldSize, render, consumerInputRef],
    );

    return <BaseUIInput render={defaultRender} className={inputClassName} id={inputId} {...rest} />;
});

InputComponent.displayName = "Input";
