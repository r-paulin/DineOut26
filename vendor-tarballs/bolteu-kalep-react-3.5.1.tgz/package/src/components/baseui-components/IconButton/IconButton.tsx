import * as React from "react";

import {Button as BaseUIButton} from "@base-ui/react";
import type {BaseUIEvent} from "@base-ui/react/utils/types";

import type {KalepIcon, KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

type Size = "sm" | "md" | "lg";
type Shape = "square" | "round";
export type Variant = "primary" | "secondary" | "ghost" | "danger" | "floating" | "inverted" | "floating-inverted";

type WithDefault<T> = {default: string} & T;
interface IconButtonStyles {
    sizes: WithDefault<Record<Size, string>>;
    variants: WithDefault<Record<Variant, string>>;
    shapes: WithDefault<Partial<Record<Shape, string>>>;
    disabled: WithDefault<Partial<Record<Variant, string>>>;
    loading: WithDefault<Partial<Record<Variant, string>>>;
    selected: WithDefault<Partial<Record<Variant, string>>>;
}

const CLASSNAME_TW_INVERTED_VARIANT_STYLES = `
  bg-neutral-primary text-primary-inverted
  hover:bg-active-neutral-primary
`;
const CLASSNAME_TW_FLOATING_DISABLED_STYLES = "cursor-not-allowed text-tertiary shadow-md";
const CLASSNAME_TW_ICON_BUTTON_STYLES: IconButtonStyles = {
    sizes: {
        default: "",
        sm: "h-9 w-9",
        md: "h-12 w-12",
        lg: "h-14 w-14",
    },
    variants: {
        default: "",
        primary: `
          bg-action-primary text-static-key-light
          hover:bg-active-action-primary
        `,
        ghost: `
          bg-transparent text-primary
          hover:bg-active-neutral-secondary
        `,
        secondary: `
          bg-neutral-secondary text-primary
          hover:bg-active-neutral-secondary
        `,
        danger: `
          bg-danger-primary text-static-key-light
          hover:bg-active-danger-primary
        `,
        floating: `
          bg-layer-floor-2 text-primary shadow-md
          hover:shadow
          active:shadow
        `,
        inverted: CLASSNAME_TW_INVERTED_VARIANT_STYLES,
        "floating-inverted": [CLASSNAME_TW_INVERTED_VARIANT_STYLES, "shadow-md"].join(" "),
    },
    shapes: {
        default: "rounded-full",
        square: "rounded-md",
    },
    disabled: {
        default: `
          cursor-not-allowed bg-neutral-secondary text-tertiary
          hover:bg-neutral-secondary
          active:bg-neutral-secondary
        `,
        secondary: `
          cursor-not-allowed bg-transparent text-tertiary
          hover:bg-transparent
          active:bg-transparent
        `,
        ghost: `
          cursor-not-allowed bg-transparent text-tertiary
          hover:bg-transparent
          active:bg-transparent
        `,
        floating: CLASSNAME_TW_FLOATING_DISABLED_STYLES,
        "floating-inverted": CLASSNAME_TW_FLOATING_DISABLED_STYLES,
    },
    loading: {
        default: "cursor-progress bg-active-neutral-secondary text-primary",
    },
    selected: {
        default: "bg-neutral-primary text-primary-inverted",
    },
};

type IconButtonClassesType = keyof IconButtonStyles;
function getIconButtonStyleClasses(type: IconButtonClassesType, key: string): string {
    const typeObj = CLASSNAME_TW_ICON_BUTTON_STYLES[type];
    return typeObj[key as keyof typeof typeObj] || typeObj["default"];
}

function getIconSizeFromButtonSize(size: Size): KalepIcon["size"] {
    if (["md", "lg"].includes(size)) {
        return "lg";
    }
    return size;
}

export type IconButtonProps = Omit<BaseUIButton.Props, "children"> & {
    size?: Size;
    variant?: Variant;
    shape?: Shape;
    icon: KalepIconElement;
    loading?: boolean;
    selected?: boolean;
    children?: never;
};

/**
 * ### Composition guide
 * ```tsx
 * <IconButton
 *     icon={<HeartIcon />}
 * />
 * ```
 */
export const IconButton = React.forwardRef(function IconButton(
    props: IconButtonProps,
    ref: React.ForwardedRef<HTMLButtonElement>,
) {
    const {
        size = "md",
        variant = "secondary",
        shape = "round",
        selected = false,
        onClick,
        className,
        loading = false,
        icon,
        ...rest
    } = props;

    const isLoading = !props.disabled && loading;

    const element = isLoading ? (
        <SpinnerIcon className={cx("animate-spin")} size={getIconSizeFromButtonSize(size)} />
    ) : (
        // Cloning, since it is needed to pass on the size prop to the icon
        React.cloneElement(icon, {size: getIconSizeFromButtonSize(size)})
    );

    const clickHandler = React.useCallback(
        function clickHandler(ev: BaseUIEvent<React.MouseEvent<HTMLButtonElement, MouseEvent>>) {
            if (isLoading) {
                ev.preventDefault();
                ev.stopPropagation();
            } else {
                onClick?.(ev);
            }
        },
        [isLoading, onClick],
    );
    const iconButtonClasses = React.useCallback(
        function iconButtonClasses(state: BaseUIButton.State) {
            return cx(
                "inline-flex items-center justify-center",
                "cursor-pointer border-none bg-special-nulled p-0",
                getIconButtonStyleClasses("sizes", size),
                getIconButtonStyleClasses("shapes", shape),
                {
                    "active:scale-975 active:duration-100 active:ease-in-out": !state.disabled,
                    [getIconButtonStyleClasses("variants", variant)]: !state.disabled,
                    [getIconButtonStyleClasses("disabled", variant)]: state.disabled,
                    [getIconButtonStyleClasses("selected", variant)]: selected,
                    [getIconButtonStyleClasses("loading", variant)]: isLoading,
                },
                addConsumerClasses(state, className),
            );
        },
        [className, isLoading, selected, shape, size, variant],
    );

    return (
        <BaseUIButton className={iconButtonClasses} onClick={clickHandler} {...rest} ref={ref}>
            {element}
        </BaseUIButton>
    );
});
