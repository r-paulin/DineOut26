import * as React from "react";

import type {Meta, StoryContext, StoryObj} from "@storybook/react-webpack5";

import {Alert, Heart, Lock, RideStart} from "@bolteu/kalep-react-icons";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {IconButton, type Variant} from "./index";

const meta = {
    component: IconButton,
    argTypes: {
        icon: {
            options: ["Heart", "Lock", "Alert", "RideStart"],
            mapping: {
                Heart: <Heart />,
                Lock: <Lock />,
                Alert: <Alert />,
                RideStart: <RideStart />,
            },
        },
    },
    title: "BaseUI Playground/IconButton",
    tags: ["experimental", "autodocs", "BaseUI"],
    parameters: {
        docs: {
            subtitle: "A primitive IconButton component",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof IconButton>;

export default meta;

type Story = StoryObj<typeof IconButton>;

export const Default: Story = {
    args: {
        icon: <Heart />,
    },
};

export const RenderAsLink: Story = {
    args: {
        icon: <Heart />,
        render: <a href="https://bolt.eu/" />,
        nativeButton: false,
    },
    parameters: {
        docs: {
            source: {
                transform: (codeBlock: string, {args}: StoryContext) => {
                    return codeBlock.replace("<IconButton", `<IconButton nativeButton={${args.nativeButton}}`);
                },
            },
        },
    },
};

export const Variants: Story = {
    render: (_args) => {
        const variants: Variant[] = [
            "primary",
            "secondary",
            "ghost",
            "danger",
            "floating",
            "inverted",
            "floating-inverted",
        ];
        return (
            <div className="flex gap-4">
                {variants.map((variant) => (
                    <div className="flex" key={variant}>
                        <IconButton icon={<Heart />} variant={variant} />
                    </div>
                ))}
            </div>
        );
    },
};

export const Disabled: Story = {
    render: (_args) => {
        const variants: Variant[] = [
            "primary",
            "secondary",
            "ghost",
            "danger",
            "floating",
            "inverted",
            "floating-inverted",
        ];
        return (
            <div className="flex gap-4">
                {variants.map((variant) => (
                    <div className="flex" key={variant}>
                        <IconButton disabled icon={<Heart />} variant={variant} />
                    </div>
                ))}
            </div>
        );
    },
};
