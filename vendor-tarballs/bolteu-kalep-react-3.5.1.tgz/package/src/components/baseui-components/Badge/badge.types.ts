import type {useRender} from "@base-ui/react";

export type BadgeVariant = "dot" | "s-dot" | "standard";
export type BadgePlacement = "top-right" | "top-left" | "bottom-left" | "bottom-right";
export type BadgePlacementOverlap = "circular" | "rectangular";
export type BadgeAppearance = "action" | "danger" | "neutral" | "promo" | "warning";

export interface BadgeCommonProps extends Omit<useRender.ComponentProps<"span">, "className" | "children"> {
    className?: string | ((state: BadgeState) => string);
    placement?: BadgePlacement;
    /**
     * Defines how the badge is positioned relative to the parent element's shape.
     */
    placementOverlap?: BadgePlacementOverlap;
    appearance?: BadgeAppearance;
    /**
     * If true, adds a stroke/border around the badge for better visibility against various backgrounds.
     */
    stroke?: boolean;
    /**
     * If `true`, the badge is rendered as a standalone element without absolute positioning.
     * If `false`, it is positioned absolutely relative to its parent. The parent needs to have `position: relative` set.
     */
    standalone?: boolean;
}

export interface NumericBadge {
    /**
     * When `maxCount` is set, `badgeContent` exceeding this value will display as a dot.
     * Only usable with numeric `badgeContent`.
     */
    maxCount?: number;
    badgeContent?: number;
}

export interface StringBadge {
    maxCount?: never;
    badgeContent?: string;
}

export type DotVariant = {
    variant: Extract<BadgeVariant, "dot" | "s-dot">;
    badgeContent?: never;
    maxCount?: never;
};

export type StandardVariant = {
    variant?: Extract<BadgeVariant, "standard">;
} & (NumericBadge | StringBadge);

export type BadgeProps = BadgeCommonProps & (DotVariant | StandardVariant);

export type BadgeState = Pick<
    BadgeProps,
    "variant" | "placement" | "stroke" | "placementOverlap" | "badgeContent" | "maxCount" | "standalone" | "appearance"
>;
