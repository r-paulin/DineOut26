import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import type {
    BadgeAppearance,
    BadgePlacement,
    BadgePlacementOverlap,
    BadgeProps,
    BadgeState,
    BadgeVariant,
} from "./badge.types";

const placementStyles: Record<BadgePlacementOverlap, Record<BadgePlacement, string>> = {
    circular: {
        // 14% offset places the badge on the curved edge of content (like in MUI)
        "top-left": "top-[14%] left-[14%] -translate-x-1/2 -translate-y-1/2",
        "top-right": "top-[14%] right-[14%] translate-x-1/2 -translate-y-1/2",
        "bottom-left": "bottom-[14%] left-[14%] -translate-x-1/2 translate-y-1/2",
        "bottom-right": "bottom-[14%] right-[14%] translate-x-1/2 translate-y-1/2",
    },
    rectangular: {
        "top-left": "top-0 left-0 -translate-x-1/2 -translate-y-1/2",
        "top-right": "top-0 right-0 translate-x-1/2 -translate-y-1/2",
        "bottom-left": "bottom-0 left-0 -translate-x-1/2 translate-y-1/2",
        "bottom-right": "bottom-0 right-0 translate-x-1/2 translate-y-1/2",
    },
};

const appearanceStyles: Record<BadgeAppearance, string> = {
    danger: "bg-danger-primary",
    warning: "bg-warning-primary",
    action: "bg-action-primary",
    neutral: "bg-neutral-secondary-hard",
    promo: "bg-promo-primary",
};

const strokeBorders: Record<BadgeVariant, string> = {
    dot: "border-2 py-[2px]",
    "s-dot": "border-1 p-[3px]",
    standard: "border-2 py-[2px]",
};

/**
 * ### Composition guide
 * Standalone usage
 *
 * ```tsx
 *   <Badge badgeContent={8} standalone />
 * ```
 *
 * Usage as a child of another component
 *
 * ```tsx
 * <div className="relative">
 *    <IconButton icon={<Heart />} />
 *    <Badge badgeContent={123} />
 * </div>
 * ```
 */
export const Badge = React.forwardRef(function BadgeIndicator(
    props: BadgeProps,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {
        render,
        className,
        placement = "top-right",
        placementOverlap = "circular",
        stroke = false,
        appearance = "danger",
        variant = "standard",
        badgeContent,
        maxCount,
        standalone = false,
        ...rest
    } = props;

    const state: BadgeState = {
        placement,
        placementOverlap,
        stroke,
        appearance,
        variant,
        badgeContent,
        maxCount,
        standalone,
    };

    const standardBadgeContent = React.useMemo(() => {
        const isLimitReached =
            variant === "standard" &&
            typeof maxCount !== "undefined" &&
            typeof badgeContent === "number" &&
            badgeContent > maxCount;
        return isLimitReached ? (
            <span className={cx("inline-block h-[6px] w-[6px] rounded-full bg-static-key-light")} />
        ) : (
            badgeContent
        );
    }, [badgeContent, maxCount, variant]);

    const defaultProps: useRender.ElementProps<"span"> = {
        className: cx(
            `
              bolt-font-body-xs-accent inline-flex items-center justify-center whitespace-nowrap rounded-full
              bg-danger-primary text-static-key-light
            `,

            appearanceStyles[appearance],
            {
                [placementStyles[placementOverlap][placement]]: !standalone,
                [[strokeBorders[variant], "border-solid"].join(" ")]: stroke,
                ["absolute"]: !standalone,
                ["h-3 w-3"]: variant === "dot" && !stroke,
                ["h-1.5 w-1.5"]: variant === "s-dot" && !stroke,
                ["h-4 w-4"]: variant === "dot" && stroke,
                ["h-1 w-1"]: variant === "s-dot" && stroke,
                ["min-h-5 min-w-5 px-1.5"]: variant === "standard" && !stroke,
                ["min-h-6 min-w-6 px-1.5"]: variant === "standard" && stroke,
            },
            addConsumerClasses(state, className),
        ),
        children: ["dot", "s-dot"].includes(variant) ? undefined : standardBadgeContent,
    };

    return useRender<BadgeState, HTMLSpanElement>({
        defaultTagName: "span",
        render,
        state,
        ref,
        props: mergeProps(defaultProps, rest),
    });
});
