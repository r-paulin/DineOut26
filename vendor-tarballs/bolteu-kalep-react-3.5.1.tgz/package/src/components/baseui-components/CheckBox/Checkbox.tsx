import * as React from "react";

import {Checkbox as BaseUICheckbox} from "@base-ui/react";

import {CheckboxIndicator} from "@/components/baseui-components/CheckBox/Indicator/CheckboxIndicator";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Composition guide
 * Regular usage:
 * ```tsx
 * <Checkbox />
 * ```
 *
 * Composed with indicator:
 * ```tsx
 * <Checkbox>
 *   <Checkbox.Indicator />
 * </Checkbox>
 * ```
 *
 * A `render` prop is provided for the `Checkbox` and `Checkbox.Indicator` components to
 * allow custom rendering of the components respectively.
 *
 * See `Field` and `Form` component documentation for better understanding of the field composition in a form.
 */
export const CheckboxComponent = React.forwardRef(
    (props: BaseUICheckbox.Root.Props, ref: React.ForwardedRef<HTMLSpanElement>) => {
        const {className, children, ...rest} = props;

        const checkboxRootClassname = React.useCallback(
            (state: BaseUICheckbox.Root.State) => {
                const {disabled, valid, indeterminate, checked} = state;
                const invalid = valid === false;
                return cx(
                    "appearance-none rounded-sm p-0",
                    "flex h-full w-full items-center justify-center",
                    "transition-colors duration-150 ease-linear",
                    "rounded-sm border-2 p-0",
                    "flex h-full w-full items-center justify-center",
                    "transition-colors duration-150 ease-linear",
                    {
                        "border-solid border-neutral-primary": !checked && !indeterminate && !invalid,
                        "border-solid border-danger-primary": !checked && !indeterminate && invalid,
                        "border-0 bg-action-primary": (checked || indeterminate) && !invalid,
                        "border-0 bg-danger-primary": (checked || indeterminate) && invalid,
                        "hover:bg-active-action-primary": (checked || indeterminate) && !disabled && !invalid,
                        "hover:bg-active-danger-primary": (checked || indeterminate) && !disabled && invalid,
                        "border-solid bg-special-nulled": !checked && !indeterminate && !disabled,
                        "cursor-default border-0 bg-special-disabled text-tertiary": disabled,
                        "cursor-pointer text-static-key-light": !disabled,
                    },
                    addConsumerClasses(state, className),
                );
            },
            [className],
        );

        return (
            <span className={cx("flex h-6 w-6 p-px")}>
                <BaseUICheckbox.Root ref={ref} {...rest} className={checkboxRootClassname}>
                    {children || <CheckboxIndicator />}
                </BaseUICheckbox.Root>
            </span>
        );
    },
);

CheckboxComponent.displayName = "Checkbox";
