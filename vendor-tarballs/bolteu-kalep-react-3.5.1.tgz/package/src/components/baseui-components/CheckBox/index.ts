import {CheckboxComponent} from "./Checkbox";
import {CheckboxIndicator} from "./Indicator/CheckboxIndicator";

export const Checkbox = Object.assign(CheckboxComponent, {
    Indicator: CheckboxIndicator,
});
