import {Toast as BaseUIToast} from "@base-ui/react/toast";

/**
 * Snackbar.Provider
 *
 * Top-level provider that manages toast queueing, limits, and lifecycle state.
 */
export const SnackbarProvider = BaseUIToast.Provider;
