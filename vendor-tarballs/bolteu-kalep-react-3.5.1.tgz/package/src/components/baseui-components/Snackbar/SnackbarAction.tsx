import * as React from "react";

import {Toast as BaseUIToast} from "@base-ui/react/toast";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Snackbar.Action
 * Optional action button for the snackbar.
 *
 * ```tsx
 * <Snackbar.Action>Undo</Snackbar.Action>
 * ```
 */
export const SnackbarAction = React.forwardRef(function SnackbarAction(
    props: BaseUIToast.Action.Props,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {className, render, ...rest} = props;

    const getActionClassNames = React.useCallback(
        (state: BaseUIToast.Action.State) =>
            cx(
                "text-action-primary-inverted",
                "bolt-font-body-s-accent inline-block cursor-pointer border-0 bg-transparent p-0",
                addConsumerClasses(state, className),
            ),
        [className],
    );

    const renderDefault = React.useCallback((iconProps: HTMLProps<HTMLButtonElement>) => {
        const {children: _children, ...restIconProps} = iconProps;
        return <button {...restIconProps}>{iconProps.children}</button>;
    }, []);

    return (
        <BaseUIToast.Action
            {...rest}
            className={getActionClassNames}
            ref={forwardedRef}
            render={render ?? renderDefault}
        />
    );
});
