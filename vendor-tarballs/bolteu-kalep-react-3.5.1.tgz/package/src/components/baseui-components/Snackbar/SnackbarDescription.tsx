import * as React from "react";

import {Toast as BaseUIToast} from "@base-ui/react/toast";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Snackbar.Description
 * Main text content for a snackbar.
 *
 * ```tsx
 * <Snackbar.Description>Changes saved successfully.</Snackbar.Description>
 * ```
 */
export const SnackbarDescription = React.forwardRef(function SnackbarDescription(
    props: BaseUIToast.Description.Props,
    forwardedRef: React.ForwardedRef<HTMLParagraphElement>,
) {
    const {className, ...rest} = props;

    const getDescriptionClassNames = React.useCallback(
        (state: BaseUIToast.Description.State) => cx("m-0 min-w-0 flex-1", addConsumerClasses(state, className)),
        [className],
    );

    return <BaseUIToast.Description {...rest} className={getDescriptionClassNames} ref={forwardedRef} />;
});
