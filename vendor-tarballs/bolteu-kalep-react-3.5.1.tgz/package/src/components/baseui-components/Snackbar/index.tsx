import {Toast as BaseUIToast} from "@base-ui/react/toast";

import {SnackbarAction} from "./SnackbarAction";
import {SnackbarClose} from "./SnackbarClose";
import {SnackbarContent} from "./SnackbarContent";
import {SnackbarDescription} from "./SnackbarDescription";
import {SnackbarPortal} from "./SnackbarPortal";
import {SnackbarProvider} from "./SnackbarProvider";
import {SnackbarRoot} from "./SnackbarRoot";
import {SnackbarTitle} from "./SnackbarTitle";
import {SnackbarViewport} from "./SnackbarViewport";

export type {SnackbarPlacement} from "./context";
export type {SnackbarViewportProps} from "./SnackbarViewport";

/**
 * Snackbar compound component built on BaseUI Toast primitives.
 *
 * ### Composition guide
 * ```tsx
 * import {Snackbar} from "@bolteu/kalep-react";
 *
 * const {toasts, add, close} = Snackbar.useToastManager();
 *
 * <Snackbar.Provider>
 *   <Button
 *     onClick={() =>
 *       add({title: "Changes saved", description: "Your settings were updated."})
 *     }
 *   >
 *     Show snackbar
 *   </Button>
 *   <Snackbar.Portal>
 *     <Snackbar.Viewport placement="bottom-left">
 *       {toasts.map((toast) => (
 *         <Snackbar.Root key={toast.id} toast={toast}>
 *           <Snackbar.Content>
 *             <div>
 *               <Snackbar.Title />
 *               <Snackbar.Description />
 *             </div>
 *           </Snackbar.Content>
 *           <Snackbar.Close onClick={() => close(toast.id)} />
 *         </Snackbar.Root>
 *       ))}
 *     </Snackbar.Viewport>
 *   </Snackbar.Portal>
 * </Snackbar.Provider>
 * ```
 */
export const Snackbar = {
    Provider: SnackbarProvider,
    Portal: SnackbarPortal,
    Viewport: SnackbarViewport,
    Root: SnackbarRoot,
    Content: SnackbarContent,
    Title: SnackbarTitle,
    Description: SnackbarDescription,
    Action: SnackbarAction,
    Close: SnackbarClose,
    useToastManager: BaseUIToast.useToastManager,
};

Object.assign(Snackbar.Provider, {displayName: "Snackbar.Provider"});
Snackbar.Portal.displayName = "Snackbar.Portal";
SnackbarRoot.displayName = "Snackbar.Root";
SnackbarContent.displayName = "Snackbar.Content";
SnackbarTitle.displayName = "Snackbar.Title";
SnackbarDescription.displayName = "Snackbar.Description";
SnackbarAction.displayName = "Snackbar.Action";
SnackbarClose.displayName = "Snackbar.Close";
SnackbarViewport.displayName = "Snackbar.Viewport";
