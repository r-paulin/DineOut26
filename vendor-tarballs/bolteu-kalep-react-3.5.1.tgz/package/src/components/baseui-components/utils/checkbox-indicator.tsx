import * as React from "react";

import type {HTMLProps} from "@base-ui/react/utils/types";

import Check from "@bolteu/kalep-react-icons/dist/Check";

import {cx} from "@/helpers/utils/cx";

export const CLASSNAME_TW_CHECKBOX_INDICATOR_BASE = `
  relative inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-sm p-px transition-colors duration-150
  ease-linear
`;
const CLASSNAME_TW_CHECKBOX_INDICATOR_SELECTED = "border-0 bg-action-primary";
const CLASSNAME_TW_CHECKBOX_INDICATOR_UNSELECTED = "border-2 border-solid border-neutral-primary bg-special-nulled";

export function getCheckboxIndicatorStateClass(selected: boolean): string {
    return selected ? CLASSNAME_TW_CHECKBOX_INDICATOR_SELECTED : CLASSNAME_TW_CHECKBOX_INDICATOR_UNSELECTED;
}

export function renderCheckboxIndicatorDefault(
    renderProps: HTMLProps<HTMLSpanElement>,
    selected: boolean,
): React.ReactElement {
    return (
        <span {...renderProps}>
            <Check
                size="md"
                className={cx(
                    "pointer-events-none text-static-key-light",
                    "transition-opacity duration-150 ease-linear",
                    selected ? "opacity-100" : "opacity-0",
                )}
                aria-hidden="true"
            />
        </span>
    );
}
