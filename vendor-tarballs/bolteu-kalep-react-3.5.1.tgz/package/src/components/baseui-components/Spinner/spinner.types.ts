export type SpinnerSize = "xs" | "sm" | "md" | "lg" | "xl" | 400 | 500 | 600 | 700 | "inherit";

export const CLASSNAME_TW_SPINNER_SIZE_MAP: Record<SpinnerSize, string> = {
    xs: "h-4 w-4",
    sm: "h-5 w-5",
    md: "h-5 w-5",
    lg: "h-6 w-6",
    xl: "h-9 w-9",
    400: "h-4 w-4",
    500: "h-6 w-6",
    600: "h-9 w-9",
    700: "h-12 w-12",
    inherit: "h-full w-full",
};
