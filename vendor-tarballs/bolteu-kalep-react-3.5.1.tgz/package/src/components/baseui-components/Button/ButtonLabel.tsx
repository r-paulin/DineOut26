import * as React from "react";

import type {Button as BaseUIButton} from "@base-ui/react";
import {mergeProps, useRender} from "@base-ui/react";

import {useButtonContext} from "@/components/baseui-components/Button/context/useButtonContext";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export interface ButtonLabelProps extends Omit<useRender.ComponentProps<"span">, "className"> {
    className?: string | ((state: BaseUIButton.State) => string);
}

/**
 * ### Button.Label
 * Use this for the `Button` content in case you need to include icons.
 *
 * Using the `Button.Label` subcomponent with `Button.Icon` components
 * ensures, that the leading and trailing icons get the correct styles applied
 * ```tsx
 *  <Button>
 *      <Button.Icon icon={<Heart />} />
 *      <Button.Label>Both Icons</Button.Label>
 *      <Button.Icon icon={<Heart />} />
 *  </Button>
 * ```
 */
export const ButtonLabel = React.forwardRef(function ButtonLabel(
    props: ButtonLabelProps,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {render, className, ...rest} = props;

    const {state} = useButtonContext();
    const defaultProps: useRender.ElementProps<"span"> = {
        className: cx(addConsumerClasses(state, className)),
    };
    return useRender({
        defaultTagName: "span",
        ref,
        render,
        state,
        props: mergeProps<"span">(defaultProps, rest),
    });
});
