import * as React from "react";
import {ButtonContext} from "@/components/baseui-components/Button/context/ButtonProvider";

export function useButtonContext() {
    const context = React.useContext(ButtonContext);
    if (!context) {
        throw new Error("useButtonContext must be used within the context");
    }
    return context;
}
