import * as React from "react";

import {Tooltip as BaseUITooltip} from "@base-ui/react/tooltip";
import type {HTMLProps} from "@base-ui/react/utils/types";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

const tooltipArrowPositioning: Record<string, string> = {
    top: "rotate-180 bottom-[-6px]",
    bottom: "top-[-6px]",
    left: "rotate-90 right-[-8px]",
    right: "-rotate-90 left-[-8px]",
};

/**
 * ### Tooltip.Arrow
 * Optional decorative arrow that mirrors the popup background.
 *
 * ```tsx
 * <Tooltip.Popup>
 *   Content
 *   <Tooltip.Arrow />
 * </Tooltip.Popup>
 * ```
 */
export const TooltipArrow = React.forwardRef(function TooltipArrow(
    props: BaseUITooltip.Arrow.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, render, ...rest} = props;

    const getArrowClassNames = React.useCallback(
        (state: BaseUITooltip.Arrow.State) => {
            return cx(
                "[color:var(--color-bg-neutral-primary)]",
                tooltipArrowPositioning[state.side],
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    const defaultRender = React.useCallback((props: HTMLProps<SVGSVGElement>) => {
        return (
            <svg width="12" height="6" viewBox="0 0 12 6" fill="none" xmlns="http://www.w3.org/2000/svg" {...props}>
                <path d="M12 6L6 0L0 6L12 6Z" fill="currentColor" />
            </svg>
        );
    }, []);

    return (
        <BaseUITooltip.Arrow
            {...rest}
            className={getArrowClassNames}
            ref={forwardedRef}
            render={render ?? defaultRender}
        />
    );
});
