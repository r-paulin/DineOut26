import {Tooltip as BaseUITooltip} from "@base-ui/react/tooltip";

/**
 * Tooltip.Portal
 *
 * Portals tooltip overlays to a top-level layer to avoid clipping and stacking issues.
 */
export const TooltipPortal = BaseUITooltip.Portal;
