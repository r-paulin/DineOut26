import {Tooltip as BaseUITooltip} from "@base-ui/react/tooltip";

import {TooltipArrow} from "./TooltipArrow";
import {TooltipPopup} from "./TooltipPopup";
import {TooltipPortal} from "./TooltipPortal";
import {TooltipPositioner} from "./TooltipPositioner";
import {TooltipRoot} from "./TooltipRoot";
import {TooltipTrigger} from "./TooltipTrigger";
import {TooltipViewport} from "./TooltipViewport";

/**
 * Tooltip compound component built on BaseUI primitives.
 *
 * ### Composition guide
 * ```tsx
 * <Tooltip.Root>
 *   <Tooltip.Trigger aria-label="More info">
 *     <Button>Hover me</Button>
 *   </Tooltip.Trigger>
 *   <Tooltip.Portal>
 *     <Tooltip.Positioner side="top" sideOffset={6}>
 *       <Tooltip.Popup>
 *         Tooltip content
 *         <Tooltip.Arrow />
 *       </Tooltip.Popup>
 *     </Tooltip.Positioner>
 *   </Tooltip.Portal>
 * </Tooltip.Root>
 * ```
 */
export const Tooltip = {
    Root: TooltipRoot,
    Trigger: TooltipTrigger,
    Portal: TooltipPortal,
    Positioner: TooltipPositioner,
    Popup: TooltipPopup,
    Arrow: TooltipArrow,
    Viewport: TooltipViewport,
    createHandle: BaseUITooltip.createHandle,
};

Object.assign(TooltipRoot, {
    displayName: "Tooltip.Root",
});
TooltipTrigger.displayName = "Tooltip.Trigger";
Tooltip.Portal.displayName = "Tooltip.Portal";
TooltipPositioner.displayName = "Tooltip.Positioner";
TooltipPopup.displayName = "Tooltip.Popup";
TooltipArrow.displayName = "Tooltip.Arrow";
Tooltip.Viewport.displayName = "Tooltip.Viewport";
