import {Tooltip as BaseUITooltip} from "@base-ui/react/tooltip";

/**
 * Tooltip compound component.
 *
 * Provides the Tooltip subparts:
 * - `Tooltip.Root`: stateful provider that links triggers and popups
 * - `Tooltip.Trigger`: interactive element that opens the tooltip
 * - `Tooltip.Portal`: renders popup content outside normal DOM stacking
 * - `Tooltip.Positioner`: positions the popup relative to the trigger
 * - `Tooltip.Popup`: floating surface for tooltip content
 * - `Tooltip.Arrow`: optional decorative arrow matching the popup background
 *
 * ### Composition guide
 * ```tsx
 * <Tooltip.Root>
 *   <Tooltip.Trigger
 *     aria-label="More info"
 *     render={({ref, ...triggerProps}) => (
 *       <Button {...triggerProps} ref={ref}>
 *         Hover me
 *       </Button>
 *     )}
 *   />
 *   <Tooltip.Portal>
 *     <Tooltip.Positioner side="top" sideOffset={6}>
 *       <Tooltip.Popup>
 *         Tooltip content
 *         <Tooltip.Arrow />
 *       </Tooltip.Popup>
 *     </Tooltip.Positioner>
 *   </Tooltip.Portal>
 * </Tooltip.Root>
 * ```
 */
export const TooltipRoot = BaseUITooltip.Root;
