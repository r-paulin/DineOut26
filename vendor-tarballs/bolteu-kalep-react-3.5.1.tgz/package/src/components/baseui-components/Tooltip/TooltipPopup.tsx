import * as React from "react";

import {Tooltip as BaseUITooltip} from "@base-ui/react/tooltip";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Tooltip.Popup
 * Floating surface that renders the tooltip content.
 *
 * ```tsx
 * <Tooltip.Popup>
 *   Tooltip text
 *   <Tooltip.Arrow />
 * </Tooltip.Popup>
 * ```
 */
export const TooltipPopup = React.forwardRef(function TooltipPopup(
    props: BaseUITooltip.Popup.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getPopupClassNames = React.useCallback(
        (state: BaseUITooltip.Popup.State) =>
            cx(
                `
                  bolt-font-body-s-regular pointer-events-none w-max max-w-[280px] break-words rounded
                  bg-neutral-primary px-3 py-2 text-left text-primary-inverted shadow-md outline-none transition
                  duration-150 ease-out
                `,
                {
                    "translate-x-0 translate-y-0 scale-100 opacity-100": state.open,
                    "scale-95 opacity-0": !state.open,
                },
                addConsumerClasses(state, className),
            ),
        [className],
    );

    return <BaseUITooltip.Popup {...rest} className={getPopupClassNames} ref={forwardedRef} />;
});
