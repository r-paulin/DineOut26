import * as React from "react";

import {Tooltip as BaseUITooltip} from "@base-ui/react/tooltip";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

const DEFAULT_SIDE: BaseUITooltip.Positioner.Props["side"] = "top";
const DEFAULT_SIDE_OFFSET = 6;

/**
 * ### Tooltip.Positioner
 * Handles floating-ui placement around the trigger.
 *
 * ```tsx
 * <Tooltip.Positioner side="bottom">
 *   <Tooltip.Popup>Content</Tooltip.Popup>
 * </Tooltip.Positioner>
 * ```
 */
export const TooltipPositioner = React.forwardRef(function TooltipPositioner(
    props: BaseUITooltip.Positioner.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, side = DEFAULT_SIDE, sideOffset = DEFAULT_SIDE_OFFSET, ...rest} = props;

    const getPositionerClassNames = React.useCallback(
        (state: BaseUITooltip.Positioner.State) =>
            cx("pointer-events-none z-tooltip", addConsumerClasses(state, className)),
        [className],
    );

    return (
        <BaseUITooltip.Positioner
            {...rest}
            side={side}
            sideOffset={sideOffset}
            className={getPositionerClassNames}
            ref={forwardedRef}
        />
    );
});
