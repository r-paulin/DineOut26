import * as React from "react";

import {expect, screen, userEvent, waitFor, within} from "storybook/test";
import type {Tooltip as BaseUITooltip} from "@base-ui/react/tooltip";
import type {HTMLProps} from "@base-ui/react/utils/types";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import Heart from "@bolteu/kalep-react-icons/dist/Heart";

import {Button} from "@/components/baseui-components/Button";
import {Dialog} from "@/components/baseui-components/Dialog";
import {IconButton} from "@/components/baseui-components/IconButton";
import {Typography} from "@/components/baseui-components/Typography";
import {cx} from "@/helpers/utils/cx";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Tooltip} from "./index";

type TooltipPlacement = "top" | "bottom" | "left" | "right" | "start" | "end";

const meta = {
    component: Tooltip as unknown as React.ComponentType<any>,
    subcomponents: {
        "Tooltip.Root": Tooltip.Root,
        "Tooltip.Trigger": Tooltip.Trigger,
        "Tooltip.Portal": Tooltip.Portal,
        "Tooltip.Positioner": Tooltip.Positioner,
        "Tooltip.Popup": Tooltip.Popup,
        "Tooltip.Arrow": Tooltip.Arrow,
    },
    title: "BaseUI Playground/Tooltip",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A BaseUI tooltip wrapper",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Tooltip.Root>;

export default meta;
type Story = StoryObj<typeof Tooltip.Root>;

type TriggerRender = React.ComponentProps<typeof Tooltip.Trigger>["render"];
type TriggerRenderFn = Extract<NonNullable<TriggerRender>, (...args: any[]) => React.ReactElement>;

interface TooltipPlaygroundProps {
    placement: TooltipPlacement;
    delay: number;
    closeDelay: number;
    offset: number;
    content: string;
    renderTrigger: TriggerRender;
    triggerLabel?: string;
}

type PositionerProps = React.ComponentProps<typeof Tooltip.Positioner>;

const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

function TooltipPlayground({
    renderTrigger,
    triggerLabel = "Tooltip trigger",
    placement,
    delay,
    closeDelay,
    offset,
    content,
}: TooltipPlaygroundProps) {
    const sideMap: Record<TooltipPlacement, PositionerProps["side"]> = {
        top: "top",
        bottom: "bottom",
        left: "left",
        right: "right",
        start: "inline-start",
        end: "inline-end",
    };

    const resolvedSide = sideMap[placement] ?? "top";

    return (
        <div className="flex min-h-[220px] items-center justify-center">
            <Tooltip.Root>
                <Tooltip.Trigger
                    render={renderTrigger}
                    aria-label={triggerLabel}
                    delay={delay}
                    closeDelay={closeDelay}
                />
                <Tooltip.Portal>
                    <Tooltip.Positioner side={resolvedSide} sideOffset={offset}>
                        <Tooltip.Popup data-testid="tooltip-popup">
                            {content}
                            <Tooltip.Arrow />
                        </Tooltip.Popup>
                    </Tooltip.Positioner>
                </Tooltip.Portal>
            </Tooltip.Root>
        </div>
    );
}

const defaultTrigger: TriggerRenderFn = (
    triggerProps: HTMLProps<HTMLButtonElement>,
    _state: BaseUITooltip.Trigger.State,
) => {
    const {ref, ...rest} = triggerProps;
    return (
        <Button {...rest} ref={ref}>
            I have tooltip!
        </Button>
    );
};

const defaultSource = `
<Tooltip.Root>
  <Tooltip.Trigger aria-label="Default tooltip">
    <Button>I have tooltip!</Button>
  </Tooltip.Trigger>
  <Tooltip.Portal>
    <Tooltip.Positioner side="top" sideOffset={6}>
      <Tooltip.Popup>
        Additional context for the action.
        <Tooltip.Arrow />
      </Tooltip.Popup>
    </Tooltip.Positioner>
  </Tooltip.Portal>
</Tooltip.Root>
`.trim();

export const Default: Story = {
    ...withSource(defaultSource),
    render: () => (
        <TooltipPlayground
            placement="top"
            delay={25}
            closeDelay={0}
            offset={6}
            content="Additional context for the action."
            renderTrigger={defaultTrigger}
            triggerLabel="Default tooltip"
        />
    ),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const trigger = await canvas.findByRole("button", {name: "Default tooltip"});

        await expect(trigger).toBeInTheDocument();

        await userEvent.hover(trigger);

        await waitFor(
            async () => {
                const tooltip = screen.queryByTestId("tooltip-popup");
                expect(tooltip).toBeInTheDocument();
                expect(tooltip).toHaveTextContent("Additional context for the action.");
            },
            {timeout: 5000, interval: 100},
        );

        await userEvent.unhover(trigger);

        await waitFor(
            () => {
                expect(screen.queryByTestId("tooltip-popup")).not.toBeInTheDocument();
            },
            {timeout: 3000},
        );
    },
};

type TooltipHandlePayload = {message: string};

function ControlledTooltipStory() {
    const [isOpen, setIsOpen] = React.useState(false);
    const tooltipHandle = React.useMemo(() => Tooltip.createHandle<TooltipHandlePayload>(), []);
    const triggerId = React.useId();

    const iconTriggerRender = React.useCallback<TriggerRenderFn>(
        (triggerProps: HTMLProps<HTMLButtonElement>, _state: BaseUITooltip.Trigger.State) => {
            const {ref, className, children: _children, ...rest} = triggerProps;
            return (
                <IconButton {...rest} ref={ref} className={className} icon={<Heart />} aria-label="Info" size="sm" />
            );
        },
        [],
    );

    const openViaButton = React.useCallback(() => {
        tooltipHandle.open(triggerId);
    }, [tooltipHandle, triggerId]);

    const hideViaButton = React.useCallback(() => {
        tooltipHandle.close();
    }, [tooltipHandle]);

    return (
        <div className="flex gap-6 p-4">
            <Tooltip.Root<TooltipHandlePayload>
                handle={tooltipHandle}
                open={isOpen}
                onOpenChange={setIsOpen}
                disableHoverablePopup
            >
                {(data) => (
                    <Tooltip.Portal>
                        <Tooltip.Positioner side="bottom">
                            <Tooltip.Popup data-testid="tooltip-popup">
                                {data.payload?.message ?? "Choose an action"}
                                <Tooltip.Arrow />
                            </Tooltip.Popup>
                        </Tooltip.Positioner>
                    </Tooltip.Portal>
                )}
            </Tooltip.Root>

            <div className="flex items-center gap-3">
                <Tooltip.Trigger
                    id={triggerId}
                    handle={tooltipHandle}
                    payload={{message: "What happens when you click this icon"}}
                    aria-label="Info tooltip"
                    render={iconTriggerRender}
                />
                <Typography className="text-secondary">Inspect the icon or trigger it manually.</Typography>
            </div>

            <div className="flex gap-3">
                <Button onClick={openViaButton}>Show tooltip</Button>
                <Button variant="secondary" onClick={hideViaButton}>
                    Hide tooltip
                </Button>
            </div>
        </div>
    );
}

const controlledSource = `
type TooltipHandlePayload = {message: string};

function ControlledTooltipStory() {
  const [open, setOpen] = React.useState(false);
  const tooltipHandle = React.useMemo(() => Tooltip.createHandle<TooltipHandlePayload>(), []);
  const triggerId = React.useId();

  return (
    <div className="flex flex-col gap-6">
      <Tooltip.Root<TooltipHandlePayload>
        handle={tooltipHandle}
        open={open}
        onOpenChange={setOpen}
        disableHoverablePopup
      >
        {(payload) => (
          <Tooltip.Portal>
            <Tooltip.Positioner side="bottom">
              <Tooltip.Popup data-testid="tooltip-popup">
                {payload?.message ?? "Choose an action"}
                <Tooltip.Arrow />
              </Tooltip.Popup>
            </Tooltip.Positioner>
          </Tooltip.Portal>
        )}
      </Tooltip.Root>

      <div className="flex items-center gap-3">
        <Tooltip.Trigger
          id={triggerId}
          handle={tooltipHandle}
          payload={{message: "What happens when you click this icon"}}
          aria-label="Info tooltip"
          render={({ref, className, ...triggerProps}) => (
            <IconButton
              {...triggerProps}
              ref={ref}
              className={className}
              icon={<Heart />}
              aria-label="Info"
              size="sm"
            />
          )}
        />
        <Typography className="text-secondary">Inspect the icon or trigger it manually.</Typography>
      </div>

      <div className="flex gap-3">
        <Button onClick={() => tooltipHandle.open(triggerId)}>Show tooltip</Button>
        <Button variant="secondary" onClick={() => tooltipHandle.close()}>
          Hide tooltip
        </Button>
      </div>
    </div>
  );
}
`.trim();

export const WithControlledState: Story = {
    ...withSource(controlledSource),
    render: () => <ControlledTooltipStory />,
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const showButton = await canvas.findByRole("button", {name: "Show tooltip"});
        await userEvent.click(showButton);
        const popup = await screen.findByTestId("tooltip-popup", {}, {timeout: 3000});
        await expect(popup).toHaveTextContent("What happens when you click this icon");

        const hideButton = await canvas.findByRole("button", {name: "Hide tooltip"});
        await userEvent.click(hideButton);

        await waitFor(
            () => {
                expect(screen.queryByTestId("tooltip-popup")).not.toBeInTheDocument();
            },
            {timeout: 3000},
        );
    },
};

const iconButtonTrigger: TriggerRenderFn = (triggerProps: HTMLProps<HTMLButtonElement>) => {
    const {ref, className, children: _children, ...rest} = triggerProps;
    return <IconButton {...rest} ref={ref} className={className} icon={<Heart />} />;
};

export const WithIconButton: Story = {
    ...withSource(
        `
<Tooltip.Root>
  <Tooltip.Trigger aria-label="Icon button tooltip" delay={25}>
    <IconButton icon={<Heart />} />
  </Tooltip.Trigger>
  <Tooltip.Portal>
    <Tooltip.Positioner side="right" sideOffset={6}>
      <Tooltip.Popup>
        Additional context for the action.
        <Tooltip.Arrow />
      </Tooltip.Popup>
    </Tooltip.Positioner>
  </Tooltip.Portal>
</Tooltip.Root>
`.trim(),
    ),
    render: () => (
        <TooltipPlayground
            placement="right"
            delay={25}
            closeDelay={0}
            offset={6}
            content="Additional context for the action."
            renderTrigger={iconButtonTrigger}
            triggerLabel="Icon button tooltip"
        />
    ),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const trigger = await canvas.findByRole("button", {name: "Icon button tooltip"});

        await expect(trigger).toBeInTheDocument();

        await userEvent.hover(trigger);

        await waitFor(
            async () => {
                const tooltip = screen.queryByTestId("tooltip-popup");
                expect(tooltip).toBeInTheDocument();
                expect(tooltip).toHaveTextContent("Additional context for the action.");
            },
            {timeout: 5000, interval: 100},
        );
    },
};

const iconViewTrigger: TriggerRenderFn = (
    triggerProps: HTMLProps<HTMLButtonElement>,
    _state: BaseUITooltip.Trigger.State,
) => {
    const {ref, className, children: _children, ...rest} = triggerProps;
    return (
        <IconButton
            size="md"
            {...rest}
            ref={ref}
            className={cx("border-0 bg-transparent p-0", className)}
            aria-label="Icon view trigger"
            icon={<Heart alt="Like" />}
        />
    );
};

export const WithIconView: Story = {
    ...withSource(
        `
<Tooltip.Root>
  <Tooltip.Trigger aria-label="Icon view" delay={25}>
    <IconView className="border-0 bg-transparent p-0" size="md" color="text-action-primary" icon={<Heart />} alt="Like" />
  </Tooltip.Trigger>
  <Tooltip.Portal>
    <Tooltip.Positioner side="top" sideOffset={6}>
      <Tooltip.Popup>
        A tooltip
        <Tooltip.Arrow />
      </Tooltip.Popup>
    </Tooltip.Positioner>
  </Tooltip.Portal>
</Tooltip.Root>
`.trim(),
    ),
    render: () => (
        <TooltipPlayground
            placement="top"
            delay={25}
            closeDelay={0}
            offset={6}
            content="A tooltip"
            renderTrigger={iconViewTrigger}
            triggerLabel="Icon view"
        />
    ),
};

function TooltipInsideDialogStory() {
    const [isOpen, setIsOpen] = React.useState(false);
    const openDialog = React.useCallback(() => setIsOpen(true), []);
    const closeDialog = React.useCallback(() => setIsOpen(false), []);
    const onDialogOpenChange = React.useCallback((nextOpen: boolean) => setIsOpen(nextOpen), []);

    const openTrigger = React.useCallback<TriggerRenderFn>(
        (triggerProps: HTMLProps<HTMLButtonElement>, _state: BaseUITooltip.Trigger.State) => {
            const {ref, onClick, ...rest} = triggerProps;
            const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
                onClick?.(event);
                openDialog();
            };

            return (
                <Button {...rest} ref={ref} variant="secondary" onClick={handleClick}>
                    Open Dialog
                </Button>
            );
        },
        [openDialog],
    );

    const closeTrigger = React.useCallback<TriggerRenderFn>(
        (triggerProps: HTMLProps<HTMLButtonElement>, _state: BaseUITooltip.Trigger.State) => {
            const {ref, onClick, ...rest} = triggerProps;
            const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
                onClick?.(event);
                closeDialog();
            };
            return (
                <Button {...rest} ref={ref} onClick={handleClick}>
                    Alright!
                </Button>
            );
        },
        [closeDialog],
    );

    return (
        <div className="p-4">
            <div style={{height: 1800}}>
                ↓ Scroll down to see the button to open a dialog with a tooltip. This mimics a page with scroll ↓
            </div>
            <Tooltip.Root>
                <Tooltip.Trigger render={openTrigger} aria-label="Open dialog tooltip" />
                <Tooltip.Portal>
                    <Tooltip.Positioner side="top">
                        <Tooltip.Popup>
                            This will open the dialog!
                            <Tooltip.Arrow />
                        </Tooltip.Popup>
                    </Tooltip.Positioner>
                </Tooltip.Portal>
            </Tooltip.Root>
            <Dialog.Root open={isOpen} onOpenChange={onDialogOpenChange}>
                <Dialog.Portal>
                    <Dialog.Backdrop />
                    <Dialog.Popup>
                        <Dialog.Header>
                            <Dialog.Title>Hot Unicorn!</Dialog.Title>
                        </Dialog.Header>
                        <Dialog.Description>
                            <Typography>
                                We’re extremely excited to announce that we were chosen as Europe’s Hottest Unicorn at
                                last week’s Europas awards — the most prestigious awards ceremony in the European
                                startup calendar!
                            </Typography>
                        </Dialog.Description>
                        <Dialog.Footer>
                            <Tooltip.Root>
                                <Tooltip.Trigger render={closeTrigger} aria-label="Close dialog tooltip" />
                                <Tooltip.Portal>
                                    <Tooltip.Positioner side="right">
                                        <Tooltip.Popup>
                                            This will close the dialog!
                                            <Tooltip.Arrow />
                                        </Tooltip.Popup>
                                    </Tooltip.Positioner>
                                </Tooltip.Portal>
                            </Tooltip.Root>
                        </Dialog.Footer>
                    </Dialog.Popup>
                </Dialog.Portal>
            </Dialog.Root>
        </div>
    );
}

const insideDialogSource = `
function TooltipInsideDialogStory() {
  const [open, setOpen] = React.useState(false);

  return (
    <>
      <Tooltip.Root>
        <Tooltip.Trigger aria-label="Open dialog tooltip">
          <Button variant="secondary" onClick={() => setOpen(true)}>
            Open Dialog
          </Button>
        </Tooltip.Trigger>
        <Tooltip.Portal>
          <Tooltip.Positioner side="top" sideOffset={6}>
            <Tooltip.Popup>
              This will open the dialog!
              <Tooltip.Arrow />
            </Tooltip.Popup>
          </Tooltip.Positioner>
        </Tooltip.Portal>
      </Tooltip.Root>

      <Dialog.Root open={open} onOpenChange={setOpen}>
        <Dialog.Portal>
          <Dialog.Backdrop />
          <Dialog.Popup>
            <Dialog.Header>
              <Dialog.Title>Hot Unicorn!</Dialog.Title>
            </Dialog.Header>
            <Dialog.Description>
              <Typography>Dialog content</Typography>
            </Dialog.Description>
            <Dialog.Footer>
            <Tooltip.Root>
              <Tooltip.Trigger aria-label="Close dialog tooltip">
                <Button onClick={() => setOpen(false)}>Alright!</Button>
              </Tooltip.Trigger>
              <Tooltip.Portal>
                <Tooltip.Positioner side="right" sideOffset={6}>
                  <Tooltip.Popup>
                    This will close the dialog!
                    <Tooltip.Arrow />
                  </Tooltip.Popup>
                </Tooltip.Positioner>
              </Tooltip.Portal>
            </Tooltip.Root>
            </Dialog.Footer>
          </Dialog.Popup>
        </Dialog.Portal>
      </Dialog.Root>
    </>
  );
}
`.trim();

export const InsideDialog: Story = {
    ...withSource(insideDialogSource),
    render: () => <TooltipInsideDialogStory />,
};
