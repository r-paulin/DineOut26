import {Tooltip as BaseUITooltip} from "@base-ui/react/tooltip";

/**
 * Tooltip.Viewport
 *
 * Optional viewport container that constrains tooltip overlays within a specific region.
 */
export const TooltipViewport = BaseUITooltip.Viewport;
