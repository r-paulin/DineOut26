import * as React from "react";

import {Tooltip as BaseUITooltip} from "@base-ui/react/tooltip";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

const DEFAULT_DELAY = 25;
const DEFAULT_CLOSE_DELAY = 0;

/**
 * ### Tooltip.Trigger
 * Wraps the interactive element that opens the tooltip.
 *
 * ```tsx
 * <Tooltip.Trigger aria-label="More info">
 *   <Button>Hover me</Button>
 * </Tooltip.Trigger>
 * ```
 */
export const TooltipTrigger = React.forwardRef(function TooltipTrigger<Payload>(
    props: BaseUITooltip.Trigger.Props<Payload>,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {className, delay = DEFAULT_DELAY, closeDelay = DEFAULT_CLOSE_DELAY, ...rest} = props;

    const getTriggerClassNames = React.useCallback(
        (state: BaseUITooltip.Trigger.State) => cx(addConsumerClasses(state, className)),
        [className],
    );

    return (
        <BaseUITooltip.Trigger
            {...rest}
            delay={delay}
            closeDelay={closeDelay}
            className={getTriggerClassNames}
            ref={forwardedRef}
        />
    );
});
