import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

import {useAutocompleteContextSelector} from "@/components/baseui-components/Autocomplete/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Autocomplete.Positioner
 * Anchors `Autocomplete.Popup` relative to the input wrapper or a custom anchor.
 *
 * ```tsx
 * <Autocomplete.Portal>
 *   <Autocomplete.Positioner sideOffset={4}>
 *     <Autocomplete.Popup>…</Autocomplete.Popup>
 *   </Autocomplete.Positioner>
 * </Autocomplete.Portal>
 * ```
 *
 * Override `anchor` to customize placement; otherwise it falls back to the input wrapper.
 */
export const AutocompletePositioner = React.forwardRef(function AutocompletePositioner(
    props: BaseUIAutocomplete.Positioner.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, anchor, ...rest} = props;
    const controlRef = useAutocompleteContextSelector((context) => context.inputWrapperRef);

    const getAutocompletePositionerClassNames = React.useCallback(
        (state: BaseUIAutocomplete.Positioner.State) =>
            cx("max-h-80 w-max rounded-md shadow-md", addConsumerClasses(state, className)),
        [className],
    );

    return (
        <BaseUIAutocomplete.Positioner
            sideOffset={5}
            {...rest}
            ref={forwardedRef}
            anchor={anchor ?? controlRef}
            className={getAutocompletePositionerClassNames}
        />
    );
});
