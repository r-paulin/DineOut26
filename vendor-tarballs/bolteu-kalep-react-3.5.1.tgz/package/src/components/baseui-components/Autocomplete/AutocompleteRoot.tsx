import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

import type {AutocompleteSize} from "@/components/baseui-components/Autocomplete/autocomplete.types";
import {AutocompleteRootContextProvider} from "@/components/baseui-components/Autocomplete/context/AutocompleteRootContextProvider";

interface AutocompleteRootCustomProps {
    /**
     * Size of the autocomplete components.
     *
     * @default md
     */
    size?: AutocompleteSize;
}

/**
 * ### Autocomplete.Root
 * Top-level provider for every other autocomplete primitive. Unlike Combobox, Autocomplete
 * manages a free-form text value (string) — its suggestions only optionally autocomplete
 * the text and no selection state is persisted.
 *
 * ```tsx
 * <Autocomplete.Root items={cities} size="md">
 *   <Autocomplete.Input placeholder="Search city">
 *     <Autocomplete.Control />
 *     <Autocomplete.Controls>
 *       <Autocomplete.Clear />
 *       <Autocomplete.Trigger>
 *         <Autocomplete.Icon />
 *       </Autocomplete.Trigger>
 *     </Autocomplete.Controls>
 *   </Autocomplete.Input>
 *   <Autocomplete.Portal>
 *     <Autocomplete.Positioner sideOffset={4}>
 *       <Autocomplete.Popup>
 *         <Autocomplete.Status>
 *           {statusMessage && <div>{statusMessage}</div>}
 *         </Autocomplete.Status>
 *         <Autocomplete.Empty>No cities found</Autocomplete.Empty>
 *         <Autocomplete.List>
 *           {(item) => (
 *             <Autocomplete.Item key={item.value} value={item}>
 *               <span>{item.label}</span>
 *             </Autocomplete.Item>
 *           )}
 *         </Autocomplete.List>
 *       </Autocomplete.Popup>
 *     </Autocomplete.Positioner>
 *   </Autocomplete.Portal>
 * </Autocomplete.Root>
 * ```
 */

export function AutocompleteRoot<Items>(
    props: BaseUIAutocomplete.Root.Props<Items> & AutocompleteRootCustomProps,
): React.JSX.Element {
    const {size = "md", children, ...rest} = props;

    return (
        <BaseUIAutocomplete.Root {...(rest as BaseUIAutocomplete.Root.Props<unknown>)}>
            <AutocompleteRootContextProvider size={size}>{children}</AutocompleteRootContextProvider>
        </BaseUIAutocomplete.Root>
    );
}
