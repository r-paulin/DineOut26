import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useAutocompleteContextSelector} from "./context";

const CLASSNAME_TW_SIZE_BASE = "min-h-12 py-3";
const CLASSNAME_TW_SIZE_SM = "min-h-9 py-[6px]";

/**
 * ### Autocomplete.Item
 * Single option row rendered inside `Autocomplete.List`.
 *
 * ```tsx
 * <Autocomplete.Item value={option}>
 *   <span>{option.label}</span>
 * </Autocomplete.Item>
 * ```
 */
export const AutocompleteItem = React.forwardRef(function AutocompleteItem(
    props: BaseUIAutocomplete.Item.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, children, ...rest} = props;

    const size = useAutocompleteContextSelector((context) => context.size);

    const getAutocompleteItemClassNames = React.useCallback(
        (state: BaseUIAutocomplete.Item.State) =>
            cx(
                `flex w-full items-center gap-3 px-4 text-left outline-none transition-colors duration-100 ease-linear`,
                size === "sm" ? "bolt-font-body-s-regular" : "bolt-font-body-m-regular",
                size === "sm" ? CLASSNAME_TW_SIZE_SM : CLASSNAME_TW_SIZE_BASE,
                {
                    "cursor-not-allowed text-tertiary": state.disabled,
                    "bg-neutral-secondary": state.highlighted,
                    "text-primary": !state.disabled,
                },
                addConsumerClasses(state, className),
            ),
        [className, size],
    );

    return (
        <BaseUIAutocomplete.Item {...rest} ref={forwardedRef} className={getAutocompleteItemClassNames}>
            {children}
        </BaseUIAutocomplete.Item>
    );
});
