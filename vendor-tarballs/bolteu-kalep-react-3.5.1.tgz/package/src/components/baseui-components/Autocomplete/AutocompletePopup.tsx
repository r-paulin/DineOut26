import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Autocomplete.Popup
 * Surface that houses `Autocomplete.List`, `Autocomplete.Empty`, or custom footers.
 *
 * ```tsx
 * <Autocomplete.Positioner>
 *   <Autocomplete.Popup>
 *     <Autocomplete.Empty>No options found</Autocomplete.Empty>
 *     <Autocomplete.List>…</Autocomplete.List>
 *   </Autocomplete.Popup>
 * </Autocomplete.Positioner>
 * ```
 */
export const AutocompletePopup = React.forwardRef(function AutocompletePopup(
    props: BaseUIAutocomplete.Popup.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getAutocompletePopupClassNames = React.useCallback(
        (state: BaseUIAutocomplete.Popup.State) =>
            cx(
                `
                  max-h-80 min-w-[var(--anchor-width)] max-w-[var(--anchor-width)] overflow-hidden rounded-md
                  bg-layer-floor-3 shadow-md
                `,
                addConsumerClasses(state, className),
            ),
        [className],
    );

    return <BaseUIAutocomplete.Popup {...rest} ref={forwardedRef} className={getAutocompletePopupClassNames} />;
});
