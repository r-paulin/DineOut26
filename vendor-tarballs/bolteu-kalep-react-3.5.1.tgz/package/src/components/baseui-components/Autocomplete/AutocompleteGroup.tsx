import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

/**
 * ### Autocomplete.Group
 *
 * Groups related autocomplete options under a shared label.
 * Renders a `<div>` element.
 */
// WHY wrapper: Base UI shares the same JS object between Autocomplete.Group and
// Combobox.Group (they are `===`). A direct re-export would mean that setting
// `displayName` on our export also mutates Combobox.Group.displayName. Wrapping in
// a dedicated forwardRef creates a unique function identity so displayNames stay isolated.
export const AutocompleteGroup = React.forwardRef(function AutocompleteGroup(
    props: BaseUIAutocomplete.Group.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    return <BaseUIAutocomplete.Group {...props} ref={forwardedRef} />;
});
