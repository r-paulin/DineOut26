import * as React from "react";

import type {AutocompleteSize} from "@/components/baseui-components/Autocomplete/autocomplete.types";

export interface AutocompleteRootContextType {
    size: AutocompleteSize;
    inputWrapperRef: React.MutableRefObject<HTMLDivElement | null>;
}

const AutocompleteRootContext = React.createContext<AutocompleteRootContextType | null>(null);

interface AutocompleteRootContextProviderProps extends Omit<AutocompleteRootContextType, "inputWrapperRef"> {
    children: React.ReactNode;
}

export function AutocompleteRootContextProvider({children, size}: AutocompleteRootContextProviderProps) {
    const inputWrapperRef = React.useRef<HTMLDivElement | null>(null);

    const contextValue: AutocompleteRootContextType = React.useMemo(
        () => ({
            size,
            inputWrapperRef,
        }),
        [size],
    );

    return <AutocompleteRootContext.Provider value={contextValue}>{children}</AutocompleteRootContext.Provider>;
}

export function useAutocompleteRootContext() {
    const context = React.useContext(AutocompleteRootContext);

    if (!context) {
        throw new Error("Autocomplete parts must be rendered within Autocomplete.Root");
    }

    return context;
}

type AutocompleteRootContextReadonly = AutocompleteRootContextType & {
    readonly size: Readonly<AutocompleteRootContextType["size"]>;
    readonly inputWrapperRef: Readonly<AutocompleteRootContextType["inputWrapperRef"]>;
};

export function useAutocompleteContextSelector<T>(selector: (context: AutocompleteRootContextReadonly) => T): T {
    const context = useAutocompleteRootContext();

    return selector(context);
}
