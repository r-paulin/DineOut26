import * as React from "react";

import {useRender} from "@base-ui/react";
import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";
import type {BaseUIEvent, HTMLProps} from "@base-ui/react/utils/types";

import type {AutocompleteSize} from "@/components/baseui-components/Autocomplete/autocomplete.types";
import {useAutocompleteContextSelector} from "@/components/baseui-components/Autocomplete/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";

import type {Indexable} from "../types/common-types";
import {AutocompleteInputContextProvider} from "./context/AutocompleteInputContextProvider";

const CLASSNAME_TW_SIZES: Record<AutocompleteSize, string> = {
    sm: "bolt-font-body-s-regular min-h-9 gap-2 px-3 py-1",
    md: "bolt-font-body-m-regular min-h-12 gap-3 px-3 py-2",
    lg: "bolt-font-body-m-regular min-h-14 gap-3 px-4 py-3",
} as const;

const CLASSNAME_TW_VISUAL_STATE = {
    idle: `
      border-special-nulled text-primary
      focus-within:border-action-primary
    `,
    disabled: "cursor-not-allowed border-neutral-secondary bg-special-nulled text-tertiary placeholder-tertiary",
    readOnly: `
      cursor-default border-special-nulled text-primary
      focus-within:bg-neutral-secondary
    `,
    error: "border-danger-primary",
    open: "border-action-primary bg-special-nulled",
} as const;

type AutocompleteInnerProps = BaseUIAutocomplete.Input.Props & {state: BaseUIAutocomplete.Input.State} & {
    baseUIInternalRef?: React.Ref<HTMLInputElement>;
    wrapperRef?: React.Ref<HTMLDivElement>;
    "data-testid"?: string;
};

const AutocompleteInner = function AutocompleteInner(props: AutocompleteInnerProps) {
    const {
        render,
        state,
        baseUIInternalRef,
        wrapperRef,
        children,
        className,
        onClick,
        onMouseDown,
        "data-testid": dataTestId,
        ...restProps
    } = props;
    const inputRef = React.useRef<HTMLInputElement | null>(null);
    const mergedInputRef = mergeRefs([inputRef, baseUIInternalRef]);
    const inputWrapperRef = useAutocompleteContextSelector((context) => context.inputWrapperRef);

    const autocompleteWrapper = useRender<Indexable<BaseUIAutocomplete.Input.State>, HTMLDivElement>({
        defaultTagName: "div",
        render,
        ref: [inputWrapperRef, wrapperRef ?? null],
        state,
        props: {
            role: "presentation",
            children,
            className,
            onClick: (event: BaseUIEvent<React.MouseEvent<HTMLInputElement>>) => {
                if (state.disabled || state.readOnly) {
                    event.preventDefault();
                    return;
                }
                if (inputRef.current && document.activeElement !== inputRef.current) {
                    inputRef.current.focus();
                }

                onClick?.(event);
            },
            onMouseDown(event: BaseUIEvent<React.MouseEvent<HTMLInputElement>>) {
                onMouseDown?.(event);
            },
            "data-testid": dataTestId,
        },
    });

    return (
        <AutocompleteInputContextProvider
            autocompleteInputProps={restProps}
            autocompleteInputState={state}
            inputRef={mergedInputRef}
        >
            {autocompleteWrapper}
        </AutocompleteInputContextProvider>
    );
};

/**
 * ### Autocomplete.Input
 * Container element for the interactive control. Nest `Autocomplete.Control`
 * and `Autocomplete.Controls` inside it.
 *
 * ```tsx
 * <Autocomplete.Input placeholder="Search city">
 *   <Autocomplete.Control />
 *   <Autocomplete.Controls>
 *     <Autocomplete.Clear />
 *     <Autocomplete.Trigger>
 *       <Autocomplete.Icon />
 *     </Autocomplete.Trigger>
 *   </Autocomplete.Controls>
 * </Autocomplete.Input>
 * ```
 */
export const AutocompleteInput = React.forwardRef(function AutocompleteInput(
    props: BaseUIAutocomplete.Input.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const size = useAutocompleteContextSelector((context) => context.size);

    const {className, placeholder, ...rest} = props;

    const getAutocompleteInputClassNames = React.useCallback(
        (state: BaseUIAutocomplete.Input.State) =>
            cx(
                `
                  group/autocomplete-trigger flex w-full cursor-text items-center justify-between overflow-hidden
                  rounded-md border-2 border-solid bg-neutral-secondary text-left outline-none
                  transition-[color,background-color,border-color] duration-100 ease-linear
                  focus-within:bg-special-nulled
                `,
                CLASSNAME_TW_SIZES[size],
                {
                    [CLASSNAME_TW_VISUAL_STATE.disabled]: state.disabled,
                    [CLASSNAME_TW_VISUAL_STATE.readOnly]: state.readOnly && !state.disabled,
                    [CLASSNAME_TW_VISUAL_STATE.error]: !state.disabled && !state.readOnly && state.valid === false,
                    [CLASSNAME_TW_VISUAL_STATE.idle]: !state.disabled && !state.readOnly && state.valid !== false,
                    [CLASSNAME_TW_VISUAL_STATE.open]: state.open && !state.disabled && !state.readOnly,
                },
                addConsumerClasses(state, className),
            ),
        [className, size],
    );

    const defaultRender = React.useCallback(
        ({ref, ...restProps}: HTMLProps<HTMLInputElement>, state: BaseUIAutocomplete.Input.State) => (
            <AutocompleteInner {...restProps} baseUIInternalRef={ref} wrapperRef={forwardedRef} state={state} />
        ),
        [forwardedRef],
    );

    return (
        <BaseUIAutocomplete.Input
            {...rest}
            placeholder={placeholder}
            render={props.render ?? defaultRender}
            className={getAutocompleteInputClassNames}
        />
    );
});
