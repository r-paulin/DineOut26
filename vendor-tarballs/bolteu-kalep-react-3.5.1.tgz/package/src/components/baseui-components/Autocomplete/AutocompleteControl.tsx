import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";
import type {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

import {useAutocompleteInputContextSelector} from "@/components/baseui-components/Autocomplete/context";
import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import type {Indexable} from "../types/common-types";

/**
 * ### Autocomplete.Control
 * The actual `<input />` element rendered directly inside `Autocomplete.Input`.
 *
 * ```tsx
 * <Autocomplete.Input>
 *   <Autocomplete.Control />
 *   <Autocomplete.Controls> … </Autocomplete.Controls>
 * </Autocomplete.Input>
 * ```
 */
export const AutocompleteControl = React.forwardRef(function AutocompleteControl(
    props: BaseUIAutocomplete.Input.Props,
    forwardedRef: React.ForwardedRef<HTMLInputElement>,
) {
    const {className, render, ...rest} = props;
    const controlState = useAutocompleteInputContextSelector((context) => context.autocompleteInputState);
    const controlProps = useAutocompleteInputContextSelector((context) => context.autocompleteInputProps);
    const inputSavedRef = useAutocompleteInputContextSelector((context) => context.inputRef);

    const ownProps = {
        className: cx(
            `
              m-0 h-full w-full min-w-0 flex-1 flex-grow border-0 border-solid bg-transparent p-0 text-size-inherit
              outline-none
              [color:inherit]
              input-clear-button:hidden
            `,
            controlState.disabled
                ? "cursor-not-allowed placeholder-tertiary"
                : controlState.readOnly
                  ? "cursor-default placeholder-secondary"
                  : "placeholder-secondary",
            addConsumerClasses(controlState, className),
        ),
        type: "text",
    };

    return useRender<Indexable<BaseUIAutocomplete.Input.State>, HTMLInputElement>({
        defaultTagName: "input",
        render,
        ref: [inputSavedRef, forwardedRef],
        state: controlState,
        props: mergeProps(controlProps ?? {}, ownProps, rest),
    });
});
