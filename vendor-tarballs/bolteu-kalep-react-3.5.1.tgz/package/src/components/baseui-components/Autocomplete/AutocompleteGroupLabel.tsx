import * as React from "react";

import {Autocomplete as BaseUIAutocomplete} from "@base-ui/react/autocomplete";

/**
 * Autocomplete.GroupLabel
 *
 * Accessible label for an `Autocomplete.Group` section in the options list.
 */
// WHY wrapper: Base UI shares the same JS object between Autocomplete.GroupLabel and
// Combobox.GroupLabel (they are `===`). A direct re-export like
// `const AutocompleteGroupLabel = BaseUIAutocomplete.GroupLabel` would mean that setting
// `displayName` on our export also mutates Combobox.GroupLabel.displayName. Wrapping in
// a dedicated forwardRef creates a unique function identity so displayNames stay isolated.
export const AutocompleteGroupLabel = React.forwardRef(function AutocompleteGroupLabel(
    props: BaseUIAutocomplete.GroupLabel.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    return <BaseUIAutocomplete.GroupLabel {...props} ref={forwardedRef} />;
});
