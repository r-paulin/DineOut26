import * as React from "react";

import {expect, userEvent, waitFor, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Field} from "@/components/baseui-components/Field";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Autocomplete} from "./index";

const meta = {
    component: Autocomplete as unknown as React.ComponentType<any>,
    subcomponents: {
        "Autocomplete.Root": Autocomplete.Root,
        "Autocomplete.Trigger": Autocomplete.Trigger,
        "Autocomplete.Control": Autocomplete.Control,
        "Autocomplete.Controls": Autocomplete.Controls,
        "Autocomplete.Value": Autocomplete.Value,
        "Autocomplete.Input": Autocomplete.Input,
        "Autocomplete.Portal": Autocomplete.Portal,
        "Autocomplete.Positioner": Autocomplete.Positioner,
        "Autocomplete.Popup": Autocomplete.Popup,
        "Autocomplete.List": Autocomplete.List,
        "Autocomplete.Item": Autocomplete.Item,
        "Autocomplete.Icon": Autocomplete.Icon,
        "Autocomplete.Clear": Autocomplete.Clear,
        "Autocomplete.Status": Autocomplete.Status,
    },
    title: "BaseUI Playground/Autocomplete",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            toc: true,
            page: DocumentationTemplate,
            subtitle: "Anatomy and API for the Base UI Autocomplete",
            controls: {
                exclude: ["items"],
            },
        },
    },
} satisfies Meta<typeof Autocomplete.Root>;

const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

export default meta;

type CityOption = {
    label: string;
    value: string;
    secondary?: string;
    disabled?: boolean;
};

const cityOptions: CityOption[] = [
    {label: "Tallinn", value: "tallinn"},
    {label: "Stockholm", value: "stockholm"},
    {label: "Berlin", value: "berlin"},
    {label: "Warsaw", value: "warsaw"},
    {label: "Paris", value: "paris"},
    {label: "London", value: "london"},
    {label: "Lisbon", value: "lisbon"},
    {label: "Johannesburg", value: "johannesburg"},
];

const cityOptionsWithSecondary: CityOption[] = [
    {label: "Tallinn", value: "tallinn", secondary: "Estonia"},
    {label: "Stockholm", value: "stockholm", secondary: "Sweden"},
    {label: "Berlin", value: "berlin", secondary: "Germany"},
    {label: "Warsaw", value: "warsaw", secondary: "Poland"},
    {label: "Paris", value: "paris", secondary: "France"},
    {label: "London", value: "london", secondary: "United Kingdom"},
    {label: "Lisbon", value: "lisbon", secondary: "Portugal"},
    {label: "Johannesburg", value: "johannesburg", secondary: "South Africa"},
];

const cityOptionsWithDisabled: CityOption[] = [
    ...cityOptions.slice(0, 3),
    {label: "Warsaw", value: "warsaw", disabled: true},
    ...cityOptions.slice(4),
];

type CityGroup = {
    label: string;
    items: CityOption[];
};

const groupedCityOptions: CityGroup[] = [
    {
        label: "Baltics",
        items: [
            {label: "Tallinn", value: "tallinn", secondary: "Estonia"},
            {label: "Riga", value: "riga", secondary: "Latvia"},
            {label: "Vilnius", value: "vilnius", secondary: "Lithuania"},
        ],
    },
    {
        label: "Central Europe",
        items: [
            {label: "Warsaw", value: "warsaw", secondary: "Poland"},
            {label: "Berlin", value: "berlin", secondary: "Germany"},
            {label: "Prague", value: "prague", secondary: "Czechia"},
        ],
    },
    {
        label: "Southern Hemisphere",
        items: [
            {label: "Johannesburg", value: "johannesburg", secondary: "South Africa"},
            {label: "Cape Town", value: "cape-town", secondary: "South Africa"},
        ],
    },
];

interface AutocompletePreviewProps {
    label?: string;
    placeholder?: string;
    options?: CityOption[];
    size?: "sm" | "md" | "lg";
    disabled?: boolean;
    readOnly?: boolean;
    defaultValue?: string;
    value?: string;
    onValueChange?: (value: string, details: any) => void;
    mode?: "list" | "both" | "inline" | "none";
    openOnInputClick?: boolean;
    autoHighlight?: boolean | "always";
    testId?: string;
    clearable?: boolean;
    statusMessage?: string;
}

function AutocompletePreview({
    label = "City",
    placeholder = "Search a city",
    options = cityOptions,
    size = "md",
    disabled,
    readOnly,
    defaultValue,
    value,
    onValueChange,
    mode,
    openOnInputClick,
    autoHighlight,
    testId,
    clearable = true,
    statusMessage,
}: AutocompletePreviewProps) {
    const getElementTestId = React.useCallback((part: string) => (testId ? `${testId}-${part}` : undefined), [testId]);

    const rootProps: Record<string, unknown> = {
        items: options,
        size,
        disabled,
        readOnly,
        mode,
        openOnInputClick,
        autoHighlight,
    };

    if (value !== undefined) {
        rootProps.value = value;
    } else if (defaultValue !== undefined) {
        rootProps.defaultValue = defaultValue;
    }

    if (onValueChange) {
        rootProps.onValueChange = onValueChange;
    }

    return (
        <div className="w-96">
            <Field.Root name={`autocomplete-${label}`} disabled={disabled} invalid={false}>
                <Field.Label>{label}</Field.Label>
                <Autocomplete.Root {...rootProps}>
                    <Autocomplete.Input placeholder={placeholder} data-testid={getElementTestId("trigger")}>
                        <Autocomplete.Control />
                        <Autocomplete.Controls>
                            {clearable && <Autocomplete.Clear />}
                            <Autocomplete.Trigger>
                                <Autocomplete.Icon />
                            </Autocomplete.Trigger>
                        </Autocomplete.Controls>
                    </Autocomplete.Input>
                    <Autocomplete.Portal>
                        <Autocomplete.Positioner sideOffset={4}>
                            <Autocomplete.Popup>
                                <Autocomplete.Empty data-testid={getElementTestId("empty-state")}>
                                    No cities found
                                </Autocomplete.Empty>
                                <Autocomplete.List>
                                    {(option: CityOption) => (
                                        <Autocomplete.Item
                                            key={option.value}
                                            value={option}
                                            disabled={option.disabled}
                                            data-testid={getElementTestId(`item-${option.value}`)}
                                        >
                                            <div className="flex min-w-0 flex-1 flex-col">
                                                <span>{option.label}</span>
                                                {option.secondary ? (
                                                    <span className="bolt-font-body-s-regular text-secondary">
                                                        {option.secondary}
                                                    </span>
                                                ) : null}
                                            </div>
                                        </Autocomplete.Item>
                                    )}
                                </Autocomplete.List>
                            </Autocomplete.Popup>
                        </Autocomplete.Positioner>
                    </Autocomplete.Portal>
                    {statusMessage ? (
                        <Autocomplete.Status
                            className="bolt-font-body-s-regular mt-2 text-secondary"
                            data-testid={getElementTestId("status")}
                        >
                            {statusMessage}
                        </Autocomplete.Status>
                    ) : null}
                </Autocomplete.Root>
            </Field.Root>
        </div>
    );
}

type Story = StoryObj<typeof meta>;

export const Default: Story = {
    render: () => <AutocompletePreview testId="default" />,
    ...withSource(`
<Autocomplete.Root items={cityOptions} size="md">
  <Autocomplete.Input placeholder="Search a city">
    <Autocomplete.Control />
    <Autocomplete.Controls>
      <Autocomplete.Clear />
      <Autocomplete.Trigger>
        <Autocomplete.Icon />
      </Autocomplete.Trigger>
    </Autocomplete.Controls>
  </Autocomplete.Input>
  <Autocomplete.Portal>
    <Autocomplete.Positioner sideOffset={4}>
      <Autocomplete.Popup>
        <Autocomplete.Empty>No cities found</Autocomplete.Empty>
        <Autocomplete.List>
          {(option) => (
            <Autocomplete.Item key={option.value} value={option}>
              <span>{option.label}</span>
            </Autocomplete.Item>
          )}
        </Autocomplete.List>
      </Autocomplete.Popup>
    </Autocomplete.Positioner>
  </Autocomplete.Portal>
</Autocomplete.Root>
`),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const input = canvas.getByRole("combobox");
        await expect(input).toBeInTheDocument();

        // Type to filter
        await userEvent.click(input);
        await userEvent.type(input, "Ber");

        // Wait for list to appear and check filtered results
        await waitFor(() => {
            const listbox = canvasElement.ownerDocument.querySelector("[role=listbox]");
            expect(listbox).toBeInTheDocument();
        });
    },
};

export const Sizes: Story = {
    render: () => (
        <div className="flex flex-col gap-6">
            <AutocompletePreview size="sm" label="Small" testId="sizes-sm" />
            <AutocompletePreview size="md" label="Medium" testId="sizes-md" />
            <AutocompletePreview size="lg" label="Large" testId="sizes-lg" />
        </div>
    ),
    ...withSource(`
{/* Small */}
<Autocomplete.Root items={options} size="sm">…</Autocomplete.Root>

{/* Medium (default) */}
<Autocomplete.Root items={options} size="md">…</Autocomplete.Root>

{/* Large */}
<Autocomplete.Root items={options} size="lg">…</Autocomplete.Root>
`),
};

export const WithSecondaryText: Story = {
    render: () => <AutocompletePreview options={cityOptionsWithSecondary} testId="secondary" />,
    ...withSource(`
<Autocomplete.Root items={cityOptionsWithSecondary}>
  {/* ... */}
  <Autocomplete.List>
    {(option) => (
      <Autocomplete.Item key={option.value} value={option}>
        <div className="flex flex-col">
          <span>{option.label}</span>
          <span className="bolt-font-body-s-regular text-secondary">{option.secondary}</span>
        </div>
      </Autocomplete.Item>
    )}
  </Autocomplete.List>
</Autocomplete.Root>
`),
};

export const Disabled: Story = {
    render: () => <AutocompletePreview disabled testId="disabled" />,
    ...withSource(`
<Autocomplete.Root items={options} disabled>…</Autocomplete.Root>
`),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const input = canvas.getByRole("combobox");
        await expect(input).toBeDisabled();
    },
};

export const ReadOnly: Story = {
    render: () => <AutocompletePreview readOnly defaultValue="Berlin" testId="readonly" />,
    ...withSource(`
<Autocomplete.Root items={options} readOnly defaultValue="Berlin">…</Autocomplete.Root>
`),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const input = canvas.getByRole("combobox");
        await expect(input).toHaveAttribute("readonly");
    },
};

export const DisabledItems: Story = {
    render: () => <AutocompletePreview options={cityOptionsWithDisabled} testId="disabled-items" />,
    ...withSource(`
const options = [
  { label: "Tallinn", value: "tallinn" },
  { label: "Warsaw", value: "warsaw", disabled: true },
  // ...
];
<Autocomplete.Root items={options}>
  <Autocomplete.List>
    {(option) => (
      <Autocomplete.Item value={option} disabled={option.disabled}>
        <span>{option.label}</span>
      </Autocomplete.Item>
    )}
  </Autocomplete.List>
</Autocomplete.Root>
`),
};

export const GroupedOptions: Story = {
    render: () => (
        <div className="w-96">
            <Field.Root name="autocomplete-grouped">
                <Field.Label>City</Field.Label>
                <Autocomplete.Root items={groupedCityOptions}>
                    <Autocomplete.Input placeholder="Search a city" data-testid="grouped-trigger">
                        <Autocomplete.Control />
                        <Autocomplete.Controls>
                            <Autocomplete.Clear />
                            <Autocomplete.Trigger>
                                <Autocomplete.Icon />
                            </Autocomplete.Trigger>
                        </Autocomplete.Controls>
                    </Autocomplete.Input>
                    <Autocomplete.Portal>
                        <Autocomplete.Positioner sideOffset={4}>
                            <Autocomplete.Popup>
                                <Autocomplete.Empty>No cities found</Autocomplete.Empty>
                                <Autocomplete.List>
                                    {groupedCityOptions.map((group) => (
                                        <Autocomplete.Group key={group.label} className="px-2 py-1">
                                            <Autocomplete.GroupLabel
                                                className={`bolt-font-body-s-regular px-2 py-1 uppercase text-secondary`}
                                            >
                                                {group.label}
                                            </Autocomplete.GroupLabel>
                                            {group.items.map((option) => (
                                                <Autocomplete.Item key={option.value} value={option}>
                                                    <div className="flex min-w-0 flex-1 flex-col">
                                                        <span>{option.label}</span>
                                                        <span className="bolt-font-body-s-regular text-secondary">
                                                            {option.secondary}
                                                        </span>
                                                    </div>
                                                </Autocomplete.Item>
                                            ))}
                                        </Autocomplete.Group>
                                    ))}
                                </Autocomplete.List>
                            </Autocomplete.Popup>
                        </Autocomplete.Positioner>
                    </Autocomplete.Portal>
                </Autocomplete.Root>
            </Field.Root>
        </div>
    ),
    ...withSource(`
const groups = [
  {
    label: "Baltics",
    items: [
      {label: "Tallinn", value: "tallinn", secondary: "Estonia"},
      {label: "Riga", value: "riga", secondary: "Latvia"},
    ],
  },
  {
    label: "Central Europe",
    items: [
      {label: "Warsaw", value: "warsaw", secondary: "Poland"},
      {label: "Berlin", value: "berlin", secondary: "Germany"},
    ],
  },
];

<Autocomplete.Root items={groups}>
  <Autocomplete.Input placeholder="Search a city">
    <Autocomplete.Control />
    <Autocomplete.Controls>…</Autocomplete.Controls>
  </Autocomplete.Input>
  <Autocomplete.Portal>
    <Autocomplete.Positioner sideOffset={4}>
      <Autocomplete.Popup>
        <Autocomplete.Empty>No cities found</Autocomplete.Empty>
        <Autocomplete.List>
          {groups.map((group) => (
            <Autocomplete.Group key={group.label}>
              <Autocomplete.GroupLabel>{group.label}</Autocomplete.GroupLabel>
              {group.items.map((option) => (
                <Autocomplete.Item key={option.value} value={option}>
                  <span>{option.label}</span>
                </Autocomplete.Item>
              ))}
            </Autocomplete.Group>
          ))}
        </Autocomplete.List>
      </Autocomplete.Popup>
    </Autocomplete.Positioner>
  </Autocomplete.Portal>
</Autocomplete.Root>
`),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const input = canvas.getByRole("combobox");

        await userEvent.click(input);
        await userEvent.type(input, "a");

        await waitFor(() => {
            const listbox = canvasElement.ownerDocument.querySelector("[role=listbox]");
            expect(listbox).toBeInTheDocument();
        });

        const baltics = canvasElement.ownerDocument.querySelector("[role=listbox]");
        await expect(baltics?.textContent).toContain("Baltics");
    },
};

export const NoClearButton: Story = {
    render: () => <AutocompletePreview clearable={false} testId="no-clear" />,
    ...withSource(`
<Autocomplete.Root items={options}>
  <Autocomplete.Input>
    <Autocomplete.Control />
    <Autocomplete.Controls>
      {/* No Autocomplete.Clear here */}
      <Autocomplete.Trigger>
        <Autocomplete.Icon />
      </Autocomplete.Trigger>
    </Autocomplete.Controls>
  </Autocomplete.Input>
  {/* … */}
</Autocomplete.Root>
`),
};

export const ValidationError: Story = {
    render: () => (
        <div className="w-96">
            <Field.Root name="autocomplete-error" invalid>
                <Field.Label>City</Field.Label>
                <Autocomplete.Root items={cityOptions}>
                    <Autocomplete.Input placeholder="Search a city" data-testid="error-trigger">
                        <Autocomplete.Control />
                        <Autocomplete.Controls>
                            <Autocomplete.Clear />
                            <Autocomplete.Trigger>
                                <Autocomplete.Icon />
                            </Autocomplete.Trigger>
                        </Autocomplete.Controls>
                    </Autocomplete.Input>
                    <Autocomplete.Portal>
                        <Autocomplete.Positioner sideOffset={4}>
                            <Autocomplete.Popup>
                                <Autocomplete.Empty>No cities found</Autocomplete.Empty>
                                <Autocomplete.List>
                                    {(option: CityOption) => (
                                        <Autocomplete.Item key={option.value} value={option}>
                                            <span>{option.label}</span>
                                        </Autocomplete.Item>
                                    )}
                                </Autocomplete.List>
                            </Autocomplete.Popup>
                        </Autocomplete.Positioner>
                    </Autocomplete.Portal>
                </Autocomplete.Root>
                <Field.Error>Please select a city</Field.Error>
            </Field.Root>
        </div>
    ),
    ...withSource(`
<Field.Root name="city" invalid>
  <Field.Label>City</Field.Label>
  <Autocomplete.Root items={options}>
    <Autocomplete.Input placeholder="Search a city">
      <Autocomplete.Control />
      <Autocomplete.Controls>
        <Autocomplete.Clear />
        <Autocomplete.Trigger>
          <Autocomplete.Icon />
        </Autocomplete.Trigger>
      </Autocomplete.Controls>
    </Autocomplete.Input>
    {/* Portal, Positioner, Popup, List … */}
  </Autocomplete.Root>
  <Field.Error>Please select a city</Field.Error>
</Field.Root>
`),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const input = canvas.getByRole("combobox");
        await expect(input).toHaveAttribute("aria-invalid", "true");
    },
};

export const Controlled: Story = {
    render: () => {
        const ControlledExample = () => {
            const [inputValue, setInputValue] = React.useState("Stock");

            return (
                <div className="flex flex-col gap-4">
                    <AutocompletePreview
                        value={inputValue}
                        onValueChange={(val) => setInputValue(val)}
                        testId="controlled"
                    />
                    <div className="bolt-font-body-s-regular text-secondary">
                        Current value: <code>{JSON.stringify(inputValue)}</code>
                    </div>
                    <div className="flex gap-2">
                        <button
                            className="rounded border border-solid border-neutral-primary px-3 py-1"
                            onClick={() => setInputValue("")}
                            type="button"
                        >
                            Clear externally
                        </button>
                        <button
                            className="rounded border border-solid border-neutral-primary px-3 py-1"
                            onClick={() => setInputValue("Tallinn")}
                            type="button"
                        >
                            Set to Tallinn
                        </button>
                    </div>
                </div>
            );
        };

        return <ControlledExample />;
    },
    ...withSource(`
const [inputValue, setInputValue] = React.useState("Stock");

<Autocomplete.Root
  items={options}
  value={inputValue}
  onValueChange={(val) => setInputValue(val)}
>
  {/* … */}
</Autocomplete.Root>
`),
};

export const FreeFormValue: Story = {
    render: () => {
        function FreeFormExample() {
            const [value, setValue] = React.useState("");

            return (
                <div className="flex flex-col gap-4">
                    <AutocompletePreview
                        value={value}
                        onValueChange={setValue}
                        testId="freeform"
                        label="City"
                        placeholder="Type any city name"
                    />
                    <div className="bolt-font-body-s-regular text-secondary">
                        Current value: <code data-testid="freeform-value">{JSON.stringify(value)}</code>
                    </div>
                </div>
            );
        }

        return <FreeFormExample />;
    },
    ...withSource(`
// Unlike Combobox, Autocomplete accepts any free-form text value —
// the user is not limited to items in the suggestion list.
const [value, setValue] = React.useState("");

<Autocomplete.Root
  items={options}
  value={value}
  onValueChange={setValue}
>
  <Autocomplete.Input placeholder="Type any city name">
    <Autocomplete.Control />
    <Autocomplete.Controls>
      <Autocomplete.Clear />
      <Autocomplete.Trigger>
        <Autocomplete.Icon />
      </Autocomplete.Trigger>
    </Autocomplete.Controls>
  </Autocomplete.Input>
  {/* Portal, Positioner, Popup, List … */}
</Autocomplete.Root>

<div>Current value: {JSON.stringify(value)}</div>
`),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const input = canvas.getByRole("combobox");

        // Type a value that does not exist in the suggestion list
        await userEvent.click(input);
        await userEvent.type(input, "New York");

        // The empty state should appear since no items match
        await waitFor(() => {
            const emptyState = canvasElement.ownerDocument.querySelector("[data-testid='freeform-empty-state']");
            expect(emptyState).toBeInTheDocument();
        });

        // Close the popup
        await userEvent.keyboard("{Escape}");

        // The free-form value is accepted and reflected in state
        const valueDisplay = canvas.getByTestId("freeform-value");
        await expect(valueDisplay.textContent).toBe('"New York"');
    },
};

export const CustomFilter: Story = {
    render: () => {
        function CustomFilterExample() {
            const filter = Autocomplete.useFilter({sensitivity: "base"});
            const [inputValue, setInputValue] = React.useState("");

            const filteredItems = React.useMemo(() => {
                if (!inputValue.trim()) return cityOptionsWithSecondary;
                return cityOptionsWithSecondary.filter(
                    (option) =>
                        filter.contains(option, inputValue, (o) => o.label) ||
                        filter.contains(option, inputValue, (o) => o.secondary ?? ""),
                );
            }, [filter, inputValue]);

            return (
                <div className="w-96">
                    <Field.Root name="autocomplete-custom-filter">
                        <Field.Label>City</Field.Label>
                        <Autocomplete.Root
                            items={filteredItems}
                            mode="none"
                            value={inputValue}
                            onValueChange={setInputValue}
                            openOnInputClick
                        >
                            <Autocomplete.Input
                                placeholder="Search by name or country"
                                data-testid="custom-filter-trigger"
                            >
                                <Autocomplete.Control />
                                <Autocomplete.Controls>
                                    <Autocomplete.Clear />
                                    <Autocomplete.Trigger>
                                        <Autocomplete.Icon />
                                    </Autocomplete.Trigger>
                                </Autocomplete.Controls>
                            </Autocomplete.Input>
                            <Autocomplete.Portal>
                                <Autocomplete.Positioner sideOffset={4}>
                                    <Autocomplete.Popup>
                                        <Autocomplete.Empty>No cities found</Autocomplete.Empty>
                                        <Autocomplete.List>
                                            {(option: CityOption) => (
                                                <Autocomplete.Item
                                                    key={option.value}
                                                    value={option}
                                                    data-testid={`custom-filter-item-${option.value}`}
                                                >
                                                    <div className="flex min-w-0 flex-1 flex-col">
                                                        <span>{option.label}</span>
                                                        <span className="bolt-font-body-s-regular text-secondary">
                                                            {option.secondary}
                                                        </span>
                                                    </div>
                                                </Autocomplete.Item>
                                            )}
                                        </Autocomplete.List>
                                    </Autocomplete.Popup>
                                </Autocomplete.Positioner>
                            </Autocomplete.Portal>
                        </Autocomplete.Root>
                    </Field.Root>
                </div>
            );
        }

        return <CustomFilterExample />;
    },
    ...withSource(`
// Matches both label and secondary text (e.g. country name)
function CustomFilterExample() {
  const filter = Autocomplete.useFilter({sensitivity: "base"});
  const [inputValue, setInputValue] = React.useState("");

  const filteredItems = React.useMemo(() => {
    if (!inputValue.trim()) return options;
    return options.filter(
      (option) =>
        filter.contains(option, inputValue, (o) => o.label) ||
        filter.contains(option, inputValue, (o) => o.secondary ?? ""),
    );
  }, [filter, inputValue]);

  return (
    <Autocomplete.Root
      items={filteredItems}
      mode="none"
      value={inputValue}
      onValueChange={setInputValue}
      openOnInputClick
    >
      <Autocomplete.Input placeholder="Search by name or country">
        <Autocomplete.Control />
        <Autocomplete.Controls>…</Autocomplete.Controls>
      </Autocomplete.Input>
      {/* Portal, Positioner, Popup, List … */}
    </Autocomplete.Root>
  );
}
`),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const input = canvas.getByRole("combobox");

        // Open by clicking the input
        await userEvent.click(input);
        await waitFor(() => {
            const listbox = canvasElement.ownerDocument.querySelector("[role=listbox]");
            expect(listbox).toBeInTheDocument();
        });

        // Type a country name (secondary text) — "Sweden" matches Stockholm
        await userEvent.type(input, "Sweden");

        await waitFor(() => {
            const listbox = canvasElement.ownerDocument.querySelector("[role=listbox]");
            expect(listbox?.textContent).toContain("Stockholm");
            expect(listbox?.textContent).not.toContain("Tallinn");
        });
    },
};

export const KeyboardNavigation: Story = {
    render: () => <AutocompletePreview openOnInputClick autoHighlight testId="keyboard" />,
    ...withSource(`
{/* Open with click, navigate with Arrow keys, select with Enter */}
<Autocomplete.Root items={options} openOnInputClick autoHighlight>…</Autocomplete.Root>
`),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement);
        const input = canvas.getByRole("combobox");

        // Open the popup
        await userEvent.click(input);
        await waitFor(() => {
            const listbox = canvasElement.ownerDocument.querySelector("[role=listbox]");
            expect(listbox).toBeInTheDocument();
        });

        // Navigate down
        await userEvent.keyboard("{ArrowDown}");
        await userEvent.keyboard("{ArrowDown}");

        // Select with Enter
        await userEvent.keyboard("{Enter}");

        // Popup should close
        await waitFor(() => {
            const listbox = canvasElement.ownerDocument.querySelector("[role=listbox]");
            expect(listbox).toBeNull();
        });
    },
};
