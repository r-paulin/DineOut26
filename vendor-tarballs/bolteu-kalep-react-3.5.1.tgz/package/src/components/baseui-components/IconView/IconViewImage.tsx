import * as React from "react";

import {Avatar as BaseUIAvatar} from "@base-ui/react/avatar";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useIconViewContext} from "./context/IconViewContext";
import type {IconViewExtendedState} from "./iconView.types";

const CLASSNAME_TW_IMAGE = "block h-full w-full object-cover";

export interface IconViewImageProps extends Omit<BaseUIAvatar.Image.Props, "className"> {
    className?: string | ((state: IconViewExtendedState) => string | undefined);
}

export const IconViewImage = React.forwardRef(function IconViewImage(
    props: IconViewImageProps,
    forwardedRef: React.ForwardedRef<HTMLImageElement>,
) {
    const {className, ...rest} = props;
    const {size} = useIconViewContext();

    const getImageClassName = React.useCallback(
        (state: BaseUIAvatar.Root.State) =>
            cx(CLASSNAME_TW_IMAGE, addConsumerClasses<IconViewExtendedState>({...state, size}, className)),
        [className, size],
    );

    return <BaseUIAvatar.Image {...rest} ref={forwardedRef} className={getImageClassName} />;
});
