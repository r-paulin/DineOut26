import {IconViewFallback} from "./IconViewFallback";
import {IconViewIcon} from "./IconViewIcon";
import {IconViewImage} from "./IconViewImage";
import {IconViewRoot} from "./IconViewRoot";

/**
 * IconView compound component.
 *
 * Provides a Base UI Avatar-based composition:
 * - `IconView.Root`: container and layout (supports `size`, `shadow`)
 * - `IconView.Image`: image slot with loading state handling
 * - `IconView.Fallback`: fallback slot for icon or initials
 * - `IconView.Icon`: icon slot for explicit icon usage. Can also serve as a fallback when used alongside `IconView.Image`.
 *
 * ### Composition guide
 *
 * With an image and a fallback
 * ```tsx
 * <IconView.Root size="md" shadow>
 *   <IconView.Image src={avatarUrl} alt="User avatar" />
 *   <IconView.Fallback>FB</IconView.Fallback>
 * </IconView.Root>
 * ```
 *
 * With an Icon
 * ```tsx
 * <IconView.Root size="md">
 *   <IconView.Icon icon={<SettingsIcon className="text-primary" />} />
 * </IconView.Root>
 * ```
 *
 * `IconView.Icon` component can also act as a fallback in case the provided image cannot be rendered:
 * ```tsx
 * <IconView.Root size="md" shadow>
 *   <IconView.Image src={avatarUrl} alt="User avatar" />
 *   <IconView.Icon icon={<UserIcon className="text-primary" />} />
 * </IconView.Root>
 * ```
 *
 * > **Tip:** when rendering an image, consider enabling `shadow` on `IconView.Root` for better depth and contrast.
 */
export const IconView = {
    Root: IconViewRoot,
    Image: IconViewImage,
    Fallback: IconViewFallback,
    Icon: IconViewIcon,
};

IconView.Root.displayName = "IconView.Root";
IconView.Image.displayName = "IconView.Image";
IconView.Fallback.displayName = "IconView.Fallback";
IconView.Icon.displayName = "IconView.Icon";
