import type {IconViewSizeVariant} from "@/components/baseui-components/IconView/iconView.types";

export const CLASSNAME_TW_ROOT_SIZE: Record<IconViewSizeVariant, string> = {
    "2xs": "h-5 w-5",
    xs: "h-7 w-7",
    sm: "h-9 w-9",
    md: "h-12 w-12",
    lg: "h-14 w-14",
    xl: "h-20 w-20",
};

export const CLASSNAME_TW_ICON_SIZE: Record<IconViewSizeVariant, string> = {
    "2xs": "h-3 w-3",
    xs: "h-5 w-5",
    sm: "h-5 w-5",
    md: "h-6 w-6",
    lg: "h-6 w-6",
    xl: "h-10 w-10",
};
