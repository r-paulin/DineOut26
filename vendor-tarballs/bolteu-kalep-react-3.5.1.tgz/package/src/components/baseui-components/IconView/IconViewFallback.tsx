import * as React from "react";

import {Avatar as BaseUIAvatar} from "@base-ui/react/avatar";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useIconViewContext} from "./context/IconViewContext";
import type {IconViewExtendedState} from "./iconView.types";
import {CLASSNAME_TW_ICON_SIZE} from "./shared-styles";

const CLASSNAME_TW_FALLBACK = "flex items-center justify-center text-primary";

export interface IconViewFallbackProps extends Omit<BaseUIAvatar.Fallback.Props, "className"> {
    className?: string | ((state: IconViewExtendedState) => string | undefined);
}

export const IconViewFallback = React.forwardRef(function IconViewFallback(
    props: IconViewFallbackProps,
    forwardedRef: React.ForwardedRef<HTMLSpanElement>,
) {
    const {className, ...rest} = props;
    const {size} = useIconViewContext();

    const getFallbackClassName = React.useCallback(
        (state: BaseUIAvatar.Root.State) =>
            cx(
                CLASSNAME_TW_FALLBACK,
                CLASSNAME_TW_ICON_SIZE[size],
                addConsumerClasses<IconViewExtendedState>({...state, size}, className),
            ),
        [className, size],
    );

    return <BaseUIAvatar.Fallback {...rest} ref={forwardedRef} className={getFallbackClassName} />;
});
