import * as React from "react";

import {Avatar as BaseUIAvatar} from "@base-ui/react/avatar";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {IconViewProvider} from "./context/IconViewContext";
import type {IconViewExtendedState, IconViewSizeVariant} from "./iconView.types";
import {CLASSNAME_TW_ROOT_SIZE} from "./shared-styles";

const CLASSNAME_TW_ROOT = "inline-flex items-center justify-center overflow-hidden rounded-full bg-neutral-secondary";
const CLASSNAME_TW_SHADOW = "shadow-[inset_0_0_8px_rgba(26,27,35,0.08)]";

export interface IconViewRootProps extends Omit<BaseUIAvatar.Root.Props, "className"> {
    size?: IconViewSizeVariant;
    shadow?: boolean;
    className?: string | ((state: IconViewExtendedState) => string | undefined);
}

export const IconViewRoot = React.forwardRef(function IconViewRoot(
    props: IconViewRootProps,
    forwardedRef: React.ForwardedRef<HTMLSpanElement>,
) {
    const {className, size = "md", shadow = false, ...rest} = props;

    const getRootClassName = React.useCallback(
        (state: BaseUIAvatar.Root.State) =>
            cx(
                CLASSNAME_TW_ROOT,
                CLASSNAME_TW_ROOT_SIZE[size],
                shadow ? CLASSNAME_TW_SHADOW : null,
                addConsumerClasses<IconViewExtendedState>({...state, size}, className),
            ),
        [className, size, shadow],
    );

    return (
        <IconViewProvider size={size}>
            <BaseUIAvatar.Root {...rest} ref={forwardedRef} className={getRootClassName} />
        </IconViewProvider>
    );
});
