import * as React from "react";

import {Switch as BaseUISwitch} from "@base-ui/react/switch";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const SwitchThumb = React.forwardRef(function SwitchThumb(
    props: BaseUISwitch.Thumb.Props,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {className, ...restProps} = props;
    const switchThumbClasses = React.useCallback(
        (state: BaseUISwitch.Thumb.State) => {
            return cx(
                "absolute inset-1 h-6 w-6 rounded-full",
                "bg-static-key-light shadow-md",
                {
                    "translate-x-0": !state.checked,
                    "translate-x-4 rtl:-translate-x-4": state.checked,
                    "shadow-none": state.disabled,
                },
                "pointer-events-none",
                "transform duration-200 ease-in-out",
                addConsumerClasses(state, className),
            );
        },
        [className],
    );
    return <BaseUISwitch.Thumb className={switchThumbClasses} {...restProps} ref={ref} />;
});

SwitchThumb.displayName = "Switch.Thumb";
