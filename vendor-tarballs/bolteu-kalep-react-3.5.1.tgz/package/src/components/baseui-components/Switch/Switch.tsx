import * as React from "react";

import {Switch as BaseUISwitch} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {SwitchThumb} from "./Thumb/SwitchThumb";

/**
 * ### Composition guide
 * Regular usage:
 * ```tsx
 * <Switch />
 * ```
 *
 * Composed with Thumb:
 * ```tsx
 * <Switch>
 *   <Switch.Thumb />
 * </Switch>
 * ```
 *
 * A `render` prop is provided for the `Switch` and `Switch.Thumb` components to
 * allow custom rendering of the components respectively.
 *
 * See `Field` and `Form` component documentation for better understanding of the field composition in a form.
 */
export const SwitchComponent = React.forwardRef(function SwitchRoot(
    props: BaseUISwitch.Root.Props,
    ref: React.ForwardedRef<HTMLSpanElement>,
) {
    const {className, children, ...restProps} = props;
    const switchRootClasses = React.useCallback(
        (state: BaseUISwitch.Root.State) => {
            const {disabled, checked, valid} = state;
            const invalid = valid === false;
            return cx(
                "rounded-full",
                "relative inline-block h-8 w-12 shrink-0 border-0",
                "transition-colors duration-200 ease-linear",
                {
                    "cursor-default": disabled,
                    "cursor-pointer": !disabled,
                    "bg-action-primary": checked && !invalid,
                    "bg-neutral-secondary-hard hover:bg-active-neutral-secondary-hard": !checked && !invalid,
                    "hover:bg-active-action-primary": checked && !disabled && !invalid,
                    "bg-special-disabled hover:bg-special-disabled": disabled && !checked && !invalid,
                    "bg-active-action-secondary": disabled && checked,
                    "bg-danger-primary": invalid && !disabled,
                    "bg-active-danger-secondary": invalid && disabled,
                },
                addConsumerClasses(state, className),
            );
        },
        [className],
    );
    return (
        <BaseUISwitch.Root className={switchRootClasses} {...restProps} ref={ref}>
            {children || <SwitchThumb />}
        </BaseUISwitch.Root>
    );
});

SwitchComponent.displayName = "Switch";
