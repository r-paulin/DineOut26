import {SwitchComponent} from "./Switch";
import {SwitchThumb} from "./Thumb/SwitchThumb";

export const Switch = Object.assign(SwitchComponent, {
    Thumb: SwitchThumb,
});
