import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Checkbox} from "@/components/baseui-components/CheckBox";
import {CheckboxGroup} from "@/components/baseui-components/CheckboxGroup";
import {Field} from "@/components/baseui-components/Field";

import {Fieldset} from "./Fieldset";

const meta = {
    component: Fieldset,
    title: "BaseUI Playground/Fieldset",
    tags: ["experimental", "BaseUI", "autodocs"],
} satisfies Meta<typeof Fieldset>;

export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
    args: {},
    render: (_args) => {
        return (
            <Field.Root name="checkbox-group" render={<Fieldset />}>
                <Fieldset.Legend>Select one or many</Fieldset.Legend>
                <CheckboxGroup>
                    <Field.Item>
                        <Field.Label inline>
                            <Checkbox value="option-1" />
                            Option 1
                        </Field.Label>
                    </Field.Item>
                    <Field.Item>
                        <Field.Label inline>
                            <Checkbox value="option-2" />
                            Option 2
                        </Field.Label>
                    </Field.Item>
                    <Field.Item>
                        <Field.Label inline>
                            <Checkbox value="option-3" />
                            Option 3
                        </Field.Label>
                    </Field.Item>
                </CheckboxGroup>
            </Field.Root>
        );
    },
};
