import * as React from "react";

import {Fieldset as BaseUIFieldset} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

const FieldsetLegend = React.forwardRef(function FieldsetLegend(
    props: BaseUIFieldset.Legend.Props,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;
    const fieldsetLegendClassname = React.useCallback(
        (state: BaseUIFieldset.Legend.State) => {
            return cx("bolt-font-body-s-accent w-fit", addConsumerClasses(state, className));
        },
        [className],
    );

    return <BaseUIFieldset.Legend className={fieldsetLegendClassname} {...rest} ref={ref} />;
});

const FieldsetComponent = React.forwardRef(function Fieldset(
    props: BaseUIFieldset.Root.Props,
    ref: React.ForwardedRef<HTMLElement>,
) {
    const {className, ...rest} = props;
    const fieldsetRootClassname = React.useCallback(
        (state: BaseUIFieldset.Root.State) => {
            return cx("m-0 border-0 p-0", addConsumerClasses(state, className));
        },
        [className],
    );
    return <BaseUIFieldset.Root className={fieldsetRootClassname} {...rest} ref={ref} />;
});

export const Fieldset = Object.assign(FieldsetComponent, {
    Legend: FieldsetLegend,
});

Fieldset.Legend.displayName = "Fieldset.Legend";
