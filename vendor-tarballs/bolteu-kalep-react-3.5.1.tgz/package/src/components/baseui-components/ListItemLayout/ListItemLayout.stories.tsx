import * as React from "react";

import {expect, fn, userEvent, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import Check from "@bolteu/kalep-react-icons/dist/Check";
import Heart from "@bolteu/kalep-react-icons/dist/Heart";
import Offer from "@bolteu/kalep-react-icons/dist/Offer";

import {Button} from "@/components/baseui-components/Button";
import {Checkbox} from "@/components/baseui-components/CheckBox";
import {IconButton} from "@/components/baseui-components/IconButton";
import {RadioGroup} from "@/components/baseui-components/RadioGroup";
import {Radio} from "@/components/baseui-components/RadioGroup/Radio";
import {Switch} from "@/components/baseui-components/Switch";
import {TypographyStack} from "@/components/baseui-components/Typography";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {ListItemLayout} from "./index";

const meta = {
    // @ts-expect-error - compound component type mismatch
    component: ListItemLayout,
    title: "BaseUI Playground/ListItemLayout",
    subcomponents: {
        "ListItemLayout.Root": ListItemLayout.Root,
        "ListItemLayout.Content": ListItemLayout.Content,
        "ListItemLayout.Slot": ListItemLayout.Slot,
    },
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "Composable list item layout with slots and selection support.",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof ListItemLayout>;

export default meta;

type Story = StoryObj<typeof ListItemLayout.Root>;

const BaseList = ({children}: {children: React.ReactNode}) => (
    <ul
        className={`
          m-0 flex max-h-80 w-96 list-none flex-col gap-y-3 overflow-y-auto px-0 py-1
          empty:py-0
        `}
    >
        {children}
    </ul>
);

export const Default: Story = {
    args: {
        "aria-label": "A Picture of Dorian Gray",
        separator: true,
    },
    render: (args) => (
        <BaseList>
            <ListItemLayout.Root {...args} render={<li />}>
                <ListItemLayout.Content>
                    <TypographyStack>
                        <TypographyStack.Primary>A Picture of Dorian Gray</TypographyStack.Primary>
                        <TypographyStack.Secondary>Oscar Wilde</TypographyStack.Secondary>
                    </TypographyStack>
                </ListItemLayout.Content>
            </ListItemLayout.Root>
        </BaseList>
    ),
};

export const WithSlots: Story = {
    render: () => (
        <BaseList>
            <li>
                <ListItemLayout.Root aria-label="War and Peace">
                    <ListItemLayout.Slot>
                        <Offer size="md" className="text-primary" />
                    </ListItemLayout.Slot>
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary>War and Peace</TypographyStack.Primary>
                            <TypographyStack.Secondary>Lev Tolstoy</TypographyStack.Secondary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                    <ListItemLayout.Slot>
                        <IconButton size="md" icon={<Heart />} aria-label="Like War and Peace" />
                    </ListItemLayout.Slot>
                </ListItemLayout.Root>
            </li>
            <li>
                <ListItemLayout.Root aria-label="The Brothers Karamazov">
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary>The Brothers Karamazov</TypographyStack.Primary>
                            <TypographyStack.Secondary>Fyodor Dostoevsky</TypographyStack.Secondary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                    <ListItemLayout.Slot>
                        <Button size="md">Add</Button>
                    </ListItemLayout.Slot>
                </ListItemLayout.Root>
            </li>
            <li>
                <ListItemLayout.Root aria-label="Pride and Prejudice">
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary>Pride and Prejudice</TypographyStack.Primary>
                            <TypographyStack.Secondary>Jane Austen</TypographyStack.Secondary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                    <ListItemLayout.Slot>
                        <Checkbox aria-label="Read Pride and Prejudice" />
                    </ListItemLayout.Slot>
                </ListItemLayout.Root>
            </li>
            <li>
                <ListItemLayout.Root aria-label="On Peace">
                    <ListItemLayout.Slot>
                        <Offer size="md" className="text-primary" />
                    </ListItemLayout.Slot>
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary lines={3}>
                                Human being&apos;s love for peace is universal. Human being is by nature peaceful. War
                                does not furnish a proof of the idea that human is a fighting animal.
                            </TypographyStack.Primary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                    <ListItemLayout.Slot>
                        <Check size="md" className="text-primary" />
                    </ListItemLayout.Slot>
                </ListItemLayout.Root>
            </li>
        </BaseList>
    ),
};

export const Variants: Story = {
    render: () => (
        <div className="flex gap-6">
            <div>
                <TypographyStack>
                    <TypographyStack.Primary>base variant</TypographyStack.Primary>
                </TypographyStack>
                <BaseList>
                    <li>
                        <ListItemLayout.Root aria-label="Base variant">
                            <ListItemLayout.Content>
                                <TypographyStack>
                                    <TypographyStack.Primary>Base layout</TypographyStack.Primary>
                                    <TypographyStack.Secondary>Secondary line</TypographyStack.Secondary>
                                </TypographyStack>
                            </ListItemLayout.Content>
                        </ListItemLayout.Root>
                    </li>
                </BaseList>
            </div>
            <div>
                <TypographyStack>
                    <TypographyStack.Primary>sm variant</TypographyStack.Primary>
                </TypographyStack>
                <BaseList>
                    <li>
                        <ListItemLayout.Root variant="sm" aria-label="Sm variant">
                            <ListItemLayout.Content>
                                <TypographyStack variant="sm">
                                    <TypographyStack.Primary>Small layout</TypographyStack.Primary>
                                    <TypographyStack.Secondary>Secondary line</TypographyStack.Secondary>
                                </TypographyStack>
                            </ListItemLayout.Content>
                        </ListItemLayout.Root>
                    </li>
                </BaseList>
            </div>
        </div>
    ),
};

export const Padding: Story = {
    render: () => (
        <BaseList>
            <li>
                <ListItemLayout.Root className="px-2" aria-label="Compact padding">
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary>Compact padding</TypographyStack.Primary>
                            <TypographyStack.Secondary>px-2</TypographyStack.Secondary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                </ListItemLayout.Root>
            </li>
            <li>
                <ListItemLayout.Root className="px-8" aria-label="Spacious padding">
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary>Spacious padding</TypographyStack.Primary>
                            <TypographyStack.Secondary>px-8</TypographyStack.Secondary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                </ListItemLayout.Root>
            </li>
            <li>
                <ListItemLayout.Root className="px-6 py-1" aria-label="Custom padding">
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary>Custom padding</TypographyStack.Primary>
                            <TypographyStack.Secondary>px-6 py-1</TypographyStack.Secondary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                </ListItemLayout.Root>
            </li>
        </BaseList>
    ),
};

export const Selection: Story = {
    render: () => {
        const [isSelected, setIsSelected] = React.useState(false);
        const toggleSelection = React.useCallback(() => {
            setIsSelected((value) => !value);
        }, []);

        return (
            <BaseList>
                <li>
                    <ListItemLayout.Root aria-label="Checkmark selection" onClick={toggleSelection}>
                        <ListItemLayout.Content>
                            <TypographyStack>
                                <TypographyStack.Primary>Solo checkmark</TypographyStack.Primary>
                                <TypographyStack.Secondary>Composed selection</TypographyStack.Secondary>
                            </TypographyStack>
                        </ListItemLayout.Content>
                        <ListItemLayout.Slot>
                            {isSelected ? (
                                <Check size="md" className="text-action-secondary" aria-label="Selected" />
                            ) : null}
                        </ListItemLayout.Slot>
                    </ListItemLayout.Root>
                </li>
                <li>
                    <ListItemLayout.Root aria-label="Radio selection" onClick={toggleSelection}>
                        <ListItemLayout.Slot>
                            <RadioGroup value={isSelected ? "selected" : "unselected"} aria-label="Radio selection">
                                <Radio value="selected" readOnly tabIndex={-1} />
                            </RadioGroup>
                        </ListItemLayout.Slot>
                        <ListItemLayout.Content>
                            <TypographyStack>
                                <TypographyStack.Primary>Solo radio</TypographyStack.Primary>
                                <TypographyStack.Secondary>Composed selection</TypographyStack.Secondary>
                            </TypographyStack>
                        </ListItemLayout.Content>
                    </ListItemLayout.Root>
                </li>
                <li>
                    <ListItemLayout.Root aria-label="Checkbox selection" onClick={toggleSelection}>
                        <ListItemLayout.Slot>
                            <Checkbox checked={isSelected} readOnly aria-label="Checkbox selection" tabIndex={-1} />
                        </ListItemLayout.Slot>
                        <ListItemLayout.Content>
                            <TypographyStack>
                                <TypographyStack.Primary>Multiple</TypographyStack.Primary>
                                <TypographyStack.Secondary>Composed selection</TypographyStack.Secondary>
                            </TypographyStack>
                        </ListItemLayout.Content>
                    </ListItemLayout.Root>
                </li>
                <li>
                    <ListItemLayout.Root aria-label="Switch selection" onClick={toggleSelection}>
                        <ListItemLayout.Content>
                            <TypographyStack>
                                <TypographyStack.Primary>Switch</TypographyStack.Primary>
                                <TypographyStack.Secondary>Composed selection</TypographyStack.Secondary>
                            </TypographyStack>
                        </ListItemLayout.Content>
                        <ListItemLayout.Slot>
                            <Switch checked={isSelected} readOnly aria-label="Switch selection" tabIndex={-1} />
                        </ListItemLayout.Slot>
                    </ListItemLayout.Root>
                </li>
            </BaseList>
        );
    },
};

export const States: Story = {
    render: () => (
        <BaseList>
            <li>
                <ListItemLayout.Root disabled aria-label="Disabled">
                    <ListItemLayout.Slot>
                        <Offer size="md" className="text-tertiary" />
                    </ListItemLayout.Slot>
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary>Disabled</TypographyStack.Primary>
                            <TypographyStack.Secondary>Secondary text</TypographyStack.Secondary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                    <ListItemLayout.Slot>
                        <Button size="md" disabled>
                            Add
                        </Button>
                    </ListItemLayout.Slot>
                </ListItemLayout.Root>
            </li>
        </BaseList>
    ),
};

export const Accessibility: Story = {
    args: {
        "aria-label": "Accessible list item",
        onClick: fn(),
    },
    render: (args) => (
        <BaseList>
            <li>
                <ListItemLayout.Root {...args}>
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary>Keyboard focus</TypographyStack.Primary>
                            <TypographyStack.Secondary>Press Enter or Space</TypographyStack.Secondary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                </ListItemLayout.Root>
            </li>
        </BaseList>
    ),
    play: async ({canvasElement, args, step}) => {
        const canvas = within(canvasElement);
        const item = canvas.getByRole("button", {name: "Accessible list item"});

        await step("Item is focusable", async () => {
            await userEvent.tab();
            await expect(item).toHaveFocus();
        });

        await step("Keyboard activates click handler", async () => {
            await userEvent.keyboard("{Enter}");
            await expect(args.onClick).toHaveBeenCalled();
        });
    },
};
