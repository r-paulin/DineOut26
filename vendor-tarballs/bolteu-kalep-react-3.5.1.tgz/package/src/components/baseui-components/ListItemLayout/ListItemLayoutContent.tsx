import * as React from "react";

import {mergeProps, useRender} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

import {useListItemLayoutContext} from "./context/useListItemLayoutContext";
import type {ListItemLayoutContentProps} from "./ListItemLayout.types";

export const ListItemLayoutContent = React.forwardRef(function ListItemLayoutContent(
    props: ListItemLayoutContentProps,
    ref: React.ForwardedRef<HTMLDivElement>,
) {
    const {render, className, ...otherComponentProps} = props;
    const state = useListItemLayoutContext();

    const defaultProps: useRender.ElementProps<"div"> = {
        className: cx("flex-1", addConsumerClasses(state, className)),
    };

    return useRender({
        defaultTagName: "div",
        render,
        ref,
        state,
        props: mergeProps<"div">(defaultProps, otherComponentProps),
    });
});

