import * as React from "react";

import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import Check from "@bolteu/kalep-react-icons/dist/Check";

import {ListItemLayout} from "@/components/baseui-components/ListItemLayout";
import {RadioGroup} from "@/components/baseui-components/RadioGroup";
import {Radio} from "@/components/baseui-components/RadioGroup/Radio";
import {TypographyStack} from "@/components/baseui-components/Typography";
import {cx} from "@/helpers/utils/cx";

function renderListItem(props?: Partial<React.ComponentProps<typeof ListItemLayout.Root>>) {
    return render(
        <ListItemLayout.Root aria-label="Test item" {...props}>
            <ListItemLayout.Content>
                <TypographyStack>
                    <TypographyStack.Primary>Primary</TypographyStack.Primary>
                    <TypographyStack.Secondary>Secondary</TypographyStack.Secondary>
                </TypographyStack>
            </ListItemLayout.Content>
        </ListItemLayout.Root>,
    );
}

describe("ListItemLayout", () => {
    test("renders button semantics when clickable", () => {
        renderListItem({onClick: vi.fn()});

        const button = screen.getByRole("button", {name: "Test item"});

        expect(button).toBeInTheDocument();
    });

    test("invokes onClick on keyboard activation", async () => {
        const onClick = vi.fn();
        const user = userEvent.setup();

        renderListItem({onClick});

        await user.tab();
        await user.keyboard("{Enter}");

        expect(onClick).toHaveBeenCalledTimes(1);
    });

    test("renders checkmark selection when provided", () => {
        render(
            <ListItemLayout.Root aria-label="Selected item">
                <ListItemLayout.Content>
                    <TypographyStack>
                        <TypographyStack.Primary>Primary</TypographyStack.Primary>
                    </TypographyStack>
                </ListItemLayout.Content>
                <ListItemLayout.Slot>
                    <Check size="md" className={cx("text-action-secondary")} aria-label="Selected checkmark" />
                </ListItemLayout.Slot>
            </ListItemLayout.Root>,
        );

        expect(screen.getAllByLabelText("Selected checkmark").length).toBeGreaterThan(0);
    });

    test("renders radio selection using radiogroup semantics", () => {
        render(
            <ListItemLayout.Root aria-label="Radio selection">
                <ListItemLayout.Content>
                    <TypographyStack>
                        <TypographyStack.Primary>Primary</TypographyStack.Primary>
                    </TypographyStack>
                </ListItemLayout.Content>
                <ListItemLayout.Slot>
                    <RadioGroup value="selected" aria-label="Radio selection">
                        <Radio value="selected" readOnly tabIndex={-1} />
                    </RadioGroup>
                </ListItemLayout.Slot>
            </ListItemLayout.Root>,
        );

        expect(screen.getByRole("radiogroup", {name: "Radio selection"})).toBeInTheDocument();
    });
});
