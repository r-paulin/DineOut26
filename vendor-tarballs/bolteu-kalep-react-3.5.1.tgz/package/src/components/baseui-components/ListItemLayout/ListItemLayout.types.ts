import type * as React from "react";

import type {useRender} from "@base-ui/react";

export type ListItemLayoutVariant = "base" | "sm";

export type ListItemLayoutState = {
    variant: ListItemLayoutVariant;
    disabled: boolean;
    clickable: boolean;
};

export interface ListItemLayoutRootProps extends Omit<
    useRender.ComponentProps<"div", ListItemLayoutState>,
    "className"
> {
    className?: string | ((state: ListItemLayoutState) => string);
    /** Preconfigured options for list item layout. Available options: `base`, `sm` */
    variant?: ListItemLayoutVariant;
    separator?: boolean;
    disabled?: boolean;
}

export interface ListItemLayoutSlotProps extends Omit<
    useRender.ComponentProps<"div", ListItemLayoutState>,
    "className" | "children"
> {
    className?: string | ((state: ListItemLayoutState) => string);
    children?: React.ReactNode;
}

export interface ListItemLayoutContentProps extends Omit<
    useRender.ComponentProps<"div", ListItemLayoutState>,
    "className"
> {
    className?: string | ((state: ListItemLayoutState) => string);
}
