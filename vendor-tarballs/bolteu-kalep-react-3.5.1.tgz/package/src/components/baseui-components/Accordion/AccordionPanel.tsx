import * as React from "react";

import {Accordion as BaseUIAccordion} from "@base-ui/react/accordion";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const AccordionPanel = React.forwardRef(function AccordionPanel(
    props: BaseUIAccordion.Panel.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getPanelClassNames = React.useCallback(
        (state: BaseUIAccordion.Panel.State) => {
            return cx(
                `h-[var(--accordion-panel-height)] overflow-hidden transition-[height,opacity] duration-300 ease-in-out`,
                {"h-0 opacity-0": state.transitionStatus === "starting" || state.transitionStatus === "ending"},
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    return <BaseUIAccordion.Panel {...rest} ref={forwardedRef} className={getPanelClassNames} />;
});
