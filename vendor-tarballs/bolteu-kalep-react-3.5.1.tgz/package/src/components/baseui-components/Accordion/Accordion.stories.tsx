import * as React from "react";

import {expect, fn, userEvent, within} from "storybook/test";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import ChevronDown from "@bolteu/kalep-react-icons/dist/ChevronDown";

import {Chip} from "@/components/baseui-components/Chip";
import {ListItemLayout} from "@/components/baseui-components/ListItemLayout";
import {TypographyStack} from "@/components/baseui-components/Typography";
import {cx} from "@/helpers/utils/cx";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Accordion} from "./index";

const meta = {
    // @ts-expect-error -- Storybook expects a single component, but Accordion is a compound export.
    component: Accordion,
    title: "BaseUI Playground/Accordion",
    tags: ["experimental", "BaseUI", "autodocs"],
    subcomponents: {
        "Accordion.Root": Accordion.Root,
        "Accordion.Item": Accordion.Item,
        "Accordion.Header": Accordion.Header,
        "Accordion.Trigger": Accordion.Trigger,
        "Accordion.Panel": Accordion.Panel,
    },
    parameters: {
        docs: {
            subtitle: "Composition patterns and API for the Base UI Accordion",
            page: DocumentationTemplate,
        },
    },
    argTypes: {
        multiple: {control: "boolean"},
        disabled: {control: "boolean"},
        orientation: {control: "radio", options: ["vertical", "horizontal"]},
        loopFocus: {control: "boolean"},
        keepMounted: {control: "boolean"},
        hiddenUntilFound: {control: "boolean"},
        onValueChange: {action: "valueChanged"},
        value: {control: "object"},
        defaultValue: {control: "object"},
    },
} satisfies Meta<typeof Accordion.Root>;

export default meta;
type Story = StoryObj<typeof meta>;

type AccordionItemData = {
    value: string;
    title: string;
    subtitle?: string;
    status?: string;
    disabled?: boolean;
};

const items: AccordionItemData[] = [
    {
        value: "accordion-1",
        title: "Accordion 1",
        subtitle: "Last updated 2 days ago",
        status: "Approved",
    },
    {
        value: "accordion-2",
        title: "Accordion 2",
        subtitle: "Last updated today",
        status: "In review",
    },
    {
        value: "accordion-3",
        title: "Accordion 3",
        subtitle: "Expires in 3 hours",
    },
];

type AccordionStoryOptions = {
    items?: AccordionItemData[];
    content?: React.ReactNode;
    rootClassName?: string;
    itemClassName?: string;
    getTriggerClassName?: (item: AccordionItemData) => string | undefined;
};

const defaultPanelContent = (
    <TypographyStack>
        <TypographyStack.Primary>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer nec odio. Praesent libero. Sed cursus ante
            dapibus diam.
        </TypographyStack.Primary>
    </TypographyStack>
);

function renderAccordion(args: React.ComponentProps<typeof Accordion.Root>, options: AccordionStoryOptions = {}) {
    const {
        items: data = items,
        content = defaultPanelContent,
        rootClassName,
        itemClassName,
        getTriggerClassName,
    } = options;

    return (
        <div className="max-w-[410px]">
            <Accordion.Root {...args} className={cx(args.className, rootClassName)}>
                {data.map((item) => (
                    <Accordion.Item
                        key={item.value}
                        value={item.value}
                        disabled={item.disabled}
                        className={itemClassName}
                    >
                        <Accordion.Header>
                            <Accordion.Trigger className={getTriggerClassName?.(item)}>
                                <ListItemLayout.Root className="w-full px-0" disabled={item.disabled}>
                                    <ListItemLayout.Content>
                                        <TypographyStack>
                                            <TypographyStack.Primary
                                                className={item.disabled ? "text-tertiary" : undefined}
                                            >
                                                {item.title}
                                            </TypographyStack.Primary>
                                            {item.subtitle ? (
                                                <TypographyStack.Secondary
                                                    className={
                                                        item.disabled
                                                            ? "text-tertiary"
                                                            : item.status === "In review"
                                                              ? "text-danger-secondary"
                                                              : "text-secondary"
                                                    }
                                                >
                                                    {item.subtitle}
                                                </TypographyStack.Secondary>
                                            ) : null}
                                        </TypographyStack>
                                    </ListItemLayout.Content>
                                    {item.status ? (
                                        <ListItemLayout.Slot>
                                            <Chip nativeButton={false} render={<span />} disabled={item.disabled}>
                                                {item.status}
                                            </Chip>
                                        </ListItemLayout.Slot>
                                    ) : null}
                                    <ListItemLayout.Slot>
                                        <ChevronDown
                                            aria-hidden="true"
                                            className={`
                                              size-5 shrink-0 text-tertiary transition-transform duration-150
                                              ease-linear
                                              group-data-[panel-open]:rotate-180
                                            `}
                                        />
                                    </ListItemLayout.Slot>
                                </ListItemLayout.Root>
                            </Accordion.Trigger>
                        </Accordion.Header>
                        <Accordion.Panel>
                            <div className="mb-5 mt-2 ps-3">{content}</div>
                        </Accordion.Panel>
                    </Accordion.Item>
                ))}
            </Accordion.Root>
        </div>
    );
}

export const Default: Story = {
    args: {
        defaultValue: ["accordion-1"],
        onValueChange: fn(),
    },
    render: (args) => renderAccordion(args, {items}),
};

export const MultipleOpen: Story = {
    args: {
        multiple: true,
        defaultValue: ["accordion-1", "accordion-2"],
    },
    render: (args) => renderAccordion(args, {items}),
};

export const DisabledItems: Story = {
    args: {
        defaultValue: ["accordion-1"],
    },
    render: (args) => {
        return renderAccordion(args, {
            items: items.map((item, index) => ({
                ...item,
                disabled: index === 2,
            })),
            getTriggerClassName: (item) => (item.disabled ? "text-primary" : undefined),
        });
    },
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const firstTrigger = canvas.getByRole("button", {name: /Accordion 1/i});
        const thirdTrigger = canvas.getByRole("button", {name: /Accordion 3/i});

        await step("First item is enabled", async () => {
            await expect(firstTrigger).toBeEnabled();
        });

        await step("Third item has aria-disabled and data-disabled attributes", async () => {
            await expect(thirdTrigger).toHaveAttribute("aria-disabled", "true");
            await expect(thirdTrigger).toHaveAttribute("data-disabled");
        });

        await step("Disabled item can be focused", async () => {
            thirdTrigger.focus();
            await expect(thirdTrigger).toHaveFocus();
        });

        await step("Disabled item doesn't respond to clicks", async () => {
            await userEvent.click(thirdTrigger);
            await expect(thirdTrigger).toHaveAttribute("aria-expanded", "false");
        });
    },
};

export const Borderless: Story = {
    args: {
        defaultValue: ["accordion-1"],
    },
    render: (args) =>
        renderAccordion(args, {
            itemClassName: "border-b-0",
            items,
        }),
};

export const Controlled: Story = {
    args: {},
    render: (args) => {
        const [value, setValue] = React.useState<string[]>(["accordion-2"]);
        const onValueChange = React.useCallback((nextValue: string[]) => {
            setValue(nextValue);
        }, []);

        return renderAccordion({...args, value, onValueChange}, {items});
    },
};

export const Accessibility: Story = {
    args: {
        defaultValue: ["accordion-1"],
    },
    render: (args) => renderAccordion(args, {items}),
    play: async ({canvasElement, step}) => {
        const canvas = within(canvasElement);
        const firstTrigger = await canvas.getByRole("button", {name: /Accordion 1/i})!;

        await step("Arrow keys move focus between triggers", async () => {
            firstTrigger.focus();
            await userEvent.keyboard("{ArrowDown}");
            const secondTrigger = await canvas.getByRole("button", {name: /Accordion 2/i})!;
            await expect(secondTrigger).toHaveFocus();
        });

        await step("Enter toggles the focused panel", async () => {
            await userEvent.keyboard("{Enter}");
            const secondTrigger = await canvas.getByRole("button", {name: /Accordion 2/i})!;
            await expect(secondTrigger).toHaveAttribute("aria-expanded", "true");
        });
    },
};
