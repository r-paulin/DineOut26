import * as React from "react";

import {Accordion as BaseUIAccordion} from "@base-ui/react/accordion";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const AccordionRoot = React.forwardRef(function AccordionRoot(
    props: BaseUIAccordion.Root.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getRootClassNames = React.useCallback(
        (state: BaseUIAccordion.Root.State) => {
            return cx("m-0 flex flex-col px-6 py-0", addConsumerClasses(state, className));
        },
        [className],
    );

    return <BaseUIAccordion.Root {...rest} ref={forwardedRef} className={getRootClassNames} />;
});
