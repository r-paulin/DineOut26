import * as React from "react";

import {Accordion as BaseUIAccordion} from "@base-ui/react/accordion";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export const AccordionTrigger = React.forwardRef(function AccordionTrigger(
    props: BaseUIAccordion.Trigger.Props,
    forwardedRef: React.ForwardedRef<HTMLButtonElement>,
) {
    const {className, ...rest} = props;

    const getTriggerClassNames = React.useCallback(
        (state: BaseUIAccordion.Item.State) => {
            return cx(
                `
                  group relative flex w-full select-none items-center justify-between gap-x-3 border-none
                  bg-special-nulled p-0 text-left transition-colors duration-150 ease-linear
                  focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2
                  focus-visible:[outline-color:var(--color-bg-action-primary)]
                `,
                state.disabled ? "cursor-not-allowed text-tertiary" : "cursor-pointer text-primary",
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    return <BaseUIAccordion.Trigger {...rest} ref={forwardedRef} className={getTriggerClassNames} />;
});
