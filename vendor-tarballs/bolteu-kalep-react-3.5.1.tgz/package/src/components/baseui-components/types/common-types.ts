export type FieldSize = "sm" | "md" | "lg";

export type PropsWithFieldSize<T> = T & {fieldSize?: FieldSize};

export type Indexable<State extends object> = {
    [Key in keyof State]: State[Key];
};
