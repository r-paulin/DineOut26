import * as React from "react";

import {Button as BaseUIButton} from "@base-ui/react";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

export type GhostButtonProps = BaseUIButton.Props;

/**
 * GhostButton renders button semantics by default on a non-button element.
 *
 * - Default render: `<div />` via `render` when no render is provided. It also sets the `nativeButton` prop to `false` by default.
 * - When rendering a native button element, set the `nativeButton` prop to `true` and provide a `render` prop of `<button />`.
 * -
 */
export const GhostButton = React.forwardRef(function GhostButton(
    props: GhostButtonProps,
    ref: React.ForwardedRef<HTMLElement>,
) {
    const {render = <div />, className, nativeButton = false, ...rest} = props;

    const ghostButtonClassName = React.useCallback(
        function ghostButtonClassName(state: BaseUIButton.State) {
            return cx(
                "inline-block",
                "appearance-none border-none bg-transparent p-0 text-size-inherit text-inherit",
                {
                    "cursor-pointer active:scale-975 active:duration-100 active:ease-in-out": !state.disabled,
                    "pointer-events-none cursor-default": state.disabled,
                },
                addConsumerClasses(state, className),
            );
        },
        [className],
    );

    return (
        <BaseUIButton
            className={ghostButtonClassName}
            nativeButton={nativeButton}
            ref={ref}
            render={render}
            {...rest}
        />
    );
});
