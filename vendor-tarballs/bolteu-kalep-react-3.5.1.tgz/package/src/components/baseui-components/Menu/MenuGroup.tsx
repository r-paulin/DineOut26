import {Menu as BaseUIMenu} from "@base-ui/react/menu";

/**
 * Menu.Group
 *
 * Groups related menu items into a labeled section within the popup.
 */
export const MenuGroup = BaseUIMenu.Group;
