import {Menu as BaseUIMenu} from "@base-ui/react/menu";

/**
 * Menu.Root
 *
 * Stateful root that coordinates menu trigger, popup positioning, and menu item interaction.
 *
 * ### Composition guide
 * ```tsx
 * <Menu.Root>
 *   <Menu.Trigger>Open menu</Menu.Trigger>
 *   <Menu.Portal>
 *     <Menu.Positioner sideOffset={4}>
 *       <Menu.Popup>
 *         <Menu.Item>First action</Menu.Item>
 *         <Menu.Item>Second action</Menu.Item>
 *         <Menu.Separator />
 *         <Menu.SubmenuRoot>
 *           <Menu.SubmenuTrigger>More actions</Menu.SubmenuTrigger>
 *           <Menu.Portal>
 *             <Menu.Positioner sideOffset={4}>
 *               <Menu.Popup>
 *                 <Menu.Item>Sub action</Menu.Item>
 *               </Menu.Popup>
 *             </Menu.Positioner>
 *           </Menu.Portal>
 *         </Menu.SubmenuRoot>
 *       </Menu.Popup>
 *     </Menu.Positioner>
 *   </Menu.Portal>
 * </Menu.Root>
 * ```
 */
export const MenuRoot = BaseUIMenu.Root;

