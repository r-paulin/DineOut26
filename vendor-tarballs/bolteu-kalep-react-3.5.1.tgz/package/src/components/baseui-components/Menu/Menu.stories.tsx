import * as React from "react";

import {expect, userEvent, within} from "storybook/test";
import type {Menu as BaseUIMenu} from "@base-ui/react/menu";
import type {HTMLProps} from "@base-ui/react/utils/types";
import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {LogOut} from "@bolteu/kalep-react-icons";
import AddressDot from "@bolteu/kalep-react-icons/dist/AddressVisited";
import Check from "@bolteu/kalep-react-icons/dist/Check";
import ChevronRight from "@bolteu/kalep-react-icons/dist/ChevronRight";
import Heart from "@bolteu/kalep-react-icons/dist/Heart";
import HeartOutlined from "@bolteu/kalep-react-icons/dist/HeartOutlined";
import OpenIn from "@bolteu/kalep-react-icons/dist/OpenIn";

import {Button} from "@/components/baseui-components/Button";
import {ListItemLayout} from "@/components/baseui-components/ListItemLayout";
import {TypographyStack} from "@/components/baseui-components/Typography";
import {cx} from "@/helpers/utils/cx";

import DocumentationTemplate from "../docs/DocumentationTemplate.mdx";
import {Menu} from "./index";

type TriggerRenderFn = React.ComponentProps<typeof Menu.Trigger>["render"];

type MenuStory = StoryObj<typeof Menu.Root>;

type MenuPositionerProps = React.ComponentProps<typeof Menu.Positioner>;

interface MenuPlaygroundProps {
    triggerLabel?: string;
    triggerRender?: TriggerRenderFn;
    triggerProps?: Omit<React.ComponentProps<typeof Menu.Trigger>, "render" | "children">;
    positionerProps?: MenuPositionerProps;
    popupClassName?: string;
    rootProps?: Omit<React.ComponentProps<typeof Menu.Root>, "children">;
    children: React.ReactNode;
}

const meta = {
    //@ts-expect-error - Compound component typing
    component: Menu,
    subcomponents: {
        "Menu.Root": Menu.Root,
        "Menu.Trigger": Menu.Trigger,
        "Menu.Portal": Menu.Portal,
        "Menu.Positioner": Menu.Positioner,
        "Menu.Popup": Menu.Popup,
        "Menu.Item": Menu.Item,
        "Menu.Separator": Menu.Separator,
        "Menu.Group": Menu.Group,
        "Menu.GroupLabel": Menu.GroupLabel,
        "Menu.SubmenuRoot": Menu.SubmenuRoot,
        "Menu.SubmenuTrigger": Menu.SubmenuTrigger,
    },
    title: "BaseUI Playground/Menu",
    tags: ["experimental", "BaseUI", "autodocs"],
    parameters: {
        docs: {
            subtitle: "A BaseUI menu wrapper",
            page: DocumentationTemplate,
        },
    },
} satisfies Meta<typeof Menu>;

export default meta;

const defaultTrigger: TriggerRenderFn = (
    triggerProps: HTMLProps<HTMLButtonElement>,
    _state: BaseUIMenu.Trigger.State,
) => {
    const {ref, ...rest} = triggerProps;
    return (
        <Button {...rest} ref={ref} variant="tertiary">
            Open menu
        </Button>
    );
};

function MenuPlayground({
    triggerLabel = "Open menu",
    triggerRender = defaultTrigger,
    triggerProps,
    positionerProps,
    popupClassName,
    rootProps,
    children,
}: MenuPlaygroundProps) {
    return (
        <Menu.Root {...rootProps}>
            <Menu.Trigger render={triggerRender} aria-label={triggerLabel} {...triggerProps} />
            <Menu.Portal>
                <Menu.Positioner {...positionerProps}>
                    <Menu.Popup className={popupClassName}>{children}</Menu.Popup>
                </Menu.Positioner>
            </Menu.Portal>
        </Menu.Root>
    );
}

const withSource = (code: string) => ({
    parameters: {
        docs: {
            source: {
                code,
            },
        },
    },
});

export const Default: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item>View profile</Menu.Item>
        <Menu.Item>Account settings</Menu.Item>
        <Menu.Item>Sign out</Menu.Item>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item>View profile</Menu.Item>
            <Menu.Item>Account settings</Menu.Item>
            <Menu.Item>Sign out</Menu.Item>
        </MenuPlayground>
    ),
};

export const CustomRenderWithState: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item
          render={(itemProps, state) => {
            const className = cx(
              "text-left",
              state.highlighted && "bg-neutral-secondary",
              state.disabled && "text-secondary",
            );

            return (
                <ListItemLayout.Root {...itemProps} className={className} disabled={state.disabled}>
                  <ListItemLayout.Slot>
                    <AddressDot className={cx("text-positive-primary")} />
                  </ListItemLayout.Slot>
                  <ListItemLayout.Content>
                  <TypographyStack>
                    <TypographyStack.Primary>Available</TypographyStack.Primary>
                    <TypographyStack.Secondary>
                      Shows highlight and disabled styles
                    </TypographyStack.Secondary>
                  </TypographyStack>
                  </ListItemLayout.Content>
                  <ListItemLayout.Slot>
                    <Check className={cx("text-primary")} />
                  </ListItemLayout.Slot>
                </ListItemLayout.Root>
              );
            }}
        />
        <Menu.Item disabled>Unavailable (disabled)</Menu.Item>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item
                render={(itemProps, state) => {
                    const className = cx(
                        "text-left",
                        state.highlighted && "bg-neutral-secondary",
                        state.disabled && "text-secondary",
                    );

                    return (
                        <ListItemLayout.Root {...itemProps} className={className} disabled={state.disabled}>
                            <ListItemLayout.Slot>
                                <AddressDot className={cx("text-positive-primary")} />
                            </ListItemLayout.Slot>
                            <ListItemLayout.Content>
                                <TypographyStack>
                                    <TypographyStack.Primary>Available</TypographyStack.Primary>
                                    <TypographyStack.Secondary>
                                        Shows highlight and disabled styles
                                    </TypographyStack.Secondary>
                                </TypographyStack>
                            </ListItemLayout.Content>
                            <ListItemLayout.Slot>
                                <Check className={cx("text-primary")} />
                            </ListItemLayout.Slot>
                        </ListItemLayout.Root>
                    );
                }}
            />
            <Menu.Item disabled>Unavailable (disabled)</Menu.Item>
        </MenuPlayground>
    ),
};

export const CustomContent: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item
          render={(itemProps, state) => (
              <ListItemLayout.Root {...itemProps} disabled={state.disabled}>
                <ListItemLayout.Slot>
                  <AddressDot className={cx("text-positive-primary")} />
                </ListItemLayout.Slot>
                <ListItemLayout.Content>
                <TypographyStack>
                  <TypographyStack.Primary>Available</TypographyStack.Primary>
                </TypographyStack>
              </ListItemLayout.Content>
            </ListItemLayout.Root>
          )}
        />
        <Menu.Item
          render={(itemProps, state) => (
              <ListItemLayout.Root {...itemProps} disabled={state.disabled}>
                <ListItemLayout.Slot>
                  <AddressDot className={cx("text-warning-primary")} />
                </ListItemLayout.Slot>
                <ListItemLayout.Content>
                <TypographyStack>
                  <TypographyStack.Primary>Busy</TypographyStack.Primary>
                </TypographyStack>
                </ListItemLayout.Content>
                <ListItemLayout.Slot>
                  <HeartOutlined className={cx("text-tertiary")} />
                </ListItemLayout.Slot>
              </ListItemLayout.Root>
            )}
        />
        <Menu.Item
          render={(itemProps, state) => (
            <ListItemLayout.Root {...itemProps} disabled={state.disabled}>
              <ListItemLayout.Slot>
                <AddressDot className={cx("text-danger-secondary")} />
              </ListItemLayout.Slot>
              <ListItemLayout.Content>
                <TypographyStack>
                  <TypographyStack.Primary>Offline</TypographyStack.Primary>
                </TypographyStack>
              </ListItemLayout.Content>
              <ListItemLayout.Slot>
                <Heart className={cx("text-danger-secondary")} />
              </ListItemLayout.Slot>
            </ListItemLayout.Root>
          )}
        />
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item
                render={(itemProps, state) => (
                    <ListItemLayout.Root {...itemProps} disabled={state.disabled}>
                        <ListItemLayout.Slot>
                            <AddressDot className={cx("text-positive-primary")} />
                        </ListItemLayout.Slot>
                        <ListItemLayout.Content>
                            <TypographyStack>
                                <TypographyStack.Primary>Available</TypographyStack.Primary>
                            </TypographyStack>
                        </ListItemLayout.Content>
                    </ListItemLayout.Root>
                )}
            />
            <Menu.Item
                render={(itemProps, state) => (
                    <ListItemLayout.Root {...itemProps} disabled={state.disabled}>
                        <ListItemLayout.Slot>
                            <AddressDot className={cx("text-warning-primary")} />
                        </ListItemLayout.Slot>
                        <ListItemLayout.Content>
                            <TypographyStack>
                                <TypographyStack.Primary>Busy</TypographyStack.Primary>
                            </TypographyStack>
                        </ListItemLayout.Content>
                        <ListItemLayout.Slot>
                            <HeartOutlined className={cx("text-tertiary")} />
                        </ListItemLayout.Slot>
                    </ListItemLayout.Root>
                )}
            />
            <Menu.Item
                render={(itemProps, state) => (
                    <ListItemLayout.Root {...itemProps} disabled={state.disabled}>
                        <ListItemLayout.Slot>
                            <AddressDot className={cx("text-danger-secondary")} />
                        </ListItemLayout.Slot>
                        <ListItemLayout.Content>
                            <TypographyStack>
                                <TypographyStack.Primary>Offline</TypographyStack.Primary>
                            </TypographyStack>
                        </ListItemLayout.Content>
                        <ListItemLayout.Slot>
                            <Heart className={cx("text-danger-secondary")} />
                        </ListItemLayout.Slot>
                    </ListItemLayout.Root>
                )}
            />
        </MenuPlayground>
    ),
};

export const Description: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item>
          <ListItemLayout.Content>
            <TypographyStack>
              <TypographyStack.Primary>Resolved</TypographyStack.Primary>
              <TypographyStack.Secondary>User confirmed the fix</TypographyStack.Secondary>
            </TypographyStack>
          </ListItemLayout.Content>
          <ListItemLayout.Slot>
            <Check className={cx("text-primary")} />
          </ListItemLayout.Slot>
        </Menu.Item>
        <Menu.Item>
          <ListItemLayout.Content>
            <TypographyStack>
              <TypographyStack.Primary>Pending</TypographyStack.Primary>
              <TypographyStack.Secondary>Waiting on customer details</TypographyStack.Secondary>
            </TypographyStack>
          </ListItemLayout.Content>
        </Menu.Item>
        <Menu.Item>
          <ListItemLayout.Content>
            <TypographyStack>
              <TypographyStack.Primary>On hold</TypographyStack.Primary>
              <TypographyStack.Secondary>Paused for internal review</TypographyStack.Secondary>
            </TypographyStack>
          </ListItemLayout.Content>
        </Menu.Item>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item>
                <ListItemLayout.Content>
                    <TypographyStack>
                        <TypographyStack.Primary>Resolved</TypographyStack.Primary>
                        <TypographyStack.Secondary>User confirmed the fix</TypographyStack.Secondary>
                    </TypographyStack>
                </ListItemLayout.Content>
                <ListItemLayout.Slot>
                    <Check className={cx("text-primary")} />
                </ListItemLayout.Slot>
            </Menu.Item>
            <Menu.Item>
                <ListItemLayout.Content>
                    <TypographyStack>
                        <TypographyStack.Primary>Pending</TypographyStack.Primary>
                        <TypographyStack.Secondary>Waiting on customer details</TypographyStack.Secondary>
                    </TypographyStack>
                </ListItemLayout.Content>
            </Menu.Item>
            <Menu.Item>
                <ListItemLayout.Content>
                    <TypographyStack>
                        <TypographyStack.Primary>On hold</TypographyStack.Primary>
                        <TypographyStack.Secondary>Paused for internal review</TypographyStack.Secondary>
                    </TypographyStack>
                </ListItemLayout.Content>
            </Menu.Item>
        </MenuPlayground>
    ),
};

export const Divider: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item>Profile</Menu.Item>
        <Menu.Item>Billing</Menu.Item>
        <Menu.Separator />
        <Menu.Item>Sign out</Menu.Item>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item>Profile</Menu.Item>
            <Menu.Item>Billing</Menu.Item>
            <Menu.Separator />
            <Menu.Item>Sign out</Menu.Item>
        </MenuPlayground>
    ),
};

export const Links: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item>Help center</Menu.Item>
        <Menu.Item>What's new</Menu.Item>
        <Menu.Item
          render={(itemProps, state) => (
            <ListItemLayout.Root
              {...itemProps}
              disabled={state.disabled}
              render={<a href="https://bolt.eu/en/careers" target="_blank" rel="noreferrer" />}
            >
              <ListItemLayout.Content>
                <span>Careers</span>
              </ListItemLayout.Content>
              <ListItemLayout.Slot>
                <OpenIn className={cx("text-primary")} />
              </ListItemLayout.Slot>
              </ListItemLayout.Root>
            )}
        />
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item>Help center</Menu.Item>
            <Menu.Item>What&apos;s new</Menu.Item>
            <Menu.Item
                render={(itemProps, state) => (
                    <ListItemLayout.Root
                        {...itemProps}
                        disabled={state.disabled}
                        render={<a href="https://bolt.eu/en/careers" target="_blank" rel="noreferrer" />}
                    >
                        <ListItemLayout.Content>
                            <span>Careers</span>
                        </ListItemLayout.Content>
                        <ListItemLayout.Slot>
                            <OpenIn className={cx("text-primary")} />
                        </ListItemLayout.Slot>
                    </ListItemLayout.Root>
                )}
            />
        </MenuPlayground>
    ),
};

export const Disabled: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item>Duplicate</Menu.Item>
        <Menu.Item>Move to folder</Menu.Item>
        <Menu.Item disabled>Delete workspace (disabled)</Menu.Item>
        <Menu.Item>Rename</Menu.Item>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item>Duplicate</Menu.Item>
            <Menu.Item>Move to folder</Menu.Item>
            <Menu.Item disabled>Delete workspace (disabled)</Menu.Item>
            <Menu.Item>Rename</Menu.Item>
        </MenuPlayground>
    ),
};

export const Overflows: MenuStory = {
    ...withSource(
        `
<div className="flex gap-4">
  <Menu.Root>
    <Menu.Trigger
      aria-label="Open menu"
      render={(triggerProps) => {
        const {ref, ...rest} = triggerProps;
        return (
          <Button {...rest} ref={ref} variant="tertiary">
            Open menu
          </Button>
        );
      }}
    />
    <Menu.Portal>
      <Menu.Positioner>
        <Menu.Popup className="w-60">
          <Menu.Item>Label</Menu.Item>
          <Menu.Item>Another label</Menu.Item>
        <Menu.Item>
          <ListItemLayout.Content className="min-w-0">
            <TypographyStack>
              <TypographyStack.Primary lines={1}>
                Long label that does not seem to fit
              </TypographyStack.Primary>
            </TypographyStack>
          </ListItemLayout.Content>
        </Menu.Item>
        </Menu.Popup>
      </Menu.Positioner>
    </Menu.Portal>
  </Menu.Root>
  <Menu.Root>
    <Menu.Trigger
      aria-label="Open menu"
      render={(triggerProps) => {
        const {ref, ...rest} = triggerProps;
        return (
          <Button {...rest} ref={ref} variant="tertiary">
            Open menu
          </Button>
        );
      }}
    />
    <Menu.Portal>
      <Menu.Positioner>
        <Menu.Popup className="w-60">
          <Menu.Item>
            <TypographyStack>
              <TypographyStack.Primary>Long label that does not seem to fit</TypographyStack.Primary>
              <TypographyStack.Secondary>Wraps to a second line</TypographyStack.Secondary>
            </TypographyStack>
          </Menu.Item>
        </Menu.Popup>
      </Menu.Positioner>
    </Menu.Portal>
  </Menu.Root>
</div>
    `.trim(),
    ),
    render: () => (
        <div className="flex gap-4">
            <MenuPlayground popupClassName="w-60">
                <Menu.Item>Label</Menu.Item>
                <Menu.Item>Another label</Menu.Item>
                <Menu.Item>
                    <ListItemLayout.Content className="min-w-0">
                        <TypographyStack>
                            <TypographyStack.Primary lines={1}>
                                Long label that does not seem to fit
                            </TypographyStack.Primary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                </Menu.Item>
            </MenuPlayground>
            <MenuPlayground popupClassName="w-60">
                <Menu.Item>
                    <TypographyStack>
                        <TypographyStack.Primary>Long label that does not seem to fit</TypographyStack.Primary>
                        <TypographyStack.Secondary>Wraps to a second line</TypographyStack.Secondary>
                    </TypographyStack>
                </Menu.Item>
            </MenuPlayground>
        </div>
    ),
};

export const Submenu: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item>Profile</Menu.Item>
        <Menu.SubmenuRoot>
          <Menu.SubmenuTrigger
            render={(triggerProps, state) => (
              <ListItemLayout.Root {...triggerProps} disabled={state.disabled}>
                <ListItemLayout.Content>
                  <span>Workspace settings</span>
                </ListItemLayout.Content>
                <ListItemLayout.Slot>
                  <ChevronRight
                    className={cx("shrink-0 rtl:rotate-180")}
                    size="md"
                  />
                </ListItemLayout.Slot>
              </ListItemLayout.Root>
            )}
          />
          <Menu.Portal>
            <Menu.Positioner alignOffset={-8}>
              <Menu.Popup className="w-60">
                <Menu.Item>Members</Menu.Item>
                <Menu.Item>Billing</Menu.Item>
                <Menu.Item>Security</Menu.Item>
              </Menu.Popup>
            </Menu.Positioner>
          </Menu.Portal>
        </Menu.SubmenuRoot>
        <Menu.Item>Help</Menu.Item>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item>Profile</Menu.Item>
            <Menu.SubmenuRoot>
                <Menu.SubmenuTrigger
                    render={(triggerProps, state) => (
                        <ListItemLayout.Root {...triggerProps} disabled={state.disabled}>
                            <ListItemLayout.Content>
                                <span>Workspace settings</span>
                            </ListItemLayout.Content>
                            <ListItemLayout.Slot>
                                <ChevronRight
                                    className={cx(`
                                      shrink-0
                                      rtl:rotate-180
                                    `)}
                                    size="md"
                                />
                            </ListItemLayout.Slot>
                        </ListItemLayout.Root>
                    )}
                />
                <Menu.Portal>
                    <Menu.Positioner alignOffset={-8}>
                        <Menu.Popup className="w-60">
                            <Menu.Item>Members</Menu.Item>
                            <Menu.Item>Billing</Menu.Item>
                            <Menu.Item>Security</Menu.Item>
                        </Menu.Popup>
                    </Menu.Positioner>
                </Menu.Portal>
            </Menu.SubmenuRoot>
            <Menu.Item>Help</Menu.Item>
        </MenuPlayground>
    ),
};

export const CustomHeader: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Group>
          <Menu.GroupLabel>Status</Menu.GroupLabel>
          <Menu.Item>Available</Menu.Item>
          <Menu.Item>Do not disturb</Menu.Item>
        </Menu.Group>
        <Menu.Separator />
        <Menu.Item>Sign out</Menu.Item>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Group>
                <Menu.GroupLabel>Status</Menu.GroupLabel>
                <Menu.Item>Available</Menu.Item>
                <Menu.Item>Do not disturb</Menu.Item>
            </Menu.Group>
            <Menu.Separator />
            <Menu.Item>Sign out</Menu.Item>
        </MenuPlayground>
    ),
};

export const Hoverable: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    openOnHover
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item>Quick actions</Menu.Item>
        <Menu.Item>New request</Menu.Item>
        <Menu.Item>View queue</Menu.Item>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground triggerProps={{openOnHover: true}}>
            <Menu.Item>Quick actions</Menu.Item>
            <Menu.Item>New request</Menu.Item>
            <Menu.Item>View queue</Menu.Item>
        </MenuPlayground>
    ),
};

export const Controlled: MenuStory = {
    ...withSource(
        `
const [open, setOpen] = React.useState(false);

return (
  <Menu.Root open={open} onOpenChange={setOpen}>
    <Menu.Trigger
      aria-label="Open menu"
      render={(triggerProps) => {
        const {ref, ...rest} = triggerProps;
        return (
          <Button {...rest} ref={ref} variant="tertiary">
            Open menu
          </Button>
        );
      }}
    />
    <Menu.Portal>
      <Menu.Positioner>
        <Menu.Popup>
          <Menu.Item>Download report</Menu.Item>
          <Menu.Item>Export CSV</Menu.Item>
          <Menu.Item>Schedule delivery</Menu.Item>
        </Menu.Popup>
      </Menu.Positioner>
    </Menu.Portal>
  </Menu.Root>
);
    `.trim(),
    ),
    render: () => {
        const [open, setOpen] = React.useState(false);

        return (
            <MenuPlayground rootProps={{open, onOpenChange: setOpen}}>
                <Menu.Item>Download report</Menu.Item>
                <Menu.Item>Export CSV</Menu.Item>
                <Menu.Item>Schedule delivery</Menu.Item>
            </MenuPlayground>
        );
    },
};

export const Accessibility: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item>Invite teammate</Menu.Item>
        <Menu.Item>Manage permissions</Menu.Item>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item>Invite teammate</Menu.Item>
            <Menu.Item>Manage permissions</Menu.Item>
        </MenuPlayground>
    ),
    play: async ({canvasElement}) => {
        const canvas = within(canvasElement.parentNode as HTMLElement);
        const trigger = await canvas.findByRole("button", {name: "Open menu"});

        await userEvent.tab();
        await userEvent.keyboard("[Enter]");

        await expect(await canvas.findByText(/invite teammate/i)).toBeInTheDocument();
        await expect(trigger).toBeInTheDocument();
    },
};

export const CustomMenuItems: MenuStory = {
    ...withSource(
        `
<Menu.Root>
  <Menu.Trigger
    aria-label="Open menu"
    render={(triggerProps) => {
      const {ref, ...rest} = triggerProps;
      return (
        <Button {...rest} ref={ref} variant="tertiary">
          Open menu
        </Button>
      );
    }}
  />
  <Menu.Portal>
    <Menu.Positioner>
      <Menu.Popup>
        <Menu.Item
          render={(itemProps, state) => (
            <ListItemLayout.Root
              {...itemProps}
              disabled={state.disabled}
              render={<a href="/?path=/story/baseui-playground-menu--custom-menu-items/profile" />}
            >
              <ListItemLayout.Content>
                <TypographyStack>
                  <TypographyStack.Primary>Profile</TypographyStack.Primary>
                  <TypographyStack.Secondary>View and edit personal details</TypographyStack.Secondary>
                </TypographyStack>
              </ListItemLayout.Content>
            </ListItemLayout.Root>
          )}
        />
        <Menu.SubmenuRoot>
          <Menu.SubmenuTrigger>
            <ListItemLayout.Content>
              <TypographyStack>
                <TypographyStack.Primary>Directory</TypographyStack.Primary>
                <TypographyStack.Secondary>People and teams</TypographyStack.Secondary>
              </TypographyStack>
            </ListItemLayout.Content>
            <ListItemLayout.Slot>
              <ChevronRight className="shrink-0 rtl:rotate-180" size="md" />
            </ListItemLayout.Slot>
          </Menu.SubmenuTrigger>
          <Menu.Portal>
            <Menu.Positioner alignOffset={-8}>
              <Menu.Popup>
                <Menu.Item
                  render={(itemProps, state) => (
                    <ListItemLayout.Root
                      {...itemProps}
                      disabled={state.disabled}
                      render={<a href="/?path=/story/baseui-playground-menu--custom-menu-items/suppliers" />}
                    >
                      <ListItemLayout.Content>Suppliers</ListItemLayout.Content>
                    </ListItemLayout.Root>
                  )}
                />
                <Menu.Item
                  render={(itemProps, state) => (
                    <ListItemLayout.Root
                      {...itemProps}
                      disabled={state.disabled}
                      render={<a href="/?path=/story/baseui-playground-menu--custom-menu-items/users" />}
                    >
                      <ListItemLayout.Content>Users</ListItemLayout.Content>
                    </ListItemLayout.Root>
                  )}
                />
                <Menu.Item
                  render={(itemProps, state) => (
                    <ListItemLayout.Root
                      {...itemProps}
                      disabled={state.disabled}
                      render={<a href="/?path=/story/baseui-playground-menu--custom-menu-items/logout" />}
                    >
                      <ListItemLayout.Content>Log out</ListItemLayout.Content>
                      <ListItemLayout.Slot>
                        <LogOut />
                      </ListItemLayout.Slot>
                    </ListItemLayout.Root>
                  )}
                />
              </Menu.Popup>
            </Menu.Positioner>
          </Menu.Portal>
        </Menu.SubmenuRoot>
      </Menu.Popup>
    </Menu.Positioner>
  </Menu.Portal>
</Menu.Root>
    `.trim(),
    ),
    render: () => (
        <MenuPlayground>
            <Menu.Item
                render={(itemProps, state) => (
                    <ListItemLayout.Root
                        {...itemProps}
                        disabled={state.disabled}
                        render={<a href="/?path=/story/baseui-playground-menu--custom-menu-items/profile" />}
                    >
                        <ListItemLayout.Content>
                            <TypographyStack>
                                <TypographyStack.Primary>Profile</TypographyStack.Primary>
                                <TypographyStack.Secondary>View and edit personal details</TypographyStack.Secondary>
                            </TypographyStack>
                        </ListItemLayout.Content>
                    </ListItemLayout.Root>
                )}
            />
            <Menu.SubmenuRoot>
                <Menu.SubmenuTrigger>
                    <ListItemLayout.Content>
                        <TypographyStack>
                            <TypographyStack.Primary>Directory</TypographyStack.Primary>
                            <TypographyStack.Secondary>People and teams</TypographyStack.Secondary>
                        </TypographyStack>
                    </ListItemLayout.Content>
                    <ListItemLayout.Slot>
                        <ChevronRight
                            className={cx(`
                              shrink-0
                              rtl:rotate-180
                            `)}
                            size="md"
                        />
                    </ListItemLayout.Slot>
                </Menu.SubmenuTrigger>
                <Menu.Portal>
                    <Menu.Positioner alignOffset={-8}>
                        <Menu.Popup>
                            <Menu.Item
                                render={(itemProps, state) => (
                                    <ListItemLayout.Root
                                        {...itemProps}
                                        disabled={state.disabled}
                                        render={
                                            <a href="/?path=/story/baseui-playground-menu--custom-menu-items/suppliers" />
                                        }
                                    >
                                        <ListItemLayout.Content>Suppliers</ListItemLayout.Content>
                                    </ListItemLayout.Root>
                                )}
                            />
                            <Menu.Item
                                render={(itemProps, state) => (
                                    <ListItemLayout.Root
                                        {...itemProps}
                                        disabled={state.disabled}
                                        render={
                                            <a href="/?path=/story/baseui-playground-menu--custom-menu-items/users" />
                                        }
                                    >
                                        <ListItemLayout.Content>Users</ListItemLayout.Content>
                                    </ListItemLayout.Root>
                                )}
                            />
                            <Menu.Item
                                render={(itemProps, state) => (
                                    <ListItemLayout.Root
                                        {...itemProps}
                                        disabled={state.disabled}
                                        render={
                                            <a href="/?path=/story/baseui-playground-menu--custom-menu-items/logout" />
                                        }
                                    >
                                        <ListItemLayout.Content>Log out</ListItemLayout.Content>
                                        <ListItemLayout.Slot>
                                            <LogOut />
                                        </ListItemLayout.Slot>
                                    </ListItemLayout.Root>
                                )}
                            />
                        </Menu.Popup>
                    </Menu.Positioner>
                </Menu.Portal>
            </Menu.SubmenuRoot>
        </MenuPlayground>
    ),
};
