import * as React from "react";

import {Menu as BaseUIMenu} from "@base-ui/react/menu";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Menu.Separator
 * Visual divider between groups of menu items.
 *
 * ```tsx
 * <Menu.Separator />
 * ```
 */
export const MenuSeparator = React.forwardRef(function MenuSeparator(
    props: BaseUIMenu.Separator.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getSeparatorClassNames = React.useCallback(
        (state: BaseUIMenu.Separator.State) => cx("h-px bg-neutral-secondary", addConsumerClasses(state, className)),
        [className],
    );

    return <BaseUIMenu.Separator {...rest} className={getSeparatorClassNames} ref={forwardedRef} />;
});
