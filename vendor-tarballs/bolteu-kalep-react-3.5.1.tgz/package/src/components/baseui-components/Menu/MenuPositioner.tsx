import * as React from "react";

import {Menu as BaseUIMenu} from "@base-ui/react/menu";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Menu.Positioner
 * Positions the menu popup relative to the trigger.
 *
 * ```tsx
 * <Menu.Positioner>
 *   <Menu.Popup />
 * </Menu.Positioner>
 * ```
 */

const DEFAULT_SIDE_OFFSET = 4;
export const MenuPositioner = React.forwardRef(function MenuPositioner(
    props: BaseUIMenu.Positioner.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, align = "start", sideOffset = DEFAULT_SIDE_OFFSET, ...rest} = props;

    const getPositionerClassNames = React.useCallback(
        (state: BaseUIMenu.Positioner.State) => cx("outline-none", addConsumerClasses(state, className)),
        [className],
    );

    return (
        <BaseUIMenu.Positioner
            sideOffset={sideOffset}
            align={align}
            {...rest}
            className={getPositionerClassNames}
            ref={forwardedRef}
        />
    );
});
