import type {Menu as BaseUIMenu} from "@base-ui/react";

import {cx} from "@/helpers/utils/cx";

export function getItemDefaultClassNames(state: BaseUIMenu.Item.State | BaseUIMenu.SubmenuTrigger.State) {
    return cx(
        "bolt-font-body-m-regular text-left no-underline outline-none",
        "transition-colors duration-100 ease-linear",
        {
            "cursor-not-allowed text-secondary": state.disabled,
            "cursor-pointer text-primary": !state.disabled,
            "bg-neutral-secondary": state.highlighted,
        },
    );
}
