import * as React from "react";

import {Menu as BaseUIMenu} from "@base-ui/react/menu";

import {addConsumerClasses} from "@/components/baseui-components/utils/combine-classes";
import {cx} from "@/helpers/utils/cx";

/**
 * ### Menu.Popup
 * Floating surface that renders menu content.
 *
 * ```tsx
 * <Menu.Popup>...</Menu.Popup>
 * ```
 */
export const MenuPopup = React.forwardRef(function MenuPopup(
    props: BaseUIMenu.Popup.Props,
    forwardedRef: React.ForwardedRef<HTMLDivElement>,
) {
    const {className, ...rest} = props;

    const getPopupClassNames = React.useCallback(
        (state: BaseUIMenu.Popup.State) =>
            cx(
                `
                  z-dropdown max-h-80 w-80 select-none overflow-auto rounded-md bg-layer-floor-2 px-0 py-2 text-primary
                  shadow-lg outline-none
                `,
                addConsumerClasses(state, className),
            ),
        [className],
    );

    return <BaseUIMenu.Popup {...rest} className={getPopupClassNames} ref={forwardedRef} />;
});
