import {Menu as BaseUIMenu} from "@base-ui/react/menu";

import {MenuGroup} from "./MenuGroup";
import {MenuGroupLabel} from "./MenuGroupLabel";
import {MenuItem} from "./MenuItem";
import {MenuPopup} from "./MenuPopup";
import {MenuPortal} from "./MenuPortal";
import {MenuPositioner} from "./MenuPositioner";
import {MenuRoot} from "./MenuRoot";
import {MenuSeparator} from "./MenuSeparator";
import {MenuSubmenuRoot} from "./MenuSubmenuRoot";
import {MenuSubmenuTrigger} from "./MenuSubmenuTrigger";
import {MenuTrigger} from "./MenuTrigger";

/**
 * Menu compound component built on Base UI primitives.
 *
 * ### Composition guide
 * ```tsx
 * <Menu.Root>
 *   <Menu.Trigger
 *     render={({ref, ...triggerProps}) => (
 *       <Button {...triggerProps} ref={ref} variant="tertiary">
 *         Open menu
 *       </Button>
 *     )}
 *   />
 *   <Menu.Portal>
 *     <Menu.Positioner sideOffset={4}>
 *       <Menu.Popup>
 *         <Menu.Item>First action</Menu.Item>
 *         <Menu.Item>Second action</Menu.Item>
 *         <Menu.Separator />
 *         <Menu.Item disabled>Disabled action</Menu.Item>
 *         <Menu.SubmenuRoot>
 *           <Menu.SubmenuTrigger>
 *             <span>More actions</span>
 *             <ChevronRight className="shrink-0 rtl:rotate-180" size="md" />
 *           </Menu.SubmenuTrigger>
 *           <Menu.Portal>
 *             <Menu.Positioner sideOffset={4} alignOffset={-8}>
 *               <Menu.Popup>
 *                 <Menu.Item>Sub action</Menu.Item>
 *               </Menu.Popup>
 *             </Menu.Positioner>
 *           </Menu.Portal>
 *         </Menu.SubmenuRoot>
 *       </Menu.Popup>
 *     </Menu.Positioner>
 *   </Menu.Portal>
 * </Menu.Root>
 * ```
 *
 * Note: Only one submenu layer (child menu) should be used. Avoid nested submenus beyond a single level.
 */
export const Menu = {
    Root: MenuRoot,
    Trigger: MenuTrigger,
    Portal: MenuPortal,
    Positioner: MenuPositioner,
    Popup: MenuPopup,
    Item: MenuItem,
    Separator: MenuSeparator,
    Group: MenuGroup,
    GroupLabel: MenuGroupLabel,
    SubmenuRoot: MenuSubmenuRoot,
    SubmenuTrigger: MenuSubmenuTrigger,
    createHandle: BaseUIMenu.createHandle,
};

// Components without render implementation by typings not allowing displayName assignment
Object.assign(Menu.Root, {displayName: "Menu.Root"});
Object.assign(Menu.SubmenuRoot, {displayName: "Menu.SubmenuRoot"});

Menu.Trigger.displayName = "Menu.Trigger";
Menu.Portal.displayName = "Menu.Portal";
Menu.Positioner.displayName = "Menu.Positioner";
Menu.Popup.displayName = "Menu.Popup";
Menu.Item.displayName = "Menu.Item";
Menu.Separator.displayName = "Menu.Separator";
Menu.Group.displayName = "Menu.Group";
Menu.GroupLabel.displayName = "Menu.GroupLabel";
Menu.SubmenuTrigger.displayName = "Menu.SubmenuTrigger";
