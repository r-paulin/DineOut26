import {Menu as BaseUIMenu} from "@base-ui/react/menu";

/**
 * Menu.Portal
 *
 * Portals menu overlays so popups render above surrounding layout and overflow contexts.
 */
export const MenuPortal = BaseUIMenu.Portal;
