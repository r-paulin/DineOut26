import * as React from "react";

import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Menu} from "../index";

const menuItems = ["Foo", "Bar"];

function renderMenu({
    rootProps,
    triggerProps,
}: {
    rootProps?: React.ComponentProps<typeof Menu.Root>;
    triggerProps?: React.ComponentProps<typeof Menu.Trigger>;
} = {}) {
    return render(
        <Menu.Root {...rootProps}>
            <Menu.Trigger {...triggerProps}>Open menu</Menu.Trigger>
            <Menu.Portal>
                <Menu.Positioner>
                    <Menu.Popup>
                        {menuItems.map((item) => (
                            <Menu.Item key={item}>{item}</Menu.Item>
                        ))}
                    </Menu.Popup>
                </Menu.Positioner>
            </Menu.Portal>
        </Menu.Root>,
    );
}

describe("Menu", () => {
    test("renders trigger and closed menu", () => {
        renderMenu();
        expect(screen.getByRole("button", {name: "Open menu"})).toBeInTheDocument();
        expect(screen.queryByText("Foo")).not.toBeInTheDocument();
    });

    test("opens menu items upon clicking trigger", async () => {
        renderMenu();
        const user = userEvent.setup();

        await user.click(screen.getByRole("button", {name: "Open menu"}));

        expect(screen.getByText("Foo")).toBeInTheDocument();
        expect(screen.getByText("Bar")).toBeInTheDocument();
    });

    test("opens menu items using keyboard", async () => {
        renderMenu();
        const user = userEvent.setup();

        await user.tab();
        await user.keyboard("[Enter]");

        expect(screen.getByText("Foo")).toBeInTheDocument();
    });

    test("opens menu items on hover", async () => {
        renderMenu({triggerProps: {openOnHover: true}});
        const user = userEvent.setup();

        await user.hover(screen.getByRole("button", {name: "Open menu"}));

        expect(screen.getByText("Foo")).toBeInTheDocument();
        expect(screen.getByText("Bar")).toBeInTheDocument();
    });

    test("handles item click event", async () => {
        const onClick = vi.fn();
        render(
            <Menu.Root>
                <Menu.Trigger>Open menu</Menu.Trigger>
                <Menu.Portal>
                    <Menu.Positioner>
                        <Menu.Popup>
                            <Menu.Item onClick={onClick}>Foo</Menu.Item>
                        </Menu.Popup>
                    </Menu.Positioner>
                </Menu.Portal>
            </Menu.Root>,
        );

        const user = userEvent.setup();
        await user.click(screen.getByRole("button", {name: "Open menu"}));
        await user.click(screen.getByText("Foo"));

        expect(onClick).toHaveBeenCalledTimes(1);
    });
});
