import * as React from "react";

import HideIcon from "@bolteu/kalep-react-icons/dist/Hide";
import ShowIcon from "@bolteu/kalep-react-icons/dist/Show";

import {Tooltip} from "@/components/Tooltip";
import {cx} from "@/helpers/utils/cx";

import {BaseTextField} from "./BaseTextField";
import type {TextFieldProps} from "./index";
import type {TextFieldRenderProps} from "./TextField.types";

export const DEFAULT_SHOW_PASSWORD_ARIA_LABEL = "Toggle Password Visibility";

export const PasswordTextField = React.forwardRef<HTMLInputElement, TextFieldProps>(
    (
        {renderEndSlot: renderEndSlotProp, showPasswordLabel = DEFAULT_SHOW_PASSWORD_ARIA_LABEL, ...baseTextFieldProps},
        ref,
    ): JSX.Element => {
        const [shouldShowPassword, setShouldShowPassword] = React.useState(false);

        const handleShowPasswordButtonClick = React.useCallback(
            function toggleShowPassword() {
                setShouldShowPassword(!shouldShowPassword);
            },
            [shouldShowPassword],
        );

        const renderEndSlot = React.useCallback(
            function endSlotRenderer(props: TextFieldRenderProps) {
                function renderEndSlotDefault(propsForRender: TextFieldRenderProps) {
                    const iconSize = propsForRender.size === "sm" ? "sm" : "lg";
                    const Icon = shouldShowPassword ? HideIcon : ShowIcon;

                    return (
                        <Tooltip content={propsForRender.showPasswordLabel ?? ""}>
                            <button
                                aria-checked={shouldShowPassword}
                                aria-label={propsForRender.showPasswordLabel}
                                className={cx("cursor-pointer border-0 bg-transparent p-2 text-tertiary")}
                                onClick={handleShowPasswordButtonClick}
                                role="switch"
                                type="button"
                            >
                                <Icon size={iconSize} className={cx("block")} />
                            </button>
                        </Tooltip>
                    );
                }

                return renderEndSlotProp ? renderEndSlotProp(props, renderEndSlotDefault) : renderEndSlotDefault(props);
            },
            [handleShowPasswordButtonClick, renderEndSlotProp, shouldShowPassword],
        );

        return (
            <BaseTextField
                {...baseTextFieldProps}
                ref={ref}
                renderEndSlot={renderEndSlot}
                type={shouldShowPassword ? "text" : "password"}
                showPasswordLabel={showPasswordLabel}
            />
        );
    },
);
PasswordTextField.displayName = "PasswordTextField";
