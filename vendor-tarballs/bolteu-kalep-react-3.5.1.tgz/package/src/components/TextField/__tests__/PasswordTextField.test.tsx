import * as React from "react";

import {vi} from "vitest";

import Settings from "@bolteu/kalep-react-icons/dist/Settings";

import {DEFAULT_SHOW_PASSWORD_ARIA_LABEL} from "../PasswordTextField";
import {
    act,
    clickOnShowPasswordSwitch,
    getShowPasswordSwitch,
    renderTextField,
    screen,
    userEvent,
} from "./TextField.testUtils";

test("can render an input of type 'password'", function passwordInput() {
    const label = "Password";

    renderTextField({type: "password", label});

    const input = screen.getByLabelText(label, {selector: "[type='password']"});

    expect(input).toHaveAttribute("type", "password");
    expect(getShowPasswordSwitch()).toHaveAttribute("aria-checked", "false");
});

test("password input has a button to show the password when pressed", async function toggleShowPasswordToggle() {
    const user = userEvent.setup({delay: null});
    const label = "Password";

    renderTextField({type: "password", label});

    const input = screen.getByLabelText(label, {selector: "[type='password']"});
    const showPasswordSwitch = getShowPasswordSwitch();

    await user.unhover(showPasswordSwitch); // make sure it's not hovered.
    await user.hover(showPasswordSwitch);

    await screen.findByRole("tooltip", {name: DEFAULT_SHOW_PASSWORD_ARIA_LABEL});

    await act(async () => {
        await clickOnShowPasswordSwitch();
    });

    expect(input).toHaveAttribute("type", "text");
    expect(showPasswordSwitch).toHaveAttribute("aria-checked", "true");

    await act(async () => {
        await clickOnShowPasswordSwitch();
    });

    expect(input).toHaveAttribute("type", "password");
    expect(showPasswordSwitch).toHaveAttribute("aria-checked", "false");

    await user.click(input);
});

test("show password label can be customized", async function customShowPasswordLabel() {
    const user = userEvent.setup({delay: null});
    const showPasswordLabel = "show me everything";

    renderTextField({type: "password", showPasswordLabel});

    const showPasswordSwitch = getShowPasswordSwitch(showPasswordLabel);

    await user.hover(showPasswordSwitch);

    await screen.findByRole("tooltip", {name: showPasswordLabel});
});

test("end slot custom render", function helperTextRender() {
    const endSlotAriaLabel = "More options";
    const renderEndSlot = vi.fn().mockReturnValue(<Settings aria-label={endSlotAriaLabel} />);
    renderTextField({renderEndSlot, type: "password"});

    expect(screen.getByLabelText(endSlotAriaLabel)).toBeInTheDocument();
    expect(renderEndSlot).toHaveBeenCalledWith(
        expect.objectContaining({renderEndSlot: expect.any(Function)}),
        expect.any(Function),
    );
    expect(renderEndSlot).toHaveBeenCalledTimes(1);
});
