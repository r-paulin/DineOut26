import * as React from "react";

import Alert from "@bolteu/kalep-react-icons/dist/Alert";

import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";
import {mergeRefs} from "@/helpers/utils/mergeRefs";

import {renderHelperTextDefault} from "../_internal/HelperText";
import type {Size, State, TextFieldProps, TextFieldRenderProps} from "./TextField.types";

const sizes: Record<Size, string> = {
    sm: "h-9 px-2 bolt-font-body-s-regular gap-2",
    md: "h-12 px-3 bolt-font-body-m-regular gap-3",
    lg: "h-14 px-4 bolt-font-body-m-regular gap-3",
};

const states: Record<State, string> = {
    idle: "border-special-nulled focus-within:!border-action-primary text-primary",
    disabled: "border-neutral-secondary cursor-not-allowed text-tertiary bg-special-nulled",
    error: "border-danger-primary text-primary caret-danger-primary",
};

export const BaseTextField = React.forwardRef<HTMLInputElement, TextFieldProps>((props, forwardedRef) => {
    const {
        value,
        defaultValue,
        disabled = false,
        error = false,
        fullWidth = false,
        id,
        onChange,
        overrideClassName,
        onClick: onClickProp,
        prefix,
        renderHelperText = renderHelperTextDefault,
        renderEndSlot = renderEndSlotDefault,
        renderInput = renderInputDefault,
        renderLabel = renderLabelDefault,
        renderStartSlot = noop,
        size = "md",
        suffix,
        type = "text",
        inputWrapperRef,
        ...rest
    } = props;

    const generatedId = useId();
    const inputId = id ?? `kalep-text-field-${generatedId}`;
    const helperTextId = `${inputId}-helper-text`;
    const labelId = `${inputId}-label`;
    const suffixId = `${inputId}-suffix`;
    const prefixId = `${inputId}-prefix`;

    const internalRef = React.useRef<HTMLInputElement>();

    const renderProps: TextFieldRenderProps = {
        defaultValue,
        disabled,
        error,
        fullWidth,
        id,
        onChange,
        prefix,
        ref: mergeRefs([internalRef, forwardedRef]),
        renderHelperText,
        renderEndSlot,
        renderInput,
        renderLabel,
        renderStartSlot,
        size,
        suffix,
        type,
        value,
        helperTextId,
        prefixId,
        suffixId,
        inputId,
        labelId,
        ...rest,
    };

    const handleWrapperClick = React.useCallback(
        function clickHandler(event: React.MouseEvent<HTMLInputElement, MouseEvent>): void {
            if (internalRef?.current && document.activeElement !== internalRef.current) {
                internalRef.current.focus();
            }

            if (onClickProp) {
                onClickProp(event);
            }
        },
        [internalRef, onClickProp],
    );

    return (
        <div className={cx("flex flex-col gap-2", fullWidth ? "w-full" : "w-96")}>
            {renderLabel(renderProps, renderLabelDefault)}
            <div
                ref={inputWrapperRef}
                className={cx(
                    "flex w-full items-center justify-end",
                    "rounded-md border-2 border-solid",
                    "bg-neutral-secondary caret-action-primary",
                    "duration-100 ease-linear",
                    "focus-within:bg-special-nulled",
                    disabled ? "cursor-not-allowed" : "cursor-text",
                    disabled && states.disabled,
                    error && states.error,
                    !disabled && !error && states.idle,
                    sizes[size],
                    overrideClassName,
                )}
                role="presentation"
                data-testid="text-field-wrapper"
                onClick={handleWrapperClick}
            >
                {prefix ? (
                    <span className={cx("shrink-0", disabled ? "text-tertiary" : "text-secondary")} id={prefixId}>
                        {prefix}
                    </span>
                ) : null}
                {renderStartSlot(renderProps, noop)}
                {renderInput(renderProps, renderInputDefault)}
                {renderEndSlot(renderProps, renderEndSlotDefault)}
                {suffix ? (
                    <span className={cx("shrink-0", disabled ? "text-tertiary" : "text-secondary")} id={suffixId}>
                        {suffix}
                    </span>
                ) : null}
            </div>
            {renderHelperText(renderProps, renderHelperTextDefault)}
        </div>
    );
});
BaseTextField.displayName = "BaseTextField";

function renderEndSlotDefault({error, size}: TextFieldRenderProps) {
    return error ? (
        <Alert
            className={cx("flex-none text-danger-secondary")}
            aria-hidden="true"
            data-testid="textfield-error-icon"
            size={size === "sm" ? "sm" : "lg"}
        />
    ) : null;
}

function renderInputDefault({
    error = false,
    disabled,
    helperText,
    helperTextId,
    inputId,
    label,
    labelId,
    prefix,
    prefixId,
    suffix,
    suffixId,
    fullWidth: _fullWidth,
    clearTextLabel: _clearTextLabel,
    renderHelperText: _renderHelperText,
    renderEndSlot: _renderEndSlot,
    renderLabel: _renderLabel,
    renderInput: _renderInput,
    renderStartSlot: _renderStartSlot,
    showPasswordLabel: _showPasswordLabel,
    size: _size,
    ...inputProps
}: TextFieldRenderProps): JSX.Element {
    return (
        <input
            {...inputProps}
            disabled={disabled}
            aria-describedby={helperText ? helperTextId : undefined}
            aria-invalid={error}
            aria-labelledby={
                label || prefix || suffix
                    ? `${label ? labelId : ""} ${prefix ? prefixId : ""} ${suffix ? suffixId : ""}`
                    : undefined
            }
            className={cx(
                "m-0 border-0 border-solid p-0 outline-none",
                `
                  text-size-inherit
                  [color:inherit]
                `, // [color:inherit] is intentional to block twMerge from removing it.
                `
                  h-full w-full bg-transparent
                  disabled:cursor-not-allowed
                  input-clear-button:hidden
                `,
                disabled ? "placeholder-tertiary" : "placeholder-secondary",
            )}
            id={inputId}
        />
    );
}

function renderLabelDefault({inputId, label, labelId, required, disabled}: TextFieldRenderProps): JSX.Element | null {
    if (!label) {
        return null;
    }

    return (
        <label
            id={labelId}
            htmlFor={inputId}
            className={cx(
                "bolt-font-body-s-accent w-fit",
                disabled ? "text-tertiary" : "text-primary",
                required && "after:text-danger-primary after:content-['_*']",
            )}
        >
            {label}
        </label>
    );
}

function noop() {
    return null;
}
