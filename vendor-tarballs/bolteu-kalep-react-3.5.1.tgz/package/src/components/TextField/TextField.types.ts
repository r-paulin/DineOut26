import type * as React from "react";

import type {RenderFunction} from "@/helpers/types";

export type Size = "sm" | "md" | "lg";
export type State = "disabled" | "idle" | "error";
export type Type = "password" | "search" | "text" | "number" | "tel";

interface AriaProps {
    "aria-describedby"?: string;
    "aria-details"?: string;
    "aria-errormessage"?: string;
    "aria-label"?: string;
    "aria-labelledby"?: string;
    "aria-required"?: boolean;
}

interface DOMProps {
    autoCapitalize?: "none" | "off" | "sentences" | "on" | "words" | "characters";
    autoComplete?: string;
    autoFocus?: boolean;
    defaultValue?: string;
    disabled?: boolean;
    enterKeyHint?: "enter" | "done" | "go" | "next" | "previous" | "search" | "send";
    id?: string;
    inputMode?: "none" | "text" | "decimal" | "numeric" | "tel" | "search" | "email" | "url";
    max?: number | string;
    maxLength?: number;
    min?: number | string;
    minLength?: number;
    name?: string;
    pattern?: string;
    placeholder?: string;
    readOnly?: boolean;
    required?: boolean;
    step?: number | "any";
    tabIndex?: number;
}

interface TextInputEvents {
    onBlur?: React.FocusEventHandler<HTMLInputElement>;
    onChange?: React.ChangeEventHandler<HTMLInputElement>;
    onClick?: React.MouseEventHandler<HTMLInputElement>;
    onCopy?: React.ClipboardEventHandler<HTMLInputElement>;
    onCut?: React.ClipboardEventHandler<HTMLInputElement>;
    onFocus?: React.FocusEventHandler<HTMLInputElement>;
    onInput?: React.FormEventHandler<HTMLInputElement>;
    onKeyDown?: React.KeyboardEventHandler<HTMLInputElement>;
    onKeyUp?: React.KeyboardEventHandler<HTMLInputElement>;
    onPaste?: React.ClipboardEventHandler<HTMLInputElement>;
    onSelect?: React.ReactEventHandler<HTMLInputElement>;
}

/**
 * Additional refs that can be passed to TextField
 */
interface TextFieldRefs {
    inputWrapperRef?: React.Ref<HTMLDivElement>;
}

export interface TextFieldProps extends AriaProps, DOMProps, TextInputEvents, TextFieldRefs {
    clearTextLabel?: string;
    error?: boolean;
    fullWidth?: boolean;
    helperText?: React.ReactNode;
    label?: string;
    overrideClassName?: string;
    prefix?: string;
    renderEndSlot?: RenderFunction<TextFieldRenderProps>;
    renderHelperText?: RenderFunction<TextFieldRenderProps>;
    renderInput?: RenderFunction<TextFieldRenderProps>;
    renderLabel?: RenderFunction<TextFieldRenderProps>;
    renderStartSlot?: RenderFunction<TextFieldRenderProps>;
    showPasswordLabel?: string;
    size?: Size;
    suffix?: string;
    type?: Type;
    value?: string;
}

// Just TextField props, but made props with defaults non-optional.
export interface TextFieldRenderProps extends TextFieldProps {
    disabled: boolean;
    error: boolean;
    fullWidth: boolean;
    helperTextId: string;
    inputId: string;
    labelId: string;
    prefixId: string;
    ref: React.Ref<HTMLInputElement>;
    renderEndSlot: RenderFunction<TextFieldRenderProps>;
    renderHelperText: RenderFunction<TextFieldRenderProps>;
    renderInput: RenderFunction<TextFieldRenderProps>;
    renderLabel: RenderFunction<TextFieldRenderProps>;
    renderStartSlot: RenderFunction<TextFieldRenderProps>;
    size: Size;
    suffixId: string;
    type: Type;
}
