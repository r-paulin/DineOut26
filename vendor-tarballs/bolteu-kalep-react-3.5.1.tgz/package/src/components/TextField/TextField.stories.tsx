import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import Lock from "@bolteu/kalep-react-icons/dist/Lock";

import type {TextFieldProps} from "./index";
import {TextField} from "./index";

export default {
    title: "Inputs/TextField",
    component: TextField,
    tags: ["autodocs"],
    parameters: {
        controls: {
            exclude: ["onCut", "onCopy", "onPaste"],
        },
    },
    argTypes: {
        onClick: {
            control: false,
        },
        onChange: {
            control: false,
        },
        onInput: {
            control: false,
        },
        onFocus: {
            control: false,
        },
        onBlur: {
            control: false,
        },
        onKeyUp: {
            control: false,
        },
        onKeyDown: {
            control: false,
        },
        onSelect: {
            control: false,
        },
    },
} as Meta<typeof TextField>;

const Template: StoryFn<typeof TextField> = (args: TextFieldProps) => <TextField {...args} />;

export const Default = Template.bind({});
Default.args = {label: "Name", helperText: "Will be used to issue invoices.", placeholder: "Jane Doe", disabled: false};

export const Disabled = Template.bind({});
Disabled.args = {
    ...Default.args,
    value: "Can't touch this",
    disabled: true,
};

export const Error = Template.bind({});
Error.args = {
    ...Default.args,
    error: true,
};

export const PrefixAndSuffix = Template.bind({});
PrefixAndSuffix.args = {
    ...Default.args,
    placeholder: "",
    label: "Website",
    helperText: "Show off your work to the world!",
    prefix: "www.",
    suffix: ".com",
};

export const FullWidth = Template.bind({});
FullWidth.args = {
    ...Default.args,
    fullWidth: true,
};

export const Required = Template.bind({});
Required.args = {
    ...Default.args,
    required: true,
};

export const Password = Template.bind({});
Password.args = {
    ...Default.args,
    placeholder: "",
    label: "Password",
    helperText: "Your chosen password needs to be strong enough.",
    type: "password",
    showPasswordLabel: "Toggle Password Visibility",
};

export const Search = Template.bind({});
Search.args = {
    ...Default.args,
    label: "Search",
    helperText: "Order from your favorite place.",
    type: "search",
    clearTextLabel: "Clear Text",
    placeholder: "Restaurants or cuisines",
};

export const CustomHelperText = Template.bind({});
CustomHelperText.args = {
    label: "Password",
    helperText: "Your password is so strong right now.",
    type: "password",
    disabled: false,
    showPasswordLabel: "Toggle Password Visibility",
    renderHelperText(props, defaultRenderFunction) {
        return (
            <div className="flex items-center">
                <Lock className="text-action-primary" />
                {defaultRenderFunction(props)}
            </div>
        );
    },
};

export const WithoutLabel = Template.bind({});
WithoutLabel.args = {
    type: "search",
    disabled: false,
    placeholder: "Search",
    "aria-label": "Search input",
};

export const Controlled: StoryFn<typeof TextField> = (args: TextFieldProps) => {
    const [value, setValue] = React.useState("");
    const handleChange = React.useCallback((e: React.ChangeEvent<HTMLInputElement>) => setValue(e.target.value), []);

    return (
        <TextField
            {...args}
            onChange={handleChange}
            value={value}
            helperText={value ? `Will issue invoices for ${value}.` : "Will be used to issue invoices."}
        />
    );
};

Controlled.args = {
    ...Default.args,
};
Controlled.argTypes = {
    value: {
        control: {
            disable: true,
        },
    },
    helperText: {
        control: {
            disable: true,
        },
    },
};

export const ControlledSearch: StoryFn<typeof TextField> = (args: TextFieldProps) => {
    const [value, setValue] = React.useState("");
    const handleChange = React.useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        setValue(e.target.value);
    }, []);

    return <TextField {...args} onChange={handleChange} value={value} />;
};
ControlledSearch.args = {
    ...Default.args,
    type: "search",
    clearTextLabel: "Clear",
};
