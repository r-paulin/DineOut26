import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Switch} from "./Switch";

export default {
    title: "Inputs/Switch",
    component: Switch,
} as Meta<typeof Switch>;

const Template: StoryFn<typeof Switch> = (args) => <Switch {...args} />;

export const Default = Template.bind({});
Default.args = {label: "Developer mode"};

export const Disabled: StoryFn<typeof Switch> = () => {
    return (
        <div className="flex gap-4">
            <Switch disabled label="Developer mode" />
            <Switch disabled checked label="Developer mode" />
        </div>
    );
};

export const NoLabel: StoryFn<typeof Switch> = (args) => <Switch {...args} aria-label="Developer mode" />;
NoLabel.parameters = {
    docs: {
        description: {
            story: "If a visible label isn't specified, an `aria-label` must be provided to the Switch for accessibility. If the field is labeled by a separate element, an `aria-labelledby` prop must be provided using the id of the labeling element instead.",
        },
    },
};

export const Controlled = () => {
    const [isChecked, setIsChecked] = React.useState<boolean>(false);

    const handleChange = React.useCallback<React.ChangeEventHandler<HTMLInputElement>>(
        (e) => {
            setIsChecked(e.target.checked);
        },
        [setIsChecked],
    );

    return <Switch label="Developer mode" checked={isChecked} onChange={handleChange} />;
};
