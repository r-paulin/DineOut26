import * as React from "react";

import {vi} from "vitest";
import {render as testingLibraryRender, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import type {SwitchProps} from "../index";
import {Switch} from "../index";

function render(props: SwitchProps = {}) {
    const {rerender} = testingLibraryRender(<Switch {...props} />);
    return (propsOverride: Partial<SwitchProps>) => rerender(<Switch {...props} {...propsOverride} />);
}

describe("Switch test suite", () => {
    const testLabel = "foo-bar-baz";
    const id = "input-field-id";

    test("renders to document", () => {
        render({"aria-label": testLabel});
        expect(screen.getByRole("switch", {name: testLabel})).toBeInTheDocument();
    });

    test("label prop value is the associated label for underlying switch", () => {
        render({label: testLabel, id});
        expect(screen.getByLabelText(testLabel)).toHaveAttribute("id", id);
    });

    test("defaultChecked=true sets switch state to checked and allows unchecking", async () => {
        render({label: testLabel, defaultChecked: true});
        expect(screen.getByLabelText(testLabel)).toBeChecked();

        const user = userEvent.setup();
        await user.click(screen.getByLabelText(testLabel));
        expect(screen.getByLabelText(testLabel)).not.toBeChecked();
    });

    test("checked prop controls switch state", async () => {
        const rerender = render({label: testLabel, checked: false, readOnly: true});

        expect(screen.getByLabelText(testLabel)).not.toBeChecked();
        rerender({checked: true});
        expect(screen.getByLabelText(testLabel)).toBeChecked();
        rerender({checked: false});
        expect(screen.getByLabelText(testLabel)).not.toBeChecked();
    });

    test("controlled switch does not react to click", async () => {
        // it's given a mock onChange function that does nothing.
        render({label: testLabel, checked: false, onChange: vi.fn()});
        const user = userEvent.setup();
        await user.click(screen.getByLabelText(testLabel));
        expect(screen.getByLabelText(testLabel)).not.toBeChecked();
    });

    test("uncontrolled switch changes checked status on click", async () => {
        render({label: testLabel});
        const user = userEvent.setup();
        await user.click(screen.getByLabelText(testLabel));
        expect(screen.getByLabelText(testLabel)).toBeChecked();
    });

    test("uncontrolled switch focuses on tab and changes checked status with space", async () => {
        render({label: testLabel});
        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[Space]");
        expect(screen.getByLabelText(testLabel)).toBeChecked();
    });

    test("uncontrolled switch focuses on tab and changes checked status with enter", async () => {
        render({label: testLabel});
        const user = userEvent.setup();
        await user.tab();
        await user.keyboard("[Enter]");
        expect(screen.getByLabelText(testLabel)).toBeChecked();
    });

    test("disabled prop blocks switch", async () => {
        const user = userEvent.setup();

        const rerender = render({label: testLabel, disabled: true, checked: false});
        await user.click(screen.getByLabelText(testLabel));
        expect(screen.getByLabelText(testLabel)).not.toBeChecked();

        rerender({label: testLabel, disabled: true, checked: true});
        expect(screen.getByLabelText(testLabel)).toBeChecked();
    });

    test("onChange callback is triggered when uncontrolled", async () => {
        const onChange = vi.fn();
        const user = userEvent.setup();

        render({label: testLabel, onChange});

        await user.click(screen.getByLabelText(testLabel));
        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange.mock.calls[0][0].target.checked).toBe(true);
    });

    test("onChange callback is triggered when controlled", async () => {
        const onChange = vi.fn();
        const user = userEvent.setup();
        const isChecked = false;

        render({label: testLabel, onChange, checked: isChecked});

        await user.click(screen.getByLabelText(testLabel));
        expect(onChange).toHaveBeenCalledTimes(1);
        expect(onChange.mock.calls[0][0].target.checked).toBe(isChecked);
    });
});
