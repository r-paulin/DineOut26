import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import type {LinkProps} from "./Link";
import {Link} from "./Link";

export default {
    title: "Navigation/Link",
    tags: ["autodocs"],
    component: Link,
} as Meta<typeof Link>;

const Template: StoryFn<typeof Link> = (args) => <Link {...args} />;

export const Default = Template.bind({});
const args: LinkProps = {children: "Bolt Website", href: "https://bolt.eu/", target: "_self", rel: "noreferrer"};
Default.args = args;

export const External = Template.bind({});
const externalArgs: LinkProps = {
    children: "Bolt Website",
    href: "https://bolt.eu/",
    target: "_blank",
    rel: "noreferrer",
};
External.args = externalArgs;
External.parameters = {
    docs: {
        description: {
            story: "Links that specify `target='_blank'` are considered external and render a `↗` symbol at the end of the link label.",
        },
    },
};

export const Inline = () => {
    return (
        <div>
            <p className="font-sans">
                Have a look at the{" "}
                <Link href="https://bolt.eu/" target="_blank" rel="noreferrer">
                    Bolt website
                </Link>{" "}
                to gain more information.
            </p>
        </div>
    );
};
Inline.parameters = {
    docs: {
        description: {
            story: "Kalep assumes you provide inline contents as children for the `Link`, so you can render links inline with text as well.",
        },
    },
};
