import * as React from "react";

import {vi} from "vitest";

import BugIcon from "@bolteu/kalep-react-icons/dist/Bug";

import {DEFAULT_CLOSE_BUTTON_ARIA_LABEL} from "..";
import {defaultProps, renderAlert, screen, userEvent} from "./Alert.testUtils";

test("renders a default alert with content, icon and the status role", function alertRender() {
    renderAlert();

    expect(screen.getByRole("region", {name: defaultProps.children})).toBeInTheDocument();
    expect(screen.getByRole("status")).toHaveTextContent(defaultProps.children);
    expect(screen.getByRole("status")).toHaveAttribute("aria-live", "polite");
    expect(screen.getByTestId("alert-success-icon")).toHaveAttribute("aria-hidden", "true");
});

test("renders an alert with a title", function alertWithTitle() {
    const title = "Great News!";
    const regionLabel = `${title} ${defaultProps.children}`;

    renderAlert({title});

    expect(screen.getByRole("region", {name: regionLabel})).toBeInTheDocument();
    expect(screen.getByText(title)).toBeInTheDocument();
});

test("renders an error alert with content, icon and the alert role", function errorAlert() {
    renderAlert({severity: "error"});

    expect(screen.getByRole("alert")).toHaveTextContent(defaultProps.children);
    expect(screen.getByRole("alert")).toHaveAttribute("aria-live", "assertive");
    expect(screen.getByTestId("alert-error-icon")).toHaveAttribute("aria-hidden", "true");
});

test("renders a promotion alert with content, icon and the status role", function infoAlert() {
    renderAlert({severity: "promotion"});

    expect(screen.getByRole("status")).toHaveTextContent(defaultProps.children);
    expect(screen.getByRole("status")).toHaveAttribute("aria-live", "polite");
    expect(screen.getByTestId("alert-promotion-icon")).toHaveAttribute("aria-hidden", "true");
});

test("renders a warning alert with content, icon and the status role", function warningAlert() {
    renderAlert({severity: "warning"});

    expect(screen.getByRole("status")).toHaveTextContent(defaultProps.children);
    expect(screen.getByRole("status")).toHaveAttribute("aria-live", "polite");
    expect(screen.getByTestId("alert-warning-icon")).toHaveAttribute("aria-hidden", "true");
});

test("renders an info alert with content, icon and the status role", function warningAlert() {
    renderAlert({severity: "info"});

    expect(screen.getByRole("status")).toHaveTextContent(defaultProps.children);
    expect(screen.getByRole("status")).toHaveAttribute("aria-live", "polite");
    expect(screen.getByTestId("alert-info-icon")).toHaveAttribute("aria-hidden", "true");
});

test("renders an alert with no icon if prop is false", function noIcon() {
    renderAlert({icon: false});

    expect(screen.getByRole("region", {name: defaultProps.children}).children).toHaveLength(1);
});

test("renders a custom Kalep icon", function customKalepIcon() {
    const iconTestId = "feature";
    const icon = <BugIcon data-testid={iconTestId} />;
    renderAlert({icon});

    expect(screen.getByTestId(iconTestId)).toBeInTheDocument();
});

test("alert can be dismissable", async function dismissableAlert() {
    const user = userEvent.setup();
    const onClose = vi.fn();

    renderAlert({onClose});

    const closeButton = screen.getByLabelText(DEFAULT_CLOSE_BUTTON_ARIA_LABEL);
    await user.click(closeButton);

    expect(closeButton).toBeInTheDocument();
    expect(onClose).toHaveBeenCalledTimes(1);
});

test("alert close button can have custom aria label", function customCloseButtonAriaLabel() {
    const closeButtonAriaLabel = "ferme moi";

    renderAlert({onClose: vi.fn(), closeButtonAriaLabel});

    expect(screen.getByLabelText(closeButtonAriaLabel, {selector: "button"})).toBeInTheDocument();
});

test("alert can have an action", async function withAction() {
    const actionLabel = "Hi";
    const actionFn = vi.fn();
    const user = userEvent.setup();

    renderAlert({action: {onClick: actionFn, label: actionLabel}});

    const actionButton = screen.getByText(actionLabel);
    expect(actionButton).toBeInTheDocument();

    await user.click(actionButton);
    expect(actionFn).toHaveBeenCalledTimes(1);
});
