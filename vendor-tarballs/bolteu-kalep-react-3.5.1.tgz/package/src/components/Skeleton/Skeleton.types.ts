type skeletonTypographySizes =
    | "text-xs"
    | "text-sm"
    | "text-base"
    | "text-lg"
    | "text-xl"
    | "text-2xl"
    | "text-3xl"
    | "text-4xl"
    | "text-5xl"
    | "text-6xl";

export type SkeletonTypographySize = skeletonTypographySizes;

type skeletonVariants = "text" | "circular" | "rounded";
export type SkeletonVariant = skeletonVariants;

type SkeletonTypography = {
    variant: "text";
    width?: number | string;
    textSize?: SkeletonTypographySize;
};

type SkeletonCircular = {
    variant: "circular";
    width?: number | string;
};

type SkeletonShape = {
    variant: "rounded";
    width?: number | string;
    height?: number | string;
};

export type SkeletonProps = SkeletonTypography | SkeletonCircular | SkeletonShape;
