import * as React from "react";
import {usePreventScroll} from "react-aria";

import Cross from "@bolteu/kalep-react-icons/dist/Cross";

import {ModalContext} from "@/components/_internal/Modal";
import {IconButton} from "@/components/IconButton";
import {cx} from "@/helpers/utils/cx";
import {filterDataAttributes} from "@/helpers/utils/props";

import type {BaseModalProps} from "./BaseModal.types";

export function BaseModal({
    isOpen,
    children,
    onRequestClose,
    allowCloseOnOutsideClick = true,
    animation,
    placement,
    shape = "shadow-xl rounded-lg",
    isModal = true,
    hasBackdrop = true,
    ...props
}: BaseModalProps) {
    const dialogRef = React.useRef<HTMLDialogElement>(null);
    const dataAttributes = filterDataAttributes(props);

    // Keeps track of actual <dialog> element open state, so we can provide it in context
    const [isElementOpen, setIsElementOpen] = React.useState(false);

    // Helper to close <dialog> with an animation
    const animatedCloseModal = React.useCallback(() => {
        if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
            dialogRef.current?.close();
            setIsElementOpen(false);
        } else if (dialogRef.current && elementHasAnimation(dialogRef.current)) {
            dialogRef.current.setAttribute("data-closing", "");
            dialogRef.current.addEventListener(
                "animationend",
                () => {
                    dialogRef.current?.removeAttribute("data-closing");
                    dialogRef.current?.close();
                    setIsElementOpen(false);
                },
                {once: true},
            );
        } else {
            dialogRef.current?.close();
            setIsElementOpen(false);
        }
    }, [dialogRef]);

    // Opening and closing the dialog according to isOpen prop changes.
    React.useEffect(() => {
        const isDialogOpen = dialogRef.current?.open;

        if (isOpen && !isDialogOpen) {
            if (isModal) {
                dialogRef.current?.showModal?.();
            } else {
                dialogRef.current?.show?.();
            }

            setIsElementOpen(true);
        }
        if (!isOpen && isDialogOpen) {
            animatedCloseModal();
        }
    }, [isOpen, dialogRef, isModal, animatedCloseModal]);

    // When platform effects for closing dialog kick in (e.g Esc key), then catch
    // the cancel event on the dialog and block closing (via preventDefault).
    // Instead, request closing from parent.
    // This gives parent control over the dialog.
    const cancelHandler: React.ReactEventHandler<HTMLDialogElement> = React.useCallback(
        (event) => {
            event.preventDefault();

            // request closing from parent
            onRequestClose();
        },
        [onRequestClose],
    );

    // On Escape keypress event check if event's target is input, textfield or select field.
    // In that case blur the target field and prevent modal closing.
    React.useEffect(() => {
        const {current} = dialogRef;
        const handleEscape = (event: KeyboardEvent) => {
            const target = event.target as HTMLElement;
            if (
                event.key === "Escape" &&
                (target?.tagName === "INPUT" ||
                    target?.tagName === "TEXTAREA" ||
                    target?.getAttribute("role") === "listbox")
            ) {
                event.preventDefault();
                target?.blur();
            }
        };

        current?.addEventListener("keydown", handleEscape);

        return () => current?.removeEventListener("keydown", handleEscape);
    }, [dialogRef]);

    // Request closing when clicking outside of modal.
    // The <dialog> element covers the whole screen. The visible part is wrapped
    // in a div. Thus, when a click event on the dialog is on the dialog
    // element itself (nodeName === DIALOG), it means the click was on the backdrop.
    // https://youtu.be/4prVdA7_6u0?t=901
    const outsideClickHandler: React.MouseEventHandler<HTMLDialogElement> = React.useCallback(
        (event) => {
            if (allowCloseOnOutsideClick) {
                if (event.target instanceof HTMLElement && event.target.nodeName === "DIALOG") {
                    // check that we're not in the middle of a selection
                    if (!window.getSelection()?.toString()) {
                        onRequestClose();
                    }
                }
            }
        },
        [allowCloseOnOutsideClick, onRequestClose],
    );

    usePreventScroll({
        isDisabled: !isElementOpen,
    });

    const modalContextValue = React.useMemo(() => ({isOpen: isElementOpen}), [isElementOpen]);

    return (
        <ModalContext.Provider value={modalContextValue}>
            {/* eslint-disable-next-line jsx-a11y/no-noninteractive-element-interactions, jsx-a11y/click-events-have-key-events -- click handler on non-interactive element */}
            <dialog
                ref={dialogRef}
                onClick={outsideClickHandler}
                onCancel={cancelHandler}
                className={cx(
                    "border-0 bg-special-nulled p-0",
                    shape,
                    hasBackdrop
                        ? `
                          backdrop:animate-fade-in backdrop:bg-special-scrim
                          [&[data-closing]::backdrop]:animate-fade-out
                        `
                        : "backdrop:hidden",
                    // default to fade-in animation, allow overriding.
                    // when applying animations with movement, use motion-safe:
                    animation ?? `
                      animate-fade-in
                      [&[data-closing]]:animate-fade-out
                    `,
                    placement,
                    "overflow-visible",
                )}
                aria-labelledby={props["aria-labelledby"]}
                aria-label={props["aria-label"]}
                role={props.role}
                {...dataAttributes}
                data-kalep-comp="basemodal"
            >
                <div>{children}</div>
            </dialog>
        </ModalContext.Provider>
    );
}

function ModalClose({onClose, autoFocus}: {onClose: () => void; autoFocus?: boolean}) {
    return (
        <IconButton
            overrideClassName="-mt-1 -me-1"
            icon={<Cross />}
            size="sm"
            onClick={onClose}
            aria-label="Close"
            // eslint-disable-next-line jsx-a11y/no-autofocus -- I don't know why its here, I am just refactoring eslint atm
            autoFocus={autoFocus}
        />
    );
}

function ModalHeader({title, titleId, children}: {title: React.ReactNode; titleId: string; children: React.ReactNode}) {
    return (
        <div
            className={cx("flex items-center justify-between gap-6 px-6 pb-4 pt-6")}
            data-kalep-comp="basemodal/header"
        >
            {title && (
                <span
                    id={titleId}
                    className={cx("bolt-font-heading-s-accent overflow-hidden break-words text-primary")}
                >
                    {title}
                </span>
            )}
            {children}
        </div>
    );
}

// Mostly here because it's exactly the same between Drawer and Dialog.
function ModalContent({children}: {children: React.ReactNode}) {
    const contentRef = React.useRef<HTMLElement>(null);
    const {isOpen} = React.useContext(ModalContext);

    React.useEffect(() => {
        if (isOpen) {
            const contentElement = contentRef.current;
            if ((contentElement?.scrollHeight || 0) > (contentElement?.clientHeight || 0)) {
                contentElement?.classList.add("border-y");
                contentElement?.classList.add("border-y-separator");
            }
        }
    }, [isOpen, contentRef]);

    return (
        <section
            ref={contentRef}
            className={cx(
                "border-0 border-solid px-6 py-2",
                "flex-grow",
                "text-base font-normal text-primary",
                "overflow-y-auto",
            )}
            data-kalep-comp="basemodal/content"
        >
            {children}
        </section>
    );
}

function ModalFooter({children}: {children: React.ReactNode}) {
    return (
        <footer className={cx("px-6 pb-6 pt-4")} data-kalep-comp="basemodal/footer">
            {children}
        </footer>
    );
}

function elementHasAnimation(el: HTMLElement): boolean {
    const styleDeclaration = window.getComputedStyle(el);
    const animationDuration = parseFloat(styleDeclaration.getPropertyValue("animation-duration"));
    const transitionDuration = parseFloat(styleDeclaration.getPropertyValue("transition-duration"));

    return animationDuration > 0 || transitionDuration > 0;
}

BaseModal.Close = ModalClose;
BaseModal.Header = ModalHeader;
BaseModal.Content = ModalContent;
BaseModal.Footer = ModalFooter;
