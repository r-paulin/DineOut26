import * as React from "react";

import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {Size, State, TextAreaProps, TextAreaRenderProps} from "./TextArea.types";

const textAreaStyles: Record<Size, string> = {
    sm: "p-2 bolt-font-body-s-regular",
    md: "p-2 bolt-font-body-m-regular",
    lg: "p-3 bolt-font-body-m-regular",
};

const textAreaHeights: Record<Size, string> = {
    sm: "h-20 min-h-comp-s",
    md: "h-28 min-h-comp-m",
    lg: "h-36 min-h-comp-l",
};

const states: Record<State, string> = {
    idle: "border-special-nulled focus:border-action-primary text-primary",
    disabled: "border-neutral-secondary cursor-not-allowed text-tertiary bg-special-nulled placeholder-tertiary",
    error: "border-danger-primary focus:border-danger-primary focus:shadow-inner text-primary caret-danger-primary",
};

export const TextArea = React.forwardRef(function RenderTextArea(
    props: TextAreaProps,
    ref: React.Ref<HTMLTextAreaElement>,
): JSX.Element {
    const {
        defaultValue,
        disabled: isDisabled = false,
        error: hasError = false,
        fullWidth: isFullWidth = false,
        id,
        label,
        helperText,
        maxLength,
        onChange,
        renderHelperText = renderHelperTextDefault,
        size = "md",
        rows,
        value,
        required = false,
        ...rest
    } = props;

    const [textLength, setTextLength] = React.useState<number>(value?.length ?? 0);

    const handleChange: React.ChangeEventHandler<HTMLTextAreaElement> = React.useCallback(
        (event) => {
            setTextLength(event.target.value.length);
            onChange?.(event);
        },
        [onChange],
    );

    const generatedId = useId();
    const textAreaId = id ?? `kalep-text-area-${generatedId}`;
    const helperTextId = `${textAreaId}-helper-text`;

    return (
        <div className={cx("flex flex-col gap-2", isFullWidth ? "w-full" : "w-96")}>
            <div className={cx("flex justify-between")}>
                {label && (
                    <label
                        className={cx(
                            "bolt-font-body-s-accent",
                            required && "after:text-danger-primary after:content-['_*']",
                            isDisabled ? "text-tertiary" : "text-primary",
                        )}
                        htmlFor={textAreaId}
                    >
                        {label}
                    </label>
                )}
                {maxLength && (
                    <span
                        className={cx("bolt-font-body-tabular-s-regular text-secondary", isDisabled && "text-tertiary")}
                    >
                        {textLength}/{maxLength}
                    </span>
                )}
            </div>
            <textarea
                aria-describedby={helperText ? helperTextId : undefined}
                aria-invalid={hasError}
                className={cx(
                    "w-full resize-y",
                    "rounded-md border-2 outline-none",
                    "bg-neutral-secondary placeholder-secondary caret-action-primary",
                    "duration-100 ease-linear",
                    "focus:bg-special-nulled",
                    hasError && states.error,
                    isDisabled && states.disabled,
                    !isDisabled && !hasError && states.idle,
                    isDisabled ? "cursor-not-allowed" : "cursor-text",
                    textAreaStyles[size],
                    rows === undefined && textAreaHeights[size],
                )}
                disabled={isDisabled}
                id={textAreaId}
                maxLength={maxLength}
                onChange={handleChange}
                ref={ref}
                value={value}
                defaultValue={defaultValue}
                rows={rows}
                {...rest}
            />
            {renderHelperText({...props, textAreaId, helperTextId}, renderHelperTextDefault)}
        </div>
    );
});

function renderHelperTextDefault({helperText, error, helperTextId, disabled}: TextAreaRenderProps): JSX.Element | null {
    if (!helperText) {
        return null;
    }

    return (
        <p
            className={cx(
                "bolt-font-body-s-regular m-0 text-secondary",
                disabled && "text-tertiary",
                error && "text-danger-primary",
            )}
            id={helperTextId}
        >
            {helperText}
        </p>
    );
}
