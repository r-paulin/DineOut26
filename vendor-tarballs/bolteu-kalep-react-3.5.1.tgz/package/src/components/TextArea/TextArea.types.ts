import type * as React from "react";

import type {RenderFunction} from "@/helpers";

export type Size = "sm" | "md" | "lg";
export type State = "disabled" | "idle" | "error";

export interface TextAreaProps extends Omit<React.ComponentPropsWithRef<"textarea">, "size" | "className"> {
    defaultValue?: string;
    error?: boolean;
    fullWidth?: boolean;
    label?: string;
    helperText?: React.ReactNode;
    size?: Size;
    renderHelperText?: RenderFunction<TextAreaRenderProps>;
    value?: string;
    required?: boolean;
}

export interface TextAreaRenderProps extends TextAreaProps {
    textAreaId: string;
    helperTextId: string;
}
