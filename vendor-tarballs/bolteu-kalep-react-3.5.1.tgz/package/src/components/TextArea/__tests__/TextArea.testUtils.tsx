import * as React from "react";

import type {RenderResult} from "@testing-library/react";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {TextArea} from "../TextArea";
import type {TextAreaProps} from "../TextArea.types";

export * from "@testing-library/react";
export {userEvent};

interface RenderTextAreaResult extends Omit<RenderResult, "rerender"> {
    rerender: (props: Partial<TextAreaProps>) => void;
}

export const defaultProps = {
    label: "Default:",
    placeholder: "write in here",
    helperText: "Hello World!",
};

export function renderTextArea(props?: Partial<TextAreaProps>): RenderTextAreaResult {
    const utils = render(<TextArea {...defaultProps} {...props} />);

    function rerender(rerenderProps: Partial<TextAreaProps>): void {
        utils.rerender(<TextArea {...defaultProps} {...rerenderProps} />);
    }

    return {...utils, rerender};
}

export function getTextArea(label = defaultProps.label): HTMLInputElement {
    return screen.getByRole("textbox", {name: label});
}

export async function changeTextArea(value: string, shouldClear = true): Promise<void> {
    const user = userEvent.setup();
    const textArea = getTextArea();

    if (shouldClear) {
        await user.clear(textArea);
    }

    await user.type(textArea, value);
}
