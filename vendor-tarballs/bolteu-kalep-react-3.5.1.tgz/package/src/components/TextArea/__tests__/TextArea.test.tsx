import * as React from "react";

import {vi} from "vitest";

import {changeTextArea, defaultProps, getTextArea, renderTextArea, screen} from "./TextArea.testUtils";

test("renders a labelled and described text area", function textAreaRender() {
    renderTextArea();

    const textArea = getTextArea();

    expect(textArea).toBeInTheDocument();
    expect(screen.getByText(defaultProps.label, {selector: "label"})).toBeInTheDocument();
    expect(textArea).toHaveAccessibleDescription(defaultProps.helperText);
    expect(screen.getByText(defaultProps.helperText)).toBeInTheDocument();
    expect(getTextArea()).toHaveAttribute("aria-invalid", "false");
});

test("textarea accept text written inside", async function writeInTextArea() {
    const text = "hello world";

    renderTextArea();

    await changeTextArea(text);

    expect(getTextArea()).toHaveValue(text);
});

test("renders without a label and helper text if not provided", function noLabelOrHelperText() {
    renderTextArea({label: "", helperText: ""});

    const textArea = getTextArea("");

    expect(textArea).toBeInTheDocument();
    expect(textArea).not.toHaveAccessibleDescription();
});

test("provided id prop is re-used by textarea and helper elements", function idPropReuse() {
    const id = "my-cool-id";
    renderTextArea({id});

    expect(getTextArea()).toHaveAttribute("id", id);
});

test("textarea can be disabled", function disabledTextArea() {
    renderTextArea({disabled: true});

    expect(getTextArea()).toBeDisabled();
});

test("textarea can be in an error state", function errorTextArea() {
    renderTextArea({error: true});

    expect(getTextArea()).toHaveAttribute("aria-invalid", "true");
});

test("textarea can be in a readonly state", function errorTextArea() {
    renderTextArea({readOnly: true});

    expect(getTextArea()).toHaveAttribute("readonly");
});

test("textarea can have placeholder", function placeholderInTextArea() {
    renderTextArea();

    expect(screen.getByPlaceholderText(defaultProps.placeholder)).toBeInTheDocument();
});

test("can have a helper text as an element", function helperTexts() {
    const helperTextString = "Pick the first option!";
    const helperTextElement = <span>{helperTextString}</span>;

    renderTextArea({helperText: helperTextElement});

    expect(screen.getByText(helperTextString)).toBeInTheDocument();
    expect(getTextArea()).toHaveAttribute("aria-describedby", expect.any(String));
});

test("helperText custom render", function helperTextRender() {
    const customHelperText = "I am so custom right now.";
    const renderHelperText = vi.fn().mockReturnValue(<div>{customHelperText}</div>);
    renderTextArea({renderHelperText});

    expect(screen.getByText(customHelperText)).toBeInTheDocument();
    expect(renderHelperText).toHaveBeenCalledWith(
        expect.objectContaining({renderHelperText, helperTextId: expect.any(String)}),
        expect.any(Function),
    );
    expect(renderHelperText).toHaveBeenCalledTimes(1);
});

test("textarea should have a default value based on the defaultValue prop", async function initialValue() {
    const defaultValue = "Dorian Gray";
    const newValue = "Basil Hallward";

    renderTextArea({defaultValue});

    expect(getTextArea()).toHaveValue(defaultValue);

    await changeTextArea(newValue);

    expect(getTextArea()).toHaveValue(newValue);
});

test("textarea should have its value controlled by the value prop", async function controlledValue() {
    const value = "Dorian Gray";
    const newValue = "Basil Hallward";
    const typedValue = "Henry Wotton";

    const {rerender} = renderTextArea({value});

    expect(getTextArea()).toHaveValue(value);

    await changeTextArea(typedValue);

    expect(getTextArea()).toHaveValue(value);

    rerender({value: newValue});

    expect(getTextArea()).toHaveValue(newValue);
});

test("onChange should be called when controlled input value is changed", async function controlledValue() {
    const onChange = vi.fn();
    const value = "foo";
    const newValue = "b";

    renderTextArea({onChange, value});

    await changeTextArea(newValue, false);

    expect(onChange).toHaveBeenCalledTimes(1);
});

test("onChange should be called every time the uncontrolled input value is changed", async function controlledValue() {
    const onChange = vi.fn();
    const value = ["B", "o", "b", " ", "J", "o", "e"];

    renderTextArea({onChange});

    for (let index = 0; index < value.length; index++) {
        const character = value[index];

        await changeTextArea(character, false);

        expect(onChange).toHaveBeenNthCalledWith(
            index + 1,
            expect.objectContaining({target: expect.objectContaining({value: value.slice(0, index + 1).join("")})}),
        );
    }

    expect(onChange).toHaveBeenCalledTimes(value.length);
});

test("renders a helping characted counter if maxLength is provided", function maxLengthCounter() {
    const maxLength = 100;
    const value = "hello my world";

    renderTextArea({maxLength, value, readOnly: true});

    renderTextArea();

    expect(screen.getByText(`${value.length}/${maxLength}`)).toBeInTheDocument();
});
