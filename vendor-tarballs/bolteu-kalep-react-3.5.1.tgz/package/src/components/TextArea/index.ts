export {TextArea} from "./TextArea";
export type {TextAreaProps, TextAreaRenderProps} from "./TextArea.types";
