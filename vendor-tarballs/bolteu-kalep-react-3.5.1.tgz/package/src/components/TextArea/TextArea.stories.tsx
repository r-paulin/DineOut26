import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import Mail from "@bolteu/kalep-react-icons/dist/Mail";

import type {TextAreaProps} from "./index";
import {TextArea} from "./index";

export default {
    title: "Inputs/TextArea",
    component: TextArea,
    tags: ["autodocs"],
} as Meta<typeof TextArea>;

const Template: StoryFn<typeof TextArea> = (args: TextAreaProps) => <TextArea {...args} />;

export const Default = Template.bind({});
Default.args = {
    label: "Feedback",
    helperText: "Tell us how could we improve your experience.",
    placeholder: "First of all ...",
    disabled: false,
};

export const Disabled = Template.bind({});
Disabled.args = {
    ...Default.args,
    placeholder: "You know what? Just don't tell us.",
    disabled: true,
};

export const Error = Template.bind({});
Error.args = {
    ...Default.args,
    error: true,
    helperText: "All feedback written is just wrong.",
};

export const WithMaxLength = Template.bind({});
WithMaxLength.args = {
    ...Default.args,
    maxLength: 250,
    helperText: "Tell us how could we improve, but don't tell us too much.",
};

export const Rows = Template.bind({});
Rows.args = {
    ...Default.args,
    rows: 2,
    size: "lg",
    helperText: "When rows prop is provided, it takes precedence over the size prop height parameter.",
};

export const Controlled: StoryFn<typeof TextArea> = (args: TextAreaProps) => {
    const [value, setValue] = React.useState("");
    const handleChange = React.useCallback((e: React.ChangeEvent<HTMLTextAreaElement>) => setValue(e.target.value), []);

    return (
        <TextArea
            {...args}
            onChange={handleChange}
            value={value}
            helperText={
                value.length
                    ? `Thank you for your feedback that is ${value.length} characters long!`
                    : "Tell us how we could improve."
            }
        />
    );
};

Controlled.args = {
    ...Default.args,
};
Controlled.argTypes = {
    value: {
        control: {
            disable: true,
        },
    },
    helperText: {
        control: {
            disable: true,
        },
    },
};

export const CustomHelperText = Template.bind({});
CustomHelperText.args = {
    ...Default.args,
    label: "Feedback",
    helperText: "Your feedback is sent to us immediately.",
    renderHelperText(props, defaultRenderFunction) {
        return (
            <div className="flex items-center gap-1">
                <Mail />
                {defaultRenderFunction(props)}
            </div>
        );
    },
};
