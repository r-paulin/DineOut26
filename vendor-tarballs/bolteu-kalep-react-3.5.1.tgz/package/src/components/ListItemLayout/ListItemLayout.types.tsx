import type {SpacingValue} from "@/components/Typography/Typography.types";
import type {TypographyStackProps as BaseTypographyStackProps} from "@/components/Typography/TypographyStack";
import type {RenderFunction} from "@/helpers";

export const variants = ["base", "sm"] as const;

export const selectionVariants = ["solo-radio", "solo-checkmark", "multiple", "switch"] as const;

type HTMLElementProps = Omit<React.ComponentPropsWithRef<"div">, "className">;

type TypographyStackProps = Omit<BaseTypographyStackProps, "variant">;

export type ListItemLayoutSlotProps = {
    size?: "sm" | "md";
    disabled?: boolean;
};

export interface ListItemLayoutProps extends HTMLElementProps, TypographyStackProps {
    /** Leading  (left) slot */
    renderStartSlot?: RenderFunction<ListItemLayoutSlotProps>;
    /** Trailing (right) slot.
     * @note If you need to show a button or a clickable item,
     * please remove the `onClick` prop from ListItemLayout for a better experience.
     */
    renderEndSlot?: RenderFunction<ListItemLayoutSlotProps>;
    /** Trailing (left) outer container padding.
     * @default 4 - (which equals to `1rem` == `16px`)
     */
    paddingStart?: SpacingValue;
    /** Trailing (right) outer container padding.
     * @default 4 - (which equals to `1rem` == `16px`)
     */
    paddingEnd?: SpacingValue;
    /** Top innner container padding.
     * @default undefined - (by default controlled by the `variant` prop)
     */
    paddingTop?: SpacingValue;
    /** Bottom inner container padding.
     * @default undefined - (by default controlled by the `variant` prop)
     */
    paddingBottom?: SpacingValue;
    /**
     * Preconfigured options for for list item layout
     * @default base
     * @param base - Use it for common, not dense screens when you need to show the primary text and a supporting text (which should not be required for the task at hand).
     * @param sm - Use it for more dense screens when you need to show the primary text and additional supporting text (which should not be required for the task at hand).
     */
    variant?: (typeof variants)[number];
    /** Whether to show a separator at the bottom of the item. */
    separator?: boolean;
    /** Highlighted state. */
    highlighted?: boolean;
    /** Selected state. */
    selected?: boolean;
    /** Selection mode variant. Takes effect if selected is provided. Default is `solo-checkmark`. */
    selectionMode?: (typeof selectionVariants)[number];
    /** Disabled state. */
    disabled?: boolean;
    /** Click handler.
     * @note
     * Please remove it, if you need to show a button or a clickable item
     * in the trailing (right) slot for a better experience.
     */
    onClick?: () => void;
}

export type ListItemLayoutSelectionSlotProps = {
    selected: ListItemLayoutProps["selected"];
    selectionMode: ListItemLayoutProps["selectionMode"];
    disabled: ListItemLayoutProps["disabled"];
    "aria-label"?: string;
};
