import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import Check from "@bolteu/kalep-react-icons/dist/Check";
import Heart from "@bolteu/kalep-react-icons/dist/Heart";
import Offer from "@bolteu/kalep-react-icons/dist/Offer";

import {Button} from "@/components/Button";
import {Checkbox} from "@/components/Checkbox";
import {IconButton} from "@/components/IconButton";
import {Typography} from "@/components/Typography";

import type {ListItemLayoutProps} from "./index";
import {ListItemLayout} from "./index";

function stopPropagationAndReportClick(event: React.MouseEvent) {
    event.stopPropagation();
    alert("ListItemLayout right slot clicked!");
}

const items: ListItemLayoutProps[] = [
    {
        primary: "A Picture of Dorian Gray",
        secondary: "Oscar Wilde",
        separator: true,
        onClick: () => alert("ListItemLayout clicked!"),
        "aria-label": "A Picture of Dorian Gray",
    },
    {
        renderStartSlot({size}) {
            return <Offer size={size} className="text-primary" />;
        },
        primary: "War and Peace",
        secondary: "Lev Tolstoy",
        renderEndSlot({disabled, size}) {
            return (
                <IconButton
                    size={size}
                    disabled={disabled}
                    icon={<Heart />}
                    aria-label="like War and Peace"
                    onClick={stopPropagationAndReportClick}
                />
            );
        },
    },
    {
        primary: "The Brothers Karamazov",
        secondary: "Fyodor Dostoevsky",
        renderEndSlot({disabled, size}) {
            return (
                <Button disabled={disabled} size={size}>
                    Add
                </Button>
            );
        },
    },
    {
        primary: "Pride and Prejudice",
        secondary: "Jane Austen",
        renderEndSlot({disabled}) {
            return <Checkbox disabled={disabled} aria-label="read Crime and Punishment" defaultChecked />;
        },
    },
    {
        renderStartSlot: ({size}) => <Offer size={size} className="text-primary" />,
        primary:
            "Human being’s love for peace is universal. Human being is by nature peaceful. War does not furnish a proof of the idea that human is a fighting animal. Even the acts of war did not spoil in the least human’s spontaneous love for peace.",
        primaryTypographyProps: {
            lines: 3,
        },
        renderEndSlot({size}) {
            return <Check size={size} className="text-primary" />;
        },
    },
];

export default {
    title: "Data Display/ListItemLayout",
    component: ListItemLayout,
    tags: ["autodocs"],
} as Meta<typeof ListItemLayout>;

export const Default: StoryFn<typeof ListItemLayout> = (args) => (
    <ul className={`
      m-0 flex max-h-80 w-96 list-none flex-col gap-y-3 overflow-y-auto px-0 py-1
      empty:py-0
    `}>
        {[items[0]].map(function renderItem(itemProps: ListItemLayoutProps) {
            return (
                <li key={itemProps.primary as string}>
                    <ListItemLayout {...args} />
                </li>
            );
        })}
    </ul>
);

Default.args = {
    ...items[0],
};

export const WithRenderSlots: StoryFn<typeof ListItemLayout> = () => (
    <div className="flex gap-5">
        <div>
            <Typography variant="title-secondary" color="primary">
                base variant
            </Typography>
            <ul className={`
              m-0 flex max-h-80 w-96 list-none flex-col gap-4 overflow-y-auto px-0 py-1
              empty:py-0
            `}>
                {items.map(function renderItem(itemProps: ListItemLayoutProps) {
                    return (
                        <li key={itemProps.primary as string}>
                            <ListItemLayout {...itemProps} />
                        </li>
                    );
                })}
            </ul>
        </div>
        <div>
            <Typography variant="title-secondary" color="primary">
                sm variant
            </Typography>
            <ul className={`
              m-0 flex max-h-80 w-96 list-none flex-col gap-4 overflow-y-auto px-0 py-1
              empty:py-0
            `}>
                {items.map(function renderItem(itemProps: ListItemLayoutProps) {
                    return (
                        <li key={itemProps.primary as string}>
                            <ListItemLayout {...itemProps} variant="sm" />
                        </li>
                    );
                })}
            </ul>
        </div>
    </div>
);

export const WithSelection: StoryFn<typeof ListItemLayout> = () => {
    const [isSelected, setIsSelected] = React.useState<boolean>(false);
    const toggleSelection = React.useCallback(() => {
        setIsSelected(!isSelected);
    }, [isSelected]);

    return (
        <div className="flex gap-5">
            <ul className={`
              m-0 flex w-96 list-none flex-col overflow-y-auto px-0 py-1
              empty:py-0
            `}>
                <li key={1}>
                    <ListItemLayout
                        {...items[0]}
                        selected={isSelected}
                        selectionMode="solo-checkmark"
                        onClick={toggleSelection}
                        aria-label={items[0]["aria-label"]}
                    />
                </li>
                <li key={2}>
                    <ListItemLayout
                        {...items[0]}
                        selected={isSelected}
                        selectionMode="solo-radio"
                        onClick={toggleSelection}
                        aria-label={items[0]["aria-label"]}
                    />
                </li>
                <li key={3}>
                    <ListItemLayout
                        {...items[0]}
                        selected={isSelected}
                        selectionMode="multiple"
                        onClick={toggleSelection}
                        aria-label={items[0]["aria-label"]}
                    />
                </li>
                <li key={4}>
                    <ListItemLayout
                        {...items[0]}
                        selected={isSelected}
                        selectionMode="switch"
                        onClick={toggleSelection}
                        aria-label={items[0]["aria-label"]}
                    />
                </li>
            </ul>
        </div>
    );
};

WithSelection.parameters = {
    a11y: {
        config: {
            rules: [
                {
                    // TODO: Consider improving the problems with nested interactive elements for a11y
                    id: "nested-interactive",
                    reviewOnFail: true,
                },
            ],
        },
    },
};
