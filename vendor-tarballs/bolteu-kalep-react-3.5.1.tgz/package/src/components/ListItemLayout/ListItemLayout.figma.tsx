import React from "react";

import figma from "@figma/code-connect";

import {ListItemLayout} from "./ListItemLayout";

figma.connect(
    ListItemLayout,
    "https://www.figma.com/design/nU1QBYZxTAYsIZ4X0jW4tV/%F0%9F%8C%88-Kalep-Web-Semantic-Components?node-id=12359-44315&m=dev",
    {
        props: {
            disabled: figma.enum("State", {
                Disabled: true,
            }),
            highlighted: figma.enum("State", {
                Hover: true,
            }),
            separator: figma.boolean("Separator"),

            renderStartSlot: figma.children("[start slot]"),

            showStart: figma.boolean("show [start]"),

            primaryContent: figma.nestedProps("🔒 [primary]", {
                text: figma.textContent("_text"),
            }),

            selectionMode: figma.enum("SelectorType", {
                Multiple: "multiple",
                SoloCheckmark: "solo-checkmark",
                SoloRadio: "solo-radio",
                Switch: "switch",
            }),
        },
        example: ({
            disabled,
            highlighted,
            separator,
            primaryContent,
            /* renderStartSlot I DONT KNOW HOW TO GET IT TO ListItemLayout */
        }) => (
            <ListItemLayout disabled={disabled} highlighted={highlighted} separator={separator}>
                {primaryContent.text}
            </ListItemLayout>
        ),
    },
);
