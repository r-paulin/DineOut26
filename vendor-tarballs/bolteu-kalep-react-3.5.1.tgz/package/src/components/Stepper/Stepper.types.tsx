import type * as React from "react";

export interface StepperProps {
    steps: number;
    value: number;
    caption?: React.ReactNode;
    "aria-labelledby"?: string;
    "aria-label"?: string;
    "aria-describedby"?: string;
    "aria-details"?: string;
}
