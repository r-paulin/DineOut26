import * as React from "react";

import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {StepperProps} from "./Stepper.types";

const MIN_VALUE = 0;
const getColorClass = (activeStep: number, step: number) => {
    if (activeStep === step) {
        return "bg-active-action-secondary";
    }
    if (activeStep > step) {
        return "bg-action-primary";
    }

    return "bg-neutral-secondary-hard";
};

export function Stepper({steps, value, caption, ...rest}: StepperProps) {
    const generatedId = useId();
    const labelId = rest["aria-labelledby"] ?? generatedId;

    if (steps < MIN_VALUE || value < MIN_VALUE) {
        return null;
    }

    return (
        <div className={cx("w-full")}>
            <div
                className={cx("flex h-1 w-full gap-1")}
                role="progressbar"
                aria-valuemin={MIN_VALUE}
                aria-valuemax={steps}
                aria-valuenow={value}
                aria-busy={value < steps}
                aria-labelledby={labelId}
                {...rest}
            >
                {Array.from(Array(steps).keys()).map((step: number) => (
                    <div
                        key={step}
                        className={cx(
                            "relative h-full rounded transition-[background-color] ease-out",
                            getColorClass(value, step),
                        )}
                        style={{width: `${100 / steps}%`}}
                    />
                ))}
            </div>
            {caption && (
                <div id={labelId} className={cx("bolt-font-body-s-accent mt-2 text-center")}>
                    {caption}
                </div>
            )}
        </div>
    );
}
