import type * as React from "react";

type Visibility = "HIDDEN_LEAVE_HOLE" | "HIDDEN_REMOVE_FIELD" | "VISIBLE";

export interface GridItemProps {
    colStart?: number | "auto";
    colSpan?: number;
    rowStart?: number | "auto";
    rowSpan?: number;
    visible?: Visibility;
    children: React.ReactNode;
}

export interface GridProps {
    children: React.ReactNode;
    /**
     * Number of columns in an implicit grid. In Figma you can see the layout grid by turning on
     * "Layout grids" from View menu (or press Shift-G hotkey).
     */
    columns?: number;
    /**
     * Vertical alignment of grid items in a row
     */
    alignItems?: "flex-start" | "center" | "flex-end" | "baseline" | "stretch";
    /**
     * Gap is defined in terms of spacing scale, which is 4px steps.
     * So the default gap of 4 translates to 16px (1rem).
     */
    gap?: number;
    /**
     * Grid can itself act as a grid item, useful in cases you need nested grids.
     * colSpan behaves the same as on Grid.Item, spanning across given number of columns.
     */
    colSpan?: number;
    /**
     * Grid can itself act as a grid item, useful in cases you need nested grids.
     * rowSpan behaves the same as on Grid.Item, spanning across given number of rows.
     */
    rowSpan?: number;
}
