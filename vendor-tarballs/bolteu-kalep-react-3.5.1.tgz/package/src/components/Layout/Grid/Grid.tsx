import * as React from "react";

import type {GridItemProps, GridProps} from "./Grid.types";

export function Grid({children, columns = 1, alignItems, gap = 4, colSpan = 1, rowSpan = 1}: GridProps) {
    const inlineStyles: React.CSSProperties = React.useMemo(() => {
        const gridGapPxValue = gap * 4; // spacing scale is in increments of 4px

        return {
            display: "grid",
            width: "100%",
            gridTemplateColumns: `repeat(${columns}, minmax(10px, 1fr))`, // Set column min width to 10px to avoid it going to min-content.
            alignItems,
            gap: gridGapPxValue,
            gridColumn: colSpan > 1 ? `auto / span ${colSpan}` : "",
            gridRow: rowSpan > 1 ? `auto / span ${rowSpan}` : "",
        };
    }, [columns, colSpan, rowSpan, alignItems, gap]);

    return <div style={inlineStyles}>{children}</div>;
}

function GridItem({
    colStart = "auto",
    colSpan = 1,
    rowStart = "auto",
    rowSpan = 1,
    visible = "VISIBLE",
    children,
}: GridItemProps) {
    const inlineStyle: React.CSSProperties = React.useMemo(
        () => ({
            gridColumn: colSpan !== 1 ? `${colStart} / span ${colSpan}` : "",
            gridRow: rowSpan !== 1 ? `${rowStart} / span ${rowSpan}` : "",
            visibility: visible === "HIDDEN_LEAVE_HOLE" ? "hidden" : undefined,
            display: visible === "HIDDEN_REMOVE_FIELD" ? "none" : undefined,
        }),
        [colStart, colSpan, rowStart, rowSpan, visible],
    );

    return <div style={inlineStyle}>{children}</div>;
}

Grid.Item = GridItem;
