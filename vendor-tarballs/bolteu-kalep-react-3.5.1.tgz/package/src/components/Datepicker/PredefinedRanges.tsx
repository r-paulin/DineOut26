import * as React from "react";

import {Chip} from "@/components/Chip";
import {cx} from "@/helpers/utils/cx";

export const defaultRanges = [
    {label: "Last 3 days", key: "KALEP_DATE_RANGE_LAST_3_DAYS"},
    {label: "Last 7 days", key: "KALEP_DATE_RANGE_LAST_7_DAYS"},
    {label: "Last 14 days", key: "KALEP_DATE_RANGE_LAST_14_DAYS"},
    {label: "Last 30 days", key: "KALEP_DATE_RANGE_LAST_30_DAYS"},
    {label: "Next 3 days", key: "KALEP_DATE_RANGE_NEXT_3_DAYS"},
    {label: "Next 7 days", key: "KALEP_DATE_RANGE_NEXT_7_DAYS"},
    {label: "Next 14 days", key: "KALEP_DATE_RANGE_NEXT_14_DAYS"},
] as const;

export type PredefinedDateRange = (typeof defaultRanges)[number]["key"];

export type CustomRangeDefinition = {
    startDate: Date;
    endDate: Date;
    label: React.ReactNode;
    key: string;
};

export type PredefinedRangeDefinition = {
    label: React.ReactNode;
    key: PredefinedDateRange;
};

function getDatesFromDefaultRange(range: PredefinedDateRange): [Date, Date] {
    const today = new Date();
    switch (range) {
        case "KALEP_DATE_RANGE_LAST_3_DAYS":
            return [new Date(today.getFullYear(), today.getMonth(), today.getDate() - 2), today];
        case "KALEP_DATE_RANGE_LAST_7_DAYS":
            return [new Date(today.getFullYear(), today.getMonth(), today.getDate() - 6), today];
        case "KALEP_DATE_RANGE_LAST_14_DAYS":
            return [new Date(today.getFullYear(), today.getMonth(), today.getDate() - 13), today];
        case "KALEP_DATE_RANGE_LAST_30_DAYS":
            return [new Date(today.getFullYear(), today.getMonth(), today.getDate() - 29), today];
        case "KALEP_DATE_RANGE_NEXT_3_DAYS":
            return [today, new Date(today.getFullYear(), today.getMonth(), today.getDate() + 2)];
        case "KALEP_DATE_RANGE_NEXT_7_DAYS":
            return [today, new Date(today.getFullYear(), today.getMonth(), today.getDate() + 6)];
        case "KALEP_DATE_RANGE_NEXT_14_DAYS":
            return [today, new Date(today.getFullYear(), today.getMonth(), today.getDate() + 13)];
        default:
            throw new Error(`Unknown predefined range: ${range}`);
    }
}

export type RequestedDateRanges = (PredefinedDateRange | CustomRangeDefinition)[];

export type PredefinedRangesProps = {
    ranges: RequestedDateRanges;
    onRangeSelected: (range: [Date, Date]) => void;
};

export function PredefinedRanges({ranges, onRangeSelected}: PredefinedRangesProps) {
    return (
        <div className={cx("flex w-64 flex-wrap gap-1 pt-2")}>
            {ranges.map((range: PredefinedDateRange | CustomRangeDefinition) => {
                let rangeDefinition = range as any;

                if (typeof range === "string") {
                    rangeDefinition = defaultRanges.find((r) => r.key === range);
                }
                return <RangeChip key={rangeDefinition.key} range={rangeDefinition} onClick={onRangeSelected} />;
            })}
        </div>
    );
}

function RangeChip({
    range,
    onClick,
}: {
    range: PredefinedRangeDefinition | CustomRangeDefinition;
    onClick: (x: [Date, Date]) => void;
}) {
    const selectRangeHandler = React.useCallback(() => {
        let dateRange: [Date, Date];

        if (isCustomRangeDefinition(range)) {
            dateRange = [range.startDate, range.endDate];
        } else {
            dateRange = getDatesFromDefaultRange(range.key);
        }

        onClick(dateRange);
    }, [onClick, range]);

    return <Chip size="sm" label={range.label as string} onClick={selectRangeHandler} />;
}

function isCustomRangeDefinition(
    range: PredefinedRangeDefinition | CustomRangeDefinition,
): range is CustomRangeDefinition {
    return (range as CustomRangeDefinition).startDate !== undefined;
}
