import * as React from "react";

import {et} from "date-fns/locale";
import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Calendar, Time} from "@bolteu/kalep-react-icons";

import type {PopperPlacement} from "./index";
import {DatePicker, registerLocale} from "./index";

export default {
    title: "Inputs/Datepicker",
    tags: ["autodocs"],
    component: DatePicker,
} as Meta<typeof DatePicker>;

const Template: StoryFn<typeof DatePicker> = (args) => <DatePicker {...args} />;

export const Default = Template.bind({});
Default.args = {
    label: "Date",
    locale: "en-GB",
    format: "dd.MM.yyyy",
    helperText: "Select a nice date",
    placeholder: "DD.MM.YYYY",
    startDay: 1,
};

export const Required = Template.bind({});
Required.args = {
    ...Default.args,
    required: true,
};

export const Localisation = () => {
    // import {DatePicker, registerLocale} from "@bolteu/kalep-react";
    // import {et} from "date-fns/locale";
    registerLocale("et-EE", et);
    return <DatePicker locale="et-EE" format="dd.MM.yyy" />;
};

Localisation.parameters = {
    docs: {
        description: {
            story: "Use `locale` prop to pass the desired locale name. \n\n🚧 Note that the Datepicker itself does not know any locales but the default, so you need to import and call `registerLocale` to register any custom locales. Locales should be imported from `date-fns`. This is due to Kalep Datepicker using `react-datepicker` underneath.",
        },
    },
};

export const Controlled = () => {
    const [value, setValue] = React.useState<Date | null>(new Date(2024, 6, 13));

    const handleChange = React.useCallback((newValue: Date | Date[] | null) => {
        if (!Array.isArray(newValue)) {
            setValue(newValue);
        }
    }, []);

    return <DatePicker value={value} onChange={handleChange} />;
};

Controlled.parameters = {
    docs: {
        description: {
            story: "Whenever `value` prop is not `undefined`, the Datepicker is considered as controlled and the `onChange` handler is called without updating internal state. Hence, specify both `value` and `onChange` props and handle value changes yourself if you want a controlled Datepicker. \n\n🚧 Note that switching between controlled and uncontrolled Datepicker (or any component) during its lifetime is strongly discouraged as it may render unexpected results.",
        },
    },
};

export const CustomInput = () => {
    const [value, setValue] = React.useState<Date | null>(new Date(2021, 2, 6, 15, 30));

    const handleChange = React.useCallback((newValue: Date | Date[] | null) => {
        if (!Array.isArray(newValue)) {
            setValue(newValue);
        }
    }, []);
    const customInput = <span>{value?.toISOString()}</span>;
    return <DatePicker value={value} onChange={handleChange} customInput={customInput} />;
};

CustomInput.parameters = {
    docs: {
        description: {
            story: "The customInput allows a custom React component to replace the default input element, enabling complete control over the date field’s appearance and behavior. \n\n This prop maps directly to the underlying react-datepicker customInput property. Internally react-datepicker will clone the element that you pass here and add a bunch of props to make it work. Check how Kalep's DatePickerInput component works (in Datepicker.tsx)",
        },
    },
};

export const ControlledRange = () => {
    const [startValue, setStartValue] = React.useState<Date | null>(null);
    const [endValue, setEndValue] = React.useState<Date | null>(null);

    const handleChange = React.useCallback((newRange: Date | Date[] | null) => {
        if (Array.isArray(newRange)) {
            const [start, end] = newRange;
            setStartValue(start);
            setEndValue(end);
        }
    }, []);

    return <DatePicker isRange startValue={startValue} endValue={endValue} onChange={handleChange} />;
};

ControlledRange.parameters = {
    docs: {
        description: {
            story: "Similarly to the regular controlled Datepicker, the range Datepicker (`isRange` prop is `true`) switches to being controlled whenever `startValue` or `endValue` is not `undefined`. For range Datepicker, the `onChange` callback is called with a date array that contains both the start and end dates.",
        },
    },
};

export const CustomStartAndEndSlot = Template.bind({});
CustomStartAndEndSlot.args = {
    ...Default.args,
    renderStartSlot: () => <Calendar />,
    renderEndSlot: () => <Time />,
};

const predefinedDateRanges = ["KALEP_DATE_RANGE_LAST_7_DAYS" as const, "KALEP_DATE_RANGE_LAST_14_DAYS" as const];

export const PredefinedRangesDefaultValues = () => {
    const [startValue, setStartValue] = React.useState<Date | null>(null);
    const [endValue, setEndValue] = React.useState<Date | null>(null);

    const handleChange = React.useCallback((newRange: Date | Date[] | null) => {
        if (Array.isArray(newRange)) {
            const [start, end] = newRange;
            setStartValue(start);
            setEndValue(end);
        }
    }, []);

    // Defined outside of component:
    // const predefinedDateRanges = ["KALEP_DATE_RANGE_LAST_7_DAYS" as const, "KALEP_DATE_RANGE_LAST_14_DAYS" as const];

    return (
        <DatePicker
            isRange
            startValue={startValue}
            endValue={endValue}
            onChange={handleChange}
            predefinedRanges={predefinedDateRanges}
        />
    );
};

const today = new Date();

export const PredefinedRangesCustomValues = () => {
    const [startValue, setStartValue] = React.useState<Date | null>(null);
    const [endValue, setEndValue] = React.useState<Date | null>(null);

    const customRanges = React.useMemo(
        () => [
            {
                key: "17days",
                label: "Last 17 days",
                startDate: new Date(today.getFullYear(), today.getMonth(), today.getDate() - 16),
                endDate: today,
            },
            {
                key: "1month",
                label: "Last month",
                startDate: new Date(today.getFullYear(), today.getMonth() - 1, today.getDate()),
                endDate: today,
            },
            "KALEP_DATE_RANGE_LAST_3_DAYS" as const,
        ],
        [],
    );

    const handleChange = React.useCallback((newRange: Date | Date[] | null) => {
        if (Array.isArray(newRange)) {
            const [start, end] = newRange;
            setStartValue(start);
            setEndValue(end);
        }
    }, []);

    return (
        <DatePicker
            isRange
            startValue={startValue}
            endValue={endValue}
            onChange={handleChange}
            predefinedRanges={customRanges}
        />
    );
};

export const DateTimePicker = Template.bind({});
DateTimePicker.args = {
    label: "Date and time",
    locale: "en-GB",
    format: "dd.MM.yyyy HH:mm",
    timeFormat: "HH:mm",
    startDay: 1,
    hasTimeSelect: true,
    name: "startdate",
    onChange: (...args) => console.log(args),
};

export const TimePicker = Template.bind({});
TimePicker.args = {
    label: "Pick time only, no date, thank you",
    locale: "en-GB",
    format: "HH:mm",
    timeFormat: "HH:mm",
    hasTimeSelect: true,
    hasTimeSelectOnly: true,
    name: "starttime",
    onChange: (...args) => console.log(args),
};

export const TimePickerWithLimits = Template.bind({});
TimePickerWithLimits.args = {
    label: "You can limit options using minTime and maxTime props",
    locale: "en-GB",
    format: "HH:mm",
    timeFormat: "HH:mm",
    hasTimeSelect: true,
    hasTimeSelectOnly: true,
    onChange: (...args) => console.log(args),
    minTime: new Date("2025-01-05 13:00"),
    maxTime: new Date("2025-01-05 17:00"),
};

const setHours = (date: Date, hours: number, minutes?: number, seconds?: number): Date => {
    return new Date(date.setHours(hours, minutes, seconds));
};

export const DateTimePickerWithCustomTimeOptions = Template.bind({});
DateTimePickerWithCustomTimeOptions.args = {
    label: "Date and time, with 23:59 added as an option",
    locale: "en-GB",
    format: "dd.MM.yyyy HH:mm",
    timeFormat: "HH:mm",
    startDay: 1,
    hasTimeSelect: true,
    name: "startdate",
    onChange: (...args) => console.log(args),
    injectTimes: [setHours(new Date(), 23, 59, 0)],
};

export const Placement = () => {
    const [placement, setPlacement] = React.useState<PopperPlacement>("bottom-start");
    const handler: React.ChangeEventHandler<HTMLSelectElement> = React.useCallback(
        (event) => setPlacement(event.target.value as PopperPlacement),
        [],
    );

    return (
        <div>
            <label htmlFor="placement">Select placement value:</label>
            <select id="placement" value={placement} onChange={handler}>
                <option value="top">top</option>
                <option value="top-start">top-start</option>
                <option value="top-end">top-end</option>
                <option value="bottom">bottom</option>
                <option value="bottom-start">bottom-start</option>
                <option value="bottom-end">bottom-end</option>
                <option value="left">left</option>
                <option value="left-start">left-start</option>
                <option value="left-end">left-end</option>
                <option value="right">right</option>
                <option value="right-start">right-start</option>
                <option value="right-end">right-end</option>
                <option value="auto">auto</option>
                <option value="auto-start">auto-start</option>
                <option value="auto-end">auto-end</option>
            </select>
            <div className="grid min-h-[800px] place-items-center">
                <DatePicker label="Date" popperPlacement={placement} />
            </div>
        </div>
    );
};

export const FullWidth = Template.bind({});
FullWidth.args = {
    label: "Date",
    locale: "en-GB",
    format: "dd.MM.yyyy",
    helperText: "Select a nice date",
    startDay: 1,
    fullWidth: true,
};
