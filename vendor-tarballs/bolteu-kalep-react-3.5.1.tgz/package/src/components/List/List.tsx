import * as React from "react";

import {cx} from "@/helpers/utils/cx";

import type {ListItemLayoutProps} from "../ListItemLayout";
import {ListItemLayout} from "../ListItemLayout";
import type {ListProps} from "./List.types";

const ListInternal = React.forwardRef<HTMLUListElement, ListProps>(function ListComponent(
    {children, className, ...rest}: ListProps,
    ref: React.Ref<HTMLUListElement>,
): JSX.Element {
    return (
        <ul className={cx("m-0 list-none p-0", className)} ref={ref} {...rest}>
            {children}
        </ul>
    );
});

function ListItemInternal(props: ListItemLayoutProps) {
    return (
        <li>
            <ListItemLayout {...props} />
        </li>
    );
}

export const List = {
    Root: ListInternal,
    Item: ListItemInternal,
};
