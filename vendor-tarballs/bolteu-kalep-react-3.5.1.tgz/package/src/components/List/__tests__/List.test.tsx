import {defaultItems, getItems, getList, renderList} from "./List.testUtils";

test("renders a list with items", function listRender() {
    renderList();

    expect(getList()).toBeInTheDocument();
    expect(getItems()).toHaveLength(defaultItems.length);
});
