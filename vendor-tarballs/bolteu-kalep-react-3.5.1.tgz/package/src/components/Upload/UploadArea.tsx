import * as React from "react";

import AlertOutlined from "@bolteu/kalep-react-icons/dist/AlertOutlined";
import InfoCircleOutlined from "@bolteu/kalep-react-icons/dist/InfoCircleOutlined";

import {Button} from "@/components/Button";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

const DROP_AREA_DEFAULT_PRIMARY_TEXT = "Drop files here to upload";
const DROP_AREA_DEFAULT_SECONDARY_TEXT = "or choose from your device";
const BROWSE_BUTTON_DEFAULT_TEXT = "Browse";

export type UploadAreaProps = {
    onFilesAttached: (files: File[]) => void;
    filesAttached?: boolean;
    fullWidth?: boolean;
    disabled?: boolean;
    required?: boolean;
    multiple?: boolean;
    id?: string;
    name?: string;
    label?: string;
    helperText?: React.ReactNode;
    renderDropAreaContent?: (props: UploadAreaProps) => React.ReactNode;
    accept?: string;
    dropAreaPrimaryText?: string;
    dropAreaSecondaryText?: string;
    browseButtonText?: string;
};

export function UploadArea({
    onFilesAttached,
    filesAttached = false,
    fullWidth = false,
    disabled = false,
    required = false,
    multiple = false,
    id,
    name,
    label,
    helperText,
    renderDropAreaContent = renderDropAreaContentDefault,
    accept,
    dropAreaPrimaryText = DROP_AREA_DEFAULT_PRIMARY_TEXT,
    dropAreaSecondaryText = DROP_AREA_DEFAULT_SECONDARY_TEXT,
    browseButtonText = BROWSE_BUTTON_DEFAULT_TEXT,
}: UploadAreaProps) {
    const fileInputRef = React.useRef<HTMLInputElement>(null);
    const dropTargetRef = React.useRef<HTMLDivElement>(null);
    const generatedId = useId();
    const inputId = id ?? generatedId;

    const handleButtonClick = React.useCallback(() => {
        if (disabled) {
            return;
        }

        if (fileInputRef.current) {
            // Reset input.
            fileInputRef.current.value = "";
            fileInputRef.current.click();
        }
    }, [fileInputRef, disabled]);

    const handleInputChange = React.useCallback(
        (event: React.ChangeEvent<HTMLInputElement>) => {
            if (event.target.files) {
                onFilesAttached(toFileArray(event.target.files));
            }
        },
        [onFilesAttached],
    );
    const handleDragOver = React.useCallback(
        (event: React.DragEvent) => {
            event.preventDefault();

            if (disabled) {
                return;
            }

            if (dropTargetRef.current && !dropTargetRef.current.classList.contains("border-positive-primary")) {
                dropTargetRef.current.classList.remove("border-neutral-secondary");
                dropTargetRef.current.classList.add("border-positive-primary");
                dropTargetRef.current.classList.remove("bg-transparent");
                dropTargetRef.current.classList.add("bg-positive-secondary");
            }
        },
        [disabled],
    );
    const handleDragLeave = React.useCallback(
        (event: React.DragEvent) => {
            event.preventDefault();

            if (disabled) {
                return;
            }

            if (dropTargetRef.current && !dropTargetRef.current.classList.contains("border-neutral-secondary")) {
                dropTargetRef.current.classList.add("border-neutral-secondary");
                dropTargetRef.current.classList.remove("border-positive-primary");
                dropTargetRef.current.classList.add("bg-transparent");
                dropTargetRef.current.classList.remove("bg-positive-secondary");
            }
        },
        [disabled],
    );

    const handleDrop = React.useCallback(
        (event: React.DragEvent) => {
            event.preventDefault();

            if (disabled) {
                return;
            }

            if (event.dataTransfer.files) {
                onFilesAttached(toFileArray(event.dataTransfer.files));
            }

            // handle the case when dragleave is not naturally triggered and drop target is still highlighted
            handleDragLeave(event);
        },
        [onFilesAttached, disabled, handleDragLeave],
    );

    return (
        <div className={cx("flex flex-col gap-2")}>
            {label && (
                <label
                    htmlFor={inputId}
                    className={cx(
                        "bolt-font-body-s-accent w-fit",
                        disabled ? "text-tertiary" : "text-primary",
                        required && "after:text-danger-primary after:content-['_*']",
                    )}
                >
                    {label}
                </label>
            )}
            <div
                className={cx(
                    "rounded border-2 border-dashed border-neutral-secondary",
                    "flex items-center justify-between gap-4",
                    "bg-special-nulled",
                    filesAttached ? "flex-row p-3" : "flex-col px-10 py-6",
                    fullWidth ? "w-full" : "w-96",
                    disabled && "cursor-not-allowed",
                )}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                ref={dropTargetRef}
            >
                {renderDropAreaContent({
                    onFilesAttached,
                    filesAttached,
                    fullWidth,
                    disabled,
                    id,
                    name,
                    label,
                    dropAreaPrimaryText,
                    dropAreaSecondaryText,
                })}

                <input
                    id={inputId}
                    name={name}
                    type="file"
                    disabled={disabled}
                    onChange={handleInputChange}
                    className={cx("hidden")}
                    ref={fileInputRef}
                    multiple={multiple}
                    accept={accept}
                />
                <Button variant="secondary" size="sm" onClick={handleButtonClick} disabled={disabled}>
                    {browseButtonText}
                </Button>
            </div>
            {helperText && (
                <div
                    className={cx("bolt-font-body-s-regular text-secondary", disabled && "text-tertiary", {
                        /* error && "text-danger-primary", */
                    })}
                >
                    {helperText}
                </div>
            )}
        </div>
    );
}

function renderDropAreaContentDefault(props: UploadAreaProps) {
    return (
        <div className={cx("flex flex-col")}>
            <span className={cx("bolt-font-body-m-regular", props.disabled ? "text-secondary" : "text-primary")}>
                {props.dropAreaPrimaryText}
            </span>
            <span className={cx("bolt-font-body-s-regular", props.disabled ? "text-tertiary" : "text-secondary")}>
                {props.dropAreaSecondaryText}
            </span>
        </div>
    );
}

function toFileArray(files: FileList): File[] {
    return Array.from(files);
}

export type UploadHelperTextProps = {
    children?: React.ReactNode;
    appearance?: "default" | "error" | "info";
    disabled?: boolean;
};

export function UploadHelperText({
    disabled,
    appearance = "default",
    children,
}: UploadHelperTextProps): JSX.Element | null {
    if (!children) {
        return null;
    }

    return (
        <div
            className={cx(
                "bolt-font-body-s-regular text-secondary",
                "mt-1 flex items-center gap-2",
                disabled && "text-tertiary",
                appearance === "error" && "text-danger-primary",
            )}
        >
            {appearance === "info" && <InfoCircleOutlined size="sm" />}
            {appearance === "error" && <AlertOutlined size="sm" />}
            {children}
        </div>
    );
}
