import * as React from "react";

import CheckCircleOutlined from "@bolteu/kalep-react-icons/dist/CheckCircleOutlined";
import Upload from "@bolteu/kalep-react-icons/dist/Upload";

import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import {IconButton} from "@/index";

import {Button} from "../Button";
import {UploadArea} from "./UploadArea";
import {UploadAttachments} from "./UploadAttachments";

export default {
    title: "Inputs/Upload",
    tags: ["autodocs"],
};

const mockFiles = [
    {name: "file1.txt", size: 1000, type: "text/plain"},
    {name: "file2.txt", size: 3000, type: "text/plain"},
] as File[];
const mockFilesHandler = (_files: File[]) => {};

export const UploadAreaComponent = () => <UploadArea onFilesAttached={mockFilesHandler} />;
export const UploadAreaComponentWithCustomLabels = () => (
    <UploadArea
        onFilesAttached={mockFilesHandler}
        dropAreaPrimaryText="Drag and drop photos here"
        dropAreaSecondaryText="or select from your photos"
        browseButtonText="Select photo"
    />
);
export const UploadAttachmentsComponent = () => <UploadAttachments files={mockFiles} />;
export const UploadAttachmentsRemovable = () => {
    const [files, setFiles] = React.useState<File[]>(structuredClone(mockFiles));

    const handleRemove = React.useCallback(
        (file: File) => {
            const i = files.findIndex((f) => f === file);
            files.splice(i, 1);
            setFiles([...files]);
        },
        [files],
    );

    const handleReset = React.useCallback(() => {
        setFiles(structuredClone(mockFiles));
    }, []);

    return (
        <>
            <UploadAttachments files={files} onRemoveFile={handleRemove} />
            <Button variant="secondary" size="sm" onClick={handleReset}>
                Restore files
            </Button>
        </>
    );
};

function EndSlot({startUpload, isUploadInProgress, isUploaded}: any) {
    if (isUploaded) {
        return <IconButton aria-label="Uploaded" disabled icon={<CheckCircleOutlined />} />;
    }

    if (isUploadInProgress) {
        return <IconButton aria-label="Uploading" disabled icon={<SpinnerIcon className="animate-spin" />} />;
    }

    return <IconButton aria-label="Upload" onClick={startUpload} icon={<Upload />} />;
}

export const UploadAttachmentsCustomEndSlot = () => {
    const [files] = React.useState<File[]>([structuredClone(mockFiles[0])]);
    const [isUploadInProgress, setUploadInProgress] = React.useState(false);
    const [isUploaded, setIsUploaded] = React.useState(false);

    // This is for demonstration only.
    const handleUpload = React.useCallback(() => {
        setUploadInProgress(true);

        setTimeout(() => {
            setUploadInProgress(false);
            setIsUploaded(true);
        }, 2000);
    }, []);

    const handleReset = React.useCallback(() => {
        setUploadInProgress(false);
        setIsUploaded(false);
    }, []);

    const endSlotRenderer = React.useCallback(
        () => <EndSlot startUpload={handleUpload} isUploadInProgress={isUploadInProgress} isUploaded={isUploaded} />,
        [handleUpload, isUploadInProgress, isUploaded],
    );

    return (
        <>
            <UploadAttachments files={files} renderEndSlot={endSlotRenderer} />
            <Button variant="secondary" size="sm" onClick={handleReset}>
                Reset
            </Button>
        </>
    );
};

export const CompleteUploadExample = () => {
    const [files, setFiles] = React.useState<File[]>([]);

    const handleRemove = React.useCallback(
        (file: File) => {
            const i = files.findIndex((f) => f === file);
            files.splice(i, 1);
            setFiles([...files]);
        },
        [files],
    );

    return (
        <>
            <UploadArea label="Any random file" onFilesAttached={setFiles} filesAttached={!!files.length} multiple />
            <UploadAttachments files={files} onRemoveFile={handleRemove} />
        </>
    );
};

CompleteUploadExample.story = {
    parameters: {
        docs: {
            storyDescription: `
This is an example of how to use the \`UploadArea\` and \`UploadAttachments\` components together.\n\n
The form here accepts multiple files, but each selection replaces the previous selection. This behavior is up to the consumer.
            `,
        },
    },
};

export const LongFileNameExample = () => {
    const [files, setFiles] = React.useState<File[]>([
        {
            name: "_rminos_y_Condiciones_para_Pasajeros___ltima_actualizaci_n__8_de_diciembre_de__2023__.docx__2_.pdf",
            size: 2700,
            type: "text/plain",
        } as File,
    ]);

    const handleRemove = React.useCallback(
        (file: File) => {
            const i = files.findIndex((f) => f === file);
            files.splice(i, 1);
            setFiles([...files]);
        },
        [files],
    );

    const handleAdd = React.useCallback((newFiles: File[]) => setFiles([...files, ...newFiles]), [files]);

    return (
        <>
            <UploadArea label="Any random file" onFilesAttached={handleAdd} filesAttached={!!files.length} multiple />
            <UploadAttachments files={files} onRemoveFile={handleRemove} />
        </>
    );
};
