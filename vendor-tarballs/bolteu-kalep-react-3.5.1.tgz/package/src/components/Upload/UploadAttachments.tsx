import * as React from "react";

import Cross from "@bolteu/kalep-react-icons/dist/Cross";

import {cx} from "@/helpers/utils/cx";

import {IconButton} from "../IconButton";

export type UploadAttachmentsProps = {
    files?: File[];
    onRemoveFile?: (file: File) => void;
    renderEndSlot?: (props: UploadAttachmentProps) => React.ReactNode;
    fullWidth?: boolean;
};

export function UploadAttachments({files, onRemoveFile, fullWidth, renderEndSlot}: UploadAttachmentsProps) {
    if (!files || !files.length) {
        return null;
    }

    return (
        <div className={cx(fullWidth ? "w-full" : "w-96")}>
            {files.map((file) => (
                <UploadAttachment key={file.name} file={file} onRemove={onRemoveFile} renderEndSlot={renderEndSlot} />
            ))}
        </div>
    );
}

export type UploadAttachmentProps = {
    file: File;
    onRemove?: (file: File) => void;
    renderEndSlot?: (props: UploadAttachmentProps) => React.ReactNode;
};

export function UploadAttachment(props: UploadAttachmentProps) {
    const {file, renderEndSlot = renderEndSlotDefault, onRemove: _onRemove} = props;

    return (
        <div className={cx("flex items-center gap-2 px-4 py-3")}>
            <div className={cx("flex flex-1 flex-col")}>
                <span className={cx("bolt-font-body-m-regular break-all")}>{file.name}</span>
                <span className={cx("bolt-font-body-s-regular text-secondary")}>
                    {getHumanFileSize(file.size)} - {file.type}
                </span>
            </div>
            <div className={cx("flex-shrink-0")}>{renderEndSlot(props)}</div>
        </div>
    );
}

function renderEndSlotDefault(props: UploadAttachmentProps) {
    const {onRemove} = props;

    if (typeof onRemove === "function") {
        return <IconButton aria-label="Remove file" icon={<Cross />} onClick={() => onRemove(props.file)} size="sm" />;
    }

    return null;
}

function getHumanFileSize(size: number) {
    if (size < 1000000) {
        return `${(size / 1024).toFixed(2)}KiB`;
    }
    return `${(size / 1024 / 1024).toFixed(2)}MiB`;
}
