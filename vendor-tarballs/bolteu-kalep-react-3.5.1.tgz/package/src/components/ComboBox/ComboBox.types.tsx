import type * as React from "react";

import type {
    UseComboboxGetInputPropsOptions,
    UseComboboxGetInputPropsReturnValue,
    UseComboboxGetToggleButtonPropsOptions,
    UseComboboxGetToggleButtonPropsReturnValue,
    UseMultipleSelectionGetDropdownReturnValue,
} from "downshift";

import type {OptionProps, SelectOption} from "@/components/_internal/Option";
import type {OverlayProps} from "@/components/_internal/Overlay";
import type {RenderFunction} from "@/helpers";

export type Size = "sm" | "md" | "lg";

export interface BaseComboBoxProps extends ComboBoxProps {
    getDropdownProps?: (ref: React.RefObject<HTMLInputElement>) => UseMultipleSelectionGetDropdownReturnValue;
    onClear?: () => void;
    onDelete?: (index: number) => void;
}

export interface ComboBoxProps {
    options: SelectOption[];

    onChange?: (newValue: SelectOption | SelectOption[] | null) => void;
    onInputChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;

    id?: string;
    name?: string;
    value?: SelectOption | SelectOption[] | null;
    inputValue?: string;
    multiple?: boolean;
    multiline?: boolean; // TODO: Add multiline support for single mode
    freeSolo?: boolean;
    readonly?: boolean;
    clearable?: boolean;
    open?: boolean;

    required?: boolean;
    disabled?: boolean;
    error?: boolean;
    loading?: boolean;

    defaultValue?: SelectOption | SelectOption[];
    defaultInputValue?: string;
    defaultOpen?: boolean;

    label?: string;
    placeholder?: string;
    helperText?: React.ReactNode;
    infoText?: string;

    size?: Size;
    fullWidth?: boolean;
    rootClassName?: string;
    overlayConfig?: OverlayProps;
    disableCloseOnSelect?: boolean;
    shouldRenderEndSlotIcon?: boolean;
    noResultsMessage?: string;
    loadingSpinnerAriaLabel?: string;
    toggleButtonAriaLabel?: string;

    filterOptions?: (
        options: SelectOption[],
        filterHelpers: {inputValue: string; getOptionLabel: (option: SelectOption) => string},
    ) => SelectOption[];
    renderOption?: RenderFunction<OptionProps>;
    getOptionLabel?: (option: SelectOption | null) => string;
    getValueFromOption?: (option: SelectOption | null) => string;
    isOptionEqualToValue?: (option: SelectOption, value: SelectOption) => boolean;

    renderHelperText?: RenderFunction<ComboBoxHelperTextProps>;
    renderStartSlot?: RenderFunction<ComboBoxTriggerProps>;
    renderEndSlot?: RenderFunction<ComboBoxTriggerProps>;
    renderOverlayFooter?: RenderFunction<ComboBoxProps>;

    portalContainer?: HTMLElement;
}

export interface ComboBoxHelperTextProps extends ComboBoxProps {
    helperTextId: string;
}

export interface ComboBoxTriggerProps {
    clearable?: boolean;
    closeMenu: () => void;
    comboBoxId: string;
    controlledInputValue?: string;
    disabled?: boolean;
    error?: boolean;
    fullWidth?: boolean;
    generatedId: string;
    getDropdownProps?: (ref: React.RefObject<HTMLInputElement>) => UseMultipleSelectionGetDropdownReturnValue;
    getInputProps: (options?: UseComboboxGetInputPropsOptions) => UseComboboxGetInputPropsReturnValue;
    getOptionLabel: (option: SelectOption | null) => string;
    getToggleButtonProps: (
        options?: UseComboboxGetToggleButtonPropsOptions,
    ) => UseComboboxGetToggleButtonPropsReturnValue;
    id?: string;
    inputValue: string;
    inputWrapperRef: React.RefObject<HTMLDivElement>;
    isOpen: boolean;
    loading?: boolean;
    loadingSpinnerAriaLabel?: string;
    multiple?: boolean;
    multiline?: boolean;
    name?: string;
    noResultsMessageId?: string;
    onDelete?: (index: number) => void;
    onClear?: () => void;
    onInputChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
    openMenu: () => void;
    placeholder?: string;
    renderStartSlot?: RenderFunction<ComboBoxTriggerProps>;
    renderEndSlot?: RenderFunction<ComboBoxTriggerProps>;
    required?: boolean;
    shouldRenderEndSlotIcon?: boolean;
    shouldShowNoResultsMessage?: boolean;
    size?: Size;
    toggleButtonAriaLabel?: string;
    toggleButtonRef: React.RefObject<HTMLButtonElement>;
    value?: SelectOption | SelectOption[] | null;
}
