import * as React from "react";

import type {UseComboboxState, UseComboboxStateChangeOptions} from "downshift";
import {useCombobox} from "downshift";
import {OverlayContainer, useOverlayPosition} from "@react-aria/overlays";
import {useVirtualizer} from "@tanstack/react-virtual";

import {renderHelperTextDefault} from "@/components/_internal/HelperText";
import {Label} from "@/components/_internal/Label";
import {KALEP_MODAL_CONTENT_ID} from "@/components/_internal/Modal";
import type {SelectOption} from "@/components/_internal/Option";
import {getOptionLabelDefault, renderOptionDefault} from "@/components/_internal/Option";
import {guessOverlayPosition} from "@/components/_internal/Overlay";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";
import {noopNull} from "@/helpers/utils/noop";

import {KALEP_BOTTOMSHEET_CONTENT_ID} from "../BottomSheet/BottomSheet";
import type {BaseComboBoxProps, ComboBoxTriggerProps} from "./ComboBox.types";
import {ComboBoxTrigger} from "./ComboBoxTrigger";
import {filterOptionsDefault, virtualizerEstimateHeightBySize} from "./helpers";

const DEFAULT_VIRTUALIZER_OVERSCAN = 4;
const VIRTUALIZER_VERTICAL_PADDING = 8;

export const DEFAULT_LOADING_SPINNER_ARIA_LABEL = "loading results";
export const DEFAULT_TOGGLE_BUTTON_ARIA_LABEL = "toggle options list";

export const BaseComboBox = React.forwardRef<HTMLInputElement, BaseComboBoxProps>(
    // TODO: Proper ref forwarding and merging for Combobox
    (props, _forwardedRef): JSX.Element => {
        const {
            clearable = true,
            defaultInputValue,
            defaultOpen,
            defaultValue,
            disableCloseOnSelect,
            disabled,
            error,
            filterOptions = filterOptionsDefault,
            freeSolo,
            fullWidth,
            getDropdownProps,
            getOptionLabel = getOptionLabelDefault,
            id,
            infoText,
            inputValue: controlledInputValue,
            label,
            loading,
            loadingSpinnerAriaLabel,
            multiple,
            multiline,
            name,
            noResultsMessage,
            onChange,
            onClear,
            onDelete,
            onInputChange,
            open,
            options,
            overlayConfig,
            placeholder,
            renderOption = renderOptionDefault,
            renderHelperText = renderHelperTextDefault,
            renderStartSlot,
            renderEndSlot,
            renderOverlayFooter = noopNull,
            required,
            rootClassName,
            shouldRenderEndSlotIcon,
            size = "md",
            toggleButtonAriaLabel,
            value: valueProp,
            portalContainer,
        } = props;

        const internalRef = React.useRef<HTMLDivElement>(null);
        const dropdownRef = React.useRef<HTMLDivElement>(null);
        const listParentRef = React.useRef<HTMLDivElement>(null);
        const toggleButtonRef = React.useRef<HTMLButtonElement>(null);

        const generatedId = useId(id);
        const comboBoxId = id ?? `kalep-combo-box-${generatedId}`;
        const noResultsMessageId = id ?? `kalep-combo-box-no-results-message-${generatedId}`;
        const helperTextId = `${comboBoxId}-helper-text`;

        const [filteredOptions, setFilteredOptions] = React.useState(options);

        const count = filteredOptions.length;
        const virtualizer = useVirtualizer({
            count,
            getScrollElement: () => listParentRef.current,
            estimateSize: () => virtualizerEstimateHeightBySize(size),
            overscan: DEFAULT_VIRTUALIZER_OVERSCAN,
        });
        const virtualItems = virtualizer.getVirtualItems();

        const useComboboxStateReducer = React.useCallback(
            (
                state: UseComboboxState<SelectOption>,
                actionAndChanges: UseComboboxStateChangeOptions<SelectOption>,
            ): Partial<UseComboboxState<SelectOption>> => {
                const shouldStayOpenOnSelect = disableCloseOnSelect === undefined ? multiple : disableCloseOnSelect;
                switch (actionAndChanges.type) {
                    // Do not close the menu after selection, reset input value for multiple select
                    case useCombobox.stateChangeTypes.InputKeyDownEnter:
                    case useCombobox.stateChangeTypes.ItemClick:
                        return {
                            ...actionAndChanges.changes,
                            isOpen: shouldStayOpenOnSelect,
                            highlightedIndex: state.highlightedIndex,
                            inputValue: multiple ? "" : actionAndChanges.changes.inputValue,
                        };
                    case useCombobox.stateChangeTypes.ControlledPropUpdatedSelectedItem: {
                        return {
                            ...actionAndChanges.changes,
                            // In multiple Combobox this state change swallows the first character typed into the input after selection
                            inputValue: multiple ? state.inputValue : actionAndChanges.changes.inputValue,
                        };
                    }
                    default:
                        return actionAndChanges.changes;
                }
            },
            [multiple, disableCloseOnSelect],
        );

        const {
            isOpen,
            inputValue,
            highlightedIndex,
            selectedItem,
            getMenuProps,
            getItemProps,
            getLabelProps,
            getInputProps,
            getToggleButtonProps,
            openMenu,
            closeMenu,
            selectItem,
        } = useCombobox<SelectOption>({
            id: comboBoxId,
            items: filteredOptions,
            itemToString(option) {
                if (option?.isCustom) {
                    return String(option.value);
                }

                return option ? getOptionLabel(option) : "";
            },
            isItemDisabled(option) {
                return !!option.disabled;
            },
            onIsOpenChange(changes) {
                if (changes.isOpen && changes.highlightedIndex !== undefined && changes.highlightedIndex >= 0) {
                    virtualizer.scrollToIndex(changes.highlightedIndex);
                }
            },
            onHighlightedIndexChange(changes) {
                if (
                    (changes.type === useCombobox.stateChangeTypes.InputKeyDownArrowUp ||
                        changes.type === useCombobox.stateChangeTypes.InputKeyDownArrowDown) &&
                    changes.highlightedIndex !== undefined &&
                    changes.highlightedIndex !== highlightedIndex
                ) {
                    virtualizer.scrollToIndex(changes.highlightedIndex);
                }
            },
            onStateChange(changes) {
                switch (changes.type) {
                    case useCombobox.stateChangeTypes.InputBlur:
                    case useCombobox.stateChangeTypes.ItemClick:
                    case useCombobox.stateChangeTypes.InputKeyDownEnter:
                    case useCombobox.stateChangeTypes.InputKeyDownEscape: {
                        if (changes.selectedItem !== undefined && typeof onChange === "function") {
                            onChange(
                                changes.selectedItem?.isCustom
                                    ? {value: changes.selectedItem.value}
                                    : changes.selectedItem,
                            );
                        }

                        setFilteredOptions(options);
                        break;
                    }
                    case useCombobox.stateChangeTypes.InputChange: {
                        if (controlledInputValue === undefined) {
                            setFilteredOptions(
                                filterOptions(options, {
                                    inputValue: changes.inputValue || "",
                                    getOptionLabel,
                                    freeSolo,
                                }),
                            );
                        }

                        break;
                    }
                    default:
                        break;
                }
            },
            stateReducer: useComboboxStateReducer,
            selectedItem: multiple ? null : (valueProp as SelectOption), // Downshift instructs to set selectedItem null for multicombobox
            initialSelectedItem: defaultValue as SelectOption,
            inputValue: controlledInputValue,
            initialInputValue: defaultInputValue,
            initialIsOpen: defaultOpen,
            isOpen: open,
        });

        const handleClear = React.useCallback(() => {
            selectItem(null);
            onChange?.(null);
            onClear?.();
        }, [onChange, selectItem, onClear]);

        React.useEffect(() => {
            setFilteredOptions(
                filterOptions(options, {
                    inputValue: controlledInputValue ?? "",
                    getOptionLabel,
                    freeSolo,
                }),
            );
        }, [controlledInputValue, filterOptions, freeSolo, getOptionLabel, options]);

        const {overlayProps} = useOverlayPosition({
            targetRef: internalRef,
            overlayRef: dropdownRef,
            isOpen,

            // Default
            placement: "bottom",
            offset: 4,

            // Optional overrides
            ...(overlayConfig?.position || {}),
        });

        if (
            overlayProps?.style &&
            overlayProps.style.top == null &&
            overlayProps.style.bottom == null &&
            isOpen &&
            internalRef.current
        ) {
            // FIXME: Hack to prevent page from scrolling to the end when Combobox opens for the 1st time
            // More context: https://github.com/bolteu/kalep/pull/730
            overlayProps.style.top = guessOverlayPosition(internalRef.current);
        }

        const overlayStyle = {...overlayProps.style, zIndex: undefined}; // We want to control z-index ourselves

        const menuA11yProps = getMenuProps({ref: dropdownRef}, {suppressRefError: true});

        const shouldShowNoResultsMessage = isOpen && filteredOptions.length === 0 && !!noResultsMessage && !freeSolo;

        const triggerProps: ComboBoxTriggerProps = {
            clearable,
            closeMenu,
            comboBoxId,
            controlledInputValue,
            disabled,
            error,
            fullWidth,
            generatedId,
            getInputProps: getInputProps as any, // TODO: Sth wrong with types here
            getToggleButtonProps: getToggleButtonProps as any, // TODO: Sth wrong with types here
            getDropdownProps,
            getOptionLabel,
            id,
            inputValue,
            inputWrapperRef: internalRef,
            isOpen,
            loading,
            loadingSpinnerAriaLabel,
            multiple,
            multiline,
            name,
            noResultsMessageId,
            onClear: handleClear,
            onDelete,
            onInputChange,
            openMenu,
            placeholder,
            renderStartSlot,
            renderEndSlot,
            required,
            shouldShowNoResultsMessage,
            shouldRenderEndSlotIcon,
            size,
            toggleButtonAriaLabel,
            toggleButtonRef,
            value: multiple ? valueProp : selectedItem,
        };

        return (
            <div className={cx("min-w-0", rootClassName)}>
                <div className={cx("flex flex-col gap-2", fullWidth ? "w-full" : "w-96")}>
                    {label && (
                        <Label
                            text={label}
                            infoText={infoText}
                            required={required}
                            disabled={disabled}
                            htmlProps={getLabelProps()}
                        />
                    )}
                    <ComboBoxTrigger {...triggerProps} />
                    {renderHelperText({...props, helperTextId}, renderHelperTextDefault)}
                </div>
                {isOpen && (
                    <OverlayContainer
                        portalContainer={
                            portalContainer ||
                            internalRef?.current?.closest("dialog") ||
                            internalRef?.current?.closest(`#${KALEP_MODAL_CONTENT_ID}`) ||
                            internalRef?.current?.closest(`#${KALEP_BOTTOMSHEET_CONTENT_ID}`) ||
                            document.body
                        }
                    >
                        <div
                            className={cx("absolute z-dropdown", "max-h-80 w-max rounded-md shadow-md")}
                            {...menuA11yProps}
                            style={{
                                minWidth: overlayConfig?.minWidth ? `${overlayConfig.minWidth}px` : "initial",
                                maxWidth: overlayConfig?.maxWidth ? `${overlayConfig.maxWidth}px` : "initial",
                                width: internalRef.current?.clientWidth || "initial",
                                ...overlayStyle,
                            }}
                        >
                            <div
                                ref={listParentRef}
                                className={cx(
                                    "max-h-80 w-full overflow-y-auto overscroll-none rounded-md bg-layer-floor-3",
                                    fullWidth && "w-full",
                                )}
                                // eslint-disable-next-line jsx-a11y/no-noninteractive-tabindex -- in case it's scrollable.
                                tabIndex={0}
                            >
                                <div
                                    className={cx("relative")}
                                    style={{
                                        height: shouldShowNoResultsMessage
                                            ? undefined
                                            : virtualizer.getTotalSize() + VIRTUALIZER_VERTICAL_PADDING,
                                    }}
                                >
                                    <ul
                                        className={cx(
                                            `
                                              m-0 list-none px-0 py-1
                                              empty:py-0
                                            `,
                                            "max-h-full overflow-y-hidden",
                                            "cursor-pointer",
                                        )}
                                        style={{transform: `translateY(${virtualItems[0]?.start ?? 0}px)`}}
                                        role="listbox"
                                    >
                                        {virtualItems.map((virtualItem) => {
                                            const {index} = virtualItem;
                                            const option = filteredOptions[index];
                                            const optionLabel = getOptionLabel(option);

                                            const optionProps = {
                                                ...getItemProps({
                                                    item: option,
                                                    index,
                                                }),
                                                highlighted: highlightedIndex === index,
                                                selected: selectedItem === option,
                                                option,
                                                label: optionLabel,
                                                key: virtualItem.key.toString(),
                                                ref: virtualizer.measureElement,
                                                "data-index": virtualItem.index,
                                                size,
                                            };

                                            return typeof renderOption === "function"
                                                ? renderOption(optionProps, renderOptionDefault)
                                                : renderOptionDefault(optionProps);
                                        })}
                                    </ul>
                                    {shouldShowNoResultsMessage && (
                                        <div
                                            id={noResultsMessageId}
                                            className={cx("flex items-center px-6 py-2 text-primary")}
                                        >
                                            {noResultsMessage}
                                        </div>
                                    )}
                                </div>
                                {renderOverlayFooter(props, noopNull)}
                            </div>
                        </div>
                    </OverlayContainer>
                )}
            </div>
        );
    },
);
BaseComboBox.displayName = "BaseComboBox";
