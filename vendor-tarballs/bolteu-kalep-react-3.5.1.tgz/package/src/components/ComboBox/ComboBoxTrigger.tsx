import React from "react";

import type {ComboBoxTriggerProps} from "./ComboBox.types";
import {ComboBoxTriggerMulti} from "./ComboBoxTriggerMulti";
import {ComboBoxTriggerMultiline} from "./ComboBoxTriggerMultiline";
import {ComboBoxTriggerSingle} from "./ComboBoxTriggerSingle";

export function ComboBoxTrigger(props: ComboBoxTriggerProps) {
    const {inputWrapperRef, multiple, required, value, multiline} = props;
    const hasValue = Array.isArray(value) ? Boolean(value.length) : !!value;

    // Input field is empty and form considers it not valid regardless of actual Combobox value.
    React.useEffect(() => {
        if (required && inputWrapperRef.current) {
            const input = inputWrapperRef.current.querySelector("input");

            if (input) {
                const validationMessage = multiple ? "Please select at least one option." : "Please select an option.";
                input.setCustomValidity(hasValue ? "" : validationMessage);
            }
        }
    }, [hasValue, multiple, required, inputWrapperRef]);

    if (multiple && multiline) {
        return <ComboBoxTriggerMultiline {...props} />;
    }

    return multiple ? <ComboBoxTriggerMulti {...props} /> : <ComboBoxTriggerSingle {...props} />;
}
