import * as React from "react";

import type {RenderResult} from "@testing-library/react";
import {render, screen, within} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {DEFAULT_TOGGLE_BUTTON_ARIA_LABEL} from "../BaseComboBox";
import {ComboBox} from "../ComboBox";
import type {ComboBoxProps} from "../ComboBox.types";

export * from "@testing-library/react";
export {userEvent};

export const user = userEvent.setup();

interface RenderTextFieldResult extends Omit<RenderResult, "rerender"> {
    rerender: (props: Partial<ComboBoxProps>) => void;
}

export const defaultProps: {
    options: {title: string; value: string; disabled?: boolean}[];
    placeholder: string;
    label: string;
    noResultsMessage: string;
} = {
    options: [
        {title: "Red", value: "color_1"},
        {title: "Blue", value: "color_2"},
        {title: "Green", value: "color_3"},
        {title: "Yellow", value: "color_4"},
    ],
    placeholder: "Pick a color",
    label: "Wall Paint:",
    noResultsMessage: "just check for something else",
};
export const menuSize = defaultProps.options.length;

export function renderComboBox(props?: Partial<ComboBoxProps>): RenderTextFieldResult {
    const utils = render(<ComboBox {...defaultProps} {...props} />);

    function rerender(rerenderProps: Partial<ComboBoxProps>): void {
        utils.rerender(<ComboBox {...defaultProps} {...rerenderProps} />);
    }

    return {...utils, rerender};
}

export function getInput(name = defaultProps.label): HTMLInputElement {
    return screen.getByRole("combobox", {name});
}

export function getToggleButton(name = DEFAULT_TOGGLE_BUTTON_ARIA_LABEL): HTMLElement {
    return screen.getByLabelText(name, {selector: "button"});
}

export function getMenu(): HTMLElement {
    return screen.getByRole("listbox");
}

export function getOptions(): HTMLElement[] {
    return screen.queryAllByRole("option");
}

export async function clickOnToggleButton(): Promise<void> {
    await user.click(getToggleButton());
}

export async function clickOnOption(optionTitle: string): Promise<void> {
    await user.click(screen.getByRole("option", {name: optionTitle}));
}

export async function changeInput(value: string, shouldClear: boolean = false): Promise<void> {
    const input = getInput();

    if (input.value && shouldClear) {
        await user.clear(input);
    }

    if (document.activeElement !== input) {
        await tab(); // if it's not the only one in the tab order, use input.focus()
    }

    await user.keyboard(value);
}

export async function tab() {
    await user.tab();
}

export async function enter() {
    await user.keyboard("{enter}");
}

export function getSelectedChip(selectedOptionName: string): HTMLDivElement | null {
    const {queryByText} = within(screen.getByRole("textbox"));
    return queryByText(selectedOptionName);
}

export async function clickOnSelectedChipRemove(selectedOptionName: string): Promise<void> {
    const removeButton = getSelectedChip(selectedOptionName)?.parentElement?.childNodes[1];
    await user.click(removeButton as HTMLDivElement);
}
