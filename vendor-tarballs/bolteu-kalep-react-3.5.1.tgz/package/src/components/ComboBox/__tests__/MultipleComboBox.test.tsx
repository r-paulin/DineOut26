import * as React from "react";

import {vi} from "vitest";

import type {SelectOption} from "@/components/_internal/Option";

import {
    changeInput,
    clickOnOption,
    clickOnSelectedChipRemove,
    clickOnToggleButton,
    defaultProps,
    enter,
    getInput,
    getOptions,
    getSelectedChip,
    menuSize,
    renderComboBox,
    screen,
    tab,
    user,
} from "./ComboBox.testUtils";

beforeEach(() => {
    // https://github.com/TanStack/virtual/issues/641
    vi.spyOn(Element.prototype, "getBoundingClientRect").mockImplementation(() => ({
        width: 120,
        height: 120,
        top: 0,
        left: 0,
        bottom: 0,
        right: 0,
        x: 0,
        y: 0,
        toJSON: () => {},
    }));
});

afterEach(() => {
    vi.restoreAllMocks();
});

test("can select multiple items", async () => {
    const option1 = defaultProps.options[1];
    const option2 = defaultProps.options[2];

    renderComboBox({multiple: true});

    await clickOnToggleButton();
    await clickOnOption(option1.title);
    await clickOnOption(option2.title);

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(2);
    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(2);

    await clickOnToggleButton();

    expect(getSelectedChip(option1.title)).toBeInTheDocument();
    expect(getSelectedChip(option2.title)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(defaultProps.placeholder)).toBeInTheDocument();
});

test("selected items can also be removed", async () => {
    const defaultValue = defaultProps.options.slice(0, 2);

    renderComboBox({multiple: true, defaultValue});

    expect(getSelectedChip(defaultValue[1].title)).toBeInTheDocument();
    expect(getSelectedChip(defaultValue[0].title)).toBeInTheDocument();

    await clickOnToggleButton(); // OPEN
    await clickOnOption(defaultValue[0].title);

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(1);
    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(3);

    await clickOnToggleButton(); // CLOSE

    expect(getSelectedChip(defaultValue[1].title)).toBeInTheDocument();
    expect(getSelectedChip(defaultValue[0].title)).not.toBeInTheDocument();

    await clickOnSelectedChipRemove(defaultValue[1].title); // OPEN
    await clickOnToggleButton(); // CLOSE

    expect(getSelectedChip(defaultValue[1].title)).not.toBeInTheDocument();
    expect(getSelectedChip(defaultValue[0].title)).not.toBeInTheDocument();

    await clickOnToggleButton(); // OPEN

    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(4);
    expect(screen.queryAllByRole("checkbox", {checked: true})).toHaveLength(0);

    await clickOnOption(defaultValue[0].title);
    await clickOnToggleButton(); // CLOSE

    await clickOnSelectedChipRemove(defaultValue[0].title); // OPEN
    await clickOnToggleButton(); // CLOSE

    expect(getSelectedChip(defaultValue[0].title)).not.toBeInTheDocument();
});

test("onChange is called with the new array of items", async function onChangeCall() {
    const onChange = vi.fn();
    const defaultValue = defaultProps.options.slice(0, 2);

    renderComboBox({multiple: true, defaultValue, onChange});

    await clickOnToggleButton();
    await clickOnOption(defaultProps.options[2].title);

    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenNthCalledWith(1, [...defaultValue, defaultProps.options[2]]);

    await clickOnOption(defaultProps.options[2].title);

    expect(onChange).toHaveBeenCalledTimes(2);
    expect(onChange).toHaveBeenNthCalledWith(2, defaultValue);
});

test("focus is managed correctly", async function arrowKeysFocusManagement() {
    const defaultValue = defaultProps.options.slice(0, 3);

    renderComboBox({multiple: true, defaultValue});

    await user.tab();
    expect(getInput()).toHaveFocus();
});

test("combobox can have options filtered", async function optionsFiltering() {
    const optionToSelect = defaultProps.options[0].title;

    const searchText = optionToSelect.slice(0, 2);

    renderComboBox({multiple: true});

    await user.tab();
    await user.keyboard(searchText);

    expect(getInput()).toHaveValue(searchText);
    expect(getOptions()).toHaveLength(2);
});

test("keep the menu open on selection", async function keepMenuOpenOnSelection() {
    const listSize = defaultProps.options.length;

    renderComboBox({multiple: true});

    await clickOnToggleButton();
    await clickOnOption(defaultProps.options[0].title);

    expect(getOptions()).toHaveLength(listSize);

    await user.keyboard("[ArrowDown][Enter]");

    expect(getOptions()).toHaveLength(listSize);

    await user.keyboard("[ArrowDown][Enter]");

    expect(getOptions()).toHaveLength(listSize);
    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(3);
});

test("closes the menu if disableCloseOnSelect is passed as false", async function closeMenuOnSelection() {
    renderComboBox({multiple: true, disableCloseOnSelect: false});

    await clickOnToggleButton();
    await clickOnOption(defaultProps.options[0].title);

    expect(getOptions()).toHaveLength(0);
});

test("backspace removes selected options", async function keepOptionsSelectedOnBackspace() {
    const defaultValue = defaultProps.options.slice(0, 2);

    renderComboBox({multiple: true, defaultValue});

    await clickOnToggleButton();
    await user.keyboard("[Backspace]");

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(1);

    await clickOnOption(defaultProps.options[3].title);

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(2);

    await user.keyboard("[Backspace]");

    expect(screen.getAllByRole("checkbox", {checked: true})).toHaveLength(1);
});

test("getOptionValue is used by selected items as well as options", async () => {
    const optionString = "I am an option";
    const getOptionLabel = vi.fn().mockImplementation(() => optionString);
    const defaultValue = defaultProps.options.slice(0, 1);

    renderComboBox({multiple: true, defaultValue, getOptionLabel});

    expect(getSelectedChip(optionString)).toBeInTheDocument();

    await clickOnToggleButton();

    expect(screen.getAllByRole("option", {name: optionString})).toHaveLength(4);
    expect(getOptionLabel).toHaveBeenNthCalledWith(1, defaultProps.options[0]); // selected item.
    // options
    for (let index = 0; index < defaultProps.options.length; index++) {
        expect(getOptionLabel).toHaveBeenNthCalledWith(index + 2, defaultProps.options[index]);
    }
});

test("freeSolo mode enables adding custom options", async () => {
    const customOption = "Black";

    renderComboBox({multiple: true, freeSolo: true});

    await changeInput(customOption);

    expect(screen.queryByTestId("combo-box-no-results")).not.toBeInTheDocument();
    expect(getOptions()).toHaveLength(1);
    expect(getOptions()[0]).toHaveTextContent(`Add "${customOption}"`);
    expect(screen.queryByRole("checkbox")).not.toBeInTheDocument();

    await enter();

    expect(getSelectedChip(customOption)).toBeInTheDocument();
    expect(getInput()).toHaveValue("");

    await user.keyboard(defaultProps.options[0].title);
    await clickOnOption(defaultProps.options[0].title);

    expect(getSelectedChip(defaultProps.options[0].title)).toBeInTheDocument();
});

test("cannot enter duplicate custom values in freeSolo mode", async () => {
    const customOption = "Black";
    const noResultsMessage = "No results";

    renderComboBox({multiple: true, freeSolo: true, noResultsMessage});

    await user.tab();
    await changeInput(customOption);

    expect(screen.queryByText(noResultsMessage)).not.toBeInTheDocument();
    expect(getOptions()).toHaveLength(1);
    expect(getOptions()[0]).toHaveTextContent(`Add "${customOption}"`);
    expect(screen.queryByRole("checkbox")).not.toBeInTheDocument();

    await enter();

    expect(getSelectedChip(customOption)).toBeInTheDocument();

    await changeInput(customOption);
    await enter();

    expect(screen.getAllByText(customOption)).toHaveLength(1);
});

test("renderOption is called when passed", async () => {
    const optionContent = "hello";
    const renderOption = vi.fn().mockImplementation((props) => <div key={props.option.value}>{optionContent}</div>);

    renderComboBox({renderOption});

    await clickOnToggleButton();

    expect(screen.getAllByText(optionContent)).toHaveLength(menuSize);
});

test("combobox can receive onInputChange callback", async function onInputChangeCallback() {
    const inputValue = "dance";
    const callArguments: string[] = [];
    const expectedCallArguments = new Array<string>(inputValue.length)
        .fill("")
        .map((_subString, index) => inputValue.slice(0, index + 1));
    const onInputChange = vi
        .fn<void, [React.ChangeEvent<HTMLInputElement>]>()
        .mockImplementation((e) => callArguments.push(e.target.value));

    renderComboBox({onInputChange, multiple: true});

    await changeInput(inputValue);

    expect(onInputChange).toHaveBeenCalledTimes(inputValue.length);
    expect(callArguments).toEqual(expectedCallArguments);
});

test("combobox can receive onInputChange callback with freeSolo", async function onInputChangeWithFreeSoloCallback() {
    const inputValue = "dance";
    const callArguments: string[] = [];
    const expectedCallArguments = new Array<string>(inputValue.length)
        .fill("")
        .map((_subString, index) => inputValue.slice(0, index + 1));
    const onInputChange = vi
        .fn<void, [React.ChangeEvent<HTMLInputElement>]>()
        .mockImplementation((e) => callArguments.push(e.target.value));

    renderComboBox({onInputChange, multiple: true, freeSolo: true});

    await changeInput(inputValue);

    expect(onInputChange).toHaveBeenCalledTimes(inputValue.length);
    expect(callArguments).toEqual(expectedCallArguments);
});

test("isOptionEqualToValue overides the default compare by reference", async function customEqualFunction() {
    // option with the same value and title, but different reference.
    const defaultValue = [{value: defaultProps.options[0].value, title: defaultProps.options[0].title}];
    // should compare by value, not by reference.
    function isOptionEqualToValue(option1: SelectOption, option2: SelectOption): boolean {
        return option1.value === option2.value;
    }

    renderComboBox({multiple: true, defaultValue, isOptionEqualToValue});

    await clickOnToggleButton();

    // ancestor (list item) of checkbox element contains the element with text content.
    expect(screen.getByRole("checkbox", {checked: true}).closest("li")).toHaveTextContent(defaultValue[0].title);
    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(3);

    // check adding items still works.
    await clickOnOption(defaultProps.options[1].title);

    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(2);

    // check removing items still works.
    await clickOnOption(defaultProps.options[0].title);

    expect(screen.getAllByRole("checkbox", {checked: false})).toHaveLength(3);
});

test("MultipleCombobox throws when value is not an array", async () => {
    const value = defaultProps.options[0];

    expect(() => renderComboBox({multiple: true, value})).toThrow("MultipleCombobox requires value to be an array.");
});

test("MultipleCombobox throws when value is null", async () => {
    expect(() => renderComboBox({multiple: true, value: null})).toThrow(
        "MultipleCombobox requires value to be an array.",
    );
});

test("MultipleCombobox throws when defaultValue is not an array", async () => {
    const defaultValue = defaultProps.options[0];

    expect(() => renderComboBox({multiple: true, defaultValue})).toThrow(
        "MultipleCombobox requires defaultValue to be an array.",
    );
});

test("combobox can be marked as required", function withRequired() {
    const label = "Required";
    const requiredSuffix = " *";
    renderComboBox({multiple: true, required: true, label});
    expect(getInput(label + requiredSuffix)).toHaveAttribute("aria-required", "true");
});

test("required combobox is marked invalid in Constraint Validation API when no value is selected", async function withRequired2() {
    const label = "Required2";
    const requiredSuffix = " *";
    renderComboBox({multiple: true, required: true, label, name: label});

    const input = getInput(label + requiredSuffix);

    expect(input.checkValidity()).toBe(false);
    expect(input.validationMessage).toBe("Please select at least one option.");

    // and even if something is written in input as filter but nothing is still selected
    if (document.activeElement !== input) {
        await tab(); // if it's not the only one in the tab order, use input.focus()
    }

    await user.keyboard("hello");

    expect(input.value).toBe("hello");
    expect(input.checkValidity()).toBe(false);
});

test("required combobox is marked valid in Constraint Validation API when a value is selected", async function withRequired3() {
    const label = "Required3";
    const requiredSuffix = " *";
    renderComboBox({multiple: true, required: true, label, name: label});

    const input = getInput(label + requiredSuffix);

    expect(input.checkValidity()).toBe(false);

    const option = defaultProps.options[1];

    await clickOnToggleButton();

    expect(screen.queryAllByRole("option")).toHaveLength(defaultProps.options.length);

    await clickOnOption(option.title);

    expect(input.checkValidity()).toBe(true);
});
