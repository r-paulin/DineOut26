import * as React from "react";

import type {UseMultipleSelectionGetDropdownReturnValue} from "downshift";
import {useMultipleSelection} from "downshift";

import {renderMultipleOptionDefault} from "@/components/_internal/MultipleOption";
import type {OptionProps, SelectOption} from "@/components/_internal/Option";
import {getOptionLabelDefault} from "@/components/_internal/Option";
import {defaultComparator} from "@/helpers/utils/comparator";

import {BaseComboBox} from "./BaseComboBox";
import type {ComboBoxProps} from "./ComboBox.types";
import {filterOptionsDefault, useMultipleSelectionStateReducer} from "./helpers";

export function MultipleComboBox({
    value: valueProp,
    onChange: onChangeProp,
    defaultValue,
    disabled,
    onInputChange,
    getOptionLabel = getOptionLabelDefault,
    filterOptions = filterOptionsDefault,
    freeSolo,
    size,
    renderOption: renderOptionProp = renderMultipleOptionDefault,
    isOptionEqualToValue = defaultComparator,
    required,
    ...rest
}: ComboBoxProps): JSX.Element {
    if (valueProp !== undefined && !Array.isArray(valueProp)) {
        throw new Error("MultipleCombobox requires value to be an array.");
    }

    if (defaultValue !== undefined && !Array.isArray(defaultValue)) {
        throw new Error("MultipleCombobox requires defaultValue to be an array.");
    }

    const {getDropdownProps, selectedItems, setSelectedItems} = useMultipleSelection<SelectOption>({
        stateReducer: useMultipleSelectionStateReducer,
        itemToString: getOptionLabelDefault,
        selectedItems: valueProp,
        initialSelectedItems: defaultValue,
    });

    const onChange = React.useCallback(
        (newOption: SelectOption | SelectOption[] | null) => {
            if (!newOption || Array.isArray(newOption) || disabled) {
                return;
            }

            const itemIndex = selectedItems.findIndex((option) => {
                return isOptionEqualToValue?.(option, newOption);
            });

            const newSelectedOptions =
                itemIndex === -1
                    ? [...selectedItems, newOption] // add
                    : [...selectedItems.slice(0, itemIndex), ...selectedItems.slice(itemIndex + 1)]; // remove

            setSelectedItems(newSelectedOptions);

            if (typeof onChangeProp === "function") {
                onChangeProp(newSelectedOptions);
            }
        },
        [setSelectedItems, onChangeProp, selectedItems, isOptionEqualToValue, disabled],
    );

    const renderOption = React.useCallback<(OptionProps: OptionProps) => JSX.Element | null>(
        (props) =>
            renderOptionProp(
                {
                    ...props,
                    selected: selectedItems.some((selectedOption) => {
                        return isOptionEqualToValue(selectedOption, props.option);
                    }),
                },
                renderMultipleOptionDefault,
            ),
        [isOptionEqualToValue, renderOptionProp, selectedItems],
    );

    const handleFilterOptions = React.useCallback(
        (options: SelectOption[], params: {inputValue: string; getOptionLabel: (option: SelectOption) => string}) => {
            const filtered = filterOptions(options, params);

            if (freeSolo) {
                const customOptionIndex = filtered.findIndex((option) => option.isCustom);
                const customOption = filtered[customOptionIndex];

                if (
                    customOptionIndex > -1 &&
                    selectedItems.filter((selected) => selected.value === customOption.value).length > 0
                ) {
                    return [...filtered.slice(0, customOptionIndex), ...filtered.slice(customOptionIndex + 1)];
                }
            }

            return filtered;
        },
        [filterOptions, freeSolo, selectedItems],
    );

    const handleDelete = React.useCallback(
        (indexToDelete: number) => {
            const newSelectedItems = [
                ...selectedItems.slice(0, indexToDelete),
                ...selectedItems.slice(indexToDelete + 1),
            ];
            setSelectedItems(newSelectedItems);

            if (typeof onChangeProp === "function") {
                onChangeProp(newSelectedItems);
            }
        },
        [selectedItems, setSelectedItems, onChangeProp],
    );

    const handleKeyDown = React.useCallback(
        function keyDownHandler(event: React.KeyboardEvent) {
            const {value: newInputValue} = event.target as HTMLInputElement;

            if (
                event.key === "Enter" &&
                freeSolo &&
                newInputValue &&
                newInputValue.length &&
                !selectedItems.find((item) => item.value === newInputValue)
            ) {
                onChange({value: newInputValue});
            }
        },
        [freeSolo, onChange, selectedItems],
    );

    const handleGetDropdownProps = React.useCallback(
        (ref: React.RefObject<HTMLInputElement>): UseMultipleSelectionGetDropdownReturnValue => {
            return getDropdownProps({
                ref,
                onKeyDown: handleKeyDown,
                onChange(event: React.ChangeEvent<HTMLInputElement>) {
                    if (typeof onInputChange === "function") {
                        onInputChange(event);
                    }
                },
            });
        },
        [getDropdownProps, handleKeyDown, onInputChange],
    );

    const onClear = React.useCallback(() => {
        setSelectedItems([]);

        if (typeof onChangeProp === "function") {
            onChangeProp([]);
        }
    }, [setSelectedItems, onChangeProp]);

    return (
        <BaseComboBox
            value={selectedItems}
            onChange={onChange}
            onClear={onClear}
            onDelete={handleDelete}
            onInputChange={onInputChange}
            renderOption={renderOption}
            getDropdownProps={handleGetDropdownProps}
            getOptionLabel={getOptionLabel}
            freeSolo={freeSolo}
            filterOptions={handleFilterOptions}
            size={size}
            disabled={disabled}
            required={required}
            {...rest}
        />
    );
}
