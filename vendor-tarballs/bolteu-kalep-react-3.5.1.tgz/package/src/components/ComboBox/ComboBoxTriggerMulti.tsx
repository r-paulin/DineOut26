import React from "react";

import {ChevronDown, Clear} from "@bolteu/kalep-react-icons";

import {MultiSelectChip} from "@/components/_internal/MultiSelectChip";
import {SpinnerIcon} from "@/components/_internal/SpinnerIcon";
import type {State} from "@/components/TextField/TextField.types";
import {cx} from "@/helpers/utils/cx";
import {noop, noopNull} from "@/helpers/utils/noop";
import type {SelectOption} from "@/index";
import {Badge, GhostButton} from "@/index";

import {DEFAULT_LOADING_SPINNER_ARIA_LABEL, DEFAULT_TOGGLE_BUTTON_ARIA_LABEL} from "./BaseComboBox";
import type {ComboBoxTriggerProps, Size} from "./ComboBox.types";

const CHIPS_COUNT_SAFEAREA = 24;
const MIN_INPUT_WIDTH = 6 * 16;

const sizeStyles: Record<Size, string> = {
    sm: "min-h-9 pl-3 pr-2 bolt-font-body-s-regular gap-2",
    md: "min-h-12 pl-3 pr-2 bolt-font-body-m-regular gap-2",
    lg: "min-h-14 pl-3 pr-2 bolt-font-body-m-regular gap-2",
};

const wrapperStyles: Record<State, string> = {
    idle: "border-special-nulled focus:border-action-primary text-primary",
    disabled: "border-neutral-secondary cursor-not-allowed text-tertiary bg-special-nulled placeholder-tertiary",
    error: "border-danger-primary text-primary",
};

const getInputTextStyles = (disabled?: boolean, hasValue?: boolean) => {
    if (disabled) {
        return "text-tertiary placeholder-tertiary";
    }

    if (hasValue) {
        return "text-primary placeholder-secondary";
    }

    return "text-secondary placeholder-secondary";
};

function calculateChipWidths(
    inputWrapperRef: React.RefObject<HTMLDivElement>,
    chipRefs: React.MutableRefObject<Record<string, React.RefObject<HTMLDivElement>>>,
    size: Size,
    chipGap: number,
    value: SelectOption[],
) {
    // Total external width of the component.
    // ref.current not being null is checked before calling this function.
    const wrapperWidth = (inputWrapperRef.current as HTMLDivElement).getBoundingClientRect().width;

    // Calculate space that we have available for representing current state and search input.
    // (TOTAL - (START_PADDING + END_PADDING) - GAP_BEFORE_CHEVRON - CHEVRON_WIDTH_SIZE_SPECIFIC)
    const availableWidth = wrapperWidth - 20 - 8 - (size === "sm" ? 28 : 32);

    // Let's drop the large MIN_INPUT_WIDTH for now
    const IDLE_MIN_INPUT_WIDTH = 2 * 16;
    const COUNTER_BADGE_WIDTH = 24;

    // Early return values for when we have not selected anything.
    if (value.length === 0) {
        return {
            maxIndexToShow: 0,
            chipsVisibleWidth: 0,
            transformWhenOpen: 0,
            chipsFullWidth: 0,
            closedInputWidth: availableWidth,
            openInputWidth: availableWidth,
            showBadgeOnly: false,
        };
    }

    // Early return values for when the field is too small to show chips, so we show a Badge instead.
    if (wrapperWidth < 161 && value.length) {
        return {
            maxIndexToShow: 0,
            chipsVisibleWidth: COUNTER_BADGE_WIDTH,
            transformWhenOpen: 0,
            chipsFullWidth: COUNTER_BADGE_WIDTH,
            closedInputWidth: availableWidth - COUNTER_BADGE_WIDTH,
            openInputWidth: availableWidth - COUNTER_BADGE_WIDTH,
            showBadgeOnly: true,
        };
    }

    // Otherwise (enough space, got selected items), calculate widths for chips and input.

    // safeAreaWidth is the space we cannot use for showing chips inside availableWidth.
    // If there's only one chip don't account for the hidden chip count area
    const safeAreaWidth =
        value.length < 2 ? chipGap + IDLE_MIN_INPUT_WIDTH : CHIPS_COUNT_SAFEAREA + chipGap * 2 + IDLE_MIN_INPUT_WIDTH;

    let chipsFullWidth = 0;
    let chipsVisibleWidth = 0;
    let chipsOverflow = false;
    let maxIndexToShow = 0;

    for (let i = 0; i < value.length; i++) {
        const option = value[i];

        if (option.value && chipRefs.current[option.value]) {
            const chipElement = chipRefs.current[option.value].current;

            if (chipElement) {
                let chipWidth = chipElement.getBoundingClientRect().width;

                // If the chip in it's natural width won't fit calculate the max width it can have and truncate.
                // it's possible that this chip won't fit and is skipped in the next step, so the style setting here might be inefficient, depending if it triggers reflow right away.
                if (chipWidth + safeAreaWidth >= availableWidth) {
                    chipWidth = Math.max(availableWidth - safeAreaWidth, 0); // rather aggressive and can result in *very* tiny chips.
                    chipElement.style.width = chipWidth === 0 ? "auto" : `${chipWidth}px`;
                    chipElement.style.overflow = "hidden";
                    chipElement.style.textOverflow = "ellipsis";
                }

                // Apply gap, if it's not the first chip.
                const gap = i === 0 ? 0 : chipGap;
                chipsFullWidth += gap + chipWidth;

                // While chips are not overflowing, add them to the visible width,
                // if we've detected overflow starting, mark it and skip this part for the remaining chips.
                if (!chipsOverflow) {
                    if (chipsFullWidth + safeAreaWidth <= availableWidth) {
                        chipsVisibleWidth += gap + chipWidth;
                        maxIndexToShow = i;
                    } else {
                        chipsOverflow = true;
                    }
                }
            }
        }
    }

    const closedInputWidth = availableWidth - chipsVisibleWidth - (chipsOverflow ? CHIPS_COUNT_SAFEAREA + chipGap : 0);
    const openInputWidth = Math.max(availableWidth - chipsFullWidth - chipGap, MIN_INPUT_WIDTH);
    const transformWhenOpen = Math.min(availableWidth - chipsFullWidth - openInputWidth, 0);

    return {
        maxIndexToShow,
        chipsVisibleWidth,
        transformWhenOpen,
        chipsFullWidth,
        closedInputWidth,
        openInputWidth,
        showBadgeOnly: false,
    };
}

export function ComboBoxTriggerMulti(props: ComboBoxTriggerProps) {
    const {
        clearable,
        closeMenu,
        disabled,
        error,
        id,
        isOpen,
        generatedId,
        getDropdownProps,
        getInputProps,
        getOptionLabel,
        getToggleButtonProps,
        inputValue,
        inputWrapperRef,
        loading,
        loadingSpinnerAriaLabel = DEFAULT_LOADING_SPINNER_ARIA_LABEL,
        name,
        noResultsMessageId,
        onClear,
        onDelete,
        onInputChange,
        openMenu,
        placeholder,
        required,
        renderStartSlot,
        shouldShowNoResultsMessage,
        shouldRenderEndSlotIcon = true,
        size = "md",
        toggleButtonAriaLabel = DEFAULT_TOGGLE_BUTTON_ARIA_LABEL,
        toggleButtonRef,
        value,
    } = props;

    const inputRef = React.useRef<HTMLInputElement>(null);
    const chipRefs = React.useRef<Record<string, React.RefObject<HTMLDivElement>>>({});

    const isValueArray = Array.isArray(value);

    const [maxChipIndex, setMaxChipIndex] = React.useState<number>(isValueArray ? value.length - 1 : -1);
    const [visibleChipOffset, setVisibleChipOffset] = React.useState<number>(0);
    const [chipTransform, setChipTransform] = React.useState<number>(0);
    const [showBadgeForChips, setShowBadgeForChips] = React.useState<boolean>(false);
    const [chipFullWidth, setChipFullWidth] = React.useState<number>(0);
    const [inputWidthWhenClosed, setInputWidthWhenClosed] = React.useState<number>(MIN_INPUT_WIDTH);
    const [inputWidthWhenOpen, setInputWidthWhenOpen] = React.useState<number>(MIN_INPUT_WIDTH);

    const hiddenChipCount = isValueArray ? value.length - maxChipIndex - 1 : 0;
    const chipGap = React.useMemo(() => (size === "sm" ? 4 : 6), [size]);

    const loadingSpinnerId = id ?? `kalep-combo-box-loading-spinner-${generatedId}`;
    const hasValue = isValueArray ? Boolean(value.length) : Boolean(value);
    const hasMoreThanOneChip = isValueArray && value.length > 1;

    if (isValueArray) {
        value.forEach((option) => {
            if (option.value && !chipRefs.current[option.value]) {
                chipRefs.current[option.value] = chipRefs.current[option.value] || React.createRef<HTMLDivElement>();
            }
        });
    }

    const ddProps = getDropdownProps?.(inputRef);

    const inputA11yProps = getInputProps({
        ref: inputRef,
        disabled,
        onChange: onInputChange,
        ...ddProps,
        onKeyDown: (e: React.KeyboardEvent) => {
            ddProps?.onKeyDown?.(e);
            if (inputValue.length === 0 && e.key === "Backspace" && isValueArray && value.length > 0) {
                onDelete?.(value.length - 1); // Remove last selected item
            }

            if (e.key === "Escape") {
                inputRef.current?.blur();
            }
        },
    });

    if (loading) {
        inputA11yProps["aria-labelledby"] = `${inputA11yProps["aria-labelledby"]} ${loadingSpinnerId}`;
    }
    if (shouldShowNoResultsMessage) {
        inputA11yProps["aria-labelledby"] = `${inputA11yProps["aria-labelledby"]} ${noResultsMessageId}`;
    }

    const handleClearButtonClick = React.useCallback(
        (e: React.MouseEvent<Element, MouseEvent> | React.KeyboardEvent<Element>) => {
            onClear?.();
            e.preventDefault();
            e.stopPropagation();
        },
        [onClear],
    );

    const onClick = React.useCallback(
        (e: React.MouseEvent) => {
            if (disabled) {
                return;
            }

            if (!toggleButtonRef?.current?.contains(e.target as Node)) {
                openMenu();
            }

            if (toggleButtonRef?.current?.contains(e.target as Node) && isOpen) {
                closeMenu();
            }
        },
        [openMenu, closeMenu, isOpen, toggleButtonRef, disabled],
    );

    const renderEndSlot = React.useCallback(() => {
        if (props.renderEndSlot) {
            return (
                <div className={cx("flex max-w-6 shrink-0 items-center gap-1")}>
                    {props.renderEndSlot(props, noopNull)}
                </div>
            );
        }
        const showClearButton = !disabled && (hasValue || !!inputValue) && clearable && hasValue && hasMoreThanOneChip;
        return (
            <div className={cx("flex flex-shrink-0 items-center justify-end", size !== "sm" && "gap-1")}>
                {showClearButton && (
                    <GhostButton
                        onClick={handleClearButtonClick}
                        overrideClassName={cx(
                            "group/clear",
                            "w-0 flex-shrink-0",
                            "z-[1021]", // Above the dropdown
                            "group-hover/trigger:mx-1 group-hover/trigger:w-6",
                        )}
                        tabIndex={-1}
                    >
                        <div
                            className={cx(
                                isOpen ? "flex" : "hidden",
                                "group-hover/trigger:flex",
                                "items-center justify-center",
                            )}
                        >
                            <Clear
                                aria-hidden="true"
                                className={cx(`
                                  text-tertiary
                                  group-hover/clear:text-secondary
                                `)}
                                size={size === "sm" ? "md" : "lg"}
                            />
                        </div>
                    </GhostButton>
                )}

                {loading && (
                    <SpinnerIcon
                        id={loadingSpinnerId}
                        aria-label={loadingSpinnerAriaLabel}
                        className={cx("mx-1 flex-none animate-spin text-action-secondary")}
                        size={size}
                        role="status"
                    />
                )}

                {!loading && shouldRenderEndSlotIcon && (
                    <button
                        type="button"
                        {...getToggleButtonProps({ref: toggleButtonRef, "aria-label": toggleButtonAriaLabel})}
                        className={cx(
                            "m-0 flex cursor-pointer items-center border-0 bg-transparent p-0",
                            disabled && "cursor-not-allowed",
                        )}
                        disabled={disabled}
                    >
                        <ChevronDown
                            className={cx(
                                "m-1 flex-none transition-transform",
                                disabled ? "text-tertiary" : "text-primary",
                                isOpen && "rotate-180",
                            )}
                            size={size === "sm" ? "md" : "lg"}
                        />
                    </button>
                )}
            </div>
        );
    }, [
        props,
        disabled,
        hasValue,
        inputValue,
        clearable,
        hasMoreThanOneChip,
        size,
        handleClearButtonClick,
        isOpen,
        loading,
        loadingSpinnerId,
        loadingSpinnerAriaLabel,
        shouldRenderEndSlotIcon,
        getToggleButtonProps,
        toggleButtonRef,
        toggleButtonAriaLabel,
    ]);

    React.useLayoutEffect(() => {
        if (isValueArray && inputWrapperRef.current) {
            const {
                maxIndexToShow,
                chipsVisibleWidth,
                transformWhenOpen,
                chipsFullWidth,
                closedInputWidth,
                openInputWidth,
                showBadgeOnly,
            } = calculateChipWidths(inputWrapperRef, chipRefs, size, chipGap, value);

            setMaxChipIndex(maxIndexToShow);
            setVisibleChipOffset(chipsVisibleWidth);
            setChipTransform(transformWhenOpen);
            setChipFullWidth(chipsFullWidth);
            setInputWidthWhenClosed(closedInputWidth);
            setInputWidthWhenOpen(openInputWidth);
            setShowBadgeForChips(showBadgeOnly);
        }
    }, [value, isValueArray, isOpen, chipGap, inputWrapperRef, size]);

    return (
        <div
            ref={inputWrapperRef}
            className={cx(
                "group/trigger",
                "flex w-full items-center justify-end",
                "rounded-md border-2 border-solid",
                "overflow-hidden outline-none",
                "caret-border-action-primary bg-neutral-secondary",
                "duration-100 ease-linear",
                disabled ? "cursor-not-allowed" : "cursor-text",
                disabled && wrapperStyles.disabled,
                error && wrapperStyles.error,
                !disabled && !error && wrapperStyles.idle,
                sizeStyles[size],
                !error && isOpen && "border-action-primary bg-special-nulled",
            )}
            onClick={onClick}
            onKeyPress={noop}
            role="textbox"
            tabIndex={-1}
        >
            {typeof renderStartSlot === "function" && (
                <div className={cx("flex max-w-6 items-center")}>{renderStartSlot(props, noopNull)} </div>
            )}

            <div className={cx("w-full min-w-0", typeof renderStartSlot === "function" && "overflow-hidden")}>
                <div
                    className={cx(
                        "relative flex w-full flex-1 items-center transition-transform",
                        "min-w-0", // Preventing overflowing flex container - https://stackoverflow.com/questions/36230944/prevent-flex-items-from-overflowing-a-container
                        size === "sm" ? "h-6" : "h-7",
                        isOpen ? "overflow-visible" : "overflow-hidden",
                    )}
                    style={{
                        transform: `translateX(${isOpen ? chipTransform : 0}px)`,
                        gap: chipGap,
                    }}
                >
                    {hasValue && Array.isArray(value) ? (
                        <>
                            {showBadgeForChips && <Badge badgeContent={value.length} appearance="promo" />}
                            {value.map((option, i) => (
                                <MultiSelectChip
                                    key={option.value}
                                    ref={option.value ? chipRefs.current[option.value] : undefined}
                                    label={getOptionLabel(option)}
                                    disabled={disabled}
                                    // We need to render chips even if we show Badge, because we need to measure them.
                                    hidden={(i > maxChipIndex && !isOpen) || showBadgeForChips}
                                    size={size}
                                    onDelete={() => onDelete?.(i)}
                                />
                            ))}
                        </>
                    ) : null}
                    {hiddenChipCount > 0 && !isOpen && !showBadgeForChips && (
                        <div
                            className={cx(
                                "absolute top-0 w-6 py-1 text-left",
                                size === "sm" ? "bolt-font-body-xs-regular" : "bolt-font-body-s-regular",
                                disabled ? "text-tertiary" : "text-primary",
                            )}
                            style={{left: visibleChipOffset + chipGap}}
                        >{`+${hiddenChipCount}`}</div>
                    )}

                    <input
                        ref={inputRef}
                        disabled={disabled}
                        name={name}
                        onChange={onInputChange}
                        onFocus={openMenu}
                        className={cx(
                            "block flex-shrink-0 truncate border-none bg-special-nulled p-0 outline-none",
                            size === "sm" ? "bolt-font-body-s-regular" : "bolt-font-body-m-regular",
                            disabled ? "cursor-not-allowed" : "cursor-text",
                            size === "sm" ? "h-6" : "h-7",
                            getInputTextStyles(disabled, !!inputValue.length),
                            isValueArray && value.length > 0 && "placeholder:opacity-0",
                        )}
                        style={
                            isOpen
                                ? {
                                      position: "absolute",
                                      left: isValueArray && value.length > 0 ? chipFullWidth + chipGap : 0,
                                      width: isValueArray && value.length > 0 ? inputWidthWhenOpen - chipGap : "100%",
                                  }
                                : {
                                      position: "absolute",
                                      left:
                                          visibleChipOffset +
                                          (Array.isArray(value) && value.length > 0 ? chipGap : 0) +
                                          (hiddenChipCount > 0 ? CHIPS_COUNT_SAFEAREA + chipGap : 0),
                                      width: isValueArray && value.length > 0 ? inputWidthWhenClosed - chipGap : "100%",
                                  }
                        }
                        placeholder={placeholder}
                        type="text"
                        aria-required={required}
                        {...inputA11yProps}
                    />
                </div>
            </div>
            {renderEndSlot()}
        </div>
    );
}
