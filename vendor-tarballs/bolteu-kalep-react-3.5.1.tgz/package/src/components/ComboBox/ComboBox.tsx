import * as React from "react";

import {BaseComboBox} from "./BaseComboBox";
import type {ComboBoxProps} from "./index";
import {MultipleComboBox} from "./MultipleComboBox";
import {ReadonlyCombobox} from "./ReadonlyCombobox";

export function ComboBox(props: ComboBoxProps): JSX.Element {
    if (props.readonly) {
        return <ReadonlyCombobox {...props} />;
    }

    if (props.multiple) {
        return <MultipleComboBox {...props} />;
    }

    return <BaseComboBox {...props} />;
}
