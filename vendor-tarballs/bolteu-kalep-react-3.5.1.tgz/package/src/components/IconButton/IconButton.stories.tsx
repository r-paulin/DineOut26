import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Alert, Heart, Lock, RideStart} from "@bolteu/kalep-react-icons";

import type {Variant} from "./IconButton";
import {IconButton} from "./index";

export default {
    title: "Inputs/IconButton",
    tags: ["autodocs"],
    component: IconButton,
    argTypes: {
        icon: {
            options: ["Heart", "Lock", "Alert", "RideStart"],
            mapping: {
                Heart: <Heart />,
                Lock: <Lock />,
                Alert: <Alert />,
                RideStart: <RideStart />,
            },
        },
    },
} as Meta<typeof IconButton>;

const Template: StoryFn<typeof IconButton> = (args: any) => <IconButton {...args} aria-label="Like" />;

export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {
    size: "md",
    icon: <Heart />,
    labelType: "text",
    shape: "round",
    disabled: false,
    loading: false,
    selected: false,
    type: "button",
};

export const Variants = () => {
    const variants: Variant[] = [
        "primary",
        "secondary",
        "ghost",
        "danger",
        "floating",
        "inverted",
        "floating-inverted",
    ];

    return (
        <div className="flex gap-4">
            {variants.map((variant) => (
                <div className="flex flex-col">
                    <IconButton icon={<Heart />} variant={variant} aria-label={variant} />
                </div>
            ))}
        </div>
    );
};

export const CustomWidth: StoryFn<typeof IconButton> = (args: any) => <IconButton {...args} />;
// More on args: https://storybook.js.org/docs/react/writing-stories/args
CustomWidth.args = {
    ...Default.args,
    "aria-label": "Add to favourites",
    variant: "primary",
    width: "100%",
};
