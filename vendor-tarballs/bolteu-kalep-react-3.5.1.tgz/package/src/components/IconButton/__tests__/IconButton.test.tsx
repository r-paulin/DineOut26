import * as React from "react";

import {vi} from "vitest";
import {cleanup, render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Heart} from "@bolteu/kalep-react-icons";

import {IconButton} from "../index";

describe("IconButton test suite", () => {
    test("Click event triggers onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<IconButton onClick={handler} icon={<Heart />} aria-label="What is Love?" />);
        await user.click(screen.getByRole("button"));
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("disabled prop actually disables the button", () => {
        render(<IconButton icon={<Heart />} aria-label="What is Love?" disabled />);
        expect(screen.getByRole("button", {name: "What is Love?"})).toBeDisabled();
    });

    test("disabled prop blocks onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        const {rerender} = render(<IconButton onClick={handler} icon={<Heart />} aria-label="What is Love?" />);
        await user.click(screen.getByRole("button"));
        expect(handler).toHaveBeenCalledTimes(1);
        rerender(<IconButton onClick={handler} icon={<Heart />} disabled aria-label="What is Love?" />);
        await user.click(screen.getByRole("button"));
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("loading prop blocks onClick handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        const {rerender} = render(<IconButton onClick={handler} icon={<Heart />} aria-label="What is Love?" />);
        await user.click(screen.getByRole("button"));
        expect(handler).toHaveBeenCalledTimes(1);
        rerender(<IconButton onClick={handler} icon={<Heart />} loading aria-label="What is Love?" />);
        await user.click(screen.getByRole("button"));
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("Tabbing onto IconButton triggers onFocus", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<IconButton onFocus={handler} icon={<Heart />} aria-label="What is Love?" />);

        await user.tab();
        expect(screen.getByRole("button")).toHaveFocus();
        expect(handler).toHaveBeenCalledTimes(1);
    });

    // https://www.w3.org/TR/wai-aria-practices/#keyboard-interaction-3
    test("Tab onto IconButton and trigger onClick handler with Space", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<IconButton onClick={handler} icon={<Heart />} aria-label="What is Love?" />);

        await user.tab();
        expect(screen.getByRole("button")).toHaveFocus();

        await user.keyboard("[Space]");

        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("Tab onto IconButton and trigger onClick handler with Enter", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        render(<IconButton onClick={handler} icon={<Heart />} aria-label="What is Love?" />);

        await user.tab();
        expect(screen.getByRole("button")).toHaveFocus();

        await user.keyboard("[Enter]");

        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("text label width is based on custom width", () => {
        const longLabel = "This is a very long label that should be truncated";

        // Test without custom width
        render(<IconButton icon={<Heart />} aria-label={longLabel} labelType="text" />);
        const textLabelWithoutWidth = screen.getByText(longLabel);
        expect(textLabelWithoutWidth).not.toHaveClass("!w-full");

        cleanup();
        // Test with custom width
        render(<IconButton icon={<Heart />} aria-label={longLabel} labelType="text" width="100px" />);
        const textLabelWithWidth = screen.getByText(longLabel);
        expect(screen.getByRole("button")).toHaveStyle("width: 100px");
        expect(textLabelWithWidth).toHaveClass("!w-full");
    });
});
