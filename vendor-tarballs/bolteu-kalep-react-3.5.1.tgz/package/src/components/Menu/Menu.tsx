import * as React from "react";

import type {MenuState} from "@szhsin/react-menu";
import {
    ControlledMenu as InnerControlledMenu,
    FocusableItem,
    MenuDivider as InnerMenuDivider,
    MenuItem as InnerMenuItem,
    SubMenu as InnerSubMenu,
    useClick,
    useHover,
} from "@szhsin/react-menu";

import ChevronRight from "@bolteu/kalep-react-icons/dist/ChevronRight";

import {useControlledValueWarning} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {MenuItemClassnameProps, MenuItemProps, MenuProps, SubMenuLabelProps, SubMenuProps} from "./Menu.types";

const SUBMENU_OFFSET_X = -8;

const menuClassName = ({state}: {state: MenuState}) =>
    cx(
        "absolute z-dropdown w-80 select-none list-none rounded-md bg-layer-floor-2 px-0 py-2 shadow-lg outline-none",
        state === "closed" && "hidden",
    );

const menuItemClassName = ({hover}: MenuItemClassnameProps) => {
    return cx(
        "bolt-font-body-m-regular flex gap-3 px-4 py-3 no-underline",
        "outline-none",
        hover && "cursor-pointer bg-neutral-secondary",
    );
};

export function MenuDivider(): JSX.Element {
    return <InnerMenuDivider className={cx("h-px bg-neutral-secondary")} />;
}

export function MenuItem({render, ...rest}: MenuItemProps): JSX.Element {
    if (render) {
        return (
            <FocusableItem>
                {({closeMenu, hover, ...restRenderProps}) =>
                    render({
                        hover,
                        onClick: ({detail}: {detail: number}) => {
                            closeMenu(detail === 0 ? "Enter" : undefined);
                        },
                        className: cx("block px-4 py-3", hover && "bg-neutral-secondary"),
                        ...restRenderProps,
                    })
                }
            </FocusableItem>
        );
    }

    return (
        <InnerMenuItem
            onClick={rest.onClick}
            className={menuItemClassName}
            value={rest.value}
            disabled={rest.disabled}
            href={rest.href}
            target={rest.target}
        >
            {rest.renderStartSlot && (
                <div className={cx("flex shrink-0 items-center")}>{rest.renderStartSlot(rest)}</div>
            )}
            <div className={cx("max-w-full", !rest.wrapText && "truncate")}>
                {rest.renderLabel ? (
                    rest.renderLabel(rest)
                ) : (
                    <>
                        <div
                            className={cx(
                                "bolt-font-body-m-regular text-primary",
                                rest.disabled && "text-secondary",
                                !rest.wrapText && "truncate",
                            )}
                        >
                            {rest.label}
                        </div>
                        {rest.description && (
                            <div
                                className={cx("bolt-font-body-s-regular text-secondary", !rest.wrapText && "truncate")}
                            >
                                {rest.description}
                            </div>
                        )}
                    </>
                )}
            </div>
            {rest.renderEndSlot && (
                <div className={cx("ml-auto flex shrink-0 items-center")}>{rest.renderEndSlot(rest)}</div>
            )}
        </InnerMenuItem>
    );
}

export function SubMenuLabel({label}: SubMenuLabelProps): JSX.Element {
    return (
        <div className={cx("flex w-full items-center justify-between gap-2")}>
            <div className={cx("truncate")}>{label}</div>
            <ChevronRight size="md" className={cx(`
              shrink-0
              rtl:rotate-180
            `)} />
        </div>
    );
}

export function SubMenu({children, label, ...props}: SubMenuProps): JSX.Element {
    return (
        <InnerSubMenu
            gap={SUBMENU_OFFSET_X}
            className={cx("relative")}
            itemProps={{
                className: cx(
                    "relative w-full cursor-pointer px-4 py-3",
                    `
                      hover:bg-neutral-secondary
                      focus:bg-neutral-secondary focus:outline-none
                    `,
                ),
            }}
            menuClassName={menuClassName}
            label={<SubMenuLabel label={label} />}
            {...props}
        >
            {children}
        </InnerSubMenu>
    );
}

export function Menu({
    children,
    menuButton,
    overrideClassName,
    open: openFromProps,
    onOpenChange: onOpenChangeFromProps,
    openOnHover,
    ...otherProps
}: MenuProps): JSX.Element {
    const anchorRef = React.useRef(null);

    const isControlled = openFromProps !== undefined;
    const [isOpenInternal, setOpenInternal] = React.useState(false);
    const isOpen = isControlled ? (openFromProps as boolean) : isOpenInternal;

    const setOpen = React.useCallback(
        (open: boolean) => {
            if (!isControlled) {
                setOpenInternal(open);
            }
            onOpenChangeFromProps?.(open);
        },
        [isControlled, onOpenChangeFromProps],
    );

    const onCloseMenu = React.useCallback(() => {
        setOpen(false);
    }, [setOpen]);

    useControlledValueWarning(isControlled);

    const clickAnchorProps = useClick(isOpen, setOpen);
    const {anchorProps: hoverAnchorProps, hoverProps} = useHover(isOpen, setOpen, {closeDelay: 0});

    const MenuButtonFromProps = typeof menuButton === "function" ? menuButton({open: isOpen}) : menuButton;
    const MenuButton = React.cloneElement(MenuButtonFromProps, {
        ...(openOnHover ? hoverAnchorProps : clickAnchorProps),
        ref: anchorRef,
    });

    // TODO: Using this due to legacy to not break anything, should be consistent and probably a Fragment
    const WrapperElement = openOnHover ? React.Fragment : "div";

    return (
        <WrapperElement>
            {MenuButton}
            <InnerControlledMenu
                anchorRef={anchorRef}
                state={isOpen ? "open" : "closed"}
                onClose={onCloseMenu}
                className={cx("relative")}
                menuClassName={(state) => cx(menuClassName(state), overrideClassName)}
                {...(openOnHover ? hoverProps : {})}
                {...otherProps}
            >
                {children}
            </InnerControlledMenu>
        </WrapperElement>
    );
}
