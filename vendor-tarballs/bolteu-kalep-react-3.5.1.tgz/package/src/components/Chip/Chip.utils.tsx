import {hex2rgb, rgb2hsl} from "@/helpers/utils/colors";

import type {
    BaseChipProps,
    ChipAppearance,
    ChipColorConfig,
    ChipColorConfigFull,
    ChipColorOverrides,
} from "./Chip.types";
import {isChipColorConfig, isChipColorConfigFull} from "./Chip.types";

export function selectChipColors(
    selected: BaseChipProps["selected"],
    disabled: BaseChipProps["disabled"],
    appearance: ChipAppearance,
): ChipColorOverrides | undefined {
    // Disabled is always the same, regardless of custom appearance config.
    if (disabled) {
        return {
            "--chip-bg": "var(--color-bg-neutral-secondary)",
            "--chip-bg-hover": "var(--color-bg-neutral-secondary)",
            "--chip-border": "var(--color-bg-neutral-secondary)",
            "--chip-content": "var(--color-content-tertiary)",
        };
    }

    // Check if we are given a custom appearance config and use it if so.
    if (isChipColorConfig(appearance)) {
        try {
            const colorConfig = generateColorConfig(appearance);

            return {
                "--chip-bg": selected ? colorConfig.light.main : colorConfig.light.bg,
                "--chip-bg-hover": colorConfig.light.bgActive,
                "--chip-border": selected ? colorConfig.light.main : colorConfig.light.border,
                "--chip-content": selected ? "var(--color-content-primary-inverted)" : appearance.light.main,
                "--chip-bg-dark": selected ? colorConfig?.dark?.main : colorConfig?.dark?.bg,
                "--chip-bg-hover-dark": colorConfig?.dark?.bgActive,
                "--chip-border-dark": selected ? colorConfig?.dark?.main : colorConfig?.dark?.border,
                "--chip-content-dark": selected ? "var(--color-content-primary-inverted)" : colorConfig?.dark?.main,
            };
        } catch (e) {
            console.error("Error in generateColorConfig", e);
        }
    } else {
        return {
            "--chip-bg": getColorProperty("bg", appearance, {selected, active: false}),
            "--chip-bg-hover": getColorProperty("bg", appearance, {selected, active: true}),
            "--chip-border": getColorProperty("border", appearance, {selected, active: false}),
            "--chip-content": getColorProperty("content", appearance, {selected, active: false}),
        };
    }

    return undefined;
}

function getColorProperty(
    colorGroup: "bg" | "border" | "content",
    appearance: "neutral" | "warning" | "action" | "danger" | "promo",
    opts: {selected: boolean; active: boolean},
) {
    // Handle text colors. Primary colors to ensure best contrast.
    if (colorGroup === "content") {
        // Selected state AND variant=simple - both essentially meaning primary-background
        if (opts.selected) {
            if (["danger", "promo", "action"].includes(appearance)) {
                return "var(--color-static-content-key-light)";
            }

            return "var(--color-content-primary-inverted)";
        }

        return `var(--color-content-${appearance}-primary)`;
    }

    return `var(--color-${colorGroup}${opts.active ? "-active" : ""}-${appearance}-${
        opts.selected ? "primary" : "secondary"
    })`;
}

export function generateColorConfig(inputConfig: ChipColorConfig): ChipColorConfigFull {
    if (isChipColorConfigFull(inputConfig)) {
        return inputConfig;
    }

    const mainColorRGB = hex2rgb(inputConfig.light.main);

    // bg-color opacity 0.12
    const bg = `rgba(${mainColorRGB?.r}, ${mainColorRGB?.g}, ${mainColorRGB?.b}, 0.12)`;

    // bg-color active opacity 0.24
    const bgActive = `rgba(${mainColorRGB?.r}, ${mainColorRGB?.g}, ${mainColorRGB?.b}, 0.24)`;

    // border color opacity 0.48
    const border = `rgba(${mainColorRGB?.r}, ${mainColorRGB?.g}, ${mainColorRGB?.b}, 0.48)`;

    // dark - convert to hsl, change lightness to 75
    const darkMain = rgb2hsl([mainColorRGB?.r, mainColorRGB?.g, mainColorRGB?.b]);
    darkMain.l = 75;

    const darkMainHSL = `hsl(${darkMain.h}, ${darkMain.s}%, ${darkMain.l}%)`;

    // apply same logic with opacity as for light mode
    const darkBg = `hsla(${darkMain.h}, ${darkMain.s}%, ${darkMain.l}%, 0.12)`;
    const darkBgActive = `hsla(${darkMain.h}, ${darkMain.s}%, ${darkMain.l}%, 0.24)`;
    const darkBorder = `hsla(${darkMain.h}, ${darkMain.s}%, ${darkMain.l}%, 0.48)`;

    return {
        light: {
            main: inputConfig.light.main,
            bg,
            bgActive,
            border,
        },
        dark: {
            main: darkMainHSL,
            bg: darkBg,
            bgActive: darkBgActive,
            border: darkBorder,
        },
    };
}
