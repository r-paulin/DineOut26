import * as React from "react";

import Cross from "@bolteu/kalep-react-icons/dist/Cross";
import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

import {cx} from "@/helpers/utils/cx";

import type {BaseChipProps, ChipColorOverrides, ChipProps, ChipSize} from "./Chip.types";
import {selectChipColors} from "./Chip.utils";

export type {ChipProps} from "./Chip.types";

const sizes: Record<ChipSize, string> = {
    xs: "h-6 px-2",
    sm: "h-7 px-3",
    md: "h-9 px-4",
};

/**
 * Always set the size prop to the same value as the Chip size.
 * @returns IconElement with given size prop.
 */
function withSize(icon: KalepIconElement, size: ChipSize) {
    const actualSize = size === "md" ? "md" : "xs";
    return React.cloneElement(icon, {size: actualSize});
}

const BaseChip = React.forwardRef<HTMLSpanElement, BaseChipProps>(
    ({children, size, variant, disabled, selected, appearance: appearanceProp, ...props}: BaseChipProps, ref) => {
        // TODO: Remove this fallback to color prop and color prop itself in a major version
        const appearance = appearanceProp ?? "neutral";
        const isClickable = typeof props.onClick === "function" && !disabled;
        const isOutlined = variant === "outline";
        const isSimple = variant === "simple";

        const isSelected = selected || false;
        const isInvertedColorScheme = isSimple || isSelected;

        let customPropertiesOverride: ChipColorOverrides | undefined;

        // Configures Chip coloring with CSS Custom Properties
        if (appearance) {
            customPropertiesOverride = selectChipColors(isInvertedColorScheme, disabled, appearance);
        }

        return (
            <span
                {...props}
                ref={ref}
                className={cx(
                    ["chip", isSelected && "selected", isSimple && "simple"], // check Chip.css
                    "bolt-font-body-s-regular truncate",
                    isSimple ? "cursor-default" : "cursor-pointer",
                    isClickable && "active:scale-975 active:duration-100 active:ease-in-out",
                    isOutlined && !selected && `
                      bg-special-nulled
                      dark:bg-special-nulled
                    `,
                    disabled && "pointer-events-none",
                    sizes[size],
                )}
                style={customPropertiesOverride as React.CSSProperties}
            >
                {children}
            </span>
        );
    },
);
BaseChip.displayName = "BaseChip";

function RemoveChipButton({
    onRemove,
    size,
    disabled,
}: {
    onRemove: (event: React.KeyboardEvent | React.MouseEvent) => void;
    size: ChipSize;
    disabled: boolean;
}) {
    return (
        <span
            onClick={onRemove}
            aria-hidden="true"
            data-testid="chip-remove"
            className={cx("-mx-2 flex h-full cursor-pointer items-center pe-1 ps-2", {
                "pointer-events-none cursor-not-allowed": disabled,
            })}
        >
            {withSize(<Cross />, size)}
        </span>
    );
}

export const Chip = React.forwardRef<HTMLSpanElement, ChipProps>(
    (
        {
            label,
            size = "md",
            variant = "filled",
            disabled = false,
            selected = false,
            startIcon,
            onKeyDown,
            onRemove,
            ...passThroughProps
        }: ChipProps,
        ref,
    ) => {
        const isRemovable = typeof onRemove === "function";
        const baseProps = {size, variant, disabled, selected};
        const variantProps: Record<string, any> = {};

        if (isRemovable) {
            variantProps.role = "button";
            variantProps.tabIndex = "0";
            variantProps["aria-disabled"] = disabled;
        }

        const content: React.ReactNode[] = [
            <span className={cx("truncate")} key="chip-content">
                {label}
            </span>,
        ];

        if (startIcon) {
            content.unshift(
                <span className={cx(`
                  -ms-1
                  [&>svg]:block
                `)} key="chip-icon">
                    {withSize(startIcon, size)}
                </span>,
            );
        }

        if (isRemovable) {
            content.push(<RemoveChipButton onRemove={onRemove} size={size} disabled={disabled} key="chip-remove" />);
        }

        const handleKeyDown = React.useCallback(
            (event: React.KeyboardEvent<HTMLSpanElement>) => {
                if (typeof onKeyDown === "function") {
                    onKeyDown(event);
                }

                if (isRemovable && (event.key === "Backspace" || event.key === "Delete")) {
                    onRemove(event);
                }
            },
            [isRemovable, onRemove, onKeyDown],
        );

        return (
            <BaseChip ref={ref} onKeyDown={handleKeyDown} {...baseProps} {...variantProps} {...passThroughProps}>
                {content}
            </BaseChip>
        );
    },
);
Chip.displayName = "Chip";
