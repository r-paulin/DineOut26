import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Alert, Heart, Lock, RideStart} from "@bolteu/kalep-react-icons";

import {Typography} from "../Typography";
import type {ChipProps} from "./Chip";
import {Chip} from "./Chip";
import type {ChipAppearance, ChipSize, ChipVariant} from "./Chip.types";

// More on default export: https://storybook.js.org/docs/react/writing-stories/introduction#default-export
export default {
    title: "Data Display/Chip",
    component: Chip,
    tags: ["autodocs"],
    argTypes: {
        startIcon: {
            options: ["None", "Heart", "Lock", "Alert", "RideStart"],
            mapping: {
                None: null,
                Heart: <Heart />,
                Lock: <Lock />,
                Alert: <Alert />,
                RideStart: <RideStart />,
            },
        },
        appearance: {
            options: ["neutral", "action", "danger", "promo", "warning"],
        },
    },
    // More on argTypes: https://storybook.js.org/docs/react/api/argtypes
} as Meta<typeof Chip>;

// More on component templates: https://storybook.js.org/docs/react/writing-stories/introduction#using-args
const Template: StoryFn<typeof Chip> = (args: ChipProps) => {
    const onClick = React.useCallback(() => console.log("Chip clicked"), []);
    return <Chip {...args} onClick={onClick} />;
};

export const Default = Template.bind({});
// More on args: https://storybook.js.org/docs/react/writing-stories/args
Default.args = {
    variant: "filled",
    size: "md",
    startIcon: <Heart />,
    label: "What is Love?",
    disabled: false,
    selected: false,
    onClick: undefined, // to prevent storybook from adding a default onClick prop
    onRemove: () => alert("remove!"),
};

export const Simple = () => {
    return (
        <div className="flex gap-1">
            <Chip variant="simple" appearance="neutral" size="sm" label="Todo" />
            <Chip variant="simple" appearance="promo" size="sm" label="In progress" />
            <Chip variant="simple" appearance="action" size="sm" label="Done" />
        </div>
    );
};

export const TruncatedLabel = () => (
    <div className="border-1 flex w-[150px] border-solid border-action-primary p-4">
        <Chip startIcon={<Lock />} label="In progresssssssssss" appearance="action" />
    </div>
);

function getRainbowGradient(opacity: number = 1) {
    return `linear-gradient(
        120deg,
        rgba(255, 0, 0, ${opacity}) 0%,
        rgba(255, 154, 0, ${opacity}) 10%,
        rgba(208, 222, 33, ${opacity}) 20%,
        rgba(79, 220, 74, ${opacity}) 30%,
        rgba(63, 218, 216, ${opacity}) 40%,
        rgba(47, 201, 226, ${opacity}) 50%,
        rgba(28, 127, 238, ${opacity}) 60%,
        rgba(95, 21, 242, ${opacity}) 70%,
        rgba(186, 12, 248, ${opacity}) 80%,
        rgba(251, 7, 217, ${opacity}) 90%,
        rgba(255, 0, 0, ${opacity}) 100%
    )`;
}

const rainbowColorConfig = {
    light: {
        main: "var(--color-content-primary)",
        bg: getRainbowGradient(0.36),
        bgActive: getRainbowGradient(0.48),
        border: "transparent",
    },
    dark: {
        main: "var(--color-content-primary)",
        bg: getRainbowGradient(0.9),
        bgActive: getRainbowGradient(1),
    },
};

export const ColorVariations = () => {
    const propsList = [
        {
            variant: "filled" as ChipVariant,
            size: "md" as ChipSize,
            startIcon: <Heart />,
            disabled: false,
            selected: false,
            onRemove: () => undefined,
        },
        {
            variant: "filled" as ChipVariant,
            size: "md" as ChipSize,
            startIcon: <Heart />,
            disabled: false,
            selected: true,
        },
        {
            variant: "filled" as ChipVariant,
            size: "md" as ChipSize,
            startIcon: <Heart />,
            disabled: true,
            selected: false,
        },
        {
            variant: "outline" as ChipVariant,
            size: "md" as ChipSize,
            startIcon: <Heart />,
            disabled: false,
            selected: false,
        },
        {
            variant: "filled" as ChipVariant,
            size: "sm" as ChipSize,
            startIcon: <Heart />,
            disabled: false,
            selected: false,
        },
        {
            variant: "filled" as ChipVariant,
            size: "sm" as ChipSize,
            disabled: false,
            selected: false,
        },
        {
            variant: "filled" as ChipVariant,
            size: "sm" as ChipSize,
            disabled: false,
            selected: true,
            onRemove: () => undefined,
        },
    ];
    const appearances: ChipAppearance[] = [
        "neutral",
        "action",
        "warning",
        "danger",
        "promo",
        {light: {main: "#FF21F5"}},
        {light: {main: "#00c8dd"}},
        {light: {main: "#CCC"}},
        {light: {main: "#d3d7dc"}},
        {light: {main: "#32bb78"}},
        {light: {main: "#ffd400"}},
        {light: {main: "#7faa42"}},
        {light: {main: "#ff8800"}},
        rainbowColorConfig,
    ];
    return (
        <div className="flex flex-col gap-1">
            <Typography paddingBottom={4}>Chosen main color must have sufficient contrast with white</Typography>
            {appearances.map((appearance) => (
                <div className="flex gap-1" key={JSON.stringify(appearance)}>
                    {propsList.map((propSet) => (
                        <Chip key={Math.random()} label="What is love" {...propSet} appearance={appearance} />
                    ))}
                </div>
            ))}
        </div>
    );
};
