import * as React from "react";

import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Chip} from "../index";

describe("Chip test suite", () => {
    const labelText = "test-label-for-chip";

    test("passing onRemove shows remove button inside chip", () => {
        const handler = vi.fn();

        render(<Chip label={labelText} onRemove={handler} />);
        expect(screen.getByText(labelText)).toBeInTheDocument();
        expect(screen.getByTestId("chip-remove")).toBeVisible();
    });

    test("clicking on remove button triggers onRemove callback", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();

        render(<Chip label={labelText} onRemove={handler} />);
        await user.click(screen.getByTestId("chip-remove"));
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("Backspace on chip element triggers onRemove", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();

        render(<Chip label={labelText} onRemove={handler} />);
        await user.tab();
        await user.keyboard("{Backspace}");
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("Delete on chip element triggers onRemove", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();

        render(<Chip label={labelText} onRemove={handler} />);
        await user.tab();
        await user.keyboard("{Delete}");
        expect(handler).toHaveBeenCalledTimes(1);
    });

    test("onKeyDown prop is called alongsite the Chip internal handler", async () => {
        const user = userEvent.setup();
        const handler = vi.fn();
        const onKeyDown = vi.fn();

        render(<Chip label={labelText} onRemove={handler} onKeyDown={onKeyDown} />);

        await user.tab();
        await user.keyboard("{Delete}");

        expect(handler).toHaveBeenCalledTimes(1);
        expect(onKeyDown).toHaveBeenCalledTimes(1);
    });
});
