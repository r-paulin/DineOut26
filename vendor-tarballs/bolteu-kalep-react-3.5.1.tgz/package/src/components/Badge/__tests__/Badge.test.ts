import {defaultProps, renderBadge, screen} from "./Badge.testUtils";

test("should render the badge as sibling to the labelled element", function renderBadgeWithSibling() {
    renderBadge();

    expect(screen.getByTestId("kalep-badge-wrapper").childElementCount).toEqual(2);
    expect(screen.getByText(defaultProps.badgeContent)).toBeInTheDocument();
});

test("should support a maximum count with a number content", function maxCountSupport() {
    const maxCount = 9;
    const badgeContent = maxCount + 5;
    renderBadge({maxCount, badgeContent});

    expect(screen.getByTestId("kalep-badge-wrapper").childElementCount).toEqual(2);
    expect(screen.getByTestId("limit-reached-badge")).toBeInTheDocument();
});

test("should render an empty dot element", function emptyBadge() {
    renderBadge({variant: "dot"});

    expect(screen.getByTestId("kalep-badge-wrapper").childElementCount).toEqual(2);
    expect(screen.getByTestId("dot-variant-badge")).toBeInTheDocument();
});

test("should not account maxCount if content is not a number", function maxCountNoNumber() {
    const badgeContent = "hello";

    renderBadge({maxCount: 5, badgeContent});

    expect(screen.getByTestId("kalep-badge-wrapper").childElementCount).toEqual(2);
    expect(screen.getByText(badgeContent)).toBeInTheDocument();
});

test("should display a standalone badge", function standaloneBadge() {
    const badgeContent = "hello";

    renderBadge({children: null, badgeContent});

    expect(screen.queryByTestId("kalep-badge-wrapper")).not.toBeInTheDocument();
    expect(screen.getByText(badgeContent)).toBeInTheDocument();
});

test("should render an s-dot element", function emptyBadge() {
    renderBadge({variant: "s-dot"});

    expect(screen.getByTestId("kalep-badge-wrapper").childElementCount).toEqual(2);
    expect(screen.getByTestId("s-dot-variant-badge")).toBeInTheDocument();
});
