import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import Mail from "@bolteu/kalep-react-icons/dist/Mail";

import {Button} from "@/components/Button";
import {IconButton} from "@/components/IconButton";
import {Island} from "@/index";

import {IconView} from "../IconView";
import type {BadgeProps} from "./index";
import {Badge} from "./index";

export default {
    title: "Data Display/Badge",
    component: Badge,
    tags: ["autodocs"],
    argTypes: {
        badgeContent: {
            type: {name: "string", required: false},
        },
    },
} as Meta<typeof Badge>;

export const Default: StoryFn<typeof Badge> = (args: BadgeProps) => <Badge {...args} />;
Default.args = {
    badgeContent: 6,
    children: <IconButton icon={<Mail />} aria-label="you have mail!" size="lg" />,
};

export const MaxCount = Default.bind({});

MaxCount.args = {
    ...Default.args,
    badgeContent: 10,
    maxCount: 9,
};
MaxCount.argTypes = {
    badgeContent: {
        type: {name: "number", required: false},
    },
};

export const Dot = Default.bind({});
Dot.args = {
    ...Default.args,
    variant: "dot",
};

export const SDot = Default.bind({});
SDot.args = {
    ...Default.args,
    variant: "s-dot",
    children: <IconView icon={<Mail />} size="xs" alt="S-Dot badge" />,
};

export const Placements = Default.bind({});
Placements.args = {
    ...Default.args,
    placement: "bottom-left",
    variant: "dot",
};

export const PlacementOverlap = Default.bind({});
PlacementOverlap.args = {
    ...Default.args,
    placement: "top-right",
    placementOverlap: "rectangular",
    variant: "standard",
    badgeContent: "123",
    children: <Island corners="square">Square corners need different placement overlap</Island>,
};

export const Stroke = Default.bind({});
Stroke.args = {
    ...Default.args,
    stroke: true,
    children: <IconButton variant="primary" icon={<Mail />} aria-label="you have mail!" size="lg" />,
};

export const Standalone = Default.bind({});
Standalone.args = {
    badgeContent: 42,
    appearance: "action",
};

function getRainbowGradient(opacity: number = 1) {
    return `linear-gradient(
        90deg,
        rgba(255, 0, 0, ${opacity}) 0%,
        rgba(255, 154, 0, ${opacity}) 10%,
        rgba(208, 222, 33, ${opacity}) 20%,
        rgba(79, 220, 74, ${opacity}) 30%,
        rgba(63, 218, 216, ${opacity}) 40%,
        rgba(47, 201, 226, ${opacity}) 50%,
        rgba(28, 127, 238, ${opacity}) 60%,
        rgba(95, 21, 242, ${opacity}) 70%,
        rgba(186, 12, 248, ${opacity}) 80%,
        rgba(251, 7, 217, ${opacity}) 90%,
        rgba(255, 0, 0, ${opacity}) 100%
    )`;
}

const rainbowColorConfig = {
    light: {
        main: getRainbowGradient(0.48),
        content: "var(--color-content-primary)",
    },
    dark: {
        main: getRainbowGradient(0.72),
    },
};

export const ColorVariations = () => {
    return (
        <div className="flex flex-col gap-8">
            <div className="flex gap-2">
                <Badge variant="dot" appearance="action">
                    <Button variant="secondary" size="sm">
                        Filters
                    </Button>
                </Badge>
                <Badge variant="dot" appearance="neutral">
                    <Button variant="secondary" size="sm">
                        Filters
                    </Button>
                </Badge>
                <Badge variant="dot" appearance="warning">
                    <Button variant="secondary" size="sm">
                        Filters
                    </Button>
                </Badge>
                <Badge variant="dot" appearance="danger">
                    <Button variant="secondary" size="sm">
                        Filters
                    </Button>
                </Badge>
                <Badge variant="dot" appearance="promo">
                    <Button variant="secondary" size="sm">
                        Filters
                    </Button>
                </Badge>
                <Badge variant="dot" appearance={{light: {main: "#FF21F5"}}}>
                    <Button variant="secondary" size="sm">
                        Filters
                    </Button>
                </Badge>
                <Badge variant="dot" appearance={{light: {main: "#00c8dd"}}}>
                    <Button variant="secondary" size="sm">
                        Filters
                    </Button>
                </Badge>
                <Badge variant="dot" appearance={rainbowColorConfig}>
                    <Button variant="secondary" size="sm">
                        Filters
                    </Button>
                </Badge>
            </div>
        </div>
    );
};
