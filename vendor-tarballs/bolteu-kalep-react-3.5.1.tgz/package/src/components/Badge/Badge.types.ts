import type {Appearance} from "@/helpers/utils/utilityTypes";

export type BadgeVariant = "dot" | "s-dot" | "standard";
export type BadgePlacement = "top-right" | "top-left" | "bottom-left" | "bottom-right";
export type BadgePlacementOverlap = "circular" | "rectangular";
export type BadgeAppearance = Appearance<BadgeColorConfig>;

export type BadgeColorConfig = {light: {main: string; content?: string}; dark?: {main?: string; content?: string}};
export type BadgeColorOverrides = {
    "--badge-bg": string;
    "--badge-content": string;
    "--badge-bg-dark"?: string;
    "--badge-content-dark"?: string;
};

export interface BadgeProps {
    badgeContent?: string | number;
    children?: React.ReactNode;
    maxCount?: number;
    variant?: BadgeVariant;
    placement?: BadgePlacement;
    placementOverlap?: BadgePlacementOverlap;
    stroke?: boolean;
    appearance?: BadgeAppearance;
}

export function isBadgeColorConfig(appearance: BadgeAppearance): appearance is BadgeColorConfig {
    return typeof appearance === "object" && "light" in appearance;
}
