import * as React from "react";

import {cx} from "@/helpers/utils/cx";

import type {
    BadgeAppearance,
    BadgeColorOverrides,
    BadgePlacement,
    BadgePlacementOverlap,
    BadgeProps,
} from "./Badge.types";
import {selectBadgeColors} from "./Badge.utils";

export type {BadgeProps} from "./Badge.types";

const circularPositions: Record<BadgePlacement, string> = {
    // 14% offset places the badge on the curved edge of content (like in MUI)
    "top-left": "top-[14%] left-[14%] -translate-x-1/2 -translate-y-1/2",
    "top-right": "top-[14%] right-[14%] translate-x-1/2 -translate-y-1/2",
    "bottom-left": "bottom-[14%] left-[14%] -translate-x-1/2 translate-y-1/2",
    "bottom-right": "bottom-[14%] right-[14%] translate-x-1/2 translate-y-1/2",
};

const rectangularPositions: Record<BadgePlacement, string> = {
    "top-left": "top-0 left-0 -translate-x-1/2 -translate-y-1/2",
    "top-right": "top-0 right-0 translate-x-1/2 -translate-y-1/2",
    "bottom-left": "bottom-0 left-0 -translate-x-1/2 translate-y-1/2",
    "bottom-right": "bottom-0 right-0 translate-x-1/2 translate-y-1/2",
};

export const Badge = React.forwardRef<HTMLDivElement, BadgeProps>(
    (
        {
            badgeContent,
            children,
            maxCount,
            variant = "standard",
            placement = "top-right",
            placementOverlap = "circular",
            appearance,
            stroke,
            ...rest
        }: BadgeProps,
        ref: React.ForwardedRef<HTMLDivElement>,
    ) => {
        const isLimitReached =
            variant === "standard" &&
            maxCount !== undefined &&
            typeof badgeContent === "number" &&
            badgeContent > maxCount;

        let customPropertiesOverride: BadgeColorOverrides | undefined;

        if (appearance) {
            customPropertiesOverride = selectBadgeColors(appearance);
        }

        if (!children) {
            return (
                <BadgeWithContent
                    badgeContent={badgeContent}
                    isLimitReached={isLimitReached}
                    standalone
                    placement={placement}
                    placementOverlap={placementOverlap}
                    appearance={appearance}
                    stroke={stroke}
                />
            );
        }

        return (
            <div data-testid="kalep-badge-wrapper" className={cx("relative inline-flex flex-shrink-0")} ref={ref}>
                {React.cloneElement(children as React.ReactElement, rest)}
                {variant === "standard" ? (
                    <BadgeWithContent
                        badgeContent={badgeContent}
                        isLimitReached={isLimitReached}
                        placement={placement}
                        placementOverlap={placementOverlap}
                        appearance={appearance}
                        stroke={stroke}
                    />
                ) : (
                    <div
                        className={cx(
                            "absolute rounded-full bg-layer-floor-1",
                            placementOverlap === "circular"
                                ? circularPositions[placement]
                                : rectangularPositions[placement],
                            "inline-flex items-center justify-center",
                            stroke && (variant === "dot" ? "p-[2px]" : "p-[1px]"),
                        )}
                    >
                        <span
                            data-testid={variant === "dot" ? "dot-variant-badge" : "s-dot-variant-badge"}
                            className={cx("badge", variant === "dot" ? "h-3 w-3" : "h-1.5 w-1.5", "rounded-full")}
                            style={customPropertiesOverride as React.CSSProperties}
                        />
                    </div>
                )}
            </div>
        );
    },
);
Badge.displayName = "Badge";

function BadgeWithContent({
    isLimitReached,
    badgeContent,
    standalone,
    placement,
    placementOverlap,
    appearance,
    stroke,
}: {
    isLimitReached: boolean;
    badgeContent?: string | number;
    standalone?: boolean;
    placement: BadgePlacement;
    placementOverlap: BadgePlacementOverlap;
    appearance?: BadgeAppearance;
    stroke?: boolean;
}): JSX.Element {
    const isNeutralColor = appearance === "neutral";
    let customPropertiesOverride: BadgeColorOverrides | undefined;

    if (appearance) {
        customPropertiesOverride = selectBadgeColors(appearance);
    }

    return (
        <div
            className={cx(
                "box-border inline-flex items-center justify-center rounded-full bg-layer-floor-1",
                standalone ? "relative" : "absolute",
                !standalone &&
                    (placementOverlap === "circular" ? circularPositions[placement] : rectangularPositions[placement]),
                stroke && "p-[2px]",
            )}
        >
            <div
                className={cx(
                    "badge", // check Badge.css
                    "inline-flex items-center justify-center",
                    "min-h-5 min-w-5 px-1.5",
                    "bolt-font-body-xs-accent whitespace-nowrap rounded-full",
                    isNeutralColor && "bg-neutral-secondary-hard text-secondary",
                )}
                style={customPropertiesOverride as React.CSSProperties}
            >
                {isLimitReached ? (
                    <span
                        data-testid="limit-reached-badge"
                        className={cx("inline-block h-[6px] w-[6px] rounded-full bg-static-key-light")}
                    />
                ) : (
                    badgeContent
                )}
            </div>
        </div>
    );
}
