import * as React from "react";

import type {SpacingValue} from "@/components/Typography/Typography.types";
import {cx} from "@/helpers/utils/cx";

type Elevation = "floor-1" | "floor-2" | "floor-3" | "surface" | "outlined";
type Corner = "rounded" | "square";

const DEFAULT_PADDING: SpacingValue = 5;

export interface IslandProps {
    elevation?: Elevation;
    corners?: Corner;
    children?: React.ReactNode;
    /** Container padding.
     * @default 5
     */
    padding?: SpacingValue;
    /** Left container padding.
     * @default undefined
     */
    paddingLeft?: SpacingValue;
    /** Top container padding.
     * @default undefined
     */
    paddingTop?: SpacingValue;
    /** Right container padding.
     * @default undefined
     */
    paddingRight?: SpacingValue;
    /** Bottom container padding.
     * @default undefined
     */
    paddingBottom?: SpacingValue;
    /**
     * Note that you can override default styles by passing tailwind classes.
     * Exercise caution when using this prop.
     */
    className?: string;
}

const elevationStyles: Record<Elevation, string> = {
    "floor-1": "bg-layer-floor-1 border-solid border border-neutral-secondary",
    "floor-2": "bg-layer-floor-2 shadow-md",
    "floor-3": "bg-layer-floor-3 shadow-lg",
    surface: "bg-layer-surface",
    outlined: "bg-special-nulled border-solid border border-separator",
};

const cornerStyles: Record<Corner, string> = {
    rounded: "rounded-lg",
    square: "rounded-none",
};

export function Island({
    elevation = "floor-1",
    corners = "rounded",
    children,
    padding = DEFAULT_PADDING,
    paddingTop,
    paddingLeft,
    paddingBottom,
    paddingRight,
    className,
}: IslandProps) {
    const containerStyle: React.CSSProperties = React.useMemo(() => {
        return {
            ...(padding !== undefined && {padding: getRemFromSpacingSize(padding)}),
            ...(paddingTop !== undefined && {paddingTop: getRemFromSpacingSize(paddingTop)}),
            ...(paddingLeft !== undefined && {paddingLeft: getRemFromSpacingSize(paddingLeft)}),
            ...(paddingRight !== undefined && {paddingRight: getRemFromSpacingSize(paddingRight)}),
            ...(paddingBottom !== undefined && {paddingBottom: getRemFromSpacingSize(paddingBottom)}),
        };
    }, [padding, paddingLeft, paddingTop, paddingRight, paddingBottom]);

    return (
        <div style={containerStyle} className={cx(elevationStyles[elevation], cornerStyles[corners], className)}>
            {children}
        </div>
    );
}

function getRemFromSpacingSize(spacingValue: SpacingValue): string {
    return `${spacingValue / 4}rem`;
}
