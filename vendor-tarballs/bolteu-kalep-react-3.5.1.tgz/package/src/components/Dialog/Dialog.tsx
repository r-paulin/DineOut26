import * as React from "react";

import {AlertDialog as RadixAlertDialog, Dialog as RadixDialog} from "radix-ui";

import {
    KALEP_MODAL_CONTENT_ID,
    ModalContent,
    ModalFooter,
    ModalHeader,
    RadixModalHeader,
} from "@/components/_internal/Modal";
import {DEFAULT_MOBILE_BREAKPOINT, useViewportWidth} from "@/helpers";
import {cx} from "@/helpers/utils/cx";
import {filterDataAttributes} from "@/helpers/utils/props";
import {BottomSheet} from "@/index";

import type {DialogProps} from "./Dialog.types";

export function Dialog({
    isOpen,
    onRequestClose,
    title,
    variant = "default",
    children,
    size,
    useBottomSheet,
    bottomSheetProps = {},
    portalContainer,
    ...rest
}: DialogProps) {
    const dataAttributes = filterDataAttributes(rest);
    const {width} = useViewportWidth();
    const DialogComponent = variant === "alert" ? RadixAlertDialog : RadixDialog;

    const handleOnOpenChange = React.useCallback(
        (newOpen: boolean) => {
            if (!newOpen) {
                onRequestClose();
            }
        },
        [onRequestClose],
    );

    if (width < DEFAULT_MOBILE_BREAKPOINT && useBottomSheet) {
        const heightClass = bottomSheetProps.snapPoints?.length ? "max-h-[94vh]" : "max-h-[80vh]";
        return (
            <BottomSheet
                isOpen={isOpen}
                onOpenChange={handleOnOpenChange}
                container={portalContainer}
                {...bottomSheetProps}
            >
                <div className={cx(heightClass, "flex w-full flex-col bg-layer-floor-2")}>
                    <ModalHeader title={title} variant={variant} onClose={onRequestClose} />
                    {children}
                </div>
            </BottomSheet>
        );
    }

    return (
        <DialogComponent.Root open={isOpen} onOpenChange={handleOnOpenChange} {...dataAttributes}>
            <DialogComponent.Portal container={portalContainer}>
                <DialogComponent.Overlay
                    className={cx(
                        "fixed inset-0 z-modalOverlay bg-special-scrim",
                        "data-[state=open]:animate-overlayShow",
                    )}
                />
                <DialogComponent.Content
                    className={cx(
                        `
                          fixed left-1/2 top-1/2 z-modal -translate-x-1/2 -translate-y-1/2 rounded-lg
                          focus:outline-none
                          data-[state=open]:animate-contentShow
                        `,
                    )}
                    aria-describedby={undefined} // Cant use Radix.Description as content is unknown
                >
                    <div
                        id={KALEP_MODAL_CONTENT_ID}
                        className={cx("flex max-h-[80vh] max-w-md flex-col rounded-lg bg-layer-floor-2", [
                            size === "custom" ? "max-w-[calc(100vw-1rem)]" : "max-w-md",
                        ])}
                    >
                        <RadixModalHeader title={title} variant={variant} onClose={onRequestClose} />
                        {children}
                    </div>
                </DialogComponent.Content>
            </DialogComponent.Portal>
        </DialogComponent.Root>
    );
}

Dialog.Content = ModalContent;
Dialog.Footer = ModalFooter;
