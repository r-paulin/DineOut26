import * as React from "react";

import type {Meta} from "@storybook/react-webpack5";

import {Button} from "@/components/Button";
import {Dialog} from "@/components/Dialog";
import {cx} from "@/helpers/utils/cx";
import {noop} from "@/helpers/utils/noop";
import {Alert, Drawer, Typography} from "@/index";

import {Radio, RadioGroup} from "../RadioGroup";

export default {
    title: "Layout/Dialog",
    tags: ["autodocs"],
    component: Dialog,
    parameters: {
        docs: {
            description: {
                component: `
Dialogs inform users about a specific task and may contain critical information, require decisions, or involve multiple tasks.

By default Dialog provides you:
- a close button
- closing on Esc and clicking outside of Dialog
- blocking interactivity with the page below

Use <code>&lt;Dialog.Content&gt;</code> and <code>&lt;Dialog.Footer&gt;</code> components to set content and
actions
                `,
            },
        },
    },
} as Meta<typeof Dialog>;

export const DefaultDialog = () => {
    const [isOpen, setIsOpen] = React.useState(false);

    const openDialog = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const closeDialog = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <>
            <Button onClick={openDialog}>Open Dialog</Button>
            <Dialog isOpen={isOpen} onRequestClose={closeDialog} title="The default Dialog">
                <Dialog.Content>
                    <Typography variant="body-m-regular">
                        Keep your Dialogs simple and concise. Avoid form elements and complex interactions inside
                        Dialogs. Use Drawers for more complex use cases instead.
                    </Typography>
                </Dialog.Content>
                <Dialog.Footer>
                    <Button onClick={closeDialog}>Got it</Button>
                    <Button variant="secondary" onClick={closeDialog}>
                        Cancel
                    </Button>
                </Dialog.Footer>
            </Dialog>
        </>
    );
};

export const AlertDialog = () => {
    const [isOpen, setIsOpen] = React.useState(false);

    const openDialog = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const closeDialog = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <>
            <Button onClick={openDialog}>Open Dialog</Button>

            <Dialog isOpen={isOpen} onRequestClose={noop} title="The Alert Dialog" variant="alert">
                <Dialog.Content>
                    <Typography variant="body-m-regular">
                        Alert Dialogs are used to inform users about critical information or decisions that require
                        action. It has a slightly different appearance compared to the default Dialog and attempts to
                        captivate the user inside the Dialog. However, it is still possible to request closing of Alert
                        Dialog by pressing Escape.
                    </Typography>
                </Dialog.Content>
                <Dialog.Footer>
                    <Button onClick={closeDialog}>Got it</Button>
                    <Button variant="secondary" onClick={closeDialog}>
                        Cancel
                    </Button>
                </Dialog.Footer>
            </Dialog>
        </>
    );
};

AlertDialog.parameters = {
    docs: {
        description: {
            story: `
Setting variant="alert" has the following effect: 
- Dialog is shown slightly smaller and title is centered
- Clicking outside of Dialog will not request closing
- Close button is not available

*NB!* Dialog will still request closing when user presses Escape. To avoid closing provide a no-op function to onRequestClose.
            `,
        },
    },
};

export const LongContent = () => {
    const [isOpen, setIsOpen] = React.useState(false);

    const openDialog = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const closeDialog = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <>
            <Button onClick={openDialog}>Open Dialog</Button>
            <Dialog title="The Dialog with long content" isOpen={isOpen} onRequestClose={closeDialog}>
                <Dialog.Content>
                    <p className="mb-4 font-semibold">
                        There`s 5 paragraphs of lorem ipsum below, demonstrating the scrolling content.
                    </p>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reiciendis corporis aliquam ipsa alias
                        saepe debitis sed temporibus, praesentium unde repudiandae non. Voluptas praesentium autem enim
                        culpa corrupti quia corporis hic.
                    </p>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reiciendis corporis aliquam ipsa alias
                        saepe debitis sed temporibus, praesentium unde repudiandae non. Voluptas praesentium autem enim
                        culpa corrupti quia corporis hic.
                    </p>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reiciendis corporis aliquam ipsa alias
                        saepe debitis sed temporibus, praesentium unde repudiandae non. Voluptas praesentium autem enim
                        culpa corrupti quia corporis hic.
                    </p>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reiciendis corporis aliquam ipsa alias
                        saepe debitis sed temporibus, praesentium unde repudiandae non. Voluptas praesentium autem enim
                        culpa corrupti quia corporis hic.
                    </p>
                    <p>
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Reiciendis corporis aliquam ipsa alias
                        saepe debitis sed temporibus, praesentium unde repudiandae non. Voluptas praesentium autem enim
                        culpa corrupti quia corporis hic.
                    </p>
                </Dialog.Content>
                <Dialog.Footer>
                    <Button onClick={closeDialog}>Got it</Button>
                    <Button variant="secondary" onClick={closeDialog}>
                        Cancel
                    </Button>
                </Dialog.Footer>
            </Dialog>
        </>
    );
};

export const AsyncClosing = () => {
    const [isOpen, setIsOpen] = React.useState(false);
    const [isClosingBlocked, setIsClosingBlocked] = React.useState(false);
    const openDialog = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const closeDialog = React.useCallback(() => !isClosingBlocked && setIsOpen(false), [setIsOpen, isClosingBlocked]);
    const doTheAsyncThing = React.useCallback(async () => {
        setIsClosingBlocked(true);
        await new Promise((resolve) => {
            setTimeout(resolve, 3000);
        });
        setIsClosingBlocked(false);
        closeDialog();
    }, [closeDialog]);

    return (
        <>
            <Button onClick={openDialog}>Open Dialog</Button>

            <Dialog isOpen={isOpen} onRequestClose={closeDialog} title="The Dialog with async closing">
                <Dialog.Content>
                    When you click the button below, it will show a spinner and delay the closing of Dialog for 3
                    seconds. During that time you cannot close the Dialog via Esc nor outside click
                </Dialog.Content>
                <Dialog.Footer>
                    <Button loading={isClosingBlocked} onClick={doTheAsyncThing}>
                        Do the async thing
                    </Button>
                    <Button variant="secondary" disabled={isClosingBlocked} onClick={closeDialog}>
                        Cancel
                    </Button>
                </Dialog.Footer>
            </Dialog>
        </>
    );
};

export const CustomWidthDialog = () => {
    const [isOpen, setIsOpen] = React.useState(false);
    const [width, setWidth] = React.useState("500px");
    const openDialog = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const closeDialog = React.useCallback(() => setIsOpen(false), [setIsOpen]);
    const updateWidth = React.useCallback(
        (event: React.ChangeEvent<HTMLInputElement>) => setWidth(event.target.value),
        [setWidth],
    );

    return (
        <>
            <Button onClick={openDialog}>Open Dialog</Button>

            <Dialog isOpen={isOpen} size="custom" onRequestClose={closeDialog} title="The custom sized Dialog">
                <Dialog.Content>
                    <div style={{width}} className="mb-4">
                        Choose the dialog width. This width is applied on the content, thus changing the Dialog size.
                        The width is still constrained by maximum of <code>calc(100vw - 1rem)</code> and on lower end by
                        content (e.g long continuous strings, images). It is possible for the Dialog body to be wide
                        enough to scroll horizontally.
                    </div>
                    <RadioGroup name="dialog-width" value={width} onChange={updateWidth}>
                        <Radio label="200px" value="200px" />
                        <Radio label="500px" value="500px" />
                        <Radio label="900px" value="900px" />
                        <Radio label="1200px" value="1200px" />
                    </RadioGroup>
                </Dialog.Content>
                <Dialog.Footer>
                    <Button onClick={closeDialog}>Got it</Button>
                    <Button variant="secondary" onClick={closeDialog}>
                        Cancel
                    </Button>
                </Dialog.Footer>
            </Dialog>
        </>
    );
};

export const BottomSheetFallback = () => {
    const [isOpen, setIsOpen] = React.useState(false);

    const openDialog = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const closeDialog = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <>
            <Alert severity="info" title="Mobile-first Dialog" overrideClassName={cx("mb-8")}>
                Pass the <code className={cx("font-semibold")}>useBottomSheet</code> flag to make the Dialog use
                BottomSheet component on smaller screens (width is smaller than 640px). Resize the Storybook window or
                select a responsive layout from the top menu to observe this change.
            </Alert>
            <Button onClick={openDialog}>Open Dialog</Button>
            <Dialog title="The mobile-first Dialog" isOpen={isOpen} onRequestClose={closeDialog} useBottomSheet>
                <Dialog.Content>
                    This Dialog renders as BottomSheet on smaller screens. Resize the Storybook window to witness this.
                </Dialog.Content>
                <Dialog.Footer>
                    <Button onClick={closeDialog}>Got it</Button>
                    <Button variant="secondary" onClick={closeDialog}>
                        Cancel
                    </Button>
                </Dialog.Footer>
            </Dialog>
        </>
    );
};

export const BottomSheetFallbackWithFullHeight = () => {
    const [isOpen, setIsOpen] = React.useState(false);

    const openDialog = React.useCallback(() => setIsOpen(true), [setIsOpen]);
    const closeDialog = React.useCallback(() => setIsOpen(false), [setIsOpen]);

    return (
        <>
            <Alert severity="info" title="Mobile-first Dialog" overrideClassName={cx("mb-8")}>
                Pass the <code className={cx("font-semibold")}>useBottomSheet</code> flag to make the Dialog use
                BottomSheet component on smaller screens (width is smaller than 640px). Resize the Storybook window or
                select a responsive layout from the top menu to observe this change.
            </Alert>
            <Button onClick={openDialog}>Open Dialog</Button>
            <Dialog
                title="The mobile-first Dialog"
                isOpen={isOpen}
                onRequestClose={closeDialog}
                useBottomSheet
                bottomSheetProps={{snapPoints: [1]}}
            >
                <Dialog.Content>
                    This Dialog renders as BottomSheet on smaller screens. Resize the Storybook window to witness this.
                </Dialog.Content>
                <Dialog.Footer>
                    <Button onClick={closeDialog}>Got it</Button>
                    <Button variant="secondary" onClick={closeDialog}>
                        Cancel
                    </Button>
                </Dialog.Footer>
            </Dialog>
        </>
    );
};

export const Portals = () => {
    const [isOpen, setIsOpen] = React.useState(false);
    const [isOpenDrawer, setIsOpenDrawer] = React.useState(false);
    const drawerRef = React.useRef<HTMLDivElement>(null);

    const openDialog = React.useCallback(() => setIsOpen(true), []);
    const closeDialog = React.useCallback(() => setIsOpen(false), []);

    const openDrawer = React.useCallback(() => setIsOpenDrawer(true), []);
    const closeDrawer = React.useCallback(() => setIsOpenDrawer(false), []);

    return (
        <>
            <Button onClick={openDrawer}>Open Drawer</Button>

            <Drawer isOpen={isOpenDrawer} onRequestClose={closeDrawer} title="The default Drawer">
                <Drawer.Content>
                    <div className="mb-6" ref={drawerRef}>
                        Drawers are great Dialog replacements when more content or form elements are required to be
                        shown.
                    </div>
                </Drawer.Content>
                <Drawer.Footer>
                    <Button onClick={openDialog}>Open Dialog</Button>
                    <Button variant="secondary" onClick={closeDrawer}>
                        Close Drawer
                    </Button>
                </Drawer.Footer>
            </Drawer>

            <Dialog
                title="The mobile-first Dialog"
                isOpen={isOpen}
                onRequestClose={closeDialog}
                useBottomSheet
                portalContainer={drawerRef.current}
            >
                <Dialog.Content>
                    This Dialog renders as BottomSheet on smaller screens. Resize the Storybook window to witness this.
                </Dialog.Content>
                <Dialog.Footer>
                    <Button onClick={closeDialog}>Got it</Button>
                    <Button variant="secondary" onClick={closeDialog}>
                        Cancel
                    </Button>
                </Dialog.Footer>
            </Dialog>
        </>
    );
};
