import type {KalepIconElement} from "@bolteu/kalep-react-icons/dist/types";

type sizes = "2xs" | "xs" | "sm" | "md" | "lg" | "xl";

export type IconViewSizeVariant = sizes;
export type IconSizeVariant = KalepIconElement["props"]["size"];

type colors =
    | "text-primary"
    | "text-secondary-primary"
    | "text-secondary"
    | "text-tertiary"
    | "text-action-primary"
    | "text-action-secondary"
    | "text-danger-primary"
    | "text-danger-secondary"
    | "text-warning-primary"
    | "text-warning-secondary"
    | "text-positive-primary"
    | "text-positive-secondary"
    | "text-promo-primary"
    | "text-promo-secondary"
    | "text-link-primary"
    | "text-link-secondary"
    | "text-primary-inverted";

export type ColorVariant = colors;

type backgroundColors =
    | "bg-neutral-primary"
    | "bg-neutral-secondary"
    | "bg-neutral-secondary-hard"
    | "bg-action-primary"
    | "bg-action-secondary"
    | "bg-danger-primary"
    | "bg-danger-secondary"
    | "bg-warning-primary"
    | "bg-warning-secondary"
    | "bg-positive-primary"
    | "bg-positive-secondary"
    | "bg-promo-primary"
    | "bg-promo-secondary"
    | "bg-layer-floor-0"
    | "bg-layer-floor-1"
    | "bg-layer-floor-2"
    | "bg-layer-floor-3"
    | "bg-layer-floor-surface";
export type BackgroundColorVariant = backgroundColors;

export interface IconViewProps {
    /**
     * If IconView does not have an associated label or labelledby link provide
     * an accessible label in alt.
     */
    alt?: string;
    /** Background color
     * @default "bg-neutral-secondary"
     */
    backgroundColor?: BackgroundColorVariant;
    /** Content color
     * @default "text-primary"
     */
    color?: ColorVariant;
    imageUrl?: string;
    icon?: KalepIconElement;
    shadow?: boolean;
    loading?: boolean;
    /** Icon View sizes. Also controls the size of the icon.
     * @default "md"
     */
    size?: IconViewSizeVariant;
}
