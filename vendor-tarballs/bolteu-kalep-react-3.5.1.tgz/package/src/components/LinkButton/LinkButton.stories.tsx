import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import {Alert, Lock, RideStart} from "@bolteu/kalep-react-icons";

import {cx} from "@/helpers/utils/cx";

import {LinkButton} from "./index";

export default {
    title: "Navigation/LinkButton",
    component: LinkButton,
    tags: ["autodocs"],
    argTypes: {
        endIcon: {
            options: ["None", "Lock", "Alert", "RideStart"],
            mapping: {
                None: undefined,
                Lock: <Lock />,
                Alert: <Alert />,
                RideStart: <RideStart />,
            },
        },
        startIcon: {
            options: ["None", "Lock", "Alert", "RideStart"],
            mapping: {
                None: undefined,
                Lock: <Lock />,
                Alert: <Alert />,
                RideStart: <RideStart />,
            },
        },
    },
} as Meta<typeof LinkButton>;

const Template: StoryFn<typeof LinkButton> = (args: any) => <LinkButton {...args}>{args.children}</LinkButton>;

export const Primary = Template.bind({});
Primary.args = {
    href: "#",
    variant: "primary",
    size: "md",
    endIcon: <Lock />,
    disabled: false,
    children: "LinkButton",
};

export const FlexConstrained = () => (
    <div className={cx("flex w-80")}>
        <LinkButton href="#">Flex constrained link button</LinkButton>
        <div className={cx("flex-shrink-0 self-center")}>This is a box width fixed width</div>
    </div>
);
