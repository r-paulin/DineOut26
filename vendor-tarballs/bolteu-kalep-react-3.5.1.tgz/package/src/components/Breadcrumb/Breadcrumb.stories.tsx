import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import ArrowRight from "@bolteu/kalep-react-icons/dist/ArrowRight";

import {cx} from "@/helpers/utils/cx";

import type {BreadcrumbItem} from "./index";
import {Breadcrumb} from "./index";

const breadcrumbItems: BreadcrumbItem[] = [
    {
        title: "Home",
        href: "#1",
    },
    {
        title: "Settings",
        href: "#2",
    },
    {
        title: "Account",
        href: "#3",
    },
];

export default {
    title: "Navigation/Breadcrumb",
    tags: ["autodocs"],
    component: Breadcrumb,
} as Meta<typeof Breadcrumb>;

const Template: StoryFn<typeof Breadcrumb> = (args) => <Breadcrumb {...args} />;

export const Default = Template.bind({});
Default.args = {items: breadcrumbItems, "aria-label": "Breadcrumb"};

export const SingleItem = Template.bind({});
SingleItem.args = {items: [breadcrumbItems[0]]};

export const Collapsing = Template.bind({});
Collapsing.args = {
    items: [
        ...breadcrumbItems,
        {
            title: "Billing",
            href: "#4",
        },
        {
            title: "Cards",
            href: "#5",
        },
        {
            title: "Debit",
            href: "#6",
        },
    ],
};

export const CustomSeparator = Template.bind({});
CustomSeparator.args = {
    items: breadcrumbItems,
    separator: <ArrowRight className={cx(`
      text-tertiary
      rtl:rotate-180
    `)} size="xs" />,
};

export const CustomRenderer = () => {
    const renderItem = React.useCallback((item: BreadcrumbItem) => {
        return (
            <li>
                <a
                    className={`
                      text-promo-primary no-underline
                      hover:text-promo-secondary
                    `}
                    href={item.href}
                    target={item.target}
                >
                    {item.title}
                </a>
            </li>
        );
    }, []);
    return <Breadcrumb items={breadcrumbItems} renderItem={renderItem} />;
};

export const WithClickHandlers = Template.bind({});
WithClickHandlers.args = {
    items: [
        {
            title: "Home",
            onClick: () => {
                alert("Home clicked!");
            },
        },
        {
            title: "Settings",
            onClick: () => {
                alert("Settings clicked!");
            },
        },
        {
            title: "Account",
            onClick: () => {
                alert("Account clicked!");
            },
        },
    ],
};
