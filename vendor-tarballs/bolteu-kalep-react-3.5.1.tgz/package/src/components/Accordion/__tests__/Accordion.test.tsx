import * as React from "react";

import {vi} from "vitest";
import {render, screen} from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import {Accordion, AccordionItem} from "..";

test("renders a collapsed acordion", async () => {
    const {findByText, findByRole} = render(
        <Accordion>
            <AccordionItem
                id={1}
                title={{
                    primary: "Accordion 1 title",
                }}
            >
                Accordion 1 content
            </AccordionItem>
        </Accordion>,
    );

    expect(await findByText("Accordion 1 title")).toBeVisible();
    expect(await findByRole("button", {name: "Accordion 1 title"})).toHaveAttribute("aria-expanded", "false");
});

test("toggles an accordion on click", async () => {
    const user = userEvent.setup();

    const {findByText, findByRole} = render(
        <Accordion>
            <AccordionItem
                id={1}
                title={{
                    primary: "Accordion 1 title",
                }}
            >
                Accordion 1 content
            </AccordionItem>
        </Accordion>,
    );

    const button = screen.getByRole("button");

    await user.click(button);

    expect(await findByRole("button", {name: "Accordion 1 title"})).toHaveAttribute("aria-expanded", "true");
    expect(await findByText("Accordion 1 content")).toBeVisible();
});

test("api: expanded keys", async () => {
    const {findByRole} = render(
        <Accordion expandedKeys={[1]}>
            <AccordionItem
                id={1}
                title={{
                    primary: "Accordion 1 title",
                }}
            >
                Accordion 1 content
            </AccordionItem>
            <AccordionItem
                id={2}
                title={{
                    primary: "Accordion 2 title",
                }}
            >
                Accordion 2 content
            </AccordionItem>
        </Accordion>,
    );

    expect(await findByRole("button", {name: "Accordion 1 title"})).toHaveAttribute("aria-expanded", "true");
    expect(await findByRole("button", {name: "Accordion 2 title"})).toHaveAttribute("aria-expanded", "false");
});

test("api: disabled keys", async () => {
    const {findByRole} = render(
        <Accordion disabledKeys={[2]}>
            <AccordionItem
                id={1}
                title={{
                    primary: "Accordion 1 title",
                }}
            >
                Accordion 1 content
            </AccordionItem>
            <AccordionItem
                id={2}
                title={{
                    primary: "Accordion 2 title",
                }}
            >
                Accordion 2 content
            </AccordionItem>
        </Accordion>,
    );

    expect(await findByRole("button", {name: "Accordion 1 title"})).toBeEnabled();
    expect(await findByRole("button", {name: "Accordion 2 title"})).toBeDisabled();
});

test("api: onExpandedChange", async () => {
    const user = userEvent.setup();

    const listener = vi.fn();

    const {findByRole} = render(
        <Accordion onExpandedChange={listener}>
            <AccordionItem
                id={1}
                title={{
                    primary: "Accordion 1 title",
                }}
            >
                Accordion 1 content
            </AccordionItem>
            <AccordionItem
                id={2}
                title={{
                    primary: "Accordion 2 title",
                }}
            >
                Accordion 2 content
            </AccordionItem>
        </Accordion>,
    );

    const button = await findByRole("button", {name: "Accordion 2 title"});

    await user.click(button);

    expect(listener).toHaveBeenCalledWith(new Set([2]));
});
