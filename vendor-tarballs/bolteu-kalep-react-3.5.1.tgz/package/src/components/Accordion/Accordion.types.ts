import type {ListItemLayoutProps} from "@/components/ListItemLayout";
import type {SpacingValue} from "@/components/Typography";

export type AccordionProps = {
    /** The item keys that are expanded. */
    expandedKeys?: Array<React.Key>;
    /** The initial expanded keys in the collection (uncontrolled). */
    defaultExpandedKeys?: Array<React.Key>;
    /** Handler that is called when items are expanded or collapsed. */
    onExpandedChange?: (keys: Set<React.Key>) => void;
    /** The item keys that are disabled. These items cannot be selected, focused, or otherwise interacted with. */
    disabledKeys?: Array<React.Key>;
    /** Trailing (left) outer container padding.
     * @default 6 - (which equals to `1.5rem` == `24px`)
     */
    paddingStart?: SpacingValue;
    /** Trailing (right) outer container padding.
     * @default 6 - (which equals to `1.5rem` == `24px`)
     */
    paddingEnd?: SpacingValue;
    children: React.ReactNode | React.ReactNode[];
    /** Whether to show a separator at the bottom of AccordionItems.
     * @default true
     */
    showSeparator?: boolean;
    /**
     * Whether to allow only one item to be expanded at a time.
     * @default false
     */
    exclusive?: boolean;
};

export type AccordionItemProps = {
    /** The unique key for the item. */
    id: React.Key;
    /** Accordion header custom props */
    title: ListItemLayoutProps;
    /** Accordion body custom props */
    children: React.ReactNode | React.ReactNode[];
};

export type AccordionState = {
    expandedKeys: Map<React.Key, boolean>;
    disabledKeys: Map<React.Key, boolean>;
    showSeparator: boolean;
    exclusive: boolean;
};

export enum AccordionActionType {
    OPEN = "OPEN",
    CLOSE = "CLOSE",
    CHANGE_EXCLUSIVE = "CHANGE_EXCLUSIVE",
}

export type AccordionAction =
    | {
          type: AccordionActionType.OPEN;
          id: React.Key;
      }
    | {
          type: AccordionActionType.CLOSE;
          id: React.Key;
      }
    | {
          type: AccordionActionType.CHANGE_EXCLUSIVE;
          exclusive: boolean;
      };

export type AccordionContextType = {
    state: AccordionState;
    dispatch: React.Dispatch<AccordionAction>;
};

export type AccordionArrowProps = {
    isOpen?: boolean;
};
