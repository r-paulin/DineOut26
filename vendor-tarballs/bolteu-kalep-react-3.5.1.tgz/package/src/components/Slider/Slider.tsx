import * as React from "react";

import {useControlledValue, useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {SliderProps} from "./Slider.types";

const DEFAULT_MIN_VALUE = 0;
const DEFAULT_MAX_VALUE = 100;
const DEFAULT_STEP = 1;

const getInitialValue = (min: number, max: number, value?: number, defaultValue?: number) => {
    if (typeof value === "number") {
        return Math.min(Math.max(value, min), max);
    }

    if (typeof defaultValue === "number") {
        return Math.min(Math.max(defaultValue, min), max);
    }

    return min;
};

export function Slider(props: SliderProps) {
    const {
        value: controlledValue,
        defaultValue,
        min = DEFAULT_MIN_VALUE,
        max = DEFAULT_MAX_VALUE,
        step = DEFAULT_STEP,
        onChange: onChangeProp,
        disabled,
        label,
        minLabel,
        maxLabel,
        "aria-label": ariaLabel,
    } = props;

    const {value, onChange} = useControlledValue({
        isControlled: controlledValue !== undefined,
        defaultValue: getInitialValue(min, max, controlledValue, defaultValue),
        onChange: onChangeProp,
        controlledValue,
    });

    const generatedId = useId();
    const [isTooltipShown, setIsTooltipShown] = React.useState(false);

    const percentage = Number.isNaN(value) ? 0 : ((Number(value) - min) * 100) / (max - min);
    const backgroundSize = disabled ? "100% 100%" : `${percentage}% 100%`;

    const handleMouseEnter = React.useCallback(() => {
        if (!disabled) {
            setIsTooltipShown(true);
        }
    }, [disabled]);

    const handleMouseLeave = React.useCallback(() => {
        setIsTooltipShown(false);
    }, []);

    return (
        <label htmlFor={generatedId}>
            <span className={cx("bolt-font-body-s-accent text-primary")}>{label}</span>
            <div className={cx("flex w-full items-center gap-4 py-2")}>
                <div
                    className={cx(
                        "shrink-0",
                        (typeof minLabel === "number" || typeof minLabel === "string") &&
                            "bolt-font-body-m-regular text-secondary",
                    )}
                >
                    {minLabel}
                </div>
                <div className={cx("h-7 w-full")}>
                    <div className={cx("relative mx-3 h-0")}>
                        <div
                            className={cx(
                                `
                                  bolt-font-body-s-regular absolute rounded-sm bg-neutral-primary p-2 text-center
                                  text-primary-inverted
                                `,
                                "min-w-10 -translate-x-2/4 -translate-y-11",
                                isTooltipShown ? "block" : "hidden",
                            )}
                            style={{left: `${percentage}%`}}
                        >
                            {value}
                            <span
                                className={cx(
                                    `
                                      absolute left-1/2 top-full -ml-[6px] h-0 w-0 rotate-180 border-x-[6px]
                                      border-b-[6px] border-t-0 border-solid border-x-transparent
                                      border-b-[var(--color-bg-neutral-primary)]
                                    `,
                                )}
                            />
                        </div>
                    </div>
                    <input
                        type="range"
                        id={generatedId}
                        min={min}
                        max={max}
                        step={step}
                        value={value}
                        disabled={disabled}
                        onChange={onChange}
                        onMouseEnter={handleMouseEnter}
                        onMouseLeave={handleMouseLeave}
                        className={cx(
                            "kalep-slider",
                            "m-0 h-1 w-full appearance-none rounded-full",
                            disabled
                                ? "cursor-not-allowed bg-special-disabled"
                                : // Gradient is used to indicate filled part of the slider bar while bg is the non-filled part
                                  `
                                    cursor-pointer bg-neutral-secondary-hard bg-gradient-to-l
                                    from-[var(--color-bg-action-primary)] to-[var(--color-bg-action-primary)]
                                    bg-no-repeat
                                  `,

                            // Arbitrary variants used to target range input internals, see https://tailwindcss.com/docs/hover-focus-and-other-states#using-arbitrary-variants
                            "slider-thumb:appearance-none slider-thumb:bg-static-key-light",
                            "slider-thumb:h-6 slider-thumb:w-6",
                            "slider-thumb:border-4 slider-thumb:border-solid slider-thumb:border-action-primary",
                            "slider-thumb:box-border slider-thumb:rounded-full slider-thumb:shadow-md",
                            "slider-thumb:disabled:border-separator slider-thumb:disabled:shadow-none",
                            `
                              slider-track:appearance-none slider-track:border-none slider-track:bg-transparent
                              slider-track:shadow-none
                            `,
                        )}
                        style={{backgroundSize}}
                        aria-label={label ? undefined : ariaLabel}
                        aria-valuemin={min}
                        aria-valuemax={max}
                        aria-valuenow={value}
                    />
                </div>
                <div
                    className={cx(
                        "shrink-0",
                        (typeof maxLabel === "number" || typeof maxLabel === "string") &&
                            "bolt-font-body-m-regular text-secondary",
                    )}
                >
                    {maxLabel}
                </div>
            </div>
        </label>
    );
}
