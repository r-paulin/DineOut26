import * as React from "react";

import type {Meta, StoryFn} from "@storybook/react-webpack5";

import Lights from "@bolteu/kalep-react-icons/dist/Lights";
import LightsOutlined from "@bolteu/kalep-react-icons/dist/LightsOutlined";

import {cx} from "@/helpers/utils/cx";

import {Slider} from "./Slider";

export default {
    title: "Inputs/Slider",
    component: Slider,
    tags: ["autodocs"],
} as Meta<typeof Slider>;

const Template: StoryFn<typeof Slider> = (args) => (
    <div className="w-80">
        <Slider {...args} />
    </div>
);

export const Default = Template.bind({});
Default.args = {defaultValue: 30, minLabel: 0, maxLabel: 100, label: "Adjust lights"};

export const Discrete = Template.bind({});
Discrete.args = {defaultValue: 30, minLabel: 0, maxLabel: 100, step: 10, label: "Adjust lights"};

export const NonIntegerValues = Template.bind({});
NonIntegerValues.args = {
    defaultValue: 0.3,
    min: 0,
    max: 1,
    minLabel: 0,
    maxLabel: 1,
    step: 0.1,
    label: "Adjust lights",
};

export const Disabled = Template.bind({});
Disabled.args = {defaultValue: 30, minLabel: 0, maxLabel: 100, disabled: true, label: "Adjust lights"};

export const CustomLabels = Template.bind({});
CustomLabels.args = {
    defaultValue: 30,
    minLabel: <LightsOutlined className={cx("text-primary")} size="lg" />,
    maxLabel: <Lights className={cx("text-primary")} size="lg" />,
    label: "Adjust lights",
};

export const Controlled = () => {
    const [value, setValue] = React.useState<number>(30);

    const handleChange = React.useCallback<React.ChangeEventHandler<HTMLInputElement>>((e) => {
        setValue(e.target.valueAsNumber);
    }, []);

    return (
        <div className="w-80">
            <Slider value={value} minLabel={0} maxLabel={100} onChange={handleChange} label="Adjust lights" />
        </div>
    );
};
