import * as React from "react";

import {Drawer} from "vaul";

import {Cross} from "@bolteu/kalep-react-icons";

import {cx} from "@/helpers/utils/cx";

import type {BottomSheetProps} from ".";
import {IconButton} from "../IconButton";

export const KALEP_BOTTOMSHEET_CONTENT_ID = "kalep__bottom-sheet-content"; // TODO: Not the best solution, but works until we find a better one - https://taxify.slack.com/archives/C049ZD40C1Y/p1738321322242899

export function BottomSheet({
    children,
    isOpen,
    onOpenChange,
    onAnimationChange,
    isDismissible = true,
    hasOverlay = true,
    hasHandle = true,
    hasCloseButton,
    snapPoints,
    container,
}: BottomSheetProps) {
    const handleCloseButtonClick = React.useCallback(() => {
        onOpenChange(false);
    }, [onOpenChange]);

    return (
        <Drawer.Root
            open={isOpen}
            onOpenChange={onOpenChange}
            onAnimationEnd={onAnimationChange}
            dismissible={isDismissible}
            fadeFromIndex={0}
            container={container}
            repositionInputs={false}
            snapPoints={snapPoints ?? []}
        >
            <Drawer.Portal>
                {hasOverlay && <Drawer.Overlay className={cx("fixed inset-0 z-modalOverlay bg-special-scrim")} />}
                <Drawer.Content
                    className={cx(
                        "fixed bottom-0 left-0 right-0 z-modal",
                        "rounded-t-lg bg-layer-floor-1 outline-none",
                        "max-h-[97vh]",
                        Array.isArray(snapPoints) ? "h-full" : "h-fit",
                    )}
                >
                    {hasCloseButton && (
                        <Drawer.Close asChild>
                            <IconButton
                                variant="secondary"
                                icon={<Cross />}
                                aria-label="Close" // TODO: Add proper localisation
                                onClick={handleCloseButtonClick}
                                overrideClassName={cx(`
                                  absolute right-2 top-2
                                  rtl:left-2 rtl:right-auto
                                `)}
                                size="sm"
                            />
                        </Drawer.Close>
                    )}
                    {hasHandle && <Drawer.Handle className={cx("my-2 !bg-neutral-secondary-hard")} />}
                    <div className={cx("flex flex-col")} style={{maxHeight: "inherit", height: "inherit"}}>
                        <div
                            id={KALEP_BOTTOMSHEET_CONTENT_ID}
                            className={cx("flex-1 overflow-y-auto")}
                            style={{maxHeight: "inherit", height: "inherit"}}
                        >
                            {children}
                        </div>
                    </div>
                </Drawer.Content>
            </Drawer.Portal>
        </Drawer.Root>
    );
}
