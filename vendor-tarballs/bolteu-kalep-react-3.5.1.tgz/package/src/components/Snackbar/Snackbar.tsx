import * as React from "react";

import {toast} from "sonner";

import Cross from "@bolteu/kalep-react-icons/dist/Cross";

import {GhostButton} from "@/components/GhostButton";
import {IconButton} from "@/components/IconButton";
import {useId} from "@/helpers";
import {cx} from "@/helpers/utils/cx";

import type {SnackbarProps} from "./Snackbar.types";

export function Snackbar({id, content}: SnackbarProps) {
    const {title, description, actions, dismissible} = content;
    const rootId = useId();
    const titleId = `${rootId}-title`;
    const descriptionId = `${rootId}-description`;

    const dismiss = React.useCallback(() => {
        toast.dismiss(id);
    }, [id]);

    if (!description) {
        return null;
    }

    const actionButtons = actions?.length
        ? actions.map((action) => {
              return (
                  <GhostButton
                      key={action.label}
                      overrideClassName="flex-shrink-0 font-semibold text-action-primary-inverted"
                      onClick={() => {
                          action.onClick();
                          dismiss();
                      }}
                  >
                      {action.label}
                  </GhostButton>
              );
          })
        : null;

    const hasCloseButton = actionButtons ? false : (dismissible ?? true);

    return (
        <div
            role="alertdialog"
            aria-labelledby={titleId}
            aria-describedby={descriptionId}
            className={cx(
                "flex w-full items-center gap-4 px-4 py-3",
                "rounded-md bg-neutral-primary",
                "bolt-font-body-s-regular text-primary-inverted",
                "min-w-60",
            )}
        >
            <div className={cx("flex w-full flex-row flex-wrap gap-3")}>
                <div>
                    {title ? (
                        <div id={titleId} className={cx("mb-1 font-semibold")}>
                            {title}
                        </div>
                    ) : null}
                    <div id={descriptionId}>{description}</div>
                </div>
                {actionButtons ? (
                    <div className={cx("ml-auto flex items-center")}>
                        <div className={cx("flex w-full justify-end gap-6")}>{actionButtons}</div>
                    </div>
                ) : null}
            </div>

            {hasCloseButton ? (
                <IconButton
                    data-testid="snackbar-close-button"
                    overrideClassName="text-primary-inverted w-6 h-6"
                    size="sm"
                    aria-label="Close"
                    onClick={dismiss}
                    icon={<Cross size="sm" />}
                />
            ) : null}
        </div>
    );
}
