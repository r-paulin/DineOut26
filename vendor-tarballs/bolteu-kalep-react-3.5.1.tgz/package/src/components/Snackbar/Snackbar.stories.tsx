import * as React from "react";

import type {Meta, StoryObj} from "@storybook/react-webpack5";

import {Button} from "@/components/Button";
import {cx} from "@/helpers/utils/cx";

import {SnackbarProvider, useSnackbar} from "./index";

const meta: Meta<typeof SnackbarProvider> = {
    component: SnackbarProvider,
    title: "Feedback/Snackbar",
    tags: ["autodocs"],
    argTypes: {
        placement: {
            control: "select",
            options: ["bottom-left", "bottom-right", "bottom-center", "top-left", "top-right", "top-center"],
        },
        maxVisibleSnackbars: {
            control: "number",
        },
    },
    args: {
        placement: "bottom-left",
        maxVisibleSnackbars: 3,
        expand: false,
    },
};

export default meta;
type Story = StoryObj<typeof SnackbarProvider>;

interface SnackbarChildProps {
    title?: string;
    description?: string;
    actions?: {label: string; onClick: () => void}[];
    dismissible?: boolean;
    timeout?: number;
}

const SnackbarChild = ({
    title,
    description = "This is a snackbar",
    actions,
    dismissible,
    timeout,
}: SnackbarChildProps) => {
    const snackbar = useSnackbar();

    return (
        <div className={cx("flex min-h-48 gap-2")}>
            <Button onClick={() => snackbar.add({description, title, actions, dismissible, timeout})}>
                Show Snackbar
            </Button>
        </div>
    );
};

const defaultCode = `
// App.tsx or some other root application file
import {SnackbarProvider} from "@bolteu/kalep-react";

return (
    <SnackbarProvider maxVisibleSnackbars={3} placement="bottom-left">
        <App />
    </SnackbarProvider>
);

// YourPage.tsx or any component in your app that is wrapped inside <SnackbarProvider />
import {useSnackbar} from "@bolteu/kalep-react";

const snackbar = useSnackbar();

return (
    <Button onClick={
        () => {
            snackbar.add({
                description: "This is a snackbar",
            });
        }}
    >
        Show message
    </Button>
);
`;

export const Default: Story = {
    render: (args) => (
        <SnackbarProvider {...args}>
            <SnackbarChild />
        </SnackbarProvider>
    ),
    parameters: {
        docs: {
            source: {
                code: defaultCode,
            },
            description: {
                story: "Use the `useSnackbar` hook to access the `Snackbar` context and call `add` or `remove` to create or remove Snackbars.",
            },
        },
    },
};

const actionsCode = `
// App.tsx or some other root application file
import {SnackbarProvider} from "@bolteu/kalep-react";

return (
    <SnackbarProvider>
        <App />
    </SnackbarProvider>
);

// YourPage.tsx or any component in your app that is wrapped inside <SnackbarProvider />
import {useSnackbar} from "@bolteu/kalep-react";

const snackbar = useSnackbar();

return (
    <Button onClick={
        () => {
            snackbar.add({
                description: "This is a snackbar with actions",
                actions: [{label: "Got it", onClick: () => {}}], // Action click closes the Snackbar automatically
            });
        }}
    >
        Show message
    </Button>
);
`;

export const Actions: Story = {
    render: (args) => (
        <SnackbarProvider {...args}>
            <SnackbarChild
                description="This is a snackbar with actions"
                actions={[{label: "Got it", onClick: () => {}}]}
            />
        </SnackbarProvider>
    ),
    parameters: {
        docs: {
            source: {
                code: actionsCode,
            },
            description: {
                story: "By default, there is a close button rendered to remove the Snackbar, but you can provide your own actions instead. You can add as many actions as you like, but it is best to not use more than two.",
            },
        },
    },
};

const anatomyCode = `
// App.tsx or some other root application file
import {SnackbarProvider} from "@bolteu/kalep-react";

return (
    <SnackbarProvider>
        <App />
    </SnackbarProvider>
);

// YourPage.tsx or any component in your app that is wrapped inside <SnackbarProvider />
import {useSnackbar} from "@bolteu/kalep-react";

const snackbar = useSnackbar();

return (
    <Button onClick={
        () => {
            snackbar.add({
                title: "This is snackbar title (optional)",
                description: "This is snackbar description (required) and it is very long so it spans on multiple lines",
                actions: [
                    {label: "Tell me more", onClick: () => {}},
                    {label: "Gotcha", onClick: () => {}},
                ],
            });
        }}
    >
        Show message
    </Button>
);
`;

export const Anatomy: Story = {
    render: (args) => (
        <SnackbarProvider {...args}>
            <SnackbarChild
                title="This is snackbar title (optional)"
                description="This is snackbar description (required) and it is very long so it spans on multiple lines"
                actions={[
                    {label: "Tell me more", onClick: () => {}},
                    {label: "Gotcha", onClick: () => {}},
                ]}
            />
        </SnackbarProvider>
    ),
    parameters: {
        docs: {
            source: {
                code: anatomyCode,
            },
            description: {
                story: "Snackbar can also have a `title` and longer `description` which modifies action placement.",
            },
        },
    },
};

const autoDismissCode = `
// App.tsx or some other root application file
import {SnackbarProvider} from "@bolteu/kalep-react";

return (
    <SnackbarProvider>
        <App />
    </SnackbarProvider>
);

// YourPage.tsx or any component in your app that is wrapped inside <SnackbarProvider />
import {useSnackbar} from "@bolteu/kalep-react";

const snackbar = useSnackbar();

return (
    <Button onClick={
        () => {
            snackbar.add({
                description: "This is a snackbar which disappears after 5 seconds",
                timeout: 5000,
            });
        }}
    >
        Show message
    </Button>
);
`;

export const Autodismiss: Story = {
    render: (args) => (
        <SnackbarProvider {...args}>
            <SnackbarChild description="This is a snackbar which disappears after 5 seconds" timeout={5000} />
        </SnackbarProvider>
    ),
    parameters: {
        docs: {
            source: {
                code: autoDismissCode,
            },
            description: {
                story: "Use the `timeout` (ms) property to control how long the auto-dismissable Snackbar is presented. Anything less than 5 seconds is questionable from readability (and usability) perspective. Ideally, do not auto-hide Snackbars and allow users to dismiss them whenever they've managed to read the contents.",
            },
        },
    },
};
