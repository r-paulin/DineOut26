import * as React from "react";

import {render, screen} from "@testing-library/react";

import {ProgressBar} from "../index";

describe("ProgressBar test suite", () => {
    test("renders partially completed determinate progress bar", () => {
        const value = 40;
        const caption = "40% complete";

        render(<ProgressBar value={value} caption={caption} />);

        const progressBar = screen.getByRole("progressbar", {name: caption});

        expect(progressBar).toHaveAttribute("aria-valuenow", `${value}`);
        expect(progressBar).toHaveAttribute("aria-busy", "true");
        expect(progressBar).toHaveAttribute("aria-valuemin", "0");
        expect(progressBar).toHaveAttribute("aria-valuemax", "100");
        expect(progressBar?.firstChild).toHaveClass("animate-pulse");
        expect(screen.getByText(caption)).toBeInTheDocument();
    });

    test("renders completed determinate progress bar", () => {
        const value = 100;
        const caption = "Done";

        render(<ProgressBar value={value} caption={caption} />);

        const progressBar = screen.getByRole("progressbar", {name: caption});

        expect(progressBar).toHaveAttribute("aria-valuenow", `${value}`);
        expect(progressBar).toHaveAttribute("aria-busy", "false");
        expect(progressBar?.getElementsByClassName("animate-pulse").length).toBe(0);
        expect(screen.getByText(caption)).toBeInTheDocument();
    });

    test("renders running indeterminate progress bar", () => {
        render(<ProgressBar isIndeterminate />);

        const progressBar = screen.getByRole("progressbar");

        expect(progressBar).toHaveAttribute("aria-valuenow", "0");
        expect(progressBar).toHaveAttribute("aria-busy", "true");
        expect(progressBar?.firstChild).toHaveClass("animate-indeterminateProgress");
    });

    test("renders completed indeterminate progress bar", () => {
        const value = 100;

        render(<ProgressBar isIndeterminate value={value} />);

        const progressBar = screen.getByRole("progressbar");

        expect(progressBar).toHaveAttribute("aria-valuenow", `${value}`);
        expect(progressBar).toHaveAttribute("aria-busy", "false");
        expect(progressBar?.firstChild).not.toHaveClass("animate-indeterminateProgress");
    });
});
