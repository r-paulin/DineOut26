import type * as React from "react";

export interface ProgressBarProps {
    isIndeterminate?: boolean;
    value?: number; // The value of progress indicator. Value between 0 and 100 for the determinate variant, 100 to indicate that the indeterminate progress is complete.
    caption?: React.ReactNode;
    "aria-labelledby"?: string;
    "aria-label"?: string;
    "aria-describedby"?: string;
    "aria-details"?: string;
}
