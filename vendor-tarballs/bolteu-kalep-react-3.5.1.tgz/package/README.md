<div align="center">

# Kalep React

A set of React components that implement Kalep Design System.
<br />

[Storybook](https://kalep.uip.boltint.net/@bolteu/kalep-react/index.html?path=/story/welcome--page) •
[Figma](https://www.figma.com/file/nU1QBYZxTAYsIZ4X0jW4tV/%F0%9F%8C%88-Kalep-Semantic-Components?node-id=1%3A3&t=S3z9WzzlCfQ882DO-1) •
[Support](https://taxify.slack.com/archives/C034P1EFKDF)

<img width="150" src="../../assets/kalep-logo.png">
</div>

## Getting started

### Peer dependencies

-   [`react`](https://www.npmjs.com/package/react)
-   [`react-dom`](https://www.npmjs.com/package/react-dom)

### Installation

#### Components

Install Kalep React package:

**npm**

```
npm install @bolteu/kalep-react
```

**yarn**

```
yarn add @bolteu/kalep-react
```

#### Fonts

Kalep React uses the [Inter](https://rsms.me/inter/) font (specifically `InterVariable`).
The available font styles are described [in Figma](https://www.figma.com/design/gM8bsTnkACiIWiuAsFTdyI/UI-Foundation---Fonts?node-id=9131-1&t=6IFefnELCtc0muX9-0).

Kalep React does not include Inter font itself, it references a font face named "InterVariable". Starting from november 2024 we host Inter font files in our static assets S3 bucket that has compression enabled and should be the go-to place to include Inter to your project. Inter is still hosted in Google Fonts CDN and rsms.me which can be used as fallbacks if necessary.

Including Inter to your project:

```HTML
<!-- Add to your main HTML file -->
<link rel="stylesheet" href="https://static.bolt.eu/fonts/inter/inter.css">
```

```CSS
/* Add to your main CSS file */
:root {
  font-family: Inter, sans-serif;
  font-feature-settings: 'liga' 1, 'calt' 1; /* fix for Chrome */
}
@supports (font-variation-settings: normal) {
  :root { font-family: InterVariable, sans-serif; }
}
```

#### Including CSS for components

Just add the prebuilt CSS file to your app entry file:

```typescript
require("@bolteu/kalep-react/build/kalep-versioned.css"); // or import, whichever way your build system works.
```

#### Usage

Use components as you would from any other component library:

```tsx
import {Button} from "@bolteu/kalep-react";

/* ... */

<Button size="sm" type="submit">
    Click me
</Button>;
```

## Contributing

Thank you for your desire to contribute to Kalep! Read our [Kalep Contribution Guide](https://github.com/bolteu/kalep/blob/main/CONTRIBUTING.md) for a better overview of the repository contribution process.

For Kalep React specific contributing information, check the [Kalep React Contribution Guide](https://github.com/bolteu/kalep/blob/main/packages/kalep-react/CONTRIBUTING.md)

---
