import StyleDictionary from "style-dictionary";
import glob from "fast-glob";
import prettier from "@prettier/sync";

import {
  filterPrimitivePaletteColor,
  filterSemanticColor,
  filterStaticColor,
  filterSemanticTypography,
  filterDimensionLike,
} from "../utils/filters.mjs";

const SD = new StyleDictionary();
await SD.registerFormat({
  name: "custom/js",
  format: createDictionaryToJSFormatter,
});
await SD.registerFormat({
  name: "custom/js-fonts",
  format: createFontsJSFormatter,
});
await SD.hasInitialized;

// NB! "light" set includes static color tokens
const defaultTokens = {
  light: ["src/Default/Primitives/**/*.json", "src/Default/{Semantic,Components}/**/!(dark.)*.json"],
  dark: ["src/Default/Primitives/**/*.json", "src/Default/{Semantic,Components}/**/dark.*tokens.json"],
};

const jsTransforms = ["name/pascal", "custom/value/nestedRgbaForTransparency"];

export async function generate(options = {}) {
  if (!options.outputFolder) {
    throw new Error("Provide outputFolder");
  }

  const resolvedDefaultTokens = options.defaultTokens ?? defaultTokens;

  const sources = {primitives: [], light: [], dark: []};

  if (options.product) {
    const primitiveTokenFiles = await glob(`src/Products/${options.product}/Primitives/**/*.tokens.json`);
    const otherTokenFiles = await glob(`src/Products/${options.product}/{Semantic,Components}/**/*.tokens.json`);

    sources.primitives.push(...primitiveTokenFiles);

    otherTokenFiles.forEach((file) => {
      if (file.includes("dark.")) {
        sources.dark.push(file);
      } else {
        sources.light.push(file);
      }
    });
  }

  // Build base set, including light mode
  const jsBaseGenerator = await SD.extend({
    include: resolvedDefaultTokens.light.concat(sources.primitives),
    source: sources.light,
    platforms: {
      js: {
        transforms: jsTransforms,
        buildPath: `dist/js/${options.outputFolder}/`,
        files: [
          {
            filter: filterDimensionLike,
            destination: "Dimensions.js",
            format: "custom/js",
            options: {
              exportName: "tokens",
            },
          },
          {
            filter: filterPrimitivePaletteColor,
            destination: "CoreColors.js",
            format: "custom/js",
            options: {
              exportName: "colors",
            },
          },
          {
            filter: (token) => token.path[0] === "map" && token.type === "color",
            destination: "SemanticLightColors-Maps.js",
            format: "custom/js",
            options: {
              exportName: "colors",
            },
          },
          {
            filter: (token) => filterSemanticColor(token) && !filterStaticColor(token),
            destination: "SemanticLightColors.js",
            format: "custom/js",
            options: {
              exportName: "colors",
            },
          },
          {
            filter: filterStaticColor,
            destination: "SemanticStaticColors.js",
            format: "custom/js",
            options: {
              exportName: "colors",
            },
          },
          {
            destination: "Fonts.js",
            format: "custom/js-fonts",
            filter: filterSemanticTypography,
            options: {
              outputReferences: true, // mis pidi see töötama peaks :/
              exportName: "tokens",
            },
          },
        ],
      },
    },
  });

  await jsBaseGenerator.cleanPlatform("js");
  await jsBaseGenerator.buildPlatform("js");

  // Build semantic dark mode overrides
  const jsDarkModeGenerator = await SD.extend({
    include: resolvedDefaultTokens.dark.concat(sources.primitives),
    source: sources.dark,
    platforms: {
      js: {
        transforms: jsTransforms,
        buildPath: `dist/js/${options.outputFolder}/`,
        files: [
          {
            filter: (token) => token.path[0] === "map" && token.type === "color",
            destination: "SemanticDarkColors-Maps.js",
            format: "custom/js",
            options: {
              exportName: "colors",
            },
          },
          {
            filter: filterSemanticColor,
            destination: "SemanticDarkColors.js",
            format: "custom/js",
            options: {
              exportName: "colors",
            },
          },
        ],
      },
    },
  });

  await jsDarkModeGenerator.cleanPlatform("js");
  await jsDarkModeGenerator.buildPlatform("js");

  if (options.themes) {
    for (const themeFolder of Object.values(options.themes)) {
      const themeSources = {primitives: [], light: [], dark: []};

      const primitiveTokenFiles = await glob(`src/Products/${themeFolder}/Primitives/**/*.tokens.json`);
      const otherTokenFiles = await glob(`src/Products/${themeFolder}/{Semantic,Components}/**/*.tokens.json`);

      themeSources.primitives.push(...primitiveTokenFiles);

      otherTokenFiles.forEach((file) => {
        if (file.includes("dark.")) {
          themeSources.dark.push(file);
        } else {
          themeSources.light.push(file);
        }
      });

      const themeBaseSetGenerator = await SD.extend({
        include: ["src/Default/Primitives/**/*.json", ...themeSources.primitives],
        source: themeSources.light,
        platforms: {
          js: {
            transforms: jsTransforms,
            buildPath: `dist/js/${options.outputFolder}/`,
            files: [
              {
                filter: (token) => filterSemanticColor(token) && !filterStaticColor(token),
                destination: `SemanticLightColors-${themeFolder}.js`,
                format: "custom/js",
                options: {
                  exportName: "colors",
                },
              },
              {
                filter: "custom/staticColor",
                destination: `SemanticStaticColors-${themeFolder}.js`,
                format: "custom/js",
                options: {
                  exportName: "colors",
                },
              },
            ],
          },
        },
      });

      await themeBaseSetGenerator.cleanPlatform("js");
      await themeBaseSetGenerator.buildPlatform("js");

      const themeDarkModeGenerator = await SD.extend({
        include: ["src/Default/Primitives/**/*.json", ...themeSources.primitives],
        source: themeSources.dark,
        platforms: {
          js: {
            transforms: jsTransforms,
            buildPath: `dist/js/${options.outputFolder}/`,
            files: [
              {
                filter: "custom/semanticColor",
                destination: `SemanticDarkColors-${themeFolder}.js`,
                format: "custom/js",
                options: {
                  exportName: "colors",
                },
              },
            ],
          },
        },
      });

      await themeDarkModeGenerator.buildPlatform("js");
    }
  }
}

function camelCase(str) {
  return str.replace(/-([0-9a-z])/g, (g) => g[1].toUpperCase());
}

function createDictionaryToJSFormatter({dictionary, options}) {
  function dictionaryToJS(token) {
    // unknown thing, just return it
    if (!token || typeof token !== "object") return token;

    // Object with "value" or "$value" is a design token
    if ("value" in token || "$value" in token) {
      let value = token.value ?? token.$value;

      if (options.outputReferences && dictionary.usesReference(token.original.value)) {
        const refs = dictionary.getReferences(token.original.value);
        value = token.original.value;

        refs.forEach((ref) => {
          if (Object.hasOwn(ref, "value") && Object.hasOwn(ref, "name")) {
            const replaceFunction = () => {
              // build correct reference from path
              return ref.path.map(camelCase).join(".");
            };

            // The references inside values are like this: {core.neutral.200} or {core.neutral.200.value}
            // which is the path to the token value. We get the same thing from the found referenced tokens
            // path by just joining it with dots.
            value = value.replace(new RegExp(`{${ref.path.join(".")}(.value)?}`, "g"), replaceFunction);
          }
        });
      }
      return value;
    }

    // It's a non-token object, go deeper.
    const next = {};

    for (const [prop, value] of Object.entries(token)) {
      next[camelCase(prop)] = dictionaryToJS(value);
    }

    return next;
  }

  const tokens = dictionaryToJS(dictionary.tokens);

  return prettier.format(`export const ${options.exportName} = ${JSON.stringify(tokens, null, 2)};`, {
    parser: "typescript",
    printWidth: 500,
  });
}

function createFontsJSFormatter({dictionary, options}) {
  function dictionaryToJS(token) {
    // unknown thing, just return it
    if (!token || typeof token !== "object") return token;

    // Object with "value" or "$value" is a design token
    if ("value" in token || "$value" in token) {
      let value = token.value ?? token.$value;

      // It is a percentage of the font size.
      // There can be a calculation (for tabular styles particularly). For now we assume
      // that only a simple addition can exist.
      if (value.letterSpacing && value.letterSpacing.includes("+")) {
        value.letterSpacing = value.letterSpacing
          .split("+")
          .map((v) => parseFloat(v))
          .reduce((acc, curr) => acc + curr, 0)
          .toFixed(3);
      }

      return value;
    }

    // It's a non-token object, go deeper.
    const next = {};

    for (const [prop, value] of Object.entries(token)) {
      next[camelCase(prop)] = dictionaryToJS(value);
    }

    return next;
  }

  const tokens = dictionaryToJS(dictionary.tokens);

  return prettier.format(`export const ${options.exportName} = ${JSON.stringify(tokens, null, 2)};`, {
    parser: "typescript",
    printWidth: 500,
  });
}
