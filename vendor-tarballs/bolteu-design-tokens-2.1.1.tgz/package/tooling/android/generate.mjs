import StyleDictionary from "style-dictionary";

const SD = new StyleDictionary();
await SD.hasInitialized;

export async function generate() {
  registerTransformsAndFormats();
  generateDimensions();
  generateSizes();
  generateTypography();
}

function registerTransformsAndFormats() {
  SD.registerFormat({
    name: "android/typographyResources",
    format: formatAndroidTypographyResources,
  });
  SD.registerTransform({
    name: "additiveTypography",
    type: "value",
    transitive: true,
    filter: (prop) =>
      prop.type === "typography" && prop.value && prop.value.letterSpacing && prop.value.letterSpacing.includes("+"),
    transform: function (prop) {
      prop.value.letterSpacing = prop.value.letterSpacing
        .split("+")
        .reduce((acc, val) => acc + parseFloat(val), 0)
        .toFixed(3);
      return prop.value;
    },
  });
  SD.registerTransform({
    // Alternative to 'size/remToDp', as that applies only to size, non-font tokens
    name: "remDimensionToDp",
    type: "value",
    transitive: true,
    filter: (prop) => prop.type === "dimension",
    transform: (prop) => `${+(parseFloat(prop.value) * 16).toFixed(2)}dp`,
  });
}

// region Typography
async function generateTypography() {
  await generateCoreTypography();
  await generateSemanticTypography();
}

async function generateCoreTypography() {
  const coreTypographyGenerator = await SD.extend({
    source: ["src/Default/Primitives/typography.tokens.json"],
    platforms: {
      android: {
        buildPath: `dist/android/Default/`,
        transforms: ["name/camel"],
        files: [
          {
            destination: "typography.xml",
            format: "android/typographyResources",
          },
        ],
      },
    },
  });
  await coreTypographyGenerator.buildPlatform("android");
}

async function generateSemanticTypography() {
  ["Rider", "Driver"].forEach(async (project) => {
    const generator = await SD.extend({
      include: ["src/Default/Primitives/typography.**.json", "src/Default/Semantic/Typography/typography.**.json"],
      source: ["src/Products/${project}App/Semantic/Typography/typography.**.json"],
      platforms: {
        android: {
          buildPath: `dist/android/${project}/`,
          transforms: ["name/camel", "additiveTypography"],
          files: [
            {
              destination: "typography.json",
              format: "json/flat",
              // Include only Semantic tokens, core tokens are delivered as Android resource xml
              filter: (token) => token.type === "typography" && !token.name.startsWith("core"),
            },
          ],
        },
      },
    });
    await generator.buildPlatform("android");
  });
}

function formatAndroidTypographyResources(dictionary, platform, options) {
  function tokenToType(token) {
    switch (token.type) {
      case "fontWeights":
        return "integer";
      case "fontSizes":
        return "dimen";
      case "letterSpacing":
        return "item";
    }
  }

  function tokenToValue(token) {
    switch (token.type) {
      case "fontSizes":
        return `${token.value}sp`;
      default:
        return token.value;
    }
  }

  function tokenToFormat(token) {
    switch (token.type) {
      case "letterSpacing":
        return ' format="float"';
      default:
        return "";
    }
  }

  function tokenToSecondaryType(token) {
    switch (token.type) {
      case "letterSpacing":
        return ' type="dimen"';
      default:
        return "";
    }
  }

  return `<?xml version="1.0" encoding="UTF-8"?>

<resources>
    ${dictionary.allTokens
      .map(
        (token) =>
          `<${tokenToType(token, options)} name="${token.name}"${tokenToFormat(token)}${tokenToSecondaryType(token)}>${tokenToValue(token)}</${tokenToType(token, options)}>`,
      )
      .join(`\n    `)}
</resources>`;
}

// endregion

// region Dimensions
async function generateDimensions() {
  const dimensionGenerator = await SD.extend({
    source: ["src/Default/Primitives/dimension.tokens.json"],
    platforms: {
      android: {
        buildPath: `dist/android/Default/`,
        transforms: ["name/camel", "remDimensionToDp"],
        files: [
          {
            destination: "dimensions.xml",
            format: "android/resources",
            options: {
              resourceType: "dimen",
              showFileHeader: false,
            },
          },
        ],
      },
    },
  });
  await dimensionGenerator.buildPlatform("android");
}

// endregion

// region Sizes

async function generateSizes() {
  ["Rider", "Driver"].forEach(async (project) => {
    const generator = await SD.extend({
      include: ["src/Default/Primitives/dimension.tokens.json", "src/Default/Semantic/Dimensions/sizes.tokens.json"],
      source: ["src/Products/${project}App/Semantic/Dimensions/sizes.tokens.json"],
      platforms: {
        android: {
          buildPath: `dist/android/${project}/`,
          transforms: ["name/camel", "remDimensionToDp"],
          files: [
            {
              destination: "sizes.xml",
              format: "android/resources",
              filter: (token) => token.type === "sizing" || token.type === "spacing",
              options: {
                resourceType: "dimen",
                showFileHeader: false,
              },
            },
          ],
        },
      },
    });
    await generator.buildPlatform("android");
  });
}

// endregion
