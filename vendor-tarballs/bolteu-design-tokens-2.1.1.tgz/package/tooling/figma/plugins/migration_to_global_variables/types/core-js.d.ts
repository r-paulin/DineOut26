declare module 'core-js/actual/structured-clone' {
    export default function structuredClone<T>(value: T): T;
}