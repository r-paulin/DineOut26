# Figma Plugin: Migration to Global Variables

This plugin is migrating references for variables to `Colors [Global]`. 

Published at https://www.figma.com/community/plugin/1582742411760399661

Currently it supports following migrations:

* All the simple properties like `width`, `height`.
* Fills with type SOLID
* Strokes with type SOLID
* TextNodes single fills and mixed fills

Does not support:

* Component Properties
* Layout Grids
* Effects
* Non TextNodes with mixed fills


## Development

* Checkout this repository
* Navigate to plugin's folder: `cd tooling/figma/plugins/migration_to_global_variables`
* Install dependencies: `pnpm i`
* Run local build in watch mode: `pnpm watch`

https://www.figma.com/plugin-docs/plugin-quickstart-guide/
