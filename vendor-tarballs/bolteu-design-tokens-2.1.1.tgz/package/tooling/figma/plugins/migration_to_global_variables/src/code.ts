// This plugin will open a tab that indicates that it will monitor the current
// selection on the page. It cannot change the document itself.

// This file holds the main code for plugins. Code in this file has access to
// the *figma document* via the figma global object.
// You can access browser APIs in the <script> tag inside "ui.html" which has a
// full browser environment (See https://www.figma.com/plugin-docs/how-plugins-run).
import structuredClone from "core-js/actual/structured-clone";
import {MigrationStatistics, MigrationStatisticsBindableVariableType} from "./utils/migration-statistics";
import { MigrationContext } from "./utils/migration-context";

interface ActionBase {
    type: string;
}

interface MigrateWholeDocumentAction extends ActionBase {
    type: "migrate-whole-document";
}

interface MigrateCurrentPageAction extends ActionBase {
    type: "migrate-current-page";
}

interface MigrateSeletionAction extends ActionBase {
    type: "migrate-selection";
}

interface JumpToNodeAction extends ActionBase {
    type: "jump-to-node";
    node_id: string;
}

interface SetSkipInvisibleElementsAction extends ActionBase {
    type: "set-skip-invisible-elements";
    value: boolean;
}

type ActionMessage = {
    action: MigrateWholeDocumentAction | MigrateCurrentPageAction | MigrateSeletionAction | JumpToNodeAction | SetSkipInvisibleElementsAction;
};
type MessageTypes = ActionMessage;

type ColorsGlobalVariablesMapByNameAndType = Map<string, LibraryVariable>;

type UpdateNodeVariablesForTypeMigrationStatisticsMetadata = {
    node_id: string;
    type: MigrationStatisticsBindableVariableType;
};

console.clear();

const migrationContext = new MigrationContext();

// This shows the HTML page in "ui.html".
figma.showUI(__html__, {width: 700, height: 600});

// Useful to get specific ID in for development to test things on single node.
figma.on("selectionchange", () => {
    migrationContext.setSelectedNodes(figma.currentPage.selection);
    figma.ui.postMessage({enable_selection_migration: figma.currentPage.selection.length > 0});
    console.log("Selection changed", figma.currentPage.selection);
});

figma.ui.onmessage = async (msg: MessageTypes) => {
    console.log("postMessage :: ui -> backend", msg);
    if ("action" in msg) {
        switch (msg.action.type) {
            case "migrate-whole-document":
                await reportToProgressLog(`Migrating whole document with ${figma.root.children.length} pages.`);
                for (const page of figma.root.children) {
                    await startPageMigration(page);
                }
                break;
            case "migrate-current-page":
                await startPageMigration(figma.currentPage);
                break;
            case "migrate-selection":
                await startSelectionMigration();
                break;
            case "jump-to-node":
                const node = await figma.getNodeByIdAsync(msg.action.node_id);
                if (node) {
                    figma.currentPage.selection = [node as SceneNode];
                    figma.viewport.scrollAndZoomIntoView([node as SceneNode]);
                }
                break;
            case "set-skip-invisible-elements":
                figma.skipInvisibleInstanceChildren = msg.action.value;
                break; 
        }
    }
};

figma.on("run", async () => {
    figma.ui.postMessage({page: figma.currentPage.name});
});

figma.on("currentpagechange", async () => {
    figma.ui.postMessage({page: figma.currentPage.name});
});

async function reportToProgressLog(message: string) {
    figma.ui.postMessage({
        progress: new Date().toISOString() + " :: " + message,
    });
    await new Promise((resolve) => setTimeout(resolve, 25));
}

async function startPageMigration(page: PageNode): Promise<void> {
    figma.ui.postMessage({is_migration_in_progress: true});

    await reportToProgressLog(`Migrating page: "${page.name}"`);
    await page.loadAsync();
    await reportToProgressLog(`Figma will be unresponsive for a moment ⏳🚧`);
    const nodes: SceneNode[] = await page.findAll((node) => {
        return filterSceneNodesWithBoundVariables(node);
    });

    await reportToProgressLog(`Found ${nodes.length} nodes with bound variables on page: "${page.name}"`);
    await reportToProgressLog(`Starting migration of page: "${page.name}"`);

    const migrationStatistics = await migrateVariablesToGlobalVariables(nodes);

    await reportToProgressLog(`Finished migrating page: "${page.name}"`);
    figma.ui.postMessage({
        migration_statistics: {page_name: page.name, statistics: migrationStatistics.getStatistics()},
    });
    figma.ui.postMessage({is_migration_in_progress: false});
}

async function startSelectionMigration(): Promise<void> {
    figma.ui.postMessage({is_migration_in_progress: true});

    await reportToProgressLog(`Starting migration of selected nodes.`);
    await reportToProgressLog(`Figma will be unresponsive for a moment ⏳🚧`);

    const selectedNodes = migrationContext.getSelectedNodesAsFlatArray().filter(filterSceneNodesWithBoundVariables);

    await reportToProgressLog(`Found ${selectedNodes.length} selected nodes with bound variables.`);

    const migrationStatistics = await migrateVariablesToGlobalVariables(selectedNodes);

    await reportToProgressLog(`Finished migrating selected nodes.`);
    figma.ui.postMessage({
        migration_statistics: {page_name: figma.currentPage.name, statistics: migrationStatistics.getStatistics()},
    });
    figma.ui.postMessage({is_migration_in_progress: false});
}

function filterSceneNodesWithBoundVariables(node: SceneNode): boolean {
    return Object.keys(node.boundVariables ?? {}).length > 0;
}

async function migrateVariablesToGlobalVariables(nodes: SceneNode[]): Promise<MigrationStatistics> {
    const globalVariablesMapByNameAndType = await loadAllGlobalVariablesMapByNameAndType();
    const migrationStatistics = new MigrationStatistics();

    for (const node of nodes) {
        if ("fills" in node) {
            const migrationStatisticsMetadata: UpdateNodeVariablesForTypeMigrationStatisticsMetadata = {
                node_id: node.id,
                type: "fills",
            };
            if (node.type === "TEXT") {
                if (node.fills === figma.mixed) {
                    const segments = node.getStyledTextSegments(["fills"]);
                    for (const segment of segments) {
                        const newFillsResult = await updateNodeVariablesForType(
                            segment.fills,
                            "Fill",
                            globalVariablesMapByNameAndType,
                            migrationStatistics,
                            {
                                ...migrationStatisticsMetadata,
                                type: "textRangeFills",
                            },
                        );
                        if (newFillsResult.updated) {
                            node.setRangeFills(segment.start, segment.end, newFillsResult.paints);
                        }
                    }
                } else {
                    const fillsResult = await updateNodeVariablesForType(
                        node.fills,
                        "Fill",
                        globalVariablesMapByNameAndType,
                        migrationStatistics,
                        migrationStatisticsMetadata,
                    );
                    if (fillsResult.updated) {
                        node.fills = fillsResult.paints;
                    }
                }
            } else {
                if (node.fills === figma.mixed) {
                    console.warn("Mixed fills, skipping", node.name, node.id, node);
                    migrationStatistics.addToUnsupported(migrationStatisticsMetadata);
                } else {
                    const fillsResult = await updateNodeVariablesForType(
                        node.fills,
                        "Fill",
                        globalVariablesMapByNameAndType,
                        migrationStatistics,
                        migrationStatisticsMetadata,
                    );
                    if (fillsResult.updated) {
                        node.fills = fillsResult.paints;
                    }
                }
            }
        }

        if ("strokes" in node) {
            const migrationStatisticsMetadata: UpdateNodeVariablesForTypeMigrationStatisticsMetadata = {
                node_id: node.id,
                type: "strokes",
            };
            const strokesResult = await updateNodeVariablesForType(
                node.strokes,
                "Stroke",
                globalVariablesMapByNameAndType,
                migrationStatistics,
                migrationStatisticsMetadata,
            );
            if (strokesResult.updated) {
                node.strokes = strokesResult.paints;
            }
        }

        const boundVars = node.boundVariables;
        for (const varType in boundVars) {
            const type = varType as keyof typeof boundVars;
            const variableAliases = boundVars[type];

            if (Array.isArray(variableAliases)) {
                for (const _ of variableAliases) {
                    migrationStatistics.addToTotal({
                        type,
                        node_id: node.id,
                    });
                }
            } else if (variableAliases) {
                migrationStatistics.addToTotal({
                    type,
                    node_id: node.id,
                });
            }

            // We are ignoring those here because we handled them separately above
            if (
                type === "fills" ||
                type === "strokes" ||
                type === "effects" ||
                type === "layoutGrids" ||
                type === "textRangeFills"
            ) {
                if (type === "effects" || type === "layoutGrids") {
                    migrationStatistics.addToUnsupported({
                        type,
                        node_id: node.id,
                    });
                }
                continue;
            }

            if (boundVars.componentProperties) {
                console.warn("Unsupported component properties bound variables for type", type);
                migrationStatistics.addToUnsupported({
                    type,
                    node_id: node.id,
                });
                continue;
            }

            if (!variableAliases) {
                console.warn("No variable aliases found for type", type);
                migrationStatistics.addToTechnicalError({
                    type,
                    node_id: node.id,
                    technical_error_reason: "Variable is not present in boundVariables",
                });
                continue;
            }

            if (Array.isArray(variableAliases)) {
                console.warn("Unsupported array of variable aliases for type", type);
                migrationStatistics.addToUnsupported({
                    type,
                    node_id: node.id,
                });
                continue;
            }
            let variableId = variableAliases.id;

            // TODO not sure we need it but TypeScript types say that variableAliases?.id can be both string can VariableAlias itself 🤷‍♂️
            if (typeof variableId !== "string") {
                variableId = variableId.id;
            }

            if (!variableId) {
                console.warn("No variable id found for type", type);
                migrationStatistics.addToTechnicalError({
                    type,
                    node_id: node.id,
                    technical_error_reason: "Variable alias does not have an id",
                });
                continue;
            }

            const variableDetails = await figma.variables.getVariableByIdAsync(variableId);

            if (variableDetails === null) {
                migrationStatistics.addToTechnicalError({
                    type,
                    node_id: node.id,
                    technical_error_reason: "No variable found for id " + variableId,
                });
                console.warn("No variable details found for id", variableId, type);
                continue;
            }

            const matchedGlobalVariable = globalVariablesMapByNameAndType.get(
                `${variableDetails.name}:${variableDetails.resolvedType}`,
            );

            if (!matchedGlobalVariable) {
                console.warn(
                    "No matching global variable found for name and type",
                    variableDetails.name,
                    variableDetails.resolvedType,
                );
                migrationStatistics.addToNoMatch({
                    type,
                    node_id: node.id,
                    variable_name: variableDetails.name,
                });
                continue;
            }

            const typeWithFirstCapitalLetter = type.charAt(0).toUpperCase() + type.slice(1);

            if (variableDetails.key !== matchedGlobalVariable.key) {
                const importedGlobalVariable = await figma.variables.importVariableByKeyAsync(
                    matchedGlobalVariable.key,
                );

                if (!importedGlobalVariable) {
                    console.warn("Could not import global variable with key", matchedGlobalVariable.key);
                    migrationStatistics.addToTechnicalError({
                        type,
                        node_id: node.id,
                        technical_error_reason:
                            "Could not import global variable with key " + matchedGlobalVariable.key,
                    });
                    continue;
                }

                node.setBoundVariable(type as VariableBindableNodeField, importedGlobalVariable);

                migrationStatistics.addToMigrated({
                    type,
                    node_id: node.id,
                });
                console.log(
                    `${typeWithFirstCapitalLetter} :: Update :: From "${variableDetails.key}" to "${matchedGlobalVariable.key}"`,
                );
            } else {
                console.log(
                    `${typeWithFirstCapitalLetter} :: Skipped :: Already matching with Colors [Global] ("${variableDetails.key}" = "${matchedGlobalVariable.key}")`,
                );
                migrationStatistics.addToSkipped({
                    type,
                    node_id: node.id,
                });
            }
        }
        await new Promise((resolve) => setTimeout(resolve, 10));
    }
    return migrationStatistics;
}

async function updateNodeVariablesForType(
    paint: readonly Paint[],
    paintTypeForLogging: "Fill" | "Stroke",
    globalVariablesMapByNameAndType: Map<string, LibraryVariable>,
    migrationStatistics: MigrationStatistics,
    migrationStatisticsMetadata: UpdateNodeVariablesForTypeMigrationStatisticsMetadata,
): Promise<{
    paints: Paint[];
    updated: boolean;
}> {
    const fillsCopy = structuredClone(paint);

    const result: {
        paints: Paint[];
        updated: boolean;
    } = {
        paints: [],
        updated: false,
    };

    for (const fill of fillsCopy) {
        let newFill = fill;

        if (fill.type !== "SOLID") {
            migrationStatistics.addToUnsupported(migrationStatisticsMetadata);
            result.paints.push(fill);
            continue;
        }

        if (fill.boundVariables?.color) {
            const currentColorVariable = await figma.variables.getVariableByIdAsync(fill.boundVariables.color.id);

            if (!currentColorVariable) {
                console.warn("No current color variable found for id", fill.boundVariables.color.id);
                migrationStatistics.addToTechnicalError({
                    ...migrationStatisticsMetadata,
                    technical_error_reason: "No variable found for id " + fill.boundVariables.color.id,
                });
                result.paints.push(fill);
                continue;
            }

            const matchedGlobalVariable = globalVariablesMapByNameAndType.get(
                `${currentColorVariable.name}:${currentColorVariable.resolvedType}`,
            );

            if (!matchedGlobalVariable) {
                console.warn(
                    "No matching global variable found for name and type",
                    currentColorVariable.name,
                    currentColorVariable.resolvedType,
                );
                migrationStatistics.addToNoMatch({
                    ...migrationStatisticsMetadata,
                    variable_name: currentColorVariable.name,
                });
                result.paints.push(fill);
                continue;
            }

            const importedGlobalColorVariable = await figma.variables.importVariableByKeyAsync(
                matchedGlobalVariable.key,
            );

            if (!importedGlobalColorVariable) {
                result.paints.push(fill);
                console.warn("Could not import global color variable with key", matchedGlobalVariable.key);
                migrationStatistics.addToTechnicalError({
                    ...migrationStatisticsMetadata,
                    technical_error_reason: "Could not import global variable with key " + matchedGlobalVariable.key,
                });
                continue;
            }

            if (currentColorVariable?.key !== importedGlobalColorVariable.key) {
                newFill = figma.variables.setBoundVariableForPaint(fill, "color", importedGlobalColorVariable);
                console.log(
                    `${paintTypeForLogging} :: Update :: From "${currentColorVariable.key}" to "${importedGlobalColorVariable.key}"`,
                );
                result.updated = true;
                migrationStatistics.addToMigrated(migrationStatisticsMetadata);
            } else {
                console.log(
                    `${paintTypeForLogging} :: Skipped :: Already matching with Colors [Global] ("${currentColorVariable.key}" = "${importedGlobalColorVariable.key}")`,
                );
                migrationStatistics.addToSkipped(migrationStatisticsMetadata);
            }
            result.paints.push(newFill);
        }
    }
    return result;
}

async function loadAllGlobalVariablesMapByNameAndType(): Promise<ColorsGlobalVariablesMapByNameAndType> {
    const globalVariablesMapByNameAndType: Map<string, LibraryVariable> = new Map();

    await reportToProgressLog("Loading Colors [Global] collections.");

    const collections = await figma.teamLibrary.getAvailableLibraryVariableCollectionsAsync();

    const globalVariablesCollection = collections.find((collection) => collection.libraryName === "Colors [Global]");

    if (!globalVariablesCollection) {
        await reportToProgressLog("No Colors [Global] collection found.");
        return globalVariablesMapByNameAndType;
    }

    const globalVariables = await figma.teamLibrary.getVariablesInLibraryCollectionAsync(globalVariablesCollection.key);

    for (const variable of globalVariables) {
        globalVariablesMapByNameAndType.set(`${variable.name}:${variable.resolvedType}`, variable);
    }
    await reportToProgressLog(
        `Finished loading Colors [Global] (${globalVariablesCollection.key}) variables collection.`,
    );
    return globalVariablesMapByNameAndType;
}
