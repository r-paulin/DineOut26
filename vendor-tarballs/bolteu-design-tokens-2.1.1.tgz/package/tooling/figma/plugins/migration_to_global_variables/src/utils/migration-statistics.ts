export class MigrationStatistics {
    private total: VariableStatistic[] = [];
    private migrated: VariableStatistic[] = [];
    private no_match: VariableStatisticNoMatch[] = [];
    private skipped: VariableStatistic[] = [];
    private unsupported: VariableStatistic[] = [];
    private technical_error: VariableStatisticTechnicalError[] = [];

    addToTotal(stat: VariableStatistic) {
        this.total.push(stat);
    }

    addToMigrated(stat: VariableStatistic) {
        this.migrated.push(stat);
    }

    addToNoMatch(stat: VariableStatisticNoMatch) {
        this.no_match.push(stat);
    }

    addToSkipped(stat: VariableStatistic) {
        this.skipped.push(stat);
    }

    addToUnsupported(stat: VariableStatistic) {
        this.unsupported.push(stat);
    }

    addToTechnicalError(stat: VariableStatisticTechnicalError) {
        this.technical_error.push(stat);
    }

    getStatistics() {
        return {
            total: this.total,
            migrated: this.migrated,
            no_match: this.no_match,
            skipped: this.skipped,
            unsupported: this.unsupported,
            technical_error: this.technical_error,
        };
    }
}

export type MigrationStatisticsBindableVariableType = keyof NonNullable<SceneNode["boundVariables"]>;
type NodeId = string;

interface VariableStatistic {
    type: MigrationStatisticsBindableVariableType;
    node_id: NodeId;
}

interface VariableStatisticNoMatch extends VariableStatistic {
    variable_name: string;
}

interface VariableStatisticTechnicalError extends VariableStatistic {
    technical_error_reason: string;
}
