export class MigrationContext {
    private selectedNodes: readonly SceneNode[] = [];

    setSelectedNodes(value: readonly SceneNode[]) {
        this.selectedNodes = value;
    }

    getSelectedNodesAsFlatArray(): readonly SceneNode[] {
        const flatNodes: SceneNode[] = [];

        const traverse = (node: SceneNode) => {
            flatNodes.push(node);
            if ("children" in node) {
                for (const child of node.children) {
                    traverse(child);
                }
            }
        };

        for (const node of this.selectedNodes) {
            traverse(node);
        }

        return flatNodes;
    }
    
}