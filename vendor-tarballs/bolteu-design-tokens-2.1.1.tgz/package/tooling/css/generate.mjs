import StyleDictionary from "style-dictionary";
import {usesReferences, getReferences} from "style-dictionary/utils";
import glob from "fast-glob";
import prettier from "@prettier/sync";
import {filterSemanticColor, filterStaticColor} from "../utils/filters.mjs";

// Default set of transforms applied to get CSS
const cssTransforms = [
  "attribute/cti", // Adds CTI metadata based on token path
  "name/kebab", // kebabCases name from path
  "custom/name/prefixColorDash", // Adds color- prefix to color token names
  "custom/value/nestedRgbaForTransparency",
];

const defaultTokens = {
  light: ["src/Default/Primitives/**/*.json", "src/Default/{Semantic,Components}/**/!(dark.)*.json"],
  dark: ["src/Default/Primitives/**/*.json", "src/Default/{Semantic,Components}/**/dark.*tokens.json"],
};

const SD = new StyleDictionary({log: {verbosity: "verbose"}});
await SD.registerFormat({
  name: "css/font-rules",
  format: fontCSSFormatter,
});
await SD.hasInitialized;

/*
 * Configuration of the desired output "set"
 * {
 *   product?: "DriverApp",
 *   themes: {plus: "BoltPlus"},
 *   outputFolder: "DriverApp",
 * }
 *
 */

export async function generate(options = {}) {
  if (!options.outputFolder) throw new Error("Provide outputFolder");

  const resolvedDefaultTokens = options.defaultTokens ?? defaultTokens;

  const sources = {primitives: [], light: [], dark: []};

  if (options.product) {
    const primitiveTokenFiles = await glob(`src/Products/${options.product}/Primitives/**/*.tokens.json`);
    const otherTokenFiles = await glob(`src/Products/${options.product}/{Semantic,Components}/**/*.tokens.json`);

    sources.primitives.push(...primitiveTokenFiles);

    otherTokenFiles.forEach((file) => {
      if (file.includes("dark.")) {
        sources.dark.push(file);
      } else {
        sources.light.push(file);
      }
    });

    console.log(sources);
  }

  // Build base set, including light mode
  const cssBaseGenerator = await SD.extend({
    include: resolvedDefaultTokens.light.concat(sources.primitives),
    source: sources.light,
    platforms: {
      css: {
        transforms: cssTransforms,
        buildPath: `dist/css/${options.outputFolder}/`,
        files: [
          {
            // dimension tokens
            filter: "custom/dimensionLike",
            destination: "variables.css",
            format: "css/variables",
            options: {
              outputReferences: false,
              showFileHeader: false,
            },
          },
          /**
           * Colors from the primitive palette. This output isn't really intended to be used anywhere.
           * It's provided just in case someone needs it though.
           */
          {
            filter: "custom/primitivePaletteColor",
            destination: "colors-core.css",
            format: "css/variables",
            options: {
              selector: ":where(:root)",
              showFileHeader: false,
            },
          },
          {
            filter: (token) => token.path[0] === "map" && token.type === "color",
            destination: "colors-map-light.css",
            format: "css/variables",
            options: {
              selector: ':where(:root, [data-mode="light"])',
              showFileHeader: false,
            },
          },
          /**
           * This output includes Semantic light mode colors + static colors.
           * Static colors are included by how the source files are defined - all except files that have a "dark." prefix.
           * It should be treated as the default set of color tokens (implemented by the ":root" selector).
           */
          {
            filter: "custom/semanticColor",
            destination: "colors-light.css",
            format: "css/variables",
            options: {
              selector: ':where(:root, [data-mode="light"])',
              showFileHeader: false,
            },
          },
          {
            filter: "custom/semanticTypography",
            destination: "fonts.css",
            format: "css/font-rules",
            options: {
              outputReferences: true,
            },
          },
        ],
      },
    },
  });

  await cssBaseGenerator.cleanPlatform("css");
  await cssBaseGenerator.buildPlatform("css");

  // Build dark mode overrides
  const cssDarkModeGenerator = await SD.extend({
    include: resolvedDefaultTokens.dark.concat(sources.primitives),
    source: sources.dark,

    platforms: {
      css: {
        transforms: cssTransforms,
        buildPath: `dist/css/${options.outputFolder}/`,
        files: [
          {
            filter: (token) => token.path[0] === "map" && token.type === "color",
            destination: "colors-map-dark.css",
            format: "css/variables",
            options: {
              selector: ':where([data-mode="dark"])',
              showFileHeader: false,
            },
          },
          {
            filter: "custom/semanticColor",
            destination: "colors-dark.css",
            format: "css/variables",
            options: {
              selector: ':where([data-mode="dark"], [data-mode="dark"] ::backdrop)',
              showFileHeader: false,
            },
          },
        ],
      },
    },
  });

  await cssDarkModeGenerator.buildPlatform("css");

  if (options.themes) {
    for (const [theme, themeFolder] of Object.entries(options.themes)) {
      const themeSources = {primitives: [], light: [], dark: []};

      const primitiveTokenFiles = await glob(`src/Products/${themeFolder}/Primitives/**/*.tokens.json`);
      const otherTokenFiles = await glob(`src/Products/${themeFolder}/{Semantic,Components}/**/*.tokens.json`);

      themeSources.primitives.push(...primitiveTokenFiles);

      otherTokenFiles.forEach((file) => {
        if (file.includes("dark.")) {
          themeSources.dark.push(file);
        } else {
          themeSources.light.push(file);
        }
      });

      console.log(`Building theme: ${theme} with sources`, themeSources);

      // Build base set, including light mode
      const themeBaseSetGenerator = await SD.extend({
        include: ["src/Default/Primitives/**/*.json", ...themeSources.primitives],
        source: themeSources.light,
        platforms: {
          css: {
            transforms: cssTransforms,
            buildPath: `dist/css/${options.outputFolder}/`,
            files: [
              {
                filter: (token) => filterSemanticColor(token) && !filterStaticColor(token),
                destination: `colors-light-theme-${theme}.css`,
                format: "css/variables",
                options: {
                  selector: `:where([data-mode="light"][data-theme="${theme}"])`,
                  showFileHeader: false,
                },
              },
              {
                filter: "custom/staticColor",
                destination: `colors-static-theme-${theme}.css`,
                format: "css/variables",
                options: {
                  selector: `:where([data-theme="${theme}"])`,
                  showFileHeader: false,
                },
              },
            ],
          },
        },
      });

      await themeBaseSetGenerator.buildPlatform("css");

      // Build dark mode overrides
      const themeDarkModeGenerator = await SD.extend({
        include: ["src/Default/Primitives/**/*.json", ...primitiveTokenFiles],
        source: themeSources.dark,

        platforms: {
          css: {
            transforms: cssTransforms,
            buildPath: `dist/css/${options.outputFolder}/`,
            files: [
              {
                filter: "custom/semanticColor",
                destination: `colors-dark-theme-${theme}.css`,
                format: "css/variables",
                options: {
                  selector: `:where([data-mode="dark"][data-theme="${theme}"], [data-mode="dark"][data-theme="${theme}"] ::backdrop)`,
                  showFileHeader: false,
                },
              },
            ],
          },
        },
      });

      await themeDarkModeGenerator.buildPlatform("css");
    }
  }
}

/**
 * Formatting semantic typography tokens to CSS.
 * Filter tokens with semanticTypographyMatcher before passing to this formatter.
 *
 * @returns a string of CSS blocks, one for each semantic token
 */
function fontCSSFormatter({dictionary}) {
  return prettier.format(
    dictionary.allTokens
      .map((token) => {
        // font size and line height in rem (x/16) - assuming base font size of 16.
        const fontSize = parseInt(resolvePotentialReference(token.value.fontSize)) / 16;
        const lineHeight = parseInt(resolvePotentialReference(token.value.lineHeight)) / 16;

        // Straightforward values, add unit where necessary.
        let cssRuleString = `.font-${token.name} {
      font-family: ${resolvePotentialReference(token.value.fontFamily)}, sans-serif;
      font-weight: ${resolvePotentialReference(token.value.fontWeight)};
      font-size: ${fontSize}rem;
      line-height: ${lineHeight}rem;
      `;

        // Open Type features are expected to be given as an array of strings.
        // Turn them into a comma separated string.
        if (token.value.openType) {
          const openTypeValue = token.value.openType.map((v) => `"${v.trim()}"`).join(", ");
          cssRuleString += `font-feature-settings: ${openTypeValue};\n`;
        }

        // Letter Spacing is given as a unitless value due to Figma variables limitations.
        // It is a percentage of the font size, so we just append "em".
        // There can be a calculation (for tabular styles particulatly). For now we assume
        // that only a simple addition can exist.
        if (token.value.letterSpacing) {
          let letterSpacingValue = token.value.letterSpacing;

          // Naive check for calculation. If it contains a "+", split on them and sum the elements.
          if (letterSpacingValue.includes("+")) {
            letterSpacingValue = letterSpacingValue
              .split("+")
              .map((v) => parseFloat(v))
              .reduce((acc, curr) => acc + curr, 0)
              .toFixed(3);
          }

          cssRuleString += `letter-spacing: ${letterSpacingValue}em;\n`;
        }

        if (token.value.opticalSize) {
          cssRuleString += `font-variation-settings: "opsz" ${resolvePotentialReference(token.value.opticalSize)};\n`;
        }

        cssRuleString += `}`;
        return cssRuleString;
      })
      .join("\n"),
    {parser: "css"},
  );
}

function resolvePotentialReference(value) {
  if (usesReferences(value)) {
    const refs = getReferences(value);

    if (refs.length > 1) {
      throw new Error(`Multiple references found for ${value}, not supported yet!`);
    }

    return refs[0].value;
  }
  return value;
}
