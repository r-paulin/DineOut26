import StyleDictionary from "style-dictionary";

import {
  filterNestedRgbaStringInValue,
  filterColorType,
  filterSemanticTypography,
  filterPrimitivePaletteColor,
  filterStaticColor,
  filterSemanticColor,
  filterDimensionLike,
} from "./utils/filters.mjs";

import {transformNamePrefixColorDash, transformValueNestedRgbaForTransparency} from "./utils/transforms.mjs";

StyleDictionary.registerFilter({
  name: "custom/nestedRgbaStringInValue",
  filter: filterNestedRgbaStringInValue,
});
StyleDictionary.registerFilter({
  name: "custom/colorType",
  filter: filterColorType,
});
StyleDictionary.registerFilter({
  name: "custom/primitivePaletteColor",
  filter: filterPrimitivePaletteColor,
});
StyleDictionary.registerFilter({
  name: "custom/semanticColor",
  filter: filterSemanticColor,
});
StyleDictionary.registerFilter({
  name: "custom/staticColor",
  filter: filterStaticColor,
});
StyleDictionary.registerFilter({
  name: "custom/semanticTypography",
  filter: filterSemanticTypography,
});
StyleDictionary.registerFilter({
  name: "custom/dimensionLike",
  filter: filterDimensionLike,
});

StyleDictionary.registerTransform({
  name: "custom/name/prefixColorDash",
  type: "name",
  filter: filterColorType,
  transform: transformNamePrefixColorDash,
});

StyleDictionary.registerTransform({
  name: "custom/value/nestedRgbaForTransparency",
  type: "value",
  transitive: true,
  filter: filterNestedRgbaStringInValue,
  transform: transformValueNestedRgbaForTransparency,
});
