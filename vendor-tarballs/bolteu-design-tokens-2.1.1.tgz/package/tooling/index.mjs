import "./setupStyleDictionary.mjs";

import {generate as generateAndroid} from "./android/generate.mjs";
import {generate as generateCss} from "./css/generate.mjs";
import {generate as generateJs} from "./js/generate.mjs";

// Build Default set CSS Custom Properties, mainly for Kalep
await generateCss({
  outputFolder: "Default",
  themes: {plus: "BoltPlus", default2024: "Default-2024", ember: "Ember", driver: "DriverApp"},
});

// Build Default set JS files
await generateJs({
  outputFolder: "Default",
  themes: {plus: "BoltPlus", default2024: "Default-2024", ember: "Ember"},
});

// Build Bolt Food set JS files
await generateJs({
  outputFolder: "BoltFood",
  product: "BoltFood",
  themes: {plus: "BoltPlus"},
});

// Build Rider and Driver Android files
await generateAndroid();
