import Color from "colorjs.io";

/**
 * Converts "rgba(rgba(x,y,z,w),a)" to "rgba(x,y,z,a)"
 * This appears in core.white-transparent and core.black-transparent colors.
 *
 * @param {Object} token
 * @returns {string}
 */
export const transformValueNestedRgbaForTransparency = (token) => {
  const { value } = token;
  const [, referencedColor, desiredAlpha] = value.match(/^rgba\((.*),(.+)\)$/);

  let parsedColor = new Color(referencedColor);
  parsedColor.alpha = parseFloat(desiredAlpha);

  return parsedColor.toString({ format: "rgba_number" });
};

/**
 * Returns token name with "color-" prefix if it doesn't already have that prefix.
 * Used for CSS custom properties.
 *
 * @param {Object} token
 * @returns {string}
 */
export const transformNamePrefixColorDash = (token) => {
  if (token.name.startsWith("color-")) {
    return token.name;
  }
  return `color-${token.name}`;
};
