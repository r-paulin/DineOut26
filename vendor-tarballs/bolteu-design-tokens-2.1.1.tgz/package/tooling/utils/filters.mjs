/**
 * Returns true if token value is a string containing "rgba(rgba(".
 *
 * @param {Object} token - Style Dictionary token (object containing the key "value")
 * @returns {boolean}
 */
export function filterNestedRgbaStringInValue(token) {
  return typeof token.value === "string" && token.value.includes("rgba(rgba(");
}

/**
 * Returns true if token type is "color".
 *
 * @param {Object} token
 * @returns {boolean}
 */
export function filterColorType(token) {
  return token.type === "color";
}

/**
 * Returns true if token type is not "color".
 *
 * @param {Object} token
 * @returns {boolean}
 */
export function filterNotColorType(token) {
  return token.type !== "color";
}

/**
 * Returns true if token type is color and it's in the primitives section
 *
 * @param {Object} token
 * @returns {boolean}
 */
export function filterPrimitivePaletteColor(token) {
  if (token.filePath.includes("Primitive") && token.type === "color") {
    return true;
  }
  return false;
}

/**
 * Returns true if token type is color and it's not in the core colors section
 * (not core implies it's semantic for our purposes)
 *
 * @param {Object} token
 * @returns {boolean}
 */
export function filterSemanticColor(token) {
  if (token.filePath.includes("Primitive")) return false;

  // TODO: This is a temporary solution to skip experimental map tokens from being included in Semantic colors
  // Long term we need to decide if we want to handle namespaced token groups in some consistent way. OR alternatively
  // declare them as special with the $extensions property and base handling on this.
  if (token.path[0] === "map") return false;

  if (token.type === "color" && token.path[0] !== "core") {
    return true;
  }

  return false;
}

/**
 * Returns true if token type is typography and it's not in the core typography section
 * (not core implies it's semantic for our purposes)
 *
 * @param {Object} token
 * @returns {boolean}
 */
export function filterSemanticTypography(token) {
  if (token.type === "typography" && token.path[0] !== "core") {
    return true;
  }
  return false;
}

/**
 * Returns true if token type is color and it's in the static colors section
 *
 * @param {Object} token
 * @returns {boolean}
 */
export function filterStaticColor(token) {
  if (token.type === "color" && token.path[0] === "static") {
    return true;
  }
  return false;
}

/**
 * Returns true if token is a dimension token or based on dimension tokens
 *
 * @param {Object} token
 * @returns {boolean}
 */
export function filterDimensionLike(token) {
  const validTypes = ["dimension", "spacing", "sizing", "borderRadius"];

  if (validTypes.includes(token.type)) {
    return true;
  }
  return false;
}
