# @bolteu/design-tokens

## 2.1.1

### Patch Changes

- [#174](https://github.com/bolteu/design-tokens/pull/174) [`6510bf6`](https://github.com/bolteu/design-tokens/commit/6510bf6e066ac059a8b5419c1e7f83cf3cc6c04a) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Add map.circle.accuracy.bg-primary token. Requested here: https://taxify.slack.com/archives/CGYMJ0REG/p1760537332578669

- [#181](https://github.com/bolteu/design-tokens/pull/181) [`700508d`](https://github.com/bolteu/design-tokens/commit/700508d13cdcbd2986006e28ae76b4ad3cdbe125) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - map.circle.accuracy -> map.user-location.accuracy-circle
  add token: map.user-location.marker

- [#179](https://github.com/bolteu/design-tokens/pull/179) [`4b799c4`](https://github.com/bolteu/design-tokens/commit/4b799c44921a54878e0e3894f2300a4a5a316c1a) Thanks [@enikeevrinat](https://github.com/enikeevrinat)! - Fixed position of map.circle.accuracy in dark mode

- [#177](https://github.com/bolteu/design-tokens/pull/177) [`8c819b0`](https://github.com/bolteu/design-tokens/commit/8c819b0b7e83d459c3759de3eabede850b5c6d76) Thanks [@BenniBoltDS](https://github.com/BenniBoltDS)! - added map/journey/path/inbound/border-primary token

- [#187](https://github.com/bolteu/design-tokens/pull/187) [`6b0d5c0`](https://github.com/bolteu/design-tokens/commit/6b0d5c0d40a83411435c08746a712f3cc9216a5b) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Add _Display M Regular_ (48/60) and _Heading XS Regular_ (20/25) text styles.
  Display styles are a new group. Likely to have more styles inside in the future.

    Task is tracked in https://taxify.atlassian.net/browse/UI-953

## 2.1.0

### Minor Changes

- [#169](https://github.com/bolteu/design-tokens/pull/169) [`8e49394`](https://github.com/bolteu/design-tokens/commit/8e49394b38dd0118dae9c9380f400dff2a23f835) Thanks [@arturluik](https://github.com/arturluik)! - WAVE-143: Add bolt-driver theme for web css

## 2.0.2

### Patch Changes

- [#166](https://github.com/bolteu/design-tokens/pull/166) [`ea5f33b`](https://github.com/bolteu/design-tokens/commit/ea5f33b9d4a3bfc87fb477621db82494c7fd9707) Thanks [@arturluik](https://github.com/arturluik)! - WAVE-74: Remove bolt-plus as theme, use default colours

## 2.0.1

### Patch Changes

- [#163](https://github.com/bolteu/design-tokens/pull/163) [`6138901`](https://github.com/bolteu/design-tokens/commit/6138901caa2c8c5de185ac5c5a86cafb6fbdbffb) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Ember theme: override corner-radius from corner-radius.full onto dimension.200

- [#164](https://github.com/bolteu/design-tokens/pull/164) [`a14a907`](https://github.com/bolteu/design-tokens/commit/a14a9074014d034ebaff5d4b852b8f420f52b967) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - upd colors
  delete boltplus.bg.neutral-secondary-inverted, fix boltplus.bg.action-primary in dark mode -> green.on-dark.4

- [#158](https://github.com/bolteu/design-tokens/pull/158) [`4d0ef45`](https://github.com/bolteu/design-tokens/commit/4d0ef4518acc48052b79a6d3627145fe511058a7) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Add Ember theme to Product overrides.

## 2.0.0

### Major Changes

- [#154](https://github.com/bolteu/design-tokens/pull/154) [`a576f0f`](https://github.com/bolteu/design-tokens/commit/a576f0f626106f5c1f7ad41e4e6585b02d9b5e35) Thanks [@libahipi](https://github.com/libahipi)! - _tl;dr: Set new accessible colors as the defaults._

    The new color theme produced within the accessibility compliance efforts is now set as the Default
    and is the baseline for all further work.

    If your product still requires access to old theme - it's available under Products/Default-2024
    however it will not receive any updates. All new work is based on the new default theme.

    Migration should be zero effort - the semantic token names remain the same, only values change.

    _IF_ you leveraged the underlying primitive palette (shouldn't though) please note that it is
    completely different from old primitive palette. In structure, names and values.

    Other changes introduced in this major:

    **3 color tokens are moved out of Default:**

    - static.bg.danger-high-contrast
    - static.bg.promo-high-contrast
    - content.action-secondary-alternative

    This is considered a low risk change, the consumers have been notified and where necessary the
    tokens have been placed in Product overrides.

    **Introduction of namespace concept**

    In some cases we need tokens that are not strictly a theme, but a set for a specific need.
    For example Bolt Plus specific tokens and map specific tokens. Often these are more volatile than
    the base semantic set but should still participate in the light/dark mode system.

    To not interfere with the stability of base semantic set, they are "namespaced" - meaning that
    their token names start with for example "boltplus" or "map" to identify the specific scope.

    The namespacing concept is still early, so it might get updates in near term.

### Patch Changes

- [#151](https://github.com/bolteu/design-tokens/pull/151) [`fa7cb47`](https://github.com/bolteu/design-tokens/commit/fa7cb47dc91fb0364671331d226345fed06ed972) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - 3 colors out of Default
  static.bg.danger-high-contrast, static.bg.promo-high-contrast, content.action-secondary-alternative

- [#149](https://github.com/bolteu/design-tokens/pull/149) [`4d9af41`](https://github.com/bolteu/design-tokens/commit/4d9af414684562f6d6238afffc1923a275d57454) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Bolt Plus:

    - override on "bg.action-primary"
    - "bg.neutral-secondary-inverted"

- [#136](https://github.com/bolteu/design-tokens/pull/136) [`db936d6`](https://github.com/bolteu/design-tokens/commit/db936d6134bfe8de0d94c5a0b4074a16163e045b) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - feature: initial map specific color tokens implementation. these tokens are in their own namespace.

## 1.5.10

### Patch Changes

- [#145](https://github.com/bolteu/design-tokens/pull/145) [`6ccf404`](https://github.com/bolteu/design-tokens/commit/6ccf404354a631f2553151966fb871bba47ef294) Thanks [@libahipi](https://github.com/libahipi)! - - Just triggers a patch release to ensure updated dark mode scrim value exists for all outputs

## 1.5.9

### Patch Changes

- [#144](https://github.com/bolteu/design-tokens/pull/144) [`8ed060c`](https://github.com/bolteu/design-tokens/commit/8ed060cc297dc8e6855608f77ddb888d6248e1ed) Thanks [@libahipi](https://github.com/libahipi)! - Add BoltFood-Accessible output

- [#141](https://github.com/bolteu/design-tokens/pull/141) [`57bcbdd`](https://github.com/bolteu/design-tokens/commit/57bcbdd5c2a6fb5d9d4c8607ad69ada1711135d7) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Scrim in dark mode: 0.28 -> 0.48.
  The issue was highlighted in [this Slack message](https://taxify.slack.com/archives/C08USN99E94/p1750342172596219)

- [#144](https://github.com/bolteu/design-tokens/pull/144) [`1737414`](https://github.com/bolteu/design-tokens/commit/1737414d8784ace260129b730fefb904f4af648b) Thanks [@libahipi](https://github.com/libahipi)! - feature: allow configuring default tokens - UI-499

- [#140](https://github.com/bolteu/design-tokens/pull/140) [`4126d3b`](https://github.com/bolteu/design-tokens/commit/4126d3bb2cecaa9351cb0fb22f8301bd05858c9e) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - add bg.warning-secondary-hard to the list of Default-Accessible

## 1.5.8

### Patch Changes

- [#135](https://github.com/bolteu/design-tokens/pull/135) [`fe7be50`](https://github.com/bolteu/design-tokens/commit/fe7be501514da31026cb88cacd3c2cdb632172f6) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Add high-contrast values to align Default and Default-Accessible. Ideally, should be cleaned up.

- [#134](https://github.com/bolteu/design-tokens/pull/134) [`009de77`](https://github.com/bolteu/design-tokens/commit/009de770ff22e5a4d4a1d650bd6e7507950a88fe) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - add content.action-secondary-alternative

- [#131](https://github.com/bolteu/design-tokens/pull/131) [`5ae6af2`](https://github.com/bolteu/design-tokens/commit/5ae6af2c8be59868402bc5bc6eb439f32bc86697) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Align Default and Accessible-Default.
  Add border-active.neutral-primary to Default.

- [#137](https://github.com/bolteu/design-tokens/pull/137) [`d10de22`](https://github.com/bolteu/design-tokens/commit/d10de228a650ab694aae4cdf5be9cb02e51ac853) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - change for all content-X-secondary: values -> onto equal to bg-X-primaries

## 1.5.7

### Patch Changes

- [#128](https://github.com/bolteu/design-tokens/pull/128) [`29f3f23`](https://github.com/bolteu/design-tokens/commit/29f3f236cc1a1eb498978e8cec40744f25d148a5) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Update dark.tokens.json
  Fix content.action-primary-inverted: on-dark.11 -> on-light.11
  Thanks to @varvara.kazakova for noticing!

## 1.5.6

### Patch Changes

- [#123](https://github.com/bolteu/design-tokens/pull/123) [`94b0852`](https://github.com/bolteu/design-tokens/commit/94b08523246ff6274f292926fafeedb2c37d3787) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - update line-heights for label-300, label-700.
  label-300: 12 / 14 -> 15
  label-700: 20 / 24 -> 25

- [#116](https://github.com/bolteu/design-tokens/pull/116) [`2eea745`](https://github.com/bolteu/design-tokens/commit/2eea74522cc7055df6d7bdb9830f1c5fd7a6b191) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Core colors v2
  New core colors, good old semantics!

## 1.5.5

### Patch Changes

- [#117](https://github.com/bolteu/design-tokens/pull/117) [`a1edb6a`](https://github.com/bolteu/design-tokens/commit/a1edb6ae2b6b6aa97ae5d1e582a0498628e9cfba) Thanks [@libahipi](https://github.com/libahipi)! - Adds ability to do RC releases of design-tokens package

- [#119](https://github.com/bolteu/design-tokens/pull/119) [`293919c`](https://github.com/bolteu/design-tokens/commit/293919c54418c33eb1a4f0d20ccbc758033d0e6e) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Push special.brand-alt to the list of semantic tokens

## 1.5.4

### Patch Changes

- [#112](https://github.com/bolteu/design-tokens/pull/112) [`b72492e`](https://github.com/bolteu/design-tokens/commit/b72492ec198159bf44768b3cc2f84c9bf141053d) Thanks [@enikeevrinat](https://github.com/enikeevrinat)! - Exposed Brand Green to Functional colors to avoid using Core colors directly.

## 1.5.3

### Patch Changes

- [#110](https://github.com/bolteu/design-tokens/pull/110) [`cb3eb67`](https://github.com/bolteu/design-tokens/commit/cb3eb679ff48b53c269c5dba9607fd5812785c28) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Add brand-green:

    - rgba(42, 156, 100, 1.0)
    - HEX: #2A9C64

    to the list of core colors.

- [#107](https://github.com/bolteu/design-tokens/pull/107) [`ab4362f`](https://github.com/bolteu/design-tokens/commit/ab4362f7d7a30763ea7528e0cd68728953038cba) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - Add Heading.L.Accent to the semantic typography tokens.
  Added as part of brand refresh, designers use it when they wanna their headings to really stand out.

## 1.5.2

### Patch Changes

- [#102](https://github.com/bolteu/design-tokens/pull/102) [`f321950`](https://github.com/bolteu/design-tokens/commit/f321950fa5b7f5ae46d2139162f5302134fb8126) Thanks [@libahipi](https://github.com/libahipi)! - chore: No actual changes to tokens, testing release flow.

## 1.5.1

### Patch Changes

- [#98](https://github.com/bolteu/design-tokens/pull/98) [`edda88b`](https://github.com/bolteu/design-tokens/commit/edda88b047501d885582e2c21512999b59be9ef4) Thanks [@libahipi](https://github.com/libahipi)! - chore: no changes to design tokens, only release script updates - UI-224

## 1.5.0

### Minor Changes

- [#93](https://github.com/bolteu/design-tokens/pull/93) [`ebb59c0`](https://github.com/bolteu/design-tokens/commit/ebb59c049e7060699f56e8a42717d35848f5ddcc) Thanks [@libahipi](https://github.com/libahipi)! - Change dimension-like semantic components in CSS to be resolved values not references - UI-223

### Patch Changes

- [#91](https://github.com/bolteu/design-tokens/pull/91) [`d54c132`](https://github.com/bolteu/design-tokens/commit/d54c1328620ec8bda5bf2cc708bb27fbf98c4cf2) Thanks [@libahipi](https://github.com/libahipi)! - Enable component tokens output for CSS and JS. UI-203, UI-204

## 1.4.1

### Patch Changes

- [#85](https://github.com/bolteu/design-tokens/pull/85) [`8788cec`](https://github.com/bolteu/design-tokens/commit/8788cec89d49d9c92fe1901f6f4bdc43ff327fc0) Thanks [@libahipi](https://github.com/libahipi)! - add semantic size & layout tokens to JS output - UI-200

- [#87](https://github.com/bolteu/design-tokens/pull/87) [`960b06a`](https://github.com/bolteu/design-tokens/commit/960b06aabca2523f570dd363681c7fadcd8a32d6) Thanks [@libahipi](https://github.com/libahipi)! - fix: change comp.Button.corner-radii to comp.Button.corner-radius, for consistent naming - UI-216

- [#82](https://github.com/bolteu/design-tokens/pull/82) [`a7e2be2`](https://github.com/bolteu/design-tokens/commit/a7e2be23f753cd4fc382f3f39a9a9b37196bb057) Thanks [@libahipi](https://github.com/libahipi)! - patch: add semantic size & layout tokens to CSS output - UI-199

- [#84](https://github.com/bolteu/design-tokens/pull/84) [`172af1c`](https://github.com/bolteu/design-tokens/commit/172af1ce43a89317308945eb073f1e7157ffc7f6) Thanks [@libahipi](https://github.com/libahipi)! - fix: change size.icon t-shirt sizes to uppercase to align with other t-shirt size usages - UI-215

## 1.4.0

### Minor Changes

- Add primitive token `corner-radius.full` with a value of 600rem

- Introduce first component token - `comp.Button.corner-radii`

- Introduce primitive animation tokens

    Animation durations:
    `timing.120` - for small/quick animations
    `timing.500`

    Bezier curve definitions:
    `timing-function.simple-ease-out`
    `timing-function.emphasized-ease-in-out`

    Transitions (timing + timing-function), token value is an object defining transition settings
    `transition.change-color`
    `transition.fade`
    `transition.slide`

- Introduce semantic layout tokens (designed for mobile first)

### Patch Changes

- Update Driver separator color value for both dark and light mode

- Add primitive dimension value 75 (0.1875rem -> 3px, for default 1rem===16px)

## 1.3.1

### Patch Changes

- fix: replaces RRGGBBAA formatted bg-neutral-secondary from dark Driver colors with RGBA() formatting

    HEX color with transparency (lengths 4 or 8) apparently cause issues for parsers on native mobile platforms.
    Avoid using this format, instead use rgba(r, g, b, a)

## 1.3.0

### Minor Changes

- Ensure all semantic typography styles have the same depth level

    Heading.XS -> Heading.XS.Accent
    Heading.S -> Heading.S.Accent
    Heading.M -> Heading.M.Accent
    Caps.S -> Caps.S.Accent
    Caps.M -> Caps.M.Accent
    Caps.L -> Caps.L.Accent

    Provides consistency with Body styles and enables potential alternative styles of the same size being added in future.

### Patch Changes

- Add content-active.link-primary overrides for Driver product theme

- Add primitive dimension values 250 (0.625rem) and 350 (0.875rem)

## 1.2.0

### Minor Changes

- feature: semantic dimension tokens - icon sizes, comp-{S,M,L}-{min-height,vr-padding}

- fix: change Body L semantic font styles to have 24px line height instead of 26px

- feature: Caps semantic font styles. Caps-{S,M,L}

### Patch Changes

- fix: Optical sizes are set to maximum (32) for font-sizes 1500, 1700 & 2100

## 1.1.3

### Patch Changes

-   - Inter label & paragraph size 200 primitive typography tokens
    - BoltFood: add semantic typography token Body 2XS full set

-   - add typography sizes 1500, 1700, 2100 and letter-spacings for them
    - add Inter primitive typography tokens for sizes 1500, 1700, 2100
    - BoltFood: add semantic typography tokens Heading L, Heading XL, Heading 2XL - for web

## 1.1.2

### Patch Changes

- [#32](https://github.com/bolteu/design-tokens/pull/32) [`58edd16`](https://github.com/bolteu/design-tokens/commit/58edd16a21faae7fdb09a36c100493ffc398017d) Thanks [@libahipi](https://github.com/libahipi)! - fix: Add fallback to system default sans for semantic typography in CSS - UI-164

## 1.1.1

### Patch Changes

- [#30](https://github.com/bolteu/design-tokens/pull/30) [`f8a4fff`](https://github.com/bolteu/design-tokens/commit/f8a4fff46c034ee8a1fe106b00fd155e47cb9150) Thanks [@libahipi](https://github.com/libahipi)! - fix: change Inter font name to "InterVariable" without a space - align with official naming

## 1.1.0

### Minor Changes

- feature: semantic typography tokens - UI-163

    This version introduces typography tokens for text styles in the new font Inter, as described here: https://www.figma.com/design/utF2hTKcP1IjNgpYCXHQ2F/[Global]-Inter-Typography-(Alpha)?node-id=502-5291&t=1VN1CCFolcoOMrU1-0

    For CSS we produce rules that have the text style name as class name and convert px sizes & line-heights to rem (assuming 16px base font size).

### Patch Changes

- fix: add transparency to Driver overrides for neutral-secondary background colors

## 1.0.4

### Patch Changes

- fix: color bg.neutral-secondary overrides for Bolt Food

## 1.0.3

### Patch Changes

- chore: add repository information and module type to package.json

## 1.0.2

### Patch Changes

- feature: add JavaScript object distribution format - UI-34

## 1.0.1

### Patch Changes

- Initial NPM package release
