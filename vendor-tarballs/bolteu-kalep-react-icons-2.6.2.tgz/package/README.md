<div align="center">

# Kalep Icons React

Icons as React Components for Kalep Design System.
<br />

[Browse](https://kalep.uip.boltint.net/@bolteu/kalep-icons-svg/index.html) •
[Source](https://www.figma.com/file/Qbht5Bzpz6aLVJh1EXpaDp/UI-Foundation---Icons?node-id=9131%3A1&t=tcVkDu1F71VpnEcp-1) •
[Support](https://taxify.slack.com/archives/C034P1EFKDF)

<img width="150" src="../../assets/kalep-logo.png">
</div>

## Getting started

These are React components generated from the icons in [`kalep-icons-svg`](https://github.com/bolteu/kalep/tree/main/packages/icons) (using [SVGR](https://react-svgr.com/)).

### Installation

**npm**

```
npm install @bolteu/kalep-react-icons
```

**yarn**

```
yarn add @bolteu/kalep-react-icons
```

### Choosing icons

See our [icons demo page](https://kalep.uip.boltint.net/@bolteu/kalep-icons-svg/index.html) and [Figma source file](https://www.figma.com/file/Qbht5Bzpz6aLVJh1EXpaDp/UI-Foundation---Icons?node-id=9131%3A1&t=tcVkDu1F71VpnEcp-1) to browse and choose proper icons. Note that icons on the "Payment icons" Figma artboard are prefixed with `Payment` when imported, e.g. `PaymentMasterCard`.

## Contributing

Thank you for your desire to contribute to Kalep! Read our [Kalep Contribution Guide](https://github.com/bolteu/kalep/blob/main/CONTRIBUTING.md) for a better overview of the repository contribution process.

### Guides

#### Updating icon components

Run the following command in this folder:

```
pnpm run generate-components
```

This will find all icons from `../icons` and create React components from them.

Commit the changes to the repository and run `pnpm run build` locally as well. It'll guarantee you have the icons ready to use in local package linking.

## Figma Code Connect

This package uses a unified Figma Code Connect abstraction located in `./figma-connect.tsx`. This file automatically connects all icon components to their corresponding Figma designs.

### Adding New Icons

-   Generate new components with `pnpm generate-components` (Fetches latest icons from Figma)
-   Generate a new `src/figma-connect.tsx` file with all figma code connect relations
-   Run `figma connect publish`

PS! We can't generate permanent Figma token right now, that's why we need to do it manually
