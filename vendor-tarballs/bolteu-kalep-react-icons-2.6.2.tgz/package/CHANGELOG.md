# @bolteu/kalep-react-icons

## 2.6.2

### Patch Changes

- [#2130](https://github.com/bolteu/kalep/pull/2130) [`c99cbee`](https://github.com/bolteu/kalep/commit/c99cbeef682fe2f743315c08ebe97820c346be98) Thanks [@edvardsr](https://github.com/edvardsr)! - Add correct handling for dark icon color replacement

## 2.6.1

### Patch Changes

- [#2124](https://github.com/bolteu/kalep/pull/2124) [`5b83e32`](https://github.com/bolteu/kalep/commit/5b83e32e5ee389aea8f8dc5f75e8edf22647bd5d) Thanks [@edvardsr](https://github.com/edvardsr)! - Fixed the SearchExtra icon

## 2.6.0

### Minor Changes

- [#2123](https://github.com/bolteu/kalep/pull/2123) [`bb38023`](https://github.com/bolteu/kalep/commit/bb38023a8bac03897ef032450c57914cd24331e1) Thanks [@edvardsr](https://github.com/edvardsr)! - Updated icons, added deprecation notices to outdated icons

## 2.5.2

### Patch Changes

- [#2022](https://github.com/bolteu/kalep/pull/2022) [`a6f5575`](https://github.com/bolteu/kalep/commit/a6f557503c78bdc0a92592563ae349b7ab9f0a32) Thanks [@arturluik](https://github.com/arturluik)! - WAVE-170: Kalep to latest Eslint

## 2.5.1

### Patch Changes

- [#1957](https://github.com/bolteu/kalep/pull/1957) [`95525ea`](https://github.com/bolteu/kalep/commit/95525eae8ae528370d7e2511012160dd43da21e7) Thanks [@arturluik](https://github.com/arturluik)! - 1. Regenerate icons from Figma 2. For all icons, add figma-codeconnect integration 3. Add codeconnect sample for `<Alert />`, `<Badge />`, `<Button />`, `<Chip />`, `<ListItemLayout />`, `<Select />`, `<TextField />`, `<Typograpgy />`

## 2.5.0

### Minor Changes

- [#1902](https://github.com/bolteu/kalep/pull/1902) [`6b7fd2a`](https://github.com/bolteu/kalep/commit/6b7fd2ac3e3208b39ccde99da0a091e73f60eea5) Thanks [@artsiom-prakapovich](https://github.com/artsiom-prakapovich)! - update icons from figma

## 2.4.2

### Patch Changes

- [#1818](https://github.com/bolteu/kalep/pull/1818) [`7940f23`](https://github.com/bolteu/kalep/commit/7940f23b5ebda1e3bc41d5b4e436825b6be2a896) Thanks [@piotr-musiol](https://github.com/piotr-musiol)! - Fresh icons from Figma, added mapping for square suffix

## 2.4.1

### Patch Changes

- [#1769](https://github.com/bolteu/kalep/pull/1769) [`34b9171`](https://github.com/bolteu/kalep/commit/34b91714a7b28627c9189991ab1c51f668aaa254) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Kalep: Remove country flags.
  SILK: Add `CountryFlag` and `RegionSelector` components.

## 2.4.0

### Minor Changes

- [#1661](https://github.com/bolteu/kalep/pull/1661) [`9e84051`](https://github.com/bolteu/kalep/commit/9e84051448b37affaa84c1e39a530144aa46399f) Thanks [@libahipi](https://github.com/libahipi)! - Update icons from Figma. October 2024

  Removed icons:
  - Repeat
  - ScooterNewColoured
  - FilterAlt

  Deprecated:
  - Radar (no longer available in Figma)

  Updated icons:
  - AddAddress (color change)
  - AddressDestination (color change)
  - AddressPickup (color change)
  - ArrowRightBottom (color change)
  - ArrowRightTop (color change)
  - Delete (color change)
  - Favourite (color change)
  - MapDestination (color change)
  - MapPickup (color change)
  - PinDestination (color change)
  - SafetyColoured (color change)
  - Timer (shape changed)
  - Verified (shape & color changed)

  New icons:
  - ArrowBackward
  - ArrowBackwardUp
  - ArrowCircleBackward
  - ArrowCircleBackwardOutlined
  - ArrowCircleBackwardUp
  - ArrowCircleBackwardUpOutlined
  - ArrowCircleForward
  - ArrowForward
  - ArrowForwardDouble
  - ArrowForwardUp
  - CalendarAdd
  - CalendarAddOutlined
  - CancelPackage
  - CancelPackageOutlined
  - CaretBackward
  - CaretForward
  - ChevronBackward
  - ChevronCircleBackward
  - ChevronCircleBackwardOutlined
  - ChevronCircleForward
  - ChevronCircleForwardOutlined
  - ChevronForward
  - DeafDriver
  - SafetyCampaignColoured
  - SortingAz
  - SortingZa

  The forward/backward icons are alternative versions of left/right arrows to be used in contexts where they should change in right-to-left read scripts.

## 2.3.0

### Minor Changes

- [#1603](https://github.com/bolteu/kalep/pull/1603) [`dbf9e5f4d58f3ad678edbab1c38a309409889706`](https://github.com/bolteu/kalep/commit/dbf9e5f4d58f3ad678edbab1c38a309409889706) Thanks [@palgij](https://github.com/palgij)! - Regular icon update

  _CHANGED_: AddressInput, AddressVisited, AppearanceOutlined, Baggage, BoltPlus, BoltPlusColoured, BoltPlusOutlined, Chain, ChildBoosterAlt, ChildBoosterAltOutlined, ChildSeat, ChildSeatOutlined, Edit, GymOutlined, LogoGoggleMapsColoured, MapDestination, MapPickup, PaymentBusiness, ReorderHoriz, ReorderVert, SafetyHelmet, SafetyHelmetOutlined, ScooterColoured, ScooterPlusColoured, StarFlower

  _ADDED_: Accessibility, AccessibilityOutlined, ArrowRightBottom, ArrowRightTop, BikeCargoColoured, BikeSeatColoured, CancelBike, CancelBikeColoured, CancelCarsharing, CancelCarsharingOutlined, CancelScooterColoured, CancelScooterOutlined, CoffeeBreak, CoffeeBreakOutlined, Family, FamilyOutlined, FilterAlt, FlightLand, FlightTakeoff, GroupRideColoured, LogoAppleCalendarColoured, LogoGoogleCalendarColoured, LogoHuaweiCalendarColoured, PaymentFamily, PaymentHumo, PaymentUZcard, Veritas, Wheelchair, WheelchairOutlined

## 2.2.1

### Patch Changes

- [#1478](https://github.com/bolteu/kalep/pull/1478) [`9ae1e0df4cf8bbd728a81ca6caef9b2c0650cc30`](https://github.com/bolteu/kalep/commit/9ae1e0df4cf8bbd728a81ca6caef9b2c0650cc30) Thanks [@KoitsaluR](https://github.com/KoitsaluR)! - React 18, Storybook 8 upgrade

## 2.2.0

### Minor Changes

- [#1374](https://github.com/bolteu/kalep/pull/1374) [`3b7aeaf2`](https://github.com/bolteu/kalep/commit/3b7aeaf26388b0f915d2c37d6d9ebd316b355b18) Thanks [@piotr-musiol](https://github.com/piotr-musiol)! - Add brightness/invert/rotate icons for image manipulation

## 2.1.1

### Patch Changes

- [#1343](https://github.com/bolteu/kalep/pull/1343) [`e7cdd42b`](https://github.com/bolteu/kalep/commit/e7cdd42b0fba3a1d5025de7fe1197283d2ca87d9) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Remove NationalFlag Icon

## 2.1.0

### Minor Changes

- [#1341](https://github.com/bolteu/kalep/pull/1341) [`01a100e4`](https://github.com/bolteu/kalep/commit/01a100e40962e7a3ba14806f0f12a0ae0c9eae12) Thanks [@burakozdemir32](https://github.com/burakozdemir32)! - Add Country Flag Icons

## 2.0.0

### Major Changes

- [#1261](https://github.com/bolteu/kalep/pull/1261) [`b34cf862`](https://github.com/bolteu/kalep/commit/b34cf86226d290d8d01a2639da76837d0552132d) Thanks [@lelumees](https://github.com/lelumees)! - Kalep React icons CJS -> ESM conversion, tree-shaking support

## 1.2.1

### Patch Changes

- [#1257](https://github.com/bolteu/kalep/pull/1257) [`4c0a87e3`](https://github.com/bolteu/kalep/commit/4c0a87e3d9c2049c077bfd2ece1dc0db22de2acf) Thanks [@lelumees](https://github.com/lelumees)! - Fresh icons pulled from Figma

## 1.2.0

### Minor Changes

- [#1211](https://github.com/bolteu/kalep/pull/1211) [`600f1f94`](https://github.com/bolteu/kalep/commit/600f1f946723b073cf95a4ecbdfbb1ce9e6db747) Thanks [@CountryTk](https://github.com/CountryTk)! - feature: Add "xl" variant to icon sizes. "xl" is 36x36 (px)

## 1.1.0

### Minor Changes

- [#923](https://github.com/bolteu/kalep/pull/923) [`5c69f9b0`](https://github.com/bolteu/kalep/commit/5c69f9b05d375a30035dbf952a10b54ae67519d4) Thanks [@libahipi](https://github.com/libahipi)! - Regular icon update

  _CHANGED_:
  Alert
  AlertOutlined
  Bike
  BikeColoured
  BoltPlusColoured
  Bug
  BugOutlined
  Card
  ChildBoosterAlt
  ChildBoosterAltOutlined
  ChildSeat
  ChildSeatOutlined
  Contact
  Delete
  Favourite
  Heart
  HeartOff
  HeartOffOutlined
  HeartOutlined
  PaymentAmericanExpress
  PaymentApplePay
  PaymentDinersClub
  PaymentGooglePay
  PaymentIDeal
  PaymentJcw
  PaymentMPesa
  PaymentMasterCard
  PaymentMir
  PaymentPayPal
  PaymentUnionPay
  PaymentWallet
  PinDestination
  PinPickup
  Scooter
  ScooterOutlined
  Walk

  _ADDED_:
  Beehive
  BikePlus
  BikePlusColoured
  Bluetooth
  BluetoothOutlined
  Chain
  LogoGoogle
  PaymentAirtel
  PaymentAirteltigo
  PaymentEquitel
  PaymentMtnGhana
  PaymentMtnUganda
  PaymentVodafone
  ScooterColoured
  ScooterPlusColoured
  ScooterPlusOutlined
  SmilingFace
  SmilingFaceOutlined
  Women
  WomenOutlined

## 1.0.2

### Patch Changes

- [#555](https://github.com/bolteu/kalep/pull/555) [`6a52a40`](https://github.com/bolteu/kalep/commit/6a52a40dc0af57f4162c426bbc3fde412632f94f) Thanks [@lelumees](https://github.com/lelumees)! - Updated icon shapes

## 1.0.1

### Patch Changes

- [#533](https://github.com/bolteu/kalep/pull/533) [`5b9686e`](https://github.com/bolteu/kalep/commit/5b9686e75aadffc4a55369ea29755b0d16492927) Thanks [@lelumees](https://github.com/lelumees)! - Optimised icons - removed duplicates and reduced icons sizes

## 1.0.0

### Major Changes

- [#502](https://github.com/bolteu/kalep/pull/502) [`29a92e2`](https://github.com/bolteu/kalep/commit/29a92e2156b8ae0817dc174371e0d54d9809bbb4) Thanks [@lelumees](https://github.com/lelumees)! - Major icons update - migration to UI foundation icons

## 0.0.11

### Patch Changes

- [#400](https://github.com/bolteu/kalep/pull/400) [`bc2006c`](https://github.com/bolteu/kalep/commit/bc2006c6e322b9b25afd506d8e554b4aa7a6f2b5) Thanks [@aleksandrashulman](https://github.com/aleksandrashulman)! - New icons added

## 0.0.10

### Patch Changes

- [#264](https://github.com/bolteu/kalep/pull/264) [`37093ac`](https://github.com/bolteu/kalep/commit/37093ac76de9ada52f5c6ad7f742d0bd3a184e80) Thanks [@silviuaavram](https://github.com/silviuaavram)! - Update icon components.

## 0.0.9

### Patch Changes

- [#139](https://github.com/bolteu/kalep/pull/139) [`f76a857`](https://github.com/bolteu/kalep/commit/f76a85793e1d351852288f1cba4ef060d06a4fe2) Thanks [@libahipi](https://github.com/libahipi)! - Update icons

## 0.0.8

### Patch Changes

- [#121](https://github.com/bolteu/kalep/pull/121) [`6c04a3b`](https://github.com/bolteu/kalep/commit/6c04a3b46d4b00370d77fbbdc024162e08d12c88) Thanks [@libahipi](https://github.com/libahipi)! - update icons. add Sort icon

## 0.0.7

### Patch Changes

- [#94](https://github.com/bolteu/kalep/pull/94) [`9efb3a1`](https://github.com/bolteu/kalep/commit/9efb3a18c0192da4595373f94b6365e9066bb26f) Thanks [@libahipi](https://github.com/libahipi)! - Update icons

  Adds:
  - Expand
  - Collapse

  Updates:
  - Radar
  - Send
  - SendFilled

## 0.0.6

### Patch Changes

- [#62](https://github.com/bolteu/kalep/pull/62) [`04968d6`](https://github.com/bolteu/kalep/commit/04968d643ae89613ecc7dacf8254360d1b8e86be) Thanks [@libahipi](https://github.com/libahipi)! - Modified:
  - Clock
  - Verified

  Added:
  - Facebook
  - Instagram
  - Linkedin
  - Tiktok
  - Twitter

## 0.0.5

### Patch Changes

- [#54](https://github.com/bolteu/kalep/pull/54) [`69bc4dd`](https://github.com/bolteu/kalep/commit/69bc4dd2bd5475fdc57ebd5c8076b5ca9be4b816) Thanks [@libahipi](https://github.com/libahipi)! - add KalepReactElement type alias

## 0.0.4

### Patch Changes

- [#43](https://github.com/bolteu/kalep/pull/43) [`609d2e6`](https://github.com/bolteu/kalep/commit/609d2e610d69e5b5f6d51376c4b5eef3c6191da0) Thanks [@libahipi](https://github.com/libahipi)! - Add "size" prop for icon components

* [#40](https://github.com/bolteu/kalep/pull/40) [`4c72f19`](https://github.com/bolteu/kalep/commit/4c72f19033b804b04b82dee6fd038acec2c776a7) Thanks [@libahipi](https://github.com/libahipi)! - Add "size" prop for icon components

## 0.0.3

### Patch Changes

- [#32](https://github.com/bolteu/kalep/pull/32) [`eb67e5b`](https://github.com/bolteu/kalep/commit/eb67e5bb93d825cc51619e1ee380bef5f1ff70ca) Thanks [@libahipi](https://github.com/libahipi)! - Switch output module format to CommonJS

## 0.0.2

### Patch Changes

- [#28](https://github.com/bolteu/kalep/pull/28) [`c7b7ca3`](https://github.com/bolteu/kalep/commit/c7b7ca3f324f75cbab1d94cd8b8512286f253d7e) Thanks [@libahipi](https://github.com/libahipi)! - Adds initial set of icons
